﻿Imports MySql.Data.MySqlClient

Public Class form_biaya_penyusutan

    Private Sub form_biaya_penyusutan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ts_input_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_input.Click
        form_input_biaya_penyusutan.Show()
        form_input_biaya_penyusutan.Focus()
    End Sub

   
End Class