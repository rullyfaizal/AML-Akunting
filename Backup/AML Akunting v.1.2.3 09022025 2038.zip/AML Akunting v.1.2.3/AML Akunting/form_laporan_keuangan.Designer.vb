﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class form_laporan_keuangan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.dgv_list_masukan = New System.Windows.Forms.DataGridView()
        Me.dgv_masukan = New System.Windows.Forms.DataGridView()
        Me.dgv_list_lain2 = New System.Windows.Forms.DataGridView()
        Me.dgv_list_batubara = New System.Windows.Forms.DataGridView()
        Me.dgv_list_obat = New System.Windows.Forms.DataGridView()
        Me.dgv_list_kain = New System.Windows.Forms.DataGridView()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.dgv_keluaran = New System.Windows.Forms.DataGridView()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.dgv_spt_clone = New System.Windows.Forms.DataGridView()
        Me.dgv_spt_aml = New System.Windows.Forms.DataGridView()
        Me.dgv_spt_efaktur = New System.Windows.Forms.DataGridView()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.dgv_pln = New System.Windows.Forms.DataGridView()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.dgv_bukpot = New System.Windows.Forms.DataGridView()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.btn_generate = New System.Windows.Forms.Button()
        Me.dtp_tahun = New System.Windows.Forms.DateTimePicker()
        Me.lbl_dgv1 = New System.Windows.Forms.Label()
        Me.btn_reset = New System.Windows.Forms.Button()
        Me.dgv_list_keluaran = New System.Windows.Forms.DataGridView()
        Me.dgv_satuan_yard = New System.Windows.Forms.DataGridView()
        Me.dgv_list_keluaran_total = New System.Windows.Forms.DataGridView()
        Me.dgv_list_keluaran_kain = New System.Windows.Forms.DataGridView()
        Me.dgv_list_celup = New System.Windows.Forms.DataGridView()
        Me.dgv_keluaran_satuan = New System.Windows.Forms.DataGridView()
        Me.dgv_satuan_mtr = New System.Windows.Forms.DataGridView()
        Me.dgv_satuan_kg = New System.Windows.Forms.DataGridView()
        Me.TabControl1.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        CType(Me.dgv_list_masukan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_masukan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_list_lain2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_list_batubara, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_list_obat, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_list_kain, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage5.SuspendLayout()
        CType(Me.dgv_keluaran, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage6.SuspendLayout()
        CType(Me.dgv_spt_clone, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_spt_aml, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_spt_efaktur, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage7.SuspendLayout()
        CType(Me.dgv_pln, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage8.SuspendLayout()
        CType(Me.dgv_bukpot, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_list_keluaran, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_satuan_yard, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_list_keluaran_total, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_list_keluaran_kain, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_list_celup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_keluaran_satuan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_satuan_mtr, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_satuan_kg, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Controls.Add(Me.TabPage8)
        Me.TabControl1.Controls.Add(Me.TabPage9)
        Me.TabControl1.Location = New System.Drawing.Point(0, 29)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1130, 554)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "HPP"
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Laporan Keuangan"
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Biaya"
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage4.Controls.Add(Me.dgv_list_masukan)
        Me.TabPage4.Controls.Add(Me.dgv_masukan)
        Me.TabPage4.Controls.Add(Me.dgv_list_lain2)
        Me.TabPage4.Controls.Add(Me.dgv_list_batubara)
        Me.TabPage4.Controls.Add(Me.dgv_list_obat)
        Me.TabPage4.Controls.Add(Me.dgv_list_kain)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Masukan"
        '
        'dgv_list_masukan
        '
        Me.dgv_list_masukan.AllowUserToAddRows = False
        Me.dgv_list_masukan.AllowUserToDeleteRows = False
        Me.dgv_list_masukan.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_masukan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_list_masukan.ColumnHeadersVisible = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_masukan.DefaultCellStyle = DataGridViewCellStyle1
        Me.dgv_list_masukan.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_masukan.Location = New System.Drawing.Point(9, 339)
        Me.dgv_list_masukan.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_masukan.MultiSelect = False
        Me.dgv_list_masukan.Name = "dgv_list_masukan"
        Me.dgv_list_masukan.ReadOnly = True
        Me.dgv_list_masukan.Size = New System.Drawing.Size(690, 180)
        Me.dgv_list_masukan.TabIndex = 52
        '
        'dgv_masukan
        '
        Me.dgv_masukan.AllowUserToAddRows = False
        Me.dgv_masukan.AllowUserToDeleteRows = False
        Me.dgv_masukan.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_masukan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_masukan.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgv_masukan.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_masukan.Location = New System.Drawing.Point(9, 11)
        Me.dgv_masukan.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_masukan.MultiSelect = False
        Me.dgv_masukan.Name = "dgv_masukan"
        Me.dgv_masukan.ReadOnly = True
        Me.dgv_masukan.Size = New System.Drawing.Size(890, 320)
        Me.dgv_masukan.TabIndex = 50
        '
        'dgv_list_lain2
        '
        Me.dgv_list_lain2.AllowUserToAddRows = False
        Me.dgv_list_lain2.AllowUserToDeleteRows = False
        Me.dgv_list_lain2.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_lain2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_lain2.DefaultCellStyle = DataGridViewCellStyle3
        Me.dgv_list_lain2.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_lain2.Location = New System.Drawing.Point(622, 118)
        Me.dgv_list_lain2.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_lain2.MultiSelect = False
        Me.dgv_list_lain2.Name = "dgv_list_lain2"
        Me.dgv_list_lain2.ReadOnly = True
        Me.dgv_list_lain2.Size = New System.Drawing.Size(432, 169)
        Me.dgv_list_lain2.TabIndex = 55
        Me.dgv_list_lain2.Visible = False
        '
        'dgv_list_batubara
        '
        Me.dgv_list_batubara.AllowUserToAddRows = False
        Me.dgv_list_batubara.AllowUserToDeleteRows = False
        Me.dgv_list_batubara.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_batubara.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_batubara.DefaultCellStyle = DataGridViewCellStyle4
        Me.dgv_list_batubara.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_batubara.Location = New System.Drawing.Point(622, 194)
        Me.dgv_list_batubara.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_batubara.MultiSelect = False
        Me.dgv_list_batubara.Name = "dgv_list_batubara"
        Me.dgv_list_batubara.ReadOnly = True
        Me.dgv_list_batubara.Size = New System.Drawing.Size(432, 169)
        Me.dgv_list_batubara.TabIndex = 54
        Me.dgv_list_batubara.Visible = False
        '
        'dgv_list_obat
        '
        Me.dgv_list_obat.AllowUserToAddRows = False
        Me.dgv_list_obat.AllowUserToDeleteRows = False
        Me.dgv_list_obat.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_obat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_obat.DefaultCellStyle = DataGridViewCellStyle5
        Me.dgv_list_obat.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_obat.Location = New System.Drawing.Point(622, 278)
        Me.dgv_list_obat.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_obat.MultiSelect = False
        Me.dgv_list_obat.Name = "dgv_list_obat"
        Me.dgv_list_obat.ReadOnly = True
        Me.dgv_list_obat.Size = New System.Drawing.Size(432, 169)
        Me.dgv_list_obat.TabIndex = 53
        Me.dgv_list_obat.Visible = False
        '
        'dgv_list_kain
        '
        Me.dgv_list_kain.AllowUserToAddRows = False
        Me.dgv_list_kain.AllowUserToDeleteRows = False
        Me.dgv_list_kain.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_kain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_kain.DefaultCellStyle = DataGridViewCellStyle6
        Me.dgv_list_kain.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_kain.Location = New System.Drawing.Point(622, 352)
        Me.dgv_list_kain.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_kain.MultiSelect = False
        Me.dgv_list_kain.Name = "dgv_list_kain"
        Me.dgv_list_kain.ReadOnly = True
        Me.dgv_list_kain.Size = New System.Drawing.Size(432, 169)
        Me.dgv_list_kain.TabIndex = 51
        Me.dgv_list_kain.Visible = False
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage5.Controls.Add(Me.dgv_keluaran)
        Me.TabPage5.Controls.Add(Me.dgv_keluaran_satuan)
        Me.TabPage5.Controls.Add(Me.dgv_satuan_kg)
        Me.TabPage5.Controls.Add(Me.dgv_satuan_mtr)
        Me.TabPage5.Controls.Add(Me.dgv_list_keluaran)
        Me.TabPage5.Controls.Add(Me.dgv_satuan_yard)
        Me.TabPage5.Controls.Add(Me.dgv_list_keluaran_total)
        Me.TabPage5.Controls.Add(Me.dgv_list_keluaran_kain)
        Me.TabPage5.Controls.Add(Me.dgv_list_celup)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Keluaran"
        '
        'dgv_keluaran
        '
        Me.dgv_keluaran.AllowUserToAddRows = False
        Me.dgv_keluaran.AllowUserToDeleteRows = False
        Me.dgv_keluaran.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_keluaran.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_keluaran.DefaultCellStyle = DataGridViewCellStyle7
        Me.dgv_keluaran.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_keluaran.Location = New System.Drawing.Point(9, 9)
        Me.dgv_keluaran.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_keluaran.MultiSelect = False
        Me.dgv_keluaran.Name = "dgv_keluaran"
        Me.dgv_keluaran.ReadOnly = True
        Me.dgv_keluaran.Size = New System.Drawing.Size(1105, 320)
        Me.dgv_keluaran.TabIndex = 52
        '
        'TabPage6
        '
        Me.TabPage6.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage6.Controls.Add(Me.dgv_spt_clone)
        Me.TabPage6.Controls.Add(Me.dgv_spt_aml)
        Me.TabPage6.Controls.Add(Me.dgv_spt_efaktur)
        Me.TabPage6.Location = New System.Drawing.Point(4, 22)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "SPT Masa PPN"
        '
        'dgv_spt_clone
        '
        Me.dgv_spt_clone.AllowUserToAddRows = False
        Me.dgv_spt_clone.AllowUserToDeleteRows = False
        Me.dgv_spt_clone.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_spt_clone.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle16.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_spt_clone.DefaultCellStyle = DataGridViewCellStyle16
        Me.dgv_spt_clone.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_spt_clone.Location = New System.Drawing.Point(9, 13)
        Me.dgv_spt_clone.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_spt_clone.MultiSelect = False
        Me.dgv_spt_clone.Name = "dgv_spt_clone"
        Me.dgv_spt_clone.ReadOnly = True
        Me.dgv_spt_clone.Size = New System.Drawing.Size(1105, 250)
        Me.dgv_spt_clone.TabIndex = 52
        '
        'dgv_spt_aml
        '
        Me.dgv_spt_aml.AllowUserToAddRows = False
        Me.dgv_spt_aml.AllowUserToDeleteRows = False
        Me.dgv_spt_aml.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_spt_aml.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle17.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_spt_aml.DefaultCellStyle = DataGridViewCellStyle17
        Me.dgv_spt_aml.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_spt_aml.Location = New System.Drawing.Point(9, 271)
        Me.dgv_spt_aml.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_spt_aml.MultiSelect = False
        Me.dgv_spt_aml.Name = "dgv_spt_aml"
        Me.dgv_spt_aml.ReadOnly = True
        Me.dgv_spt_aml.Size = New System.Drawing.Size(1105, 250)
        Me.dgv_spt_aml.TabIndex = 51
        '
        'dgv_spt_efaktur
        '
        Me.dgv_spt_efaktur.AllowUserToAddRows = False
        Me.dgv_spt_efaktur.AllowUserToDeleteRows = False
        Me.dgv_spt_efaktur.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_spt_efaktur.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle18.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_spt_efaktur.DefaultCellStyle = DataGridViewCellStyle18
        Me.dgv_spt_efaktur.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_spt_efaktur.Location = New System.Drawing.Point(9, 13)
        Me.dgv_spt_efaktur.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_spt_efaktur.MultiSelect = False
        Me.dgv_spt_efaktur.Name = "dgv_spt_efaktur"
        Me.dgv_spt_efaktur.ReadOnly = True
        Me.dgv_spt_efaktur.Size = New System.Drawing.Size(1105, 250)
        Me.dgv_spt_efaktur.TabIndex = 50
        '
        'TabPage7
        '
        Me.TabPage7.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage7.Controls.Add(Me.dgv_pln)
        Me.TabPage7.Location = New System.Drawing.Point(4, 22)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "PLN Garam Coal"
        '
        'dgv_pln
        '
        Me.dgv_pln.AllowUserToAddRows = False
        Me.dgv_pln.AllowUserToDeleteRows = False
        Me.dgv_pln.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_pln.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle19.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_pln.DefaultCellStyle = DataGridViewCellStyle19
        Me.dgv_pln.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_pln.Location = New System.Drawing.Point(9, 24)
        Me.dgv_pln.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_pln.MultiSelect = False
        Me.dgv_pln.Name = "dgv_pln"
        Me.dgv_pln.ReadOnly = True
        Me.dgv_pln.Size = New System.Drawing.Size(650, 320)
        Me.dgv_pln.TabIndex = 49
        '
        'TabPage8
        '
        Me.TabPage8.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage8.Controls.Add(Me.dgv_bukpot)
        Me.TabPage8.Location = New System.Drawing.Point(4, 22)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage8.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage8.TabIndex = 7
        Me.TabPage8.Text = "Bukti Potong"
        '
        'dgv_bukpot
        '
        Me.dgv_bukpot.AllowUserToAddRows = False
        Me.dgv_bukpot.AllowUserToDeleteRows = False
        Me.dgv_bukpot.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_bukpot.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle20.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_bukpot.DefaultCellStyle = DataGridViewCellStyle20
        Me.dgv_bukpot.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_bukpot.Location = New System.Drawing.Point(9, 24)
        Me.dgv_bukpot.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_bukpot.MultiSelect = False
        Me.dgv_bukpot.Name = "dgv_bukpot"
        Me.dgv_bukpot.ReadOnly = True
        Me.dgv_bukpot.Size = New System.Drawing.Size(1105, 485)
        Me.dgv_bukpot.TabIndex = 48
        '
        'TabPage9
        '
        Me.TabPage9.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage9.Location = New System.Drawing.Point(4, 22)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage9.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage9.TabIndex = 8
        Me.TabPage9.Text = "Rincian Penyusutan"
        '
        'btn_generate
        '
        Me.btn_generate.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_generate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_generate.Location = New System.Drawing.Point(656, 4)
        Me.btn_generate.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.btn_generate.Name = "btn_generate"
        Me.btn_generate.Size = New System.Drawing.Size(93, 24)
        Me.btn_generate.TabIndex = 54
        Me.btn_generate.TabStop = False
        Me.btn_generate.Text = "GENERATE"
        Me.btn_generate.UseVisualStyleBackColor = True
        '
        'dtp_tahun
        '
        Me.dtp_tahun.CalendarFont = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtp_tahun.CustomFormat = "yyyy"
        Me.dtp_tahun.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtp_tahun.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtp_tahun.Location = New System.Drawing.Point(568, 5)
        Me.dtp_tahun.Name = "dtp_tahun"
        Me.dtp_tahun.ShowUpDown = True
        Me.dtp_tahun.Size = New System.Drawing.Size(71, 22)
        Me.dtp_tahun.TabIndex = 53
        '
        'lbl_dgv1
        '
        Me.lbl_dgv1.AutoSize = True
        Me.lbl_dgv1.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_dgv1.Location = New System.Drawing.Point(382, 9)
        Me.lbl_dgv1.Name = "lbl_dgv1"
        Me.lbl_dgv1.Size = New System.Drawing.Size(182, 14)
        Me.lbl_dgv1.TabIndex = 52
        Me.lbl_dgv1.Text = "LAPORAN KEUANGAN TAHUN"
        '
        'btn_reset
        '
        Me.btn_reset.Enabled = False
        Me.btn_reset.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_reset.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_reset.Location = New System.Drawing.Point(768, 4)
        Me.btn_reset.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.btn_reset.Name = "btn_reset"
        Me.btn_reset.Size = New System.Drawing.Size(93, 24)
        Me.btn_reset.TabIndex = 55
        Me.btn_reset.TabStop = False
        Me.btn_reset.Text = "RESET"
        Me.btn_reset.UseVisualStyleBackColor = True
        '
        'dgv_list_keluaran
        '
        Me.dgv_list_keluaran.AllowUserToAddRows = False
        Me.dgv_list_keluaran.AllowUserToDeleteRows = False
        Me.dgv_list_keluaran.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_keluaran.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_list_keluaran.ColumnHeadersVisible = False
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_keluaran.DefaultCellStyle = DataGridViewCellStyle11
        Me.dgv_list_keluaran.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_keluaran.Location = New System.Drawing.Point(9, 339)
        Me.dgv_list_keluaran.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_keluaran.MultiSelect = False
        Me.dgv_list_keluaran.Name = "dgv_list_keluaran"
        Me.dgv_list_keluaran.ReadOnly = True
        Me.dgv_list_keluaran.Size = New System.Drawing.Size(540, 180)
        Me.dgv_list_keluaran.TabIndex = 57
        '
        'dgv_satuan_yard
        '
        Me.dgv_satuan_yard.AllowUserToAddRows = False
        Me.dgv_satuan_yard.AllowUserToDeleteRows = False
        Me.dgv_satuan_yard.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_satuan_yard.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_satuan_yard.DefaultCellStyle = DataGridViewCellStyle12
        Me.dgv_satuan_yard.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_satuan_yard.Location = New System.Drawing.Point(622, 120)
        Me.dgv_satuan_yard.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_satuan_yard.MultiSelect = False
        Me.dgv_satuan_yard.Name = "dgv_satuan_yard"
        Me.dgv_satuan_yard.ReadOnly = True
        Me.dgv_satuan_yard.Size = New System.Drawing.Size(432, 169)
        Me.dgv_satuan_yard.TabIndex = 60
        Me.dgv_satuan_yard.Visible = False
        '
        'dgv_list_keluaran_total
        '
        Me.dgv_list_keluaran_total.AllowUserToAddRows = False
        Me.dgv_list_keluaran_total.AllowUserToDeleteRows = False
        Me.dgv_list_keluaran_total.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_keluaran_total.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle13.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_keluaran_total.DefaultCellStyle = DataGridViewCellStyle13
        Me.dgv_list_keluaran_total.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_keluaran_total.Location = New System.Drawing.Point(67, 162)
        Me.dgv_list_keluaran_total.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_keluaran_total.MultiSelect = False
        Me.dgv_list_keluaran_total.Name = "dgv_list_keluaran_total"
        Me.dgv_list_keluaran_total.ReadOnly = True
        Me.dgv_list_keluaran_total.Size = New System.Drawing.Size(432, 169)
        Me.dgv_list_keluaran_total.TabIndex = 59
        Me.dgv_list_keluaran_total.Visible = False
        '
        'dgv_list_keluaran_kain
        '
        Me.dgv_list_keluaran_kain.AllowUserToAddRows = False
        Me.dgv_list_keluaran_kain.AllowUserToDeleteRows = False
        Me.dgv_list_keluaran_kain.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_keluaran_kain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle14.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_keluaran_kain.DefaultCellStyle = DataGridViewCellStyle14
        Me.dgv_list_keluaran_kain.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_keluaran_kain.Location = New System.Drawing.Point(67, 246)
        Me.dgv_list_keluaran_kain.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_keluaran_kain.MultiSelect = False
        Me.dgv_list_keluaran_kain.Name = "dgv_list_keluaran_kain"
        Me.dgv_list_keluaran_kain.ReadOnly = True
        Me.dgv_list_keluaran_kain.Size = New System.Drawing.Size(432, 169)
        Me.dgv_list_keluaran_kain.TabIndex = 58
        Me.dgv_list_keluaran_kain.Visible = False
        '
        'dgv_list_celup
        '
        Me.dgv_list_celup.AllowUserToAddRows = False
        Me.dgv_list_celup.AllowUserToDeleteRows = False
        Me.dgv_list_celup.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_celup.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle15.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_celup.DefaultCellStyle = DataGridViewCellStyle15
        Me.dgv_list_celup.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_celup.Location = New System.Drawing.Point(67, 320)
        Me.dgv_list_celup.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_celup.MultiSelect = False
        Me.dgv_list_celup.Name = "dgv_list_celup"
        Me.dgv_list_celup.ReadOnly = True
        Me.dgv_list_celup.Size = New System.Drawing.Size(432, 169)
        Me.dgv_list_celup.TabIndex = 56
        Me.dgv_list_celup.Visible = False
        '
        'dgv_keluaran_satuan
        '
        Me.dgv_keluaran_satuan.AllowUserToAddRows = False
        Me.dgv_keluaran_satuan.AllowUserToDeleteRows = False
        Me.dgv_keluaran_satuan.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_keluaran_satuan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_keluaran_satuan.ColumnHeadersVisible = False
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_keluaran_satuan.DefaultCellStyle = DataGridViewCellStyle8
        Me.dgv_keluaran_satuan.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_keluaran_satuan.Location = New System.Drawing.Point(574, 339)
        Me.dgv_keluaran_satuan.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_keluaran_satuan.MultiSelect = False
        Me.dgv_keluaran_satuan.Name = "dgv_keluaran_satuan"
        Me.dgv_keluaran_satuan.ReadOnly = True
        Me.dgv_keluaran_satuan.Size = New System.Drawing.Size(540, 180)
        Me.dgv_keluaran_satuan.TabIndex = 61
        '
        'dgv_satuan_mtr
        '
        Me.dgv_satuan_mtr.AllowUserToAddRows = False
        Me.dgv_satuan_mtr.AllowUserToDeleteRows = False
        Me.dgv_satuan_mtr.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_satuan_mtr.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_satuan_mtr.DefaultCellStyle = DataGridViewCellStyle10
        Me.dgv_satuan_mtr.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_satuan_mtr.Location = New System.Drawing.Point(622, 222)
        Me.dgv_satuan_mtr.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_satuan_mtr.MultiSelect = False
        Me.dgv_satuan_mtr.Name = "dgv_satuan_mtr"
        Me.dgv_satuan_mtr.ReadOnly = True
        Me.dgv_satuan_mtr.Size = New System.Drawing.Size(432, 169)
        Me.dgv_satuan_mtr.TabIndex = 62
        Me.dgv_satuan_mtr.Visible = False
        '
        'dgv_satuan_kg
        '
        Me.dgv_satuan_kg.AllowUserToAddRows = False
        Me.dgv_satuan_kg.AllowUserToDeleteRows = False
        Me.dgv_satuan_kg.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_satuan_kg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_satuan_kg.DefaultCellStyle = DataGridViewCellStyle9
        Me.dgv_satuan_kg.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_satuan_kg.Location = New System.Drawing.Point(622, 320)
        Me.dgv_satuan_kg.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_satuan_kg.MultiSelect = False
        Me.dgv_satuan_kg.Name = "dgv_satuan_kg"
        Me.dgv_satuan_kg.ReadOnly = True
        Me.dgv_satuan_kg.Size = New System.Drawing.Size(432, 169)
        Me.dgv_satuan_kg.TabIndex = 63
        Me.dgv_satuan_kg.Visible = False
        '
        'form_laporan_keuangan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1131, 587)
        Me.Controls.Add(Me.btn_reset)
        Me.Controls.Add(Me.btn_generate)
        Me.Controls.Add(Me.dtp_tahun)
        Me.Controls.Add(Me.lbl_dgv1)
        Me.Controls.Add(Me.TabControl1)
        Me.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "form_laporan_keuangan"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        CType(Me.dgv_list_masukan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_masukan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_list_lain2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_list_batubara, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_list_obat, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_list_kain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage5.ResumeLayout(False)
        CType(Me.dgv_keluaran, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage6.ResumeLayout(False)
        CType(Me.dgv_spt_clone, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_spt_aml, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_spt_efaktur, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage7.ResumeLayout(False)
        CType(Me.dgv_pln, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage8.ResumeLayout(False)
        CType(Me.dgv_bukpot, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_list_keluaran, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_satuan_yard, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_list_keluaran_total, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_list_keluaran_kain, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_list_celup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_keluaran_satuan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_satuan_mtr, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_satuan_kg, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage8 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage9 As System.Windows.Forms.TabPage
    Friend WithEvents btn_generate As System.Windows.Forms.Button
    Friend WithEvents dtp_tahun As System.Windows.Forms.DateTimePicker
    Friend WithEvents lbl_dgv1 As System.Windows.Forms.Label
    Friend WithEvents dgv_bukpot As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_pln As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_spt_aml As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_spt_efaktur As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_spt_clone As System.Windows.Forms.DataGridView
    Friend WithEvents btn_reset As System.Windows.Forms.Button
    Friend WithEvents dgv_masukan As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_kain As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_masukan As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_obat As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_batubara As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_lain2 As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_keluaran As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_keluaran As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_satuan_yard As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_keluaran_total As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_keluaran_kain As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_celup As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_satuan_kg As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_satuan_mtr As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_keluaran_satuan As System.Windows.Forms.DataGridView
End Class
