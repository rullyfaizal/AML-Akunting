﻿Imports MySql.Data.MySqlClient
Imports OfficeOpenXml
Imports OfficeOpenXml.Style
Imports System.IO

Public Class form_laporan_keuangan

    Private Sub form_laporan_keuangan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call isi_ppn()
        TabControl1.TabPages.Remove(TabPage1)
        TabControl1.TabPages.Remove(TabPage2)

    End Sub

    Dim ppn, pph23, pph22 As Double
    Private Sub isi_ppn()
        Try
            Using conx As New MySqlConnection(sLocalConn)
                conx.Open()
                Dim sqlx = "SELECT ppn,pph23,pph22 from tbppn WHERE id ='ppn'"
                Using cmdx As New MySqlCommand(sqlx, conx)
                    Using drx As MySqlDataReader = cmdx.ExecuteReader
                        drx.Read()
                        ppn = drx(0)
                        pph23 = drx(1)
                        pph22 = drx(2)
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
    End Sub

    Private Sub btn_generate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_generate.Click
        Try
            Me.Enabled = False
            If btn_generate.Text = "GENERATE" Then
                btn_generate.Text = "EKSPOR"
                btn_reset.Enabled = True
                Call load_sheet_biaya()

                Call load_sheet_masukan()
                Call load_list_masukan_kain()
                Call load_list_masukan_obat()
                Call load_list_masukan_batubara()
                Call load_list_masukan_lain2()
                Call gabung_dgv_masukan()

                Call load_sheet_keluaran()
                Call load_list_dpp_celup()
                Call load_list_dpp_kain()
                Call load_list_dpp_total()
                Call gabung_dgv_keluaran()
                Call load_list_kg()
                Call load_list_mtr()
                Call load_list_yard()
                Call gabung_dgv_keluaran_satuan()

                Call tampil_spt()
                Call LoadDataPLN()
                Call tampil_data_bukpot()

                Call tampil_induk_penyusutan()
                Call tampil_data_penyusutan()

                dtp_tahun.Enabled = False
            Else
                Dim txtdate, txttahun As New TextBox
                Dim dtptoday As New DateTimePicker
                dtptoday.Value = DateTime.Now
                txtdate.Text = dtptoday.Value.ToString("dd-MM-yyyy HH:mm:ss")
                txttahun.Text = dtp_tahun.Value.ToString("yyyy")
                Export("D:\Ekspor\Laporan Keuangan Tahun " & txttahun.Text & " " & txtdate.Text.Replace("-", "").Replace(":", "") & ".xlsx")

            End If
            Me.Enabled = True
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub load_sheet_biaya()
        dgv_biaya.Columns.Clear()
        Dim tahun As Integer = dtp_tahun.Value.Year
        ' Deklarasi array kategori aset
        Dim kategoriAset() As String = {"BANGUNAN", "INVENTARIS", "TANKI PENGOLAH LIMBAH", "MESIN"}

        ' Pastikan DataGridView memiliki kolom yang sesuai
        Dim bulanArray() As String = {"Januari", "Februari", "Maret", "April", "Mei", "Juni",
                                      "Juli", "Agustus", "September", "Oktober", "November", "Desember"}

        ' Jika DataGridView belum memiliki kolom, tambahkan kolomnya
        If dgv_biaya.ColumnCount = 0 Then
            dgv_biaya.Columns.Add("Kategori", "")
            For Each bulan In bulanArray
                dgv_biaya.Columns.Add(bulan, bulan)
            Next
        End If

        'upah harian
        dgv_biaya.Rows.Add("", "", "", "", "", "", "", "", "", "", "", "", "")
        dgv_biaya.Rows.Add("UPAH HARIAN", "", "", "", "", "", "", "", "", "", "", "", "")

        ' Penyusutan
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            dgv_biaya.Rows.Add("", "", "", "", "", "", "", "", "", "", "", "", "")
            For Each kategori In kategoriAset
                ' Query untuk setiap kategori aset
                Dim query As String =
                    "SELECT SUM(nilai_penyusutan) AS total_penyusutan " &
                    "FROM tbdatapenyusutan " &
                    "WHERE kategori_aset = @kategori AND tahun = @tahun;"

                Using cmd As New MySqlCommand(query, conx)
                    cmd.Parameters.AddWithValue("@kategori", kategori)
                    cmd.Parameters.AddWithValue("@tahun", tahun)

                    Using reader As MySqlDataReader = cmd.ExecuteReader()
                        If reader.Read() Then
                            Dim total_penyusutan As Decimal = 0
                            If Not reader.IsDBNull(reader.GetOrdinal("total_penyusutan")) Then
                                total_penyusutan = reader.GetDecimal("total_penyusutan")
                            End If

                            ' Cek apakah baris sudah ada
                            Dim rowIndex As Integer = -1
                            For Each row As DataGridViewRow In dgv_biaya.Rows
                                If row.Cells(0).Value IsNot Nothing AndAlso row.Cells(0).Value.ToString() = "BIAYA PENYUSUTAN " & kategori Then
                                    rowIndex = row.Index
                                    Exit For
                                End If
                            Next

                            ' Jika belum ada, tambahkan baris baru
                            If rowIndex = -1 Then
                                rowIndex = dgv_biaya.Rows.Add("BIAYA PENYUSUTAN " & kategori, "", "", "", "", "", "", "", "", "", "", "", "")
                            End If

                            ' Isi nilai pada kolom Desember
                            dgv_biaya.Rows(rowIndex).Cells("Desember").Value = total_penyusutan
                        End If
                    End Using
                End Using
            Next
        End Using

        ' Listrik dll
        dgv_biaya.Rows.Add("", "", "", "", "", "", "", "", "", "", "", "", "")
        Dim daftarBiaya() As String = {
            "BIAYA LISTRIK PABRIK", "BATUBARA", "BIAYA GARAM", "BIAYA PACKING",
            "BIAYA PEMAKAIAN SPAREPART MESIN", "BIAYA PENGOLAHAN LIMBAH",
            "BIAYA PENGUJIAN DAN LEGALITAS"}

        For Each jenisBiaya In daftarBiaya
            ' Pastikan DataGridView memiliki baris kosong untuk jenis biaya ini
            Dim rowIndex As Integer = -1
            For Each row As DataGridViewRow In dgv_biaya.Rows
                If row.Cells(0).Value IsNot Nothing AndAlso row.Cells(0).Value.ToString() = jenisBiaya Then
                    rowIndex = row.Index
                    Exit For
                End If
            Next

            ' Jika belum ada, tambahkan baris baru
            If rowIndex = -1 Then
                If jenisBiaya = "BATUBARA" Then
                    rowIndex = dgv_biaya.Rows.Add("BIAYA " & jenisBiaya, "", "", "", "", "", "", "", "", "", "", "", "")
                Else
                    rowIndex = dgv_biaya.Rows.Add(jenisBiaya, "", "", "", "", "", "", "", "", "", "", "", "")
                End If
            End If

            ' Loop untuk setiap bulan dari Januari sampai Desember
            For bulan As Integer = 1 To 12
                Dim query As String =
                    "SELECT " &
                    "SUM(CASE WHEN status = 'ppn' THEN dpp ELSE 0 END) AS total_dpp, " &
                    "SUM(CASE WHEN status = 'polos' THEN total ELSE 0 END) AS total_polos " &
                    "FROM tbpembelian " &
                    "WHERE jenis_biaya = @jenisBiaya " &
                    "AND MONTH(tanggal) = @bulan " &
                    "AND YEAR(tanggal) = @tahun;"

                Using conx As New MySqlConnection(sLocalConn)
                    conx.Open()
                    Using cmd As New MySqlCommand(query, conx)
                        cmd.Parameters.AddWithValue("@jenisBiaya", jenisBiaya)
                        cmd.Parameters.AddWithValue("@bulan", bulan)
                        cmd.Parameters.AddWithValue("@tahun", tahun)

                        Using reader As MySqlDataReader = cmd.ExecuteReader()
                            If reader.Read() Then
                                Dim total_dpp As Decimal = If(Not reader.IsDBNull(reader.GetOrdinal("total_dpp")), reader.GetDecimal("total_dpp"), 0)
                                Dim total_polos As Decimal = If(Not reader.IsDBNull(reader.GetOrdinal("total_polos")), reader.GetDecimal("total_polos"), 0)
                                Dim total_biaya As Decimal = total_dpp + total_polos

                                ' Pastikan data masuk ke kolom bulan yang benar
                                Dim namaKolom As String = bulanArray(bulan - 1) ' Ambil nama bulan dari array
                                If dgv_biaya.Columns.Contains(namaKolom) Then
                                    dgv_biaya.Rows(rowIndex).Cells(namaKolom).Value = total_biaya.ToString("#,##0")
                                Else
                                    MessageBox.Show("Kolom " & namaKolom & " tidak ditemukan di DataGridView!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                End If
                            End If
                        End Using
                    End Using
                End Using
            Next
        Next

        'Biaya sewa pabrik
        dgv_biaya.Rows.Add("BIAYA SEWA PABRIK", "", "", "", "", "", "", "", "", "", "", "", "")



        ' Terapkan format untuk semua kolom bulan
        For Each bulan In bulanArray
            If dgv_biaya.Columns.Contains(bulan) Then
                dgv_biaya.Columns(bulan).DefaultCellStyle.Format = "#,##0"
                dgv_biaya.Columns(bulan).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            End If
        Next

        dgv_biaya.Columns(0).Width = 300
    End Sub
    

    Private Sub load_sheet_masukan()
        dgv_masukan.Columns.Clear()
        Call setup_dgv_masukan()
        Dim tahun As Integer = dtp_tahun.Value.Year ' Ambil tahun dari DateTimePicker
        ' Query untuk Kain
        Dim query_kain As String =
            "SELECT MONTH(tanggal) AS bulan, SUM(total_dpp) AS total_kain " &
            "FROM tbindukpembelian " &
            "WHERE (jenis_biaya = 'GREY' OR jenis_biaya = 'RETUR') AND YEAR(tanggal) = @tahun AND total_dpp <> 0 " &
            "GROUP BY MONTH(tanggal) ORDER BY MONTH(tanggal);"
        ' Query untuk Obat
        Dim query_obat As String =
            "SELECT MONTH(tanggal) AS bulan, SUM(total_dpp) AS total_obat " &
            "FROM tbindukpembelian " &
            "WHERE jenis_biaya = 'OBAT' AND YEAR(tanggal) = @tahun AND total_dpp <> 0 " &
            "GROUP BY MONTH(tanggal) ORDER BY MONTH(tanggal);"
        ' Query untuk Batubara
        Dim query_batubara As String =
            "SELECT MONTH(tanggal) AS bulan, SUM(total_dpp) AS total_batubara " &
            "FROM tbindukpembelian " &
            "WHERE jenis_biaya = 'BATUBARA' AND YEAR(tanggal) = @tahun AND total_dpp <> 0 " &
            "GROUP BY MONTH(tanggal) ORDER BY MONTH(tanggal);"
        ' Query untuk Lain2
        Dim query_lain2 As String =
            "SELECT MONTH(tanggal) AS bulan, SUM(total_dpp) AS total_lain2 " &
            "FROM tbindukpembelian " &
            "WHERE jenis_biaya NOT IN ('GREY', 'RETUR', 'OBAT', 'BATUBARA') AND YEAR(tanggal) = @tahun AND total_dpp <> 0 " &
            "GROUP BY MONTH(tanggal) ORDER BY MONTH(tanggal);"
        ' Kosongkan semua kolom sebelum diisi ulang
        For Each row As DataGridViewRow In dgv_masukan.Rows
            row.Cells("DPP MASUKAN KAIN").Value = 0
            row.Cells("DPP MASUKAN OBAT").Value = 0
            row.Cells("DPP MASUKAN BATUBARA").Value = 0
            row.Cells("DPP MASUKAN LAIN2").Value = 0
            row.Cells("TOTAL DPP MASUKAN").Value = 0
        Next
        ' Proses Masukan
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Using cmd As New MySqlCommand(query_kain, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim bulan As Integer = reader.GetInt32("bulan")
                        Dim total_masukan As Decimal = reader.GetDecimal("total_kain")
                        If bulan >= 1 And bulan <= 12 Then
                            dgv_masukan.Rows(bulan - 1).Cells("DPP MASUKAN KAIN").Value = total_masukan
                        End If
                    End While
                End Using
            End Using
            Using cmd As New MySqlCommand(query_obat, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim bulan As Integer = reader.GetInt32("bulan")
                        Dim total_masukan As Decimal = reader.GetDecimal("total_obat")
                        If bulan >= 1 And bulan <= 12 Then
                            dgv_masukan.Rows(bulan - 1).Cells("DPP MASUKAN OBAT").Value = total_masukan
                        End If
                    End While
                End Using
            End Using
            Using cmd As New MySqlCommand(query_batubara, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim bulan As Integer = reader.GetInt32("bulan")
                        Dim total_masukan As Decimal = reader.GetDecimal("total_batubara")
                        If bulan >= 1 And bulan <= 12 Then
                            dgv_masukan.Rows(bulan - 1).Cells("DPP MASUKAN BATUBARA").Value = total_masukan
                        End If
                    End While
                End Using
            End Using
            Using cmd As New MySqlCommand(query_lain2, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim bulan As Integer = reader.GetInt32("bulan")
                        Dim total_masukan As Decimal = reader.GetDecimal("total_lain2")
                        If bulan >= 1 And bulan <= 12 Then
                            dgv_masukan.Rows(bulan - 1).Cells("DPP MASUKAN LAIN2").Value = total_masukan
                        End If
                    End While
                End Using
            End Using
        End Using
        ' Pastikan dgv_masukan sudah memiliki data sebelum menjalankan kode ini
        Dim totalDPPKain As Decimal = 0
        Dim totalDPPObat As Decimal = 0
        Dim totalDPPBatubara As Decimal = 0
        Dim totalDPPLain2 As Decimal = 0
        Dim totalDPPMasukan As Decimal = 0
        For Each row As DataGridViewRow In dgv_masukan.Rows
            If Not row.IsNewRow Then
                ' Ambil nilai dari masing-masing kolom
                Dim dppKain As Decimal = Convert.ToDecimal(row.Cells("DPP MASUKAN KAIN").Value)
                Dim dppObat As Decimal = Convert.ToDecimal(row.Cells("DPP MASUKAN OBAT").Value)
                Dim dppBatubara As Decimal = Convert.ToDecimal(row.Cells("DPP MASUKAN BATUBARA").Value)
                Dim dppLain2 As Decimal = Convert.ToDecimal(row.Cells("DPP MASUKAN LAIN2").Value)
                ' Hitung TOTAL DPP MASUKAN
                Dim total As Decimal = dppKain + dppObat + dppBatubara + dppLain2
                row.Cells("TOTAL DPP MASUKAN").Value = total
                ' Akumulasi untuk baris total
                totalDPPKain += dppKain
                totalDPPObat += dppObat
                totalDPPBatubara += dppBatubara
                totalDPPLain2 += dppLain2
                totalDPPMasukan += total
            End If
        Next
        ' Tambahkan baris total ke dgv_masukan
        Dim index As Integer = dgv_masukan.Rows.Add()
        With dgv_masukan.Rows(index)
            .Cells(0).Value = "" ' Kolom pertama sebagai label
            .Cells("DPP MASUKAN KAIN").Value = totalDPPKain
            .Cells("DPP MASUKAN OBAT").Value = totalDPPObat
            .Cells("DPP MASUKAN BATUBARA").Value = totalDPPBatubara
            .Cells("DPP MASUKAN LAIN2").Value = totalDPPLain2
            .Cells("TOTAL DPP MASUKAN").Value = totalDPPMasukan
        End With
        For Each col As DataGridViewColumn In dgv_masukan.Columns
            col.SortMode = DataGridViewColumnSortMode.NotSortable
        Next
    End Sub
    Private Sub setup_dgv_masukan()
        dgv_masukan.ColumnCount = 6
        dgv_masukan.Columns(0).Name = ""
        dgv_masukan.Columns(1).Name = "DPP MASUKAN KAIN"
        dgv_masukan.Columns(2).Name = "DPP MASUKAN OBAT"
        dgv_masukan.Columns(3).Name = "DPP MASUKAN BATUBARA"
        dgv_masukan.Columns(4).Name = "DPP MASUKAN LAIN2"
        dgv_masukan.Columns(5).Name = "TOTAL DPP MASUKAN"

        Dim bulanArray As String() = {"JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"}
        For Each bulan As String In bulanArray
            dgv_masukan.Rows.Add(bulan, 0, 0, 0, 0, 0)
        Next
        dgv_masukan.Columns(1).Width = 140
        dgv_masukan.Columns(2).Width = 140
        dgv_masukan.Columns(3).Width = 170
        dgv_masukan.Columns(4).Width = 140
        dgv_masukan.Columns(5).Width = 140
        dgv_masukan.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_masukan.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_masukan.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_masukan.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_masukan.Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_masukan.Columns(1).DefaultCellStyle.Format = "#,##0.00"
        dgv_masukan.Columns(2).DefaultCellStyle.Format = "#,##0.00"
        dgv_masukan.Columns(3).DefaultCellStyle.Format = "#,##0.00"
        dgv_masukan.Columns(4).DefaultCellStyle.Format = "#,##0.00"
        dgv_masukan.Columns(5).DefaultCellStyle.Format = "#,##0.00"
    End Sub

    Private Sub load_list_masukan_kain()
        dgv_list_kain.Columns.Clear()

        ' Ambil tahun dari DateTimePicker
        Dim tahun As Integer = dtp_tahun.Value.Year
        ' Query untuk Kain pembelian
        Dim query_kain_pembelian As String =
                "SELECT supplier, SUM(total_dpp) AS total_dpp " &
                "FROM tbindukpembelian " &
                "WHERE (jenis_biaya = 'GREY' OR jenis_biaya = 'RETUR') AND YEAR(tanggal) = @tahun AND total_dpp <> 0 " &
                "GROUP BY supplier ORDER BY MONTH(tanggal);"
        ' Query untuk Kain pembelian belum upload
        Dim query_kain_belum_upload As String =
                "SELECT supplier, SUM(total_dpp) AS belum_upload, SUM(total_ppn) AS ppn " &
                "FROM tbindukpembelian " &
                "WHERE (jenis_biaya = 'GREY' OR jenis_biaya = 'RETUR') AND YEAR(tanggal) = @tahun AND tanggal_upload IS NULL AND total_dpp <> 0 " &
                "GROUP BY supplier ORDER BY MONTH(tanggal);"
        ' DataTable untuk menyimpan hasil query pertama
        Dim dt As New DataTable()
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            ' Eksekusi query pertama
            Using cmd As New MySqlCommand(query_kain_pembelian, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using adapter As New MySqlDataAdapter(cmd)
                    adapter.Fill(dt)
                End Using
            End Using
            ' Tambahkan kolom untuk data belum upload dan PPN ke DataTable
            dt.Columns.Add("BELUM DIUPLOAD", GetType(Decimal))
            dt.Columns.Add("PPN", GetType(Decimal))
            ' Eksekusi query kedua dan update DataTable yang sudah ada
            Using cmd As New MySqlCommand(query_kain_belum_upload, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim supplier As String = reader("supplier").ToString()
                        Dim belumUpload As Decimal = If(IsDBNull(reader("belum_upload")), 0, Convert.ToDecimal(reader("belum_upload")))
                        Dim ppn As Decimal = If(IsDBNull(reader("ppn")), 0, Convert.ToDecimal(reader("ppn")))

                        ' Temukan baris yang sesuai di DataTable
                        For Each row As DataRow In dt.Rows
                            If row("supplier").ToString() = supplier Then
                                row("BELUM DIUPLOAD") = belumUpload
                                row("PPN") = ppn
                                Exit For
                            End If
                        Next
                    End While
                End Using
            End Using
            ' Tampilkan data di DataGridView
            dgv_list_kain.DataSource = dt
            ' Pastikan dgv_masukan sudah memiliki data sebelum menjalankan kode ini
            Dim totalDPP As Decimal = 0
            Dim totalbelumupload As Decimal = 0
            Dim totalppn As Decimal = 0
            For Each row As DataGridViewRow In dgv_list_kain.Rows
                If Not row.IsNewRow Then
                    ' Ambil nilai dari masing-masing kolom
                    'Dim dppKain As Decimal = Convert.ToDecimal(row.Cells(1).Value)
                    'Dim belumupload As Decimal = Convert.ToDecimal(row.Cells(2).Value)
                    'Dim ppnkain As Decimal = Convert.ToDecimal(row.Cells(3).Value)
                    Dim dppKain As Decimal = If(IsDBNull(row.Cells(1).Value), 0, Convert.ToDecimal(row.Cells(1).Value))
                    Dim belumUpload As Decimal = If(IsDBNull(row.Cells(2).Value), 0, Convert.ToDecimal(row.Cells(2).Value))
                    Dim ppnkain As Decimal = If(IsDBNull(row.Cells(3).Value), 0, Convert.ToDecimal(row.Cells(3).Value))

                    ' Akumulasi untuk baris total
                    totalDPP += dppKain
                    totalbelumupload += belumUpload
                    totalppn += ppnkain
                End If
            Next

            Dim baris As DataRow = dt.NewRow()
            baris(0) = "" ' Kolom pertama sebagai label
            baris(1) = totalDPP
            baris(2) = totalbelumupload
            baris(3) = totalppn
            dt.Rows.Add(baris)

            Call setup_dgv_list_masukan()
            For Each col As DataGridViewColumn In dgv_list_kain.Columns
                col.SortMode = DataGridViewColumnSortMode.NotSortable
            Next
        End Using

    End Sub
    Private Sub load_list_masukan_obat()
        dgv_list_obat.Columns.Clear()

        ' Ambil tahun dari DateTimePicker
        Dim tahun As Integer = dtp_tahun.Value.Year
        ' Query untuk Kain pembelian
        Dim query_kain_pembelian As String =
                "SELECT supplier, SUM(total_dpp) AS total_dpp " &
                "FROM tbindukpembelian " &
                "WHERE jenis_biaya = 'OBAT' AND YEAR(tanggal) = @tahun AND total_dpp <> 0 " &
                "GROUP BY supplier ORDER BY MONTH(tanggal);"
        ' Query untuk Kain pembelian belum upload
        Dim query_kain_belum_upload As String =
                "SELECT supplier, SUM(total_dpp) AS belum_upload, SUM(total_ppn) AS ppn " &
                "FROM tbindukpembelian " &
                "WHERE jenis_biaya = 'OBAT' AND YEAR(tanggal) = @tahun AND tanggal_upload IS NULL AND total_dpp <> 0 " &
                "GROUP BY supplier ORDER BY MONTH(tanggal);"
        ' DataTable untuk menyimpan hasil query pertama
        Dim dt As New DataTable()
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            ' Eksekusi query pertama
            Using cmd As New MySqlCommand(query_kain_pembelian, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using adapter As New MySqlDataAdapter(cmd)
                    adapter.Fill(dt)
                End Using
            End Using
            ' Tambahkan kolom untuk data belum upload dan PPN ke DataTable
            dt.Columns.Add("BELUM DIUPLOAD", GetType(Decimal))
            dt.Columns.Add("PPN", GetType(Decimal))
            ' Eksekusi query kedua dan update DataTable yang sudah ada
            Using cmd As New MySqlCommand(query_kain_belum_upload, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim supplier As String = reader("supplier").ToString()
                        Dim belumUpload As Decimal = If(IsDBNull(reader("belum_upload")), 0, Convert.ToDecimal(reader("belum_upload")))
                        Dim ppn As Decimal = If(IsDBNull(reader("ppn")), 0, Convert.ToDecimal(reader("ppn")))

                        ' Temukan baris yang sesuai di DataTable
                        For Each row As DataRow In dt.Rows
                            If row("supplier").ToString() = supplier Then
                                row("BELUM DIUPLOAD") = belumUpload
                                row("PPN") = ppn
                                Exit For
                            End If
                        Next
                    End While
                End Using
            End Using
            ' Tampilkan data di DataGridView
            dgv_list_obat.DataSource = dt
            ' Pastikan dgv_masukan sudah memiliki data sebelum menjalankan kode ini
            Dim totalDPP As Decimal = 0
            Dim totalbelumupload As Decimal = 0
            Dim totalppn As Decimal = 0
            For Each row As DataGridViewRow In dgv_list_obat.Rows
                If Not row.IsNewRow Then
                    ' Ambil nilai dari masing-masing kolom
                    'Dim dppKain As Decimal = Convert.ToDecimal(row.Cells(1).Value)
                    'Dim belumupload As Decimal = Convert.ToDecimal(row.Cells(2).Value)
                    'Dim ppnkain As Decimal = Convert.ToDecimal(row.Cells(3).Value)
                    Dim dppKain As Decimal = If(IsDBNull(row.Cells(1).Value), 0, Convert.ToDecimal(row.Cells(1).Value))
                    Dim belumUpload As Decimal = If(IsDBNull(row.Cells(2).Value), 0, Convert.ToDecimal(row.Cells(2).Value))
                    Dim ppnkain As Decimal = If(IsDBNull(row.Cells(3).Value), 0, Convert.ToDecimal(row.Cells(3).Value))

                    ' Akumulasi untuk baris total
                    totalDPP += dppKain
                    totalbelumupload += belumUpload
                    totalppn += ppnkain
                End If
            Next

            Dim baris As DataRow = dt.NewRow()
            baris(0) = "" ' Kolom pertama sebagai label
            baris(1) = totalDPP
            baris(2) = totalbelumupload
            baris(3) = totalppn
            dt.Rows.Add(baris)

            'Call setup_dgv_list_masukan()
            For Each col As DataGridViewColumn In dgv_list_obat.Columns
                col.SortMode = DataGridViewColumnSortMode.NotSortable
            Next
        End Using

    End Sub
    Private Sub load_list_masukan_batubara()
        dgv_list_batubara.Columns.Clear()

        ' Ambil tahun dari DateTimePicker
        Dim tahun As Integer = dtp_tahun.Value.Year
        ' Query untuk Kain pembelian
        Dim query_kain_pembelian As String =
                "SELECT supplier, SUM(total_dpp) AS total_dpp " &
                "FROM tbindukpembelian " &
                "WHERE jenis_biaya = 'BATUBARA' AND YEAR(tanggal) = @tahun AND total_dpp <> 0 " &
                "GROUP BY supplier ORDER BY MONTH(tanggal);"
        ' Query untuk Kain pembelian belum upload
        Dim query_kain_belum_upload As String =
                "SELECT supplier, SUM(total_dpp) AS belum_upload, SUM(total_ppn) AS ppn " &
                "FROM tbindukpembelian " &
                "WHERE jenis_biaya = 'BATUBARA' AND YEAR(tanggal) = @tahun AND tanggal_upload IS NULL AND total_dpp <> 0 " &
                "GROUP BY supplier ORDER BY MONTH(tanggal);"
        ' DataTable untuk menyimpan hasil query pertama
        Dim dt As New DataTable()
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            ' Eksekusi query pertama
            Using cmd As New MySqlCommand(query_kain_pembelian, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using adapter As New MySqlDataAdapter(cmd)
                    adapter.Fill(dt)
                End Using
            End Using
            ' Tambahkan kolom untuk data belum upload dan PPN ke DataTable
            dt.Columns.Add("BELUM DIUPLOAD", GetType(Decimal))
            dt.Columns.Add("PPN", GetType(Decimal))
            ' Eksekusi query kedua dan update DataTable yang sudah ada
            Using cmd As New MySqlCommand(query_kain_belum_upload, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim supplier As String = reader("supplier").ToString()
                        Dim belumUpload As Decimal = If(IsDBNull(reader("belum_upload")), 0, Convert.ToDecimal(reader("belum_upload")))
                        Dim ppn As Decimal = If(IsDBNull(reader("ppn")), 0, Convert.ToDecimal(reader("ppn")))

                        ' Temukan baris yang sesuai di DataTable
                        For Each row As DataRow In dt.Rows
                            If row("supplier").ToString() = supplier Then
                                row("BELUM DIUPLOAD") = belumUpload
                                row("PPN") = ppn
                                Exit For
                            End If
                        Next
                    End While
                End Using
            End Using
            ' Tampilkan data di DataGridView
            dgv_list_batubara.DataSource = dt
            ' Pastikan dgv_masukan sudah memiliki data sebelum menjalankan kode ini
            Dim totalDPP As Decimal = 0
            Dim totalbelumupload As Decimal = 0
            Dim totalppn As Decimal = 0
            For Each row As DataGridViewRow In dgv_list_batubara.Rows
                If Not row.IsNewRow Then
                    ' Ambil nilai dari masing-masing kolom
                    'Dim dppKain As Decimal = Convert.ToDecimal(row.Cells(1).Value)
                    'Dim belumupload As Decimal = Convert.ToDecimal(row.Cells(2).Value)
                    'Dim ppnkain As Decimal = Convert.ToDecimal(row.Cells(3).Value)
                    Dim dppKain As Decimal = If(IsDBNull(row.Cells(1).Value), 0, Convert.ToDecimal(row.Cells(1).Value))
                    Dim belumUpload As Decimal = If(IsDBNull(row.Cells(2).Value), 0, Convert.ToDecimal(row.Cells(2).Value))
                    Dim ppnkain As Decimal = If(IsDBNull(row.Cells(3).Value), 0, Convert.ToDecimal(row.Cells(3).Value))

                    ' Akumulasi untuk baris total
                    totalDPP += dppKain
                    totalbelumupload += belumUpload
                    totalppn += ppnkain
                End If
            Next

            Dim baris As DataRow = dt.NewRow()
            baris(0) = "" ' Kolom pertama sebagai label
            baris(1) = totalDPP
            baris(2) = totalbelumupload
            baris(3) = totalppn
            dt.Rows.Add(baris)

            'Call setup_dgv_list_masukan()
            For Each col As DataGridViewColumn In dgv_list_batubara.Columns
                col.SortMode = DataGridViewColumnSortMode.NotSortable
            Next
        End Using

    End Sub
    Private Sub load_list_masukan_lain2()
        dgv_list_lain2.Columns.Clear()

        ' Ambil tahun dari DateTimePicker
        Dim tahun As Integer = dtp_tahun.Value.Year
        ' Query untuk Kain pembelian
        Dim query_kain_pembelian As String =
                "SELECT supplier, SUM(total_dpp) AS total_dpp " &
                "FROM tbindukpembelian " &
                "WHERE jenis_biaya NOT IN ('GREY', 'RETUR', 'OBAT', 'BATUBARA') AND YEAR(tanggal) = @tahun AND total_dpp <> 0 " &
                "GROUP BY supplier ORDER BY MONTH(tanggal);"
        ' Query untuk Kain pembelian belum upload
        Dim query_kain_belum_upload As String =
                "SELECT supplier, SUM(total_dpp) AS belum_upload, SUM(total_ppn) AS ppn " &
                "FROM tbindukpembelian " &
                "WHERE jenis_biaya NOT IN ('GREY', 'RETUR', 'OBAT', 'BATUBARA') AND YEAR(tanggal) = @tahun AND tanggal_upload IS NULL AND total_dpp <> 0 " &
                "GROUP BY supplier ORDER BY MONTH(tanggal);"
        ' DataTable untuk menyimpan hasil query pertama
        Dim dt As New DataTable()
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            ' Eksekusi query pertama
            Using cmd As New MySqlCommand(query_kain_pembelian, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using adapter As New MySqlDataAdapter(cmd)
                    adapter.Fill(dt)
                End Using
            End Using
            ' Tambahkan kolom untuk data belum upload dan PPN ke DataTable
            dt.Columns.Add("BELUM DIUPLOAD", GetType(Decimal))
            dt.Columns.Add("PPN", GetType(Decimal))
            ' Eksekusi query kedua dan update DataTable yang sudah ada
            Using cmd As New MySqlCommand(query_kain_belum_upload, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim supplier As String = reader("supplier").ToString()
                        Dim belumUpload As Decimal = If(IsDBNull(reader("belum_upload")), 0, Convert.ToDecimal(reader("belum_upload")))
                        Dim ppn As Decimal = If(IsDBNull(reader("ppn")), 0, Convert.ToDecimal(reader("ppn")))

                        ' Temukan baris yang sesuai di DataTable
                        For Each row As DataRow In dt.Rows
                            If row("supplier").ToString() = supplier Then
                                row("BELUM DIUPLOAD") = belumUpload
                                row("PPN") = ppn
                                Exit For
                            End If
                        Next
                    End While
                End Using
            End Using
            ' Tampilkan data di DataGridView
            dgv_list_lain2.DataSource = dt
            ' Pastikan dgv_masukan sudah memiliki data sebelum menjalankan kode ini
            Dim totalDPP As Decimal = 0
            Dim totalbelumupload As Decimal = 0
            Dim totalppn As Decimal = 0
            For Each row As DataGridViewRow In dgv_list_lain2.Rows
                If Not row.IsNewRow Then
                    ' Ambil nilai dari masing-masing kolom
                    'Dim dppKain As Decimal = Convert.ToDecimal(row.Cells(1).Value)
                    'Dim belumupload As Decimal = Convert.ToDecimal(row.Cells(2).Value)
                    'Dim ppnkain As Decimal = Convert.ToDecimal(row.Cells(3).Value)
                    Dim dppKain As Decimal = If(IsDBNull(row.Cells(1).Value), 0, Convert.ToDecimal(row.Cells(1).Value))
                    Dim belumUpload As Decimal = If(IsDBNull(row.Cells(2).Value), 0, Convert.ToDecimal(row.Cells(2).Value))
                    Dim ppnkain As Decimal = If(IsDBNull(row.Cells(3).Value), 0, Convert.ToDecimal(row.Cells(3).Value))

                    ' Akumulasi untuk baris total
                    totalDPP += dppKain
                    totalbelumupload += belumUpload
                    totalppn += ppnkain
                End If
            Next

            Dim baris As DataRow = dt.NewRow()
            baris(0) = "" ' Kolom pertama sebagai label
            baris(1) = totalDPP
            baris(2) = totalbelumupload
            baris(3) = totalppn
            dt.Rows.Add(baris)

            'Call setup_dgv_list_masukan()
            For Each col As DataGridViewColumn In dgv_list_lain2.Columns
                col.SortMode = DataGridViewColumnSortMode.NotSortable
            Next
        End Using

    End Sub
    Private Sub gabung_dgv_masukan()
        ' Pastikan dgv_list_masukan kosong sebelum menambahkan data
        dgv_list_masukan.Rows.Clear()
        dgv_list_masukan.Columns.Clear()

        ' Salin struktur kolom dari dgv_list_kain ke dgv_list_masukan
        For Each col As DataGridViewColumn In dgv_list_kain.Columns
            dgv_list_masukan.Columns.Add(DirectCast(col.Clone(), DataGridViewColumn))
        Next

        Dim emptyRowIndexKain As Integer = dgv_list_masukan.Rows.Add()
        dgv_list_masukan.Rows(emptyRowIndexKain).Cells(0).Value = "DATA MASUKAN KAIN" ' Contoh isi kolom pertama
        dgv_list_masukan.Rows(emptyRowIndexKain).Cells(1).Value = "TOTAL DPP" ' Kosongkan kolom lainnya
        dgv_list_masukan.Rows(emptyRowIndexKain).Cells(2).Value = "BELUM UPLOAD"
        dgv_list_masukan.Rows(emptyRowIndexKain).Cells(3).Value = "PPN"
        dgv_list_masukan.Rows(emptyRowIndexKain).Cells(0).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_list_masukan.Rows(emptyRowIndexKain).Cells(1).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_list_masukan.Rows(emptyRowIndexKain).Cells(2).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_list_masukan.Rows(emptyRowIndexKain).Cells(3).Style.Alignment = DataGridViewContentAlignment.MiddleCenter

        ' Salin data dari dgv_list_kain ke dgv_list_masukan
        For Each row As DataGridViewRow In dgv_list_kain.Rows
            If Not row.IsNewRow Then
                Dim newRow As DataGridViewRow = DirectCast(row.Clone(), DataGridViewRow)
                For i As Integer = 0 To row.Cells.Count - 1
                    newRow.Cells(i).Value = row.Cells(i).Value
                Next
                dgv_list_masukan.Rows.Add(newRow)
            End If
        Next

        ' Tambahkan 2 baris kosong sebagai pemisah
        dgv_list_masukan.Rows.Add()
        Dim emptyRowIndexObat As Integer = dgv_list_masukan.Rows.Add()
        dgv_list_masukan.Rows(emptyRowIndexObat).Cells(0).Value = "DATA MASUKAN KIMIA" ' Contoh isi kolom pertama
        dgv_list_masukan.Rows(emptyRowIndexObat).Cells(1).Value = "TOTAL DPP" ' Kosongkan kolom lainnya
        dgv_list_masukan.Rows(emptyRowIndexObat).Cells(2).Value = "BELUM UPLOAD"
        dgv_list_masukan.Rows(emptyRowIndexObat).Cells(3).Value = "PPN"
        dgv_list_masukan.Rows(emptyRowIndexObat).Cells(0).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_list_masukan.Rows(emptyRowIndexObat).Cells(1).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_list_masukan.Rows(emptyRowIndexObat).Cells(2).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_list_masukan.Rows(emptyRowIndexObat).Cells(3).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        ' Salin data dari dgv_list_obat ke dgv_list_masukan
        For Each row As DataGridViewRow In dgv_list_obat.Rows
            If Not row.IsNewRow Then
                Dim newRow As DataGridViewRow = DirectCast(row.Clone(), DataGridViewRow)
                For i As Integer = 0 To row.Cells.Count - 1
                    newRow.Cells(i).Value = row.Cells(i).Value
                Next
                dgv_list_masukan.Rows.Add(newRow)
            End If
        Next

        ' Tambahkan 2 baris kosong sebagai pemisah
        dgv_list_masukan.Rows.Add()
        Dim emptyRowIndexBatubara As Integer = dgv_list_masukan.Rows.Add()
        dgv_list_masukan.Rows(emptyRowIndexBatubara).Cells(0).Value = "DATA MASUKAN BATUBARA" ' Contoh isi kolom pertama
        dgv_list_masukan.Rows(emptyRowIndexBatubara).Cells(1).Value = "TOTAL DPP" ' Kosongkan kolom lainnya
        dgv_list_masukan.Rows(emptyRowIndexBatubara).Cells(2).Value = "BELUM UPLOAD"
        dgv_list_masukan.Rows(emptyRowIndexBatubara).Cells(3).Value = "PPN"
        dgv_list_masukan.Rows(emptyRowIndexBatubara).Cells(0).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_list_masukan.Rows(emptyRowIndexBatubara).Cells(1).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_list_masukan.Rows(emptyRowIndexBatubara).Cells(2).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_list_masukan.Rows(emptyRowIndexBatubara).Cells(3).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        ' Salin data dari dgv_list_obat ke dgv_list_masukan
        For Each row As DataGridViewRow In dgv_list_batubara.Rows
            If Not row.IsNewRow Then
                Dim newRow As DataGridViewRow = DirectCast(row.Clone(), DataGridViewRow)
                For i As Integer = 0 To row.Cells.Count - 1
                    newRow.Cells(i).Value = row.Cells(i).Value
                Next
                dgv_list_masukan.Rows.Add(newRow)
            End If
        Next

        ' Tambahkan 2 baris kosong sebagai pemisah
        dgv_list_masukan.Rows.Add()
        Dim emptyRowIndexlain2 As Integer = dgv_list_masukan.Rows.Add()
        dgv_list_masukan.Rows(emptyRowIndexlain2).Cells(0).Value = "DATA MASUKAN LAIN2" ' Contoh isi kolom pertama
        dgv_list_masukan.Rows(emptyRowIndexlain2).Cells(1).Value = "TOTAL DPP" ' Kosongkan kolom lainnya
        dgv_list_masukan.Rows(emptyRowIndexlain2).Cells(2).Value = "BELUM UPLOAD"
        dgv_list_masukan.Rows(emptyRowIndexlain2).Cells(3).Value = "PPN"
        dgv_list_masukan.Rows(emptyRowIndexlain2).Cells(0).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_list_masukan.Rows(emptyRowIndexlain2).Cells(1).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_list_masukan.Rows(emptyRowIndexlain2).Cells(2).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_list_masukan.Rows(emptyRowIndexlain2).Cells(3).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        ' Salin data dari dgv_list_obat ke dgv_list_masukan
        For Each row As DataGridViewRow In dgv_list_lain2.Rows
            If Not row.IsNewRow Then
                Dim newRow As DataGridViewRow = DirectCast(row.Clone(), DataGridViewRow)
                For i As Integer = 0 To row.Cells.Count - 1
                    newRow.Cells(i).Value = row.Cells(i).Value
                Next
                dgv_list_masukan.Rows.Add(newRow)
            End If
        Next

        ' Nonaktifkan sorting agar tampilan tetap sesuai urutan
        For Each col As DataGridViewColumn In dgv_list_masukan.Columns
            col.SortMode = DataGridViewColumnSortMode.NotSortable
        Next
    End Sub
    Private Sub setup_dgv_list_masukan()
        dgv_list_kain.Columns(0).HeaderText = "DPP MASUKAN KAIN"
        dgv_list_kain.Columns(1).HeaderText = "TOTAL DPP"
        dgv_list_kain.Columns(2).HeaderText = "BELUM DIUPLOAD"
        dgv_list_kain.Columns(3).HeaderText = "PPN"
        dgv_list_kain.Columns(0).Width = 200
        dgv_list_kain.Columns(1).Width = 140
        dgv_list_kain.Columns(2).Width = 140
        dgv_list_kain.Columns(3).Width = 140
        dgv_list_kain.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_list_kain.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_list_kain.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_list_kain.Columns(1).DefaultCellStyle.Format = "#,##0.00"
        dgv_list_kain.Columns(2).DefaultCellStyle.Format = "#,##0.00"
        dgv_list_kain.Columns(3).DefaultCellStyle.Format = "#,##0.00"
    End Sub

    Private Sub load_sheet_keluaran()
        dgv_keluaran.Columns.Clear()
        Call setup_dgv_keluaran()

        Dim tahun As Integer = dtp_tahun.Value.Year ' Ambil tahun dari DateTimePicker

        ' Query untuk Celup
        Dim query_celup As String =
            "SELECT MONTH(tanggal) AS bulan, SUM(dpp) AS dpp_celup " &
            "FROM tbpenjualan " &
            "WHERE status = 'Celup' AND YEAR(tanggal) = @tahun AND dpp <> 0 " &
            "GROUP BY MONTH(tanggal) ORDER BY MONTH(tanggal);"
        ' Query untuk Kain
        Dim query_kain As String =
           "SELECT MONTH(tanggal) AS bulan, SUM(dpp) AS dpp_kain " &
           "FROM tbpenjualan " &
           "WHERE status = 'Kain' AND YEAR(tanggal) = @tahun AND dpp <> 0 " &
           "GROUP BY MONTH(tanggal) ORDER BY MONTH(tanggal);"
        Dim query_total As String =
          "SELECT MONTH(tanggal) AS bulan, SUM(dpp) AS dpp_total " &
          "FROM tbpenjualan " &
          "WHERE (status = 'Celup' OR status = 'Kain') AND YEAR(tanggal) = @tahun AND dpp <> 0 " &
          "GROUP BY MONTH(tanggal) ORDER BY MONTH(tanggal);"
        Dim query_spt As String =
            "SELECT FIELD(bulan, 'JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE', " &
            "'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER') AS bulan_num, nilai_keluaran " &
            "FROM tbsptppn " &
            "WHERE tahun = @tahun " &
            "ORDER BY bulan_num;"
        Dim query_kg As String =
          "SELECT MONTH(tanggal) AS bulan, SUM(jumlah) AS jumlah_kg " &
          "FROM tbpenjualan " &
          "WHERE satuan = 'Kg' AND YEAR(tanggal) = @tahun AND dpp <> 0 AND jenis_biaya = 'Jasa' " &
          "GROUP BY MONTH(tanggal) ORDER BY MONTH(tanggal);"
        Dim query_Meter As String =
        "SELECT MONTH(tanggal) AS bulan, SUM(jumlah) AS jumlah_meter " &
        "FROM tbpenjualan " &
        "WHERE satuan = 'Meter' AND YEAR(tanggal) = @tahun AND dpp <> 0 " &
        "GROUP BY MONTH(tanggal) ORDER BY MONTH(tanggal);"
        Dim query_Yard As String =
        "SELECT MONTH(tanggal) AS bulan, SUM(jumlah) AS jumlah_yard " &
        "FROM tbpenjualan " &
        "WHERE satuan = 'Yard' AND YEAR(tanggal) = @tahun AND dpp <> 0 " &
        "GROUP BY MONTH(tanggal) ORDER BY MONTH(tanggal);"

        ' Kosongkan semua kolom sebelum diisi ulang
        For Each row As DataGridViewRow In dgv_keluaran.Rows
            row.Cells("DPP CELUP").Value = 0
            row.Cells("DPP KAIN").Value = 0
            row.Cells("DPP TOTAL").Value = 0
            row.Cells("DPP SESUAI SPT").Value = 0
            row.Cells("SELISIH").Value = 0
            row.Cells("KOSONG").Value = ""
            row.Cells("KG CELUPAN").Value = 0
            row.Cells("MTR KAIN").Value = 0
            row.Cells("YARD KAIN").Value = 0
        Next

        'Proses(Keluaran)
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Using cmd As New MySqlCommand(query_celup, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim bulan As Integer = reader.GetInt32("bulan")
                        Dim total_keluaran As Decimal = reader.GetDecimal("dpp_celup")
                        If bulan >= 1 And bulan <= 12 Then
                            dgv_keluaran.Rows(bulan - 1).Cells("DPP CELUP").Value = total_keluaran
                        End If
                    End While
                End Using
            End Using
        End Using
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Using cmd As New MySqlCommand(query_kain, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim bulan As Integer = reader.GetInt32("bulan")
                        Dim total_keluaran As Decimal = reader.GetDecimal("dpp_kain")
                        If bulan >= 1 And bulan <= 12 Then
                            dgv_keluaran.Rows(bulan - 1).Cells("DPP KAIN").Value = total_keluaran
                        End If
                    End While
                End Using
            End Using
        End Using
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Using cmd As New MySqlCommand(query_total, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim bulan As Integer = reader.GetInt32("bulan")
                        Dim total_keluaran As Decimal = reader.GetDecimal("dpp_total")
                        If bulan >= 1 And bulan <= 12 Then
                            dgv_keluaran.Rows(bulan - 1).Cells("DPP TOTAL").Value = total_keluaran
                        End If
                    End While
                End Using
            End Using
        End Using
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Using cmd As New MySqlCommand(query_spt, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim bulan As Integer = reader.GetInt32("bulan_num") ' Ambil nilai angka bulan
                        Dim total_keluaran As Decimal = reader.GetDecimal("nilai_keluaran")
                        If bulan >= 1 And bulan <= 12 Then
                            dgv_keluaran.Rows(bulan - 1).Cells("DPP SESUAI SPT").Value = total_keluaran
                        End If
                    End While
                End Using
            End Using
        End Using
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Using cmd As New MySqlCommand(query_kg, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim bulan As Integer = reader.GetInt32("bulan")
                        Dim total_keluaran As Decimal = reader.GetDecimal("jumlah_kg")
                        If bulan >= 1 And bulan <= 12 Then
                            dgv_keluaran.Rows(bulan - 1).Cells("KG CELUPAN").Value = total_keluaran
                        End If
                    End While
                End Using
            End Using
        End Using
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Using cmd As New MySqlCommand(query_Meter, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim bulan As Integer = reader.GetInt32("bulan")
                        Dim total_keluaran As Decimal = reader.GetDecimal("jumlah_meter")
                        If bulan >= 1 And bulan <= 12 Then
                            dgv_keluaran.Rows(bulan - 1).Cells("MTR KAIN").Value = total_keluaran
                        End If
                    End While
                End Using
            End Using
        End Using
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Using cmd As New MySqlCommand(query_Yard, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim bulan As Integer = reader.GetInt32("bulan")
                        Dim total_keluaran As Decimal = reader.GetDecimal("jumlah_yard")
                        If bulan >= 1 And bulan <= 12 Then
                            dgv_keluaran.Rows(bulan - 1).Cells("YARD KAIN").Value = total_keluaran
                        End If
                    End While
                End Using
            End Using
        End Using

        ' Pastikan dgv_keluaran sudah memiliki data sebelum menjalankan kode ini
        Dim totalDPPCelup As Decimal = 0
        Dim totalDPPKain As Decimal = 0
        Dim totalDPPTotal As Decimal = 0
        Dim totalDPPSesuaiSPT As Decimal = 0
        Dim totalDPPSelisih As Decimal = 0
        Dim totalKgCelup As Decimal = 0
        Dim totalMtrKain As Decimal = 0
        Dim totalYardKain As Decimal = 0

        For Each row As DataGridViewRow In dgv_keluaran.Rows
            If Not row.IsNewRow Then
                ' Ambil nilai dari masing-masing kolom
                Dim dppcelup As Decimal = Convert.ToDecimal(row.Cells("DPP CELUP").Value)
                Dim dppkain As Decimal = Convert.ToDecimal(row.Cells("DPP KAIN").Value)
                Dim dpptotal As Decimal = Convert.ToDecimal(row.Cells("DPP TOTAL").Value)
                Dim dppsesuaispt As Decimal = Convert.ToDecimal(row.Cells("DPP SESUAI SPT").Value)

                ' Hitung SELISIH
                Dim selisih As Decimal = dpptotal - dppsesuaispt
                row.Cells("SELISIH").Value = selisih

                Dim dppselisih As Decimal = Convert.ToDecimal(row.Cells("SELISIH").Value)
                Dim kgcelup As Decimal = Convert.ToDecimal(row.Cells("KG CELUPAN").Value)
                Dim mtrkain As Decimal = Convert.ToDecimal(row.Cells("MTR KAIN").Value)
                Dim yardkain As Decimal = Convert.ToDecimal(row.Cells("YARD KAIN").Value)

                ' Akumulasi untuk baris total
                totalDPPCelup += dppcelup
                totalDPPKain += dppkain
                totalDPPTotal += dpptotal
                totalDPPSesuaiSPT += dppsesuaispt
                totalDPPSelisih += dppselisih
                totalKgCelup += kgcelup
                totalMtrKain += mtrkain
                totalYardKain += yardkain
            End If
        Next

        ' Tambahkan baris total ke dgv_keluaran
        Dim index As Integer = dgv_keluaran.Rows.Add()
        With dgv_keluaran.Rows(index)
            .Cells(0).Value = "" ' Kolom pertama sebagai label
            .Cells("DPP CELUP").Value = totalDPPCelup
            .Cells("DPP KAIN").Value = totalDPPKain
            .Cells("DPP TOTAL").Value = totalDPPTotal
            .Cells("DPP SESUAI SPT").Value = totalDPPSesuaiSPT
            .Cells("SELISIH").Value = totalDPPSelisih
            .Cells("KG CELUPAN").Value = totalKgCelup
            .Cells("MTR KAIN").Value = totalMtrKain
            .Cells("YARD KAIN").Value = totalYardKain
        End With

        For Each col As DataGridViewColumn In dgv_keluaran.Columns
            col.SortMode = DataGridViewColumnSortMode.NotSortable
        Next
    End Sub
    Private Sub setup_dgv_keluaran()
        dgv_keluaran.ColumnCount = 10
        dgv_keluaran.Columns(0).Name = "BULAN"
        dgv_keluaran.Columns(1).Name = "DPP CELUP"
        dgv_keluaran.Columns(1).HeaderText = "DPP CELUPAN"
        dgv_keluaran.Columns(2).Name = "DPP KAIN"
        dgv_keluaran.Columns(3).Name = "DPP TOTAL"
        dgv_keluaran.Columns(4).Name = "DPP SESUAI SPT"
        dgv_keluaran.Columns(5).Name = "SELISIH"
        dgv_keluaran.Columns(6).Name = "KOSONG"
        dgv_keluaran.Columns(6).HeaderText = ""
        dgv_keluaran.Columns(7).Name = "KG CELUPAN"
        dgv_keluaran.Columns(8).Name = "MTR KAIN"
        dgv_keluaran.Columns(9).Name = "YARD KAIN"

        Dim bulanArray As String() = {"JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"}
        For Each bulan As String In bulanArray
            dgv_keluaran.Rows.Add(bulan, 0, 0, 0, 0, 0, "", 0, 0, 0)
        Next
        dgv_keluaran.Columns(1).Width = 130
        dgv_keluaran.Columns(2).Width = 130
        dgv_keluaran.Columns(3).Width = 140
        dgv_keluaran.Columns(4).Width = 140
        dgv_keluaran.Columns(5).Width = 70
        dgv_keluaran.Columns(6).Width = 40
        dgv_keluaran.Columns(7).Width = 100
        dgv_keluaran.Columns(8).Width = 100
        dgv_keluaran.Columns(9).Width = 100
        dgv_keluaran.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_keluaran.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_keluaran.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_keluaran.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_keluaran.Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_keluaran.Columns(7).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_keluaran.Columns(8).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_keluaran.Columns(9).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_keluaran.Columns(1).DefaultCellStyle.Format = "#,##0.00"
        dgv_keluaran.Columns(2).DefaultCellStyle.Format = "#,##0.00"
        dgv_keluaran.Columns(3).DefaultCellStyle.Format = "#,##0.00"
        dgv_keluaran.Columns(4).DefaultCellStyle.Format = "#,##0.00"
        dgv_keluaran.Columns(5).DefaultCellStyle.Format = "#,##0.00"
        dgv_keluaran.Columns(7).DefaultCellStyle.Format = "#,##0.00"
        dgv_keluaran.Columns(8).DefaultCellStyle.Format = "#,##0.00"
        dgv_keluaran.Columns(9).DefaultCellStyle.Format = "#,##0.00"
    End Sub
    Private Sub dgv_keluaran_CellFormatting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles dgv_keluaran.CellFormatting
        If dgv_keluaran.Columns(e.ColumnIndex).Name = "SELISIH" Then
            ' Pastikan nilai tidak kosong dan merupakan angka
            If e.Value IsNot Nothing AndAlso IsNumeric(e.Value.ToString()) Then
                Dim nilai As Decimal
                ' Gunakan TryParse untuk menghindari error konversi
                If Decimal.TryParse(e.Value.ToString(), nilai) Then
                    ' Cek jika nilai lebih dari 100
                    If nilai > 100 Or nilai < -100 Then
                        dgv_keluaran.Rows(e.RowIndex).Cells(e.ColumnIndex).Style.ForeColor = Color.White
                        dgv_keluaran.Rows(e.RowIndex).Cells(e.ColumnIndex).Style.BackColor = Color.Red
                    Else
                        dgv_keluaran.Rows(e.RowIndex).Cells(e.ColumnIndex).Style.ForeColor = Color.Black
                    End If
                End If
            Else
                ' Jika nilai tidak valid, pastikan warna tetap default (opsional)
                dgv_keluaran.Rows(e.RowIndex).Cells(e.ColumnIndex).Style.ForeColor = Color.Black
            End If
        End If
        ' Periksa apakah nilai di sel adalah numerik
        If e.Value IsNot Nothing AndAlso IsNumeric(e.Value) Then
            Dim nilai As Decimal = Convert.ToDecimal(e.Value)
            If nilai < 0 Then
                ' Format nilai negatif dengan tanda kurung
                e.Value = "(" & Format(Math.Abs(nilai), "#,##0.00") & ")"
                e.FormattingApplied = True
            Else
                ' Format nilai positif atau nol tanpa tanda kurung
                e.Value = Format(nilai, "#,##0.00")
                e.FormattingApplied = True
            End If
        End If
    End Sub

    Private Sub load_list_dpp_celup()
        dgv_list_celup.Columns.Clear()
        Dim tahun As Integer = dtp_tahun.Value.Year
        Dim query_celup As String =
            "SELECT supplier, SUM(dpp) AS dpp_celup " &
            "FROM tbpenjualan " &
            "WHERE status = 'Celup' AND YEAR(tanggal) = @tahun AND dpp <> 0 " &
            "GROUP BY supplier ORDER BY MONTH(tanggal);"
        Dim dt As New DataTable()
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Using cmd As New MySqlCommand(query_celup, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using adapter As New MySqlDataAdapter(cmd)
                    adapter.Fill(dt)
                End Using
            End Using
            dgv_list_celup.DataSource = dt
            Dim totalDPP As Decimal = 0
            For Each row As DataGridViewRow In dgv_list_celup.Rows
                If Not row.IsNewRow Then
                    Dim dppcelup As Decimal = If(IsDBNull(row.Cells(1).Value), 0, Convert.ToDecimal(row.Cells(1).Value))
                    ' Akumulasi untuk baris total
                    totalDPP += dppcelup
                End If
            Next
            Dim baris As DataRow = dt.NewRow()
            baris(0) = "" ' Kolom pertama sebagai label
            baris(1) = totalDPP
            dt.Rows.Add(baris)

            Call setup_dgv_list_keluaran()
            For Each col As DataGridViewColumn In dgv_list_celup.Columns
                col.SortMode = DataGridViewColumnSortMode.NotSortable
            Next
        End Using

    End Sub
    Private Sub load_list_dpp_kain()
        dgv_list_keluaran_kain.Columns.Clear()
        Dim tahun As Integer = dtp_tahun.Value.Year
        Dim query_celup As String =
            "SELECT supplier, SUM(dpp) AS dpp_celup " &
            "FROM tbpenjualan " &
            "WHERE status = 'Kain' AND YEAR(tanggal) = @tahun AND dpp <> 0 " &
            "GROUP BY supplier ORDER BY MONTH(tanggal);"
        Dim dt As New DataTable()
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Using cmd As New MySqlCommand(query_celup, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using adapter As New MySqlDataAdapter(cmd)
                    adapter.Fill(dt)
                End Using
            End Using
            dgv_list_keluaran_kain.DataSource = dt
            Dim totalDPP As Decimal = 0
            For Each row As DataGridViewRow In dgv_list_keluaran_kain.Rows
                If Not row.IsNewRow Then
                    Dim dppcelup As Decimal = If(IsDBNull(row.Cells(1).Value), 0, Convert.ToDecimal(row.Cells(1).Value))
                    ' Akumulasi untuk baris total
                    totalDPP += dppcelup
                End If
            Next
            Dim baris As DataRow = dt.NewRow()
            baris(0) = "" ' Kolom pertama sebagai label
            baris(1) = totalDPP
            dt.Rows.Add(baris)
            For Each col As DataGridViewColumn In dgv_list_keluaran_kain.Columns
                col.SortMode = DataGridViewColumnSortMode.NotSortable
            Next
        End Using
    End Sub
    Private Sub load_list_dpp_total()
        dgv_list_keluaran_total.Columns.Clear()
        Dim tahun As Integer = dtp_tahun.Value.Year
        Dim query_celup As String =
            "SELECT supplier, SUM(dpp) AS dpp_celup " &
            "FROM tbpenjualan " &
            "WHERE (status = 'Celup' OR status = 'Kain') AND YEAR(tanggal) = @tahun AND dpp <> 0 " &
            "GROUP BY supplier ORDER BY MONTH(tanggal);"
        Dim dt As New DataTable()
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Using cmd As New MySqlCommand(query_celup, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using adapter As New MySqlDataAdapter(cmd)
                    adapter.Fill(dt)
                End Using
            End Using
            dgv_list_keluaran_total.DataSource = dt
            Dim totalDPP As Decimal = 0
            For Each row As DataGridViewRow In dgv_list_keluaran_total.Rows
                If Not row.IsNewRow Then
                    Dim dppcelup As Decimal = If(IsDBNull(row.Cells(1).Value), 0, Convert.ToDecimal(row.Cells(1).Value))
                    ' Akumulasi untuk baris total
                    totalDPP += dppcelup
                End If
            Next
            Dim baris As DataRow = dt.NewRow()
            baris(0) = "" ' Kolom pertama sebagai label
            baris(1) = totalDPP
            dt.Rows.Add(baris)
            For Each col As DataGridViewColumn In dgv_list_keluaran_total.Columns
                col.SortMode = DataGridViewColumnSortMode.NotSortable
            Next
        End Using
    End Sub
    Private Sub gabung_dgv_keluaran()
        ' Pastikan dgv_list_keluaran kosong sebelum menambahkan data
        dgv_list_keluaran.Rows.Clear()
        dgv_list_keluaran.Columns.Clear()
        For Each col As DataGridViewColumn In dgv_list_celup.Columns
            dgv_list_keluaran.Columns.Add(DirectCast(col.Clone(), DataGridViewColumn))
        Next
        Dim emptyRowIndexKain As Integer = dgv_list_keluaran.Rows.Add()
        dgv_list_keluaran.Rows(emptyRowIndexKain).Cells(0).Value = "DPP CELUPAN" ' Contoh isi kolom pertama
        dgv_list_keluaran.Rows(emptyRowIndexKain).Cells(1).Value = "TOTAL DPP" ' Kosongkan kolom lainnya
        dgv_list_keluaran.Rows(emptyRowIndexKain).Cells(0).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_list_keluaran.Rows(emptyRowIndexKain).Cells(1).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        For Each row As DataGridViewRow In dgv_list_celup.Rows
            If Not row.IsNewRow Then
                Dim newRow As DataGridViewRow = DirectCast(row.Clone(), DataGridViewRow)
                For i As Integer = 0 To row.Cells.Count - 1
                    newRow.Cells(i).Value = row.Cells(i).Value
                Next
                dgv_list_keluaran.Rows.Add(newRow)
            End If
        Next

        dgv_list_keluaran.Rows.Add()
        Dim emptyRowIndexObat As Integer = dgv_list_keluaran.Rows.Add()
        dgv_list_keluaran.Rows(emptyRowIndexObat).Cells(0).Value = "DPP KAIN" ' Contoh isi kolom pertama
        dgv_list_keluaran.Rows(emptyRowIndexObat).Cells(1).Value = "TOTAL DPP" ' Kosongkan kolom lainnya
        dgv_list_keluaran.Rows(emptyRowIndexObat).Cells(0).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_list_keluaran.Rows(emptyRowIndexObat).Cells(1).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        For Each row As DataGridViewRow In dgv_list_keluaran_kain.Rows
            If Not row.IsNewRow Then
                Dim newRow As DataGridViewRow = DirectCast(row.Clone(), DataGridViewRow)
                For i As Integer = 0 To row.Cells.Count - 1
                    newRow.Cells(i).Value = row.Cells(i).Value
                Next
                dgv_list_keluaran.Rows.Add(newRow)
            End If
        Next

        dgv_list_keluaran.Rows.Add()
        Dim emptyRowIndextotal As Integer = dgv_list_keluaran.Rows.Add()
        dgv_list_keluaran.Rows(emptyRowIndextotal).Cells(0).Value = "DPP TOTAL" ' Contoh isi kolom pertama
        dgv_list_keluaran.Rows(emptyRowIndextotal).Cells(1).Value = "TOTAL DPP" ' Kosongkan kolom lainnya
        dgv_list_keluaran.Rows(emptyRowIndextotal).Cells(0).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_list_keluaran.Rows(emptyRowIndextotal).Cells(1).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        For Each row As DataGridViewRow In dgv_list_keluaran_total.Rows
            If Not row.IsNewRow Then
                Dim newRow As DataGridViewRow = DirectCast(row.Clone(), DataGridViewRow)
                For i As Integer = 0 To row.Cells.Count - 1
                    newRow.Cells(i).Value = row.Cells(i).Value
                Next
                dgv_list_keluaran.Rows.Add(newRow)
            End If
        Next



        For Each col As DataGridViewColumn In dgv_list_keluaran.Columns
            col.SortMode = DataGridViewColumnSortMode.NotSortable
        Next
    End Sub
    Private Sub setup_dgv_list_keluaran()
        dgv_list_celup.Columns(0).HeaderText = "DPP CELUPAN"
        dgv_list_celup.Columns(1).HeaderText = "TOTAL DPP"
        dgv_list_celup.Columns(0).Width = 200
        dgv_list_celup.Columns(1).Width = 140
        dgv_list_celup.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_list_celup.Columns(1).DefaultCellStyle.Format = "#,##0.00"
    End Sub

    Private Sub load_list_kg()
        dgv_satuan_kg.Columns.Clear()
        Dim tahun As Integer = dtp_tahun.Value.Year
        Dim query_celup As String =
            "SELECT supplier, SUM(jumlah) AS dpp_celup " &
            "FROM tbpenjualan " &
            "WHERE satuan = 'Kg' AND YEAR(tanggal) = @tahun AND dpp <> 0 AND jenis_biaya = 'Jasa'  " &
            "GROUP BY supplier ORDER BY MONTH(tanggal);"
        Dim dt As New DataTable()
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Using cmd As New MySqlCommand(query_celup, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using adapter As New MySqlDataAdapter(cmd)
                    adapter.Fill(dt)
                End Using
            End Using
            dgv_satuan_kg.DataSource = dt
            Dim totalDPP As Decimal = 0
            For Each row As DataGridViewRow In dgv_satuan_kg.Rows
                If Not row.IsNewRow Then
                    Dim dppcelup As Decimal = If(IsDBNull(row.Cells(1).Value), 0, Convert.ToDecimal(row.Cells(1).Value))
                    ' Akumulasi untuk baris total
                    totalDPP += dppcelup
                End If
            Next
            Dim baris As DataRow = dt.NewRow()
            baris(0) = "" ' Kolom pertama sebagai label
            baris(1) = totalDPP
            dt.Rows.Add(baris)

            Call setup_dgv_list_keluaran_satuan()
            For Each col As DataGridViewColumn In dgv_satuan_kg.Columns
                col.SortMode = DataGridViewColumnSortMode.NotSortable
            Next
        End Using

    End Sub
    Private Sub load_list_mtr()
        dgv_satuan_mtr.Columns.Clear()
        Dim tahun As Integer = dtp_tahun.Value.Year
        Dim query_celup As String =
            "SELECT supplier, SUM(jumlah) AS dpp_celup " &
            "FROM tbpenjualan " &
            "WHERE satuan = 'Meter' AND YEAR(tanggal) = @tahun AND dpp <> 0 " &
            "GROUP BY supplier ORDER BY MONTH(tanggal);"
        Dim dt As New DataTable()
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Using cmd As New MySqlCommand(query_celup, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using adapter As New MySqlDataAdapter(cmd)
                    adapter.Fill(dt)
                End Using
            End Using
            dgv_satuan_mtr.DataSource = dt
            Dim totalDPP As Decimal = 0
            For Each row As DataGridViewRow In dgv_satuan_mtr.Rows
                If Not row.IsNewRow Then
                    Dim dppcelup As Decimal = If(IsDBNull(row.Cells(1).Value), 0, Convert.ToDecimal(row.Cells(1).Value))
                    ' Akumulasi untuk baris total
                    totalDPP += dppcelup
                End If
            Next
            Dim baris As DataRow = dt.NewRow()
            baris(0) = "" ' Kolom pertama sebagai label
            baris(1) = totalDPP
            dt.Rows.Add(baris)
            For Each col As DataGridViewColumn In dgv_satuan_mtr.Columns
                col.SortMode = DataGridViewColumnSortMode.NotSortable
            Next
        End Using
    End Sub
    Private Sub load_list_yard()
        dgv_satuan_yard.Columns.Clear()
        Dim tahun As Integer = dtp_tahun.Value.Year
        Dim query_celup As String =
            "SELECT supplier, SUM(jumlah) AS dpp_celup " &
            "FROM tbpenjualan " &
            "WHERE satuan = 'Yard' AND YEAR(tanggal) = @tahun AND dpp <> 0 " &
            "GROUP BY supplier ORDER BY MONTH(tanggal);"
        Dim dt As New DataTable()
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Using cmd As New MySqlCommand(query_celup, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using adapter As New MySqlDataAdapter(cmd)
                    adapter.Fill(dt)
                End Using
            End Using
            dgv_satuan_yard.DataSource = dt
            Dim totalDPP As Decimal = 0
            For Each row As DataGridViewRow In dgv_satuan_yard.Rows
                If Not row.IsNewRow Then
                    Dim dppcelup As Decimal = If(IsDBNull(row.Cells(1).Value), 0, Convert.ToDecimal(row.Cells(1).Value))
                    ' Akumulasi untuk baris total
                    totalDPP += dppcelup
                End If
            Next
            Dim baris As DataRow = dt.NewRow()
            baris(0) = "" ' Kolom pertama sebagai label
            baris(1) = totalDPP
            dt.Rows.Add(baris)
            For Each col As DataGridViewColumn In dgv_satuan_yard.Columns
                col.SortMode = DataGridViewColumnSortMode.NotSortable
            Next
        End Using
    End Sub
    Private Sub gabung_dgv_keluaran_satuan()
        ' Pastikan dgv_keluaran_satuan kosong sebelum menambahkan data
        dgv_keluaran_satuan.Rows.Clear()
        dgv_keluaran_satuan.Columns.Clear()
        For Each col As DataGridViewColumn In dgv_satuan_kg.Columns
            dgv_keluaran_satuan.Columns.Add(DirectCast(col.Clone(), DataGridViewColumn))
        Next
        Dim emptyRowIndexKain As Integer = dgv_keluaran_satuan.Rows.Add()
        dgv_keluaran_satuan.Rows(emptyRowIndexKain).Cells(0).Value = "KG CELUPAN" ' Contoh isi kolom pertama
        dgv_keluaran_satuan.Rows(emptyRowIndexKain).Cells(1).Value = "JUMLAH" ' Kosongkan kolom lainnya
        dgv_keluaran_satuan.Rows(emptyRowIndexKain).Cells(0).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_keluaran_satuan.Rows(emptyRowIndexKain).Cells(1).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        For Each row As DataGridViewRow In dgv_satuan_kg.Rows
            If Not row.IsNewRow Then
                Dim newRow As DataGridViewRow = DirectCast(row.Clone(), DataGridViewRow)
                For i As Integer = 0 To row.Cells.Count - 1
                    newRow.Cells(i).Value = row.Cells(i).Value
                Next
                dgv_keluaran_satuan.Rows.Add(newRow)
            End If
        Next

        dgv_keluaran_satuan.Rows.Add()
        Dim emptyRowIndexObat As Integer = dgv_keluaran_satuan.Rows.Add()
        dgv_keluaran_satuan.Rows(emptyRowIndexObat).Cells(0).Value = "MTR KAIN" ' Contoh isi kolom pertama
        dgv_keluaran_satuan.Rows(emptyRowIndexObat).Cells(1).Value = "JUMLAH" ' Kosongkan kolom lainnya
        dgv_keluaran_satuan.Rows(emptyRowIndexObat).Cells(0).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_keluaran_satuan.Rows(emptyRowIndexObat).Cells(1).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        For Each row As DataGridViewRow In dgv_satuan_mtr.Rows
            If Not row.IsNewRow Then
                Dim newRow As DataGridViewRow = DirectCast(row.Clone(), DataGridViewRow)
                For i As Integer = 0 To row.Cells.Count - 1
                    newRow.Cells(i).Value = row.Cells(i).Value
                Next
                dgv_keluaran_satuan.Rows.Add(newRow)
            End If
        Next

        dgv_keluaran_satuan.Rows.Add()
        Dim emptyRowIndextotal As Integer = dgv_keluaran_satuan.Rows.Add()
        dgv_keluaran_satuan.Rows(emptyRowIndextotal).Cells(0).Value = "YARD KAIN" ' Contoh isi kolom pertama
        dgv_keluaran_satuan.Rows(emptyRowIndextotal).Cells(1).Value = "JUMLAH" ' Kosongkan kolom lainnya
        dgv_keluaran_satuan.Rows(emptyRowIndextotal).Cells(0).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_keluaran_satuan.Rows(emptyRowIndextotal).Cells(1).Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        For Each row As DataGridViewRow In dgv_satuan_yard.Rows
            If Not row.IsNewRow Then
                Dim newRow As DataGridViewRow = DirectCast(row.Clone(), DataGridViewRow)
                For i As Integer = 0 To row.Cells.Count - 1
                    newRow.Cells(i).Value = row.Cells(i).Value
                Next
                dgv_keluaran_satuan.Rows.Add(newRow)
            End If
        Next
        For Each col As DataGridViewColumn In dgv_keluaran_satuan.Columns
            col.SortMode = DataGridViewColumnSortMode.NotSortable
        Next
    End Sub
    Private Sub setup_dgv_list_keluaran_satuan()
        dgv_satuan_kg.Columns(0).HeaderText = "DPP CELUPAN"
        dgv_satuan_kg.Columns(1).HeaderText = "TOTAL DPP"
        dgv_satuan_kg.Columns(0).Width = 200
        dgv_satuan_kg.Columns(1).Width = 140
        dgv_satuan_kg.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_satuan_kg.Columns(1).DefaultCellStyle.Format = "#,##0.00"
    End Sub

    Private Sub tampil_data_bukpot()
        dgv_bukpot.Columns.Clear()
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Dim selectedYear As Integer = dtp_tahun.Value.Year
            Dim sqlx As String = "SELECT id_jual, supplier, npwp, tanggal, no_faktur, dpp, ppn, pph23, pph23_actual, no_bukpot, tgl_bukpot, masa_bukpot, gabung_bukpot " &
                                 "FROM tbpenjualan " &
                                 "WHERE no_bukpot <> '' " &
                                 "AND jenis_biaya = 'Jasa' " &
                                 "AND no_faktur <> '' " &
                                 "AND YEAR(masa_bukpot) = " & selectedYear & " " &
                                 "ORDER BY tgl_bukpot ASC, no_bukpot ASC, supplier ASC, pph23_actual DESC"

            Using cmdx As New MySqlCommand(sqlx, conx)
                Using dax As New MySqlDataAdapter
                    dax.SelectCommand = cmdx
                    Using dsx As New DataSet
                        dax.Fill(dsx, "tbpenjualan")
                        dgv_bukpot.DataSource = dsx.Tables("tbpenjualan")
                    End Using
                End Using
            End Using
        End Using

        dgv_bukpot.Columns(1).HeaderText = "CUSTOMER"
        dgv_bukpot.Columns(2).HeaderText = "NPWP"
        dgv_bukpot.Columns(3).HeaderText = "TANGGAL"
        dgv_bukpot.Columns(4).HeaderText = "NO FAKTUR"
        dgv_bukpot.Columns(5).HeaderText = "DPP"
        dgv_bukpot.Columns(6).HeaderText = "PPN"
        dgv_bukpot.Columns(7).HeaderText = "PPH 23"
        dgv_bukpot.Columns(8).HeaderText = "PPH23 ACTUAL"
        dgv_bukpot.Columns(9).HeaderText = "NO BUKPOT"
        dgv_bukpot.Columns(10).HeaderText = "TGL BUKPOT"
        dgv_bukpot.Columns(11).HeaderText = "MASA BUKPOT"
        For Each column As DataGridViewColumn In dgv_bukpot.Columns
            column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        Next
        dgv_bukpot.RowHeadersWidth = 60
        dgv_bukpot.Columns(0).Visible = False
        dgv_bukpot.Columns(12).Visible = False
        dgv_bukpot.Columns(1).Width = 220
        dgv_bukpot.Columns(2).Width = 160
        dgv_bukpot.Columns(3).Width = 85
        dgv_bukpot.Columns(4).Width = 160
        dgv_bukpot.Columns(5).Width = 120
        dgv_bukpot.Columns(6).Width = 120
        dgv_bukpot.Columns(7).Width = 120
        dgv_bukpot.Columns(8).Width = 140
        dgv_bukpot.Columns(9).Width = 120
        dgv_bukpot.Columns(10).Width = 120
        dgv_bukpot.Columns(11).Width = 120
        dgv_bukpot.Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_bukpot.Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_bukpot.Columns(7).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_bukpot.Columns(8).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_bukpot.Columns(9).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_bukpot.Columns(10).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_bukpot.Columns(11).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_bukpot.Columns(12).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_bukpot.Columns(5).DefaultCellStyle.Format = "#,##0.00"
        dgv_bukpot.Columns(6).DefaultCellStyle.Format = "#,##0.00"
        dgv_bukpot.Columns(7).DefaultCellStyle.Format = "#,##0.00"
        dgv_bukpot.Columns(8).DefaultCellStyle.Format = "#,##0.00"
        dgv_bukpot.Columns(10).DefaultCellStyle.Format = "dd-MMM-yy"
        dgv_bukpot.Columns(11).DefaultCellStyle.Format = "MMMM-yy"

        For Each col As DataGridViewColumn In dgv_bukpot.Columns
            col.SortMode = DataGridViewColumnSortMode.NotSortable
        Next
    End Sub
    Private Sub dgv_bukpot_CellFormatting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles dgv_bukpot.CellFormatting
        dgv_bukpot.Rows(e.RowIndex).HeaderCell.Value = (e.RowIndex + 1).ToString()
    End Sub

    Private Sub LoadDataPLN()
        dgv_pln.Columns.Clear()
        Call setup_dgv_pln()
        Dim tahun As Integer = dtp_tahun.Value.Year ' Ambil tahun dari DateTimePicker
        ' Query untuk PLN
        Dim queryPLN As String =
            "SELECT MONTH(tanggal) AS bulan, SUM(total) AS total_pln " &
            "FROM tbpembelian " &
            "WHERE jenis_biaya = 'BIAYA LISTRIK PABRIK' AND YEAR(tanggal) = @tahun " &
            "GROUP BY MONTH(tanggal) ORDER BY MONTH(tanggal);"
        ' Query untuk GARAM
        Dim queryGARAM As String =
            "SELECT MONTH(tanggal) AS bulan, SUM(total) AS total_garam " &
            "FROM tbpembelian " &
            "WHERE jenis_biaya = 'BIAYA GARAM' AND YEAR(tanggal) = @tahun " &
            "GROUP BY MONTH(tanggal) ORDER BY MONTH(tanggal);"
        ' Query untuk COAL
        Dim queryCOAL As String =
            "SELECT MONTH(tanggal) AS bulan, SUM(dpp) AS total_coal " &
            "FROM tbpembelian " &
            "WHERE jenis_biaya = 'BATUBARA' AND YEAR(tanggal) = @tahun " &
            "GROUP BY MONTH(tanggal) ORDER BY MONTH(tanggal);"
        ' Kosongkan semua kolom sebelum diisi ulang
        For Each row As DataGridViewRow In dgv_pln.Rows
            row.Cells("PLN").Value = 0
            row.Cells("GARAM").Value = 0
            row.Cells("COAL").Value = 0
            row.Cells("PPH 22 COAL").Value = 0
        Next
        ' Proses PLN
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Using cmd As New MySqlCommand(queryPLN, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim bulan As Integer = reader.GetInt32("bulan")
                        Dim total_pln As Decimal = reader.GetDecimal("total_pln")
                        If bulan >= 1 And bulan <= 12 Then
                            dgv_pln.Rows(bulan - 1).Cells("PLN").Value = total_pln
                        End If
                    End While
                End Using
            End Using
            ' Proses GARAM
            Using cmd As New MySqlCommand(queryGARAM, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim bulan As Integer = reader.GetInt32("bulan")
                        Dim total_garam As Decimal = reader.GetDecimal("total_garam")
                        If bulan >= 1 And bulan <= 12 Then
                            dgv_pln.Rows(bulan - 1).Cells("GARAM").Value = total_garam
                        End If
                    End While
                End Using
            End Using
            ' Proses COAL
            Using cmd As New MySqlCommand(queryCOAL, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim bulan As Integer = reader.GetInt32("bulan")
                        Dim total_coal As Decimal = reader.GetDecimal("total_coal")
                        If bulan >= 1 And bulan <= 12 Then
                            dgv_pln.Rows(bulan - 1).Cells("COAL").Value = total_coal
                            ' Hitung PPH 22 COAL (COAL * PPN 22 dari variabel global)
                            dgv_pln.Rows(bulan - 1).Cells("PPH 22 COAL").Value = total_coal * (pph22 / 100)
                        End If
                    End While
                End Using
            End Using
        End Using

        ' Pastikan dgv_masukan sudah memiliki data sebelum menjalankan kode ini
        Dim totalDPPKain As Decimal = 0
        Dim totalDPPObat As Decimal = 0
        Dim totalDPPBatubara As Decimal = 0
        Dim totalDPPLain2 As Decimal = 0
        For Each row As DataGridViewRow In dgv_pln.Rows
            If Not row.IsNewRow Then
                ' Ambil nilai dari masing-masing kolom
                Dim dppKain As Decimal = Convert.ToDecimal(row.Cells("PLN").Value)
                Dim dppObat As Decimal = Convert.ToDecimal(row.Cells("GARAM").Value)
                Dim dppBatubara As Decimal = Convert.ToDecimal(row.Cells("COAL").Value)
                Dim dppLain2 As Decimal = Convert.ToDecimal(row.Cells("PPH 22 COAL").Value)
                ' Akumulasi untuk baris total
                totalDPPKain += dppKain
                totalDPPObat += dppObat
                totalDPPBatubara += dppBatubara
                totalDPPLain2 += dppLain2
            End If
        Next
        ' Tambahkan baris total ke dgv_masukan
        Dim index As Integer = dgv_pln.Rows.Add()
        With dgv_pln.Rows(index)
            .Cells(0).Value = "" ' Kolom pertama sebagai label
            .Cells("PLN").Value = totalDPPKain
            .Cells("GARAM").Value = totalDPPObat
            .Cells("COAL").Value = totalDPPBatubara
            .Cells("PPH 22 COAL").Value = totalDPPLain2
        End With

        For Each col As DataGridViewColumn In dgv_pln.Columns
            col.SortMode = DataGridViewColumnSortMode.NotSortable
        Next
    End Sub
    Private Sub setup_dgv_pln()
        dgv_pln.ColumnCount = 5
        dgv_pln.Columns(0).Name = ""
        dgv_pln.Columns(1).Name = "PLN"
        dgv_pln.Columns(2).Name = "GARAM"
        dgv_pln.Columns(3).Name = "COAL"
        dgv_pln.Columns(4).Name = "PPH 22 COAL"

        Dim bulanArray As String() = {"JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"}
        For Each bulan As String In bulanArray
            dgv_pln.Rows.Add(bulan, 0, 0, 0, 0)
        Next
        dgv_pln.Columns(1).Width = 120
        dgv_pln.Columns(2).Width = 120
        dgv_pln.Columns(3).Width = 120
        dgv_pln.Columns(4).Width = 120
        dgv_pln.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_pln.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_pln.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_pln.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_pln.Columns(1).DefaultCellStyle.Format = "#,##0.00"
        dgv_pln.Columns(2).DefaultCellStyle.Format = "#,##0.00"
        dgv_pln.Columns(3).DefaultCellStyle.Format = "#,##0.00"
        dgv_pln.Columns(4).DefaultCellStyle.Format = "#,##0.00"
    End Sub

    Private Sub tampil_spt()
        dgv_spt_aml.Columns.Clear()
        Call headertablesptaml()
        Dim tahun As Integer = dtp_tahun.Value.Year ' Ambil tahun dari DateTimePicker
        ' Query untuk Pembelian
        Dim querypembelian As String =
            "SELECT MONTH(tanggal_upload) AS bulan, SUM(total_dpp) AS total_beli, SUM(total_ppn) AS total_ppn_beli " &
            "FROM tbindukpembelian " &
            "WHERE YEAR(tanggal_upload) = @tahun " &
            "GROUP BY MONTH(tanggal_upload) ORDER BY MONTH(tanggal_upload);"
        ' Query untuk Penjualan
        Dim querypenjualan As String =
            "SELECT MONTH(tanggal) AS bulan, SUM(dpp) AS total_jual, SUM(ppn) AS total_ppn_jual " &
            "FROM tbpenjualan " &
            "WHERE YEAR(tanggal) = @tahun " &
            "GROUP BY MONTH(tanggal) ORDER BY MONTH(tanggal);"
        ' Kosongkan semua kolom sebelum diisi ulang
        For Each row As DataGridViewRow In dgv_spt_aml.Rows
            row.Cells("NILAI MASUKAN").Value = 0
            row.Cells("NILAI KELUARAN").Value = 0
            row.Cells("PPN MASUKAN").Value = 0
            row.Cells("PPN KELUARAN").Value = 0
            row.Cells("PPN DISETOR").Value = 0
        Next
        ' Proses Pembelian
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Using cmd As New MySqlCommand(querypembelian, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim bulan As Integer = reader.GetInt32("bulan")
                        Dim total_beli As Decimal = reader.GetDecimal("total_beli")
                        Dim total_ppn_beli As Decimal = reader.GetDecimal("total_ppn_beli")
                        If bulan >= 1 And bulan <= 12 Then
                            dgv_spt_aml.Rows(bulan - 1).Cells("NILAI MASUKAN").Value = total_beli
                            dgv_spt_aml.Rows(bulan - 1).Cells("PPN MASUKAN").Value = total_ppn_beli
                        End If
                    End While
                End Using
            End Using
            ' Proses Penjualan
            Using cmd As New MySqlCommand(querypenjualan, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim bulan As Integer = reader.GetInt32("bulan")
                        Dim total_jual As Decimal = reader.GetDecimal("total_jual")
                        Dim total_ppn_jual As Decimal = reader.GetDecimal("total_ppn_jual")
                        If bulan >= 1 And bulan <= 12 Then
                            dgv_spt_aml.Rows(bulan - 1).Cells("NILAI KELUARAN").Value = total_jual
                            dgv_spt_aml.Rows(bulan - 1).Cells("PPN KELUARAN").Value = total_ppn_jual
                        End If
                    End While
                End Using
            End Using
            ' Hitung PPN DISETOR
            For Each row As DataGridViewRow In dgv_spt_aml.Rows
                ' Pastikan baris bukan baris kosong baru
                If Not row.IsNewRow Then
                    ' Ambil nilai PPN Keluaran dan PPN Masukan
                    Dim ppnKeluaran As Decimal = 0
                    Dim ppnMasukan As Decimal = 0

                    ' Pastikan nilai tidak kosong sebelum parsing
                    If Not IsDBNull(row.Cells("PPN KELUARAN").Value) AndAlso IsNumeric(row.Cells("PPN KELUARAN").Value) Then
                        ppnKeluaran = Convert.ToDecimal(row.Cells("PPN KELUARAN").Value)
                    End If
                    If Not IsDBNull(row.Cells("PPN MASUKAN").Value) AndAlso IsNumeric(row.Cells("PPN MASUKAN").Value) Then
                        ppnMasukan = Convert.ToDecimal(row.Cells("PPN MASUKAN").Value)
                    End If

                    ' Hitung selisih
                    Dim selisihPPN As Decimal = ppnKeluaran - ppnMasukan

                    ' Masukkan selisih ke kolom baru
                    row.Cells("PPN DISETOR").Value = selisihPPN
                End If
            Next
        End Using

        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Dim selectedYear As Integer = dtp_tahun.Value.Year
            Dim sqlx As String = "SELECT bulan, nilai_masukan, nilai_keluaran, ppn_masukan, ppn_keluaran, ppn_disetor " &
                                 "FROM tbsptppn " &
                                 "WHERE tahun = @selectedYear " &
                                 "ORDER BY FIELD(bulan, 'January', 'February', 'March', 'April', 'May', 'June', " &
                                 "'July', 'August', 'September', 'October', 'November', 'December')"
            Using cmdx As New MySqlCommand(sqlx, conx)
                cmdx.Parameters.AddWithValue("@selectedYear", selectedYear)
                Using dax As New MySqlDataAdapter
                    dax.SelectCommand = cmdx
                    Using dsx As New DataSet
                        dax.Fill(dsx, "spt_ppn")
                        dgv_spt_efaktur.DataSource = dsx.Tables("spt_ppn")
                    End Using
                End Using
            End Using
        End Using

        ' Clear dgv_spt_clone before populating
        dgv_spt_clone.Columns.Clear()
        dgv_spt_clone.Rows.Clear()

        ' Copy columns from dgv_spt_efaktur to dgv_spt_clone
        For Each col As DataGridViewColumn In dgv_spt_efaktur.Columns
            Dim newCol As New DataGridViewColumn(col.CellTemplate)
            newCol.HeaderText = col.HeaderText
            newCol.Name = col.Name
            newCol.Width = col.Width
            dgv_spt_clone.Columns.Add(newCol)
        Next

        ' Add new column "SELISIH PPN" at the end
        Dim selisihPpnCol As New DataGridViewTextBoxColumn()
        selisihPpnCol.HeaderText = "SELISIH PPN"
        selisihPpnCol.Name = "SELISIH PPN"
        dgv_spt_clone.Columns.Add(selisihPpnCol)

        ' Copy rows from dgv_spt_efaktur to dgv_spt_clone
        For Each row As DataGridViewRow In dgv_spt_efaktur.Rows
            If Not row.IsNewRow Then
                Dim newRow As DataGridViewRow = CType(row.Clone(), DataGridViewRow)
                For i As Integer = 0 To row.Cells.Count - 1
                    newRow.Cells(i).Value = row.Cells(i).Value
                Next
                dgv_spt_clone.Rows.Add(newRow)
            End If
        Next

        For i As Integer = 0 To dgv_spt_clone.Rows.Count - 1
            ' Pastikan kolom pada kedua DataGridView memiliki data numerik
            Dim value1 As Decimal = 0
            Dim value2 As Decimal = 0
            Dim hasil As Decimal = 0
            ' Cek apakah data di dgv_spt_aml valid dan numerik
            If Not IsDBNull(dgv_spt_aml.Rows(i).Cells(5).Value) AndAlso IsNumeric(dgv_spt_aml.Rows(i).Cells(5).Value) Then
                value1 = Convert.ToDecimal(dgv_spt_aml.Rows(i).Cells(5).Value)
            End If
            ' Cek apakah data di dgv_spt_efaktur valid dan numerik
            If Not IsDBNull(dgv_spt_efaktur.Rows(i).Cells(5).Value) AndAlso IsNumeric(dgv_spt_efaktur.Rows(i).Cells(5).Value) Then
                value2 = Convert.ToDecimal(dgv_spt_efaktur.Rows(i).Cells(5).Value)
            End If
            ' Jumlahkan kedua nilai dan masukkan hasilnya ke dgv_spt_aml
            hasil = value1 - value2
            dgv_spt_clone.Rows(i).Cells("SELISIH PPN").Value = hasil
        Next

        ' Tambahkan kolom "TDK DIGUNGGUNG" setelah "NILAI KELUARAN"
        Dim kolomTdkDigunggung As New DataGridViewTextBoxColumn()
        kolomTdkDigunggung.Name = "TDK DIGUNGGUNG"
        kolomTdkDigunggung.HeaderText = "TDK DIGUNGGUNG"
        dgv_spt_clone.Columns.Insert(2 + 1, kolomTdkDigunggung)

        ' Tambahkan kolom "DIGUNGGUNG" setelah "TDK DIGUNGGUNG"
        Dim kolomDigunggung As New DataGridViewTextBoxColumn()
        kolomDigunggung.Name = "DIGUNGGUNG"
        kolomDigunggung.HeaderText = "DIGUNGGUNG"
        dgv_spt_clone.Columns.Insert(2 + 2, kolomDigunggung)

        ' Tambahkan kolom "TDK DIGUNGGUNG" setelah "NILAI KELUARAN"
        Dim kolomTdkDigunggungamal As New DataGridViewTextBoxColumn()
        kolomTdkDigunggungamal.Name = "TDK DIGUNGGUNG"
        kolomTdkDigunggungamal.HeaderText = "TDK DIGUNGGUNG"
        dgv_spt_aml.Columns.Insert(2 + 1, kolomTdkDigunggungamal)

        ' Tambahkan kolom "Digunggungamal" setelah "TDK Digunggungamal"
        Dim kolomDigunggungamal As New DataGridViewTextBoxColumn()
        kolomDigunggungamal.Name = "DIGUNGGUNG"
        kolomDigunggungamal.HeaderText = "DIGUNGGUNG"
        dgv_spt_aml.Columns.Insert(2 + 2, kolomDigunggungamal)

        ' Pastikan nilai awal pada kolom-kolom baru adalah kosong
        For Each row As DataGridViewRow In dgv_spt_clone.Rows
            row.Cells("TDK DIGUNGGUNG").Value = ""
            row.Cells("DIGUNGGUNG").Value = ""
        Next
        For Each row As DataGridViewRow In dgv_spt_aml.Rows
            row.Cells("TDK DIGUNGGUNG").Value = ""
            row.Cells("DIGUNGGUNG").Value = ""
        Next

        Call headertablesptclone()
        Call headertablesptamltambah()

        For Each col As DataGridViewColumn In dgv_spt_clone.Columns
            col.SortMode = DataGridViewColumnSortMode.NotSortable
        Next
        For Each col As DataGridViewColumn In dgv_spt_aml.Columns
            col.SortMode = DataGridViewColumnSortMode.NotSortable
        Next
    End Sub
    Private Sub headertablesptclone()
        dgv_spt_clone.Columns(0).HeaderText = "SPT EFAKTUR"
        dgv_spt_clone.Columns(1).HeaderText = "NILAI MASUKAN"
        dgv_spt_clone.Columns(2).HeaderText = "NILAI KELUARAN"
        dgv_spt_clone.Columns(3).HeaderText = "TDK DIGUNGGUNG"
        dgv_spt_clone.Columns(4).HeaderText = "DIGUNGGUNG"
        dgv_spt_clone.Columns(5).HeaderText = "PPN MASUKAN"
        dgv_spt_clone.Columns(6).HeaderText = "PPN KELUARAN"
        dgv_spt_clone.Columns(7).HeaderText = "PPN DISETOR"
        For Each column As DataGridViewColumn In dgv_spt_clone.Columns
            column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        Next
        dgv_spt_clone.Columns(0).Width = 100
        dgv_spt_clone.Columns(1).Width = 130
        dgv_spt_clone.Columns(2).Width = 130
        dgv_spt_clone.Columns(3).Width = 100
        dgv_spt_clone.Columns(4).Width = 100
        dgv_spt_clone.Columns(5).Width = 120
        dgv_spt_clone.Columns(6).Width = 120
        dgv_spt_clone.Columns(7).Width = 110
        dgv_spt_clone.Columns(8).Width = 110
        dgv_spt_clone.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_clone.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_clone.Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_clone.Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_clone.Columns(7).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_clone.Columns(8).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_clone.Columns(1).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_clone.Columns(2).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_clone.Columns(4).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_clone.Columns(5).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_clone.Columns(6).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_clone.Columns(7).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_clone.Columns(8).DefaultCellStyle.Format = "#,##0.00"
    End Sub
    Private Sub headertablesptaml()
        dgv_spt_aml.ColumnCount = 6
        dgv_spt_aml.Columns(0).Name = "SPT AML"
        dgv_spt_aml.Columns(1).Name = "NILAI MASUKAN"
        dgv_spt_aml.Columns(2).Name = "NILAI KELUARAN"
        dgv_spt_aml.Columns(3).Name = "PPN MASUKAN"
        dgv_spt_aml.Columns(4).Name = "PPN KELUARAN"
        dgv_spt_aml.Columns(5).Name = "PPN DISETOR"

        Dim bulanArray As String() = {"JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"}
        For Each bulan As String In bulanArray
            dgv_spt_aml.Rows.Add(bulan, 0, 0, 0, 0, 0)
        Next

        For Each column As DataGridViewColumn In dgv_spt_aml.Columns
            column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        Next
        dgv_spt_aml.Columns(0).Width = 120
        dgv_spt_aml.Columns(1).Width = 150
        dgv_spt_aml.Columns(2).Width = 150
        dgv_spt_aml.Columns(3).Width = 140
        dgv_spt_aml.Columns(4).Width = 140
        dgv_spt_aml.Columns(5).Width = 130
        dgv_spt_aml.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_aml.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_aml.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_aml.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_aml.Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_aml.Columns(1).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_aml.Columns(2).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_aml.Columns(3).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_aml.Columns(4).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_aml.Columns(5).DefaultCellStyle.Format = "#,##0.00"
    End Sub
    Private Sub headertablesptamltambah()
        dgv_spt_aml.Columns(0).HeaderText = "SPT AML"
        dgv_spt_aml.Columns(1).HeaderText = "NILAI MASUKAN"
        dgv_spt_aml.Columns(2).HeaderText = "NILAI KELUARAN"
        dgv_spt_aml.Columns(3).HeaderText = "TDK DIGUNGGUNG"
        dgv_spt_aml.Columns(4).HeaderText = "DIGUNGGUNG"
        dgv_spt_aml.Columns(5).HeaderText = "PPN MASUKAN"
        dgv_spt_aml.Columns(6).HeaderText = "PPN KELUARAN"
        dgv_spt_aml.Columns(7).HeaderText = "PPN DISETOR"
        For Each column As DataGridViewColumn In dgv_spt_aml.Columns
            column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        Next
        dgv_spt_aml.Columns(0).Width = 100
        dgv_spt_aml.Columns(1).Width = 130
        dgv_spt_aml.Columns(2).Width = 130
        dgv_spt_aml.Columns(3).Width = 100
        dgv_spt_aml.Columns(4).Width = 100
        dgv_spt_aml.Columns(5).Width = 120
        dgv_spt_aml.Columns(6).Width = 120
        dgv_spt_aml.Columns(7).Width = 110
        dgv_spt_aml.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_aml.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_aml.Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_aml.Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_aml.Columns(7).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_aml.Columns(1).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_aml.Columns(2).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_aml.Columns(4).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_aml.Columns(5).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_aml.Columns(6).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_aml.Columns(7).DefaultCellStyle.Format = "#,##0.00"
    End Sub
    Private Sub dgv_spt_aml_CellFormatting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles dgv_spt_aml.CellFormatting
        ' Periksa apakah nilai di sel adalah numerik
        If e.Value IsNot Nothing AndAlso IsNumeric(e.Value) Then
            Dim nilai As Decimal = Convert.ToDecimal(e.Value)
            If nilai < 0 Then
                ' Format nilai negatif dengan tanda kurung
                e.Value = "(" & Format(Math.Abs(nilai), "#,##0.00") & ")"
                e.FormattingApplied = True
            Else
                ' Format nilai positif atau nol tanpa tanda kurung
                e.Value = Format(nilai, "#,##0.00")
                e.FormattingApplied = True
            End If
        End If
    End Sub
    Private Sub dgv_spt_clone_CellFormatting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles dgv_spt_clone.CellFormatting
        If dgv_spt_clone.Columns(e.ColumnIndex).Name = "SELISIH PPN" Then
            ' Pastikan nilai tidak kosong dan merupakan angka
            If e.Value IsNot Nothing AndAlso IsNumeric(e.Value.ToString()) Then
                Dim nilai As Decimal
                ' Gunakan TryParse untuk menghindari error konversi
                If Decimal.TryParse(e.Value.ToString(), nilai) Then
                    ' Cek jika nilai lebih dari 100
                    If nilai > 100 Or nilai < -100 Then
                        dgv_spt_clone.Rows(e.RowIndex).Cells(e.ColumnIndex).Style.ForeColor = Color.White
                        dgv_spt_clone.Rows(e.RowIndex).Cells(e.ColumnIndex).Style.BackColor = Color.Red
                    Else
                        dgv_spt_clone.Rows(e.RowIndex).Cells(e.ColumnIndex).Style.ForeColor = Color.Black
                    End If
                End If
            Else
                ' Jika nilai tidak valid, pastikan warna tetap default (opsional)
                dgv_spt_clone.Rows(e.RowIndex).Cells(e.ColumnIndex).Style.ForeColor = Color.Black
            End If
        End If
        ' Periksa apakah nilai di sel adalah numerik
        If e.Value IsNot Nothing AndAlso IsNumeric(e.Value) Then
            Dim nilai As Decimal = Convert.ToDecimal(e.Value)
            If nilai < 0 Then
                ' Format nilai negatif dengan tanda kurung
                e.Value = "(" & Format(Math.Abs(nilai), "#,##0.00") & ")"
                e.FormattingApplied = True
            Else
                ' Format nilai positif atau nol tanpa tanda kurung
                e.Value = Format(nilai, "#,##0.00")
                e.FormattingApplied = True
            End If
        End If
    End Sub

    Private Sub tampil_induk_penyusutan()
        dgv_induk_penyusutan_mesin.Columns.Clear()
        dgv_induk_penyusutan_mesin.Columns.Add("Tahun", "Tahun")
        dgv_induk_penyusutan_mesin.Columns.Add("PerolehanTahun", "Perolehan Tahun")
        dgv_induk_penyusutan_mesin.Columns.Add("Penambahan", "Penambahan")
        Dim query As String = "SELECT tahun, SUM(nilai_buku) AS penambahan " &
                      "FROM tbindukpenyusutan " &
                      "WHERE kategori_aset = 'MESIN' " &
                      "GROUP BY tahun " &
                      "ORDER BY tahun"
        Using conn As New MySqlConnection(sLocalConn)
            conn.Open()
            Using cmd As New MySqlCommand(query, conn)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    dgv_induk_penyusutan_mesin.Rows.Clear()
                    While reader.Read()
                        Dim tahun As String = reader("tahun").ToString()
                        Dim penambahan As Decimal = Convert.ToDecimal(reader("penambahan"))

                        dgv_induk_penyusutan_mesin.Rows.Add(tahun, 0, If(penambahan = 0, "-", penambahan.ToString("#,##0")))
                    End While
                End Using
            End Using
        End Using

        For i As Integer = 0 To dgv_induk_penyusutan_mesin.Rows.Count - 1
            If i = 0 Then
                dgv_induk_penyusutan_mesin.Rows(i).Cells(1).Value = dgv_induk_penyusutan_mesin.Rows(i).Cells(2).Value
            Else
                Dim nilaiSebelumnya As Decimal = Convert.ToDecimal(dgv_induk_penyusutan_mesin.Rows(i - 1).Cells(1).Value)
                Dim nilaiKolom3 As Decimal = Convert.ToDecimal(dgv_induk_penyusutan_mesin.Rows(i).Cells(2).Value)
                dgv_induk_penyusutan_mesin.Rows(i).Cells(1).Value = nilaiSebelumnya + nilaiKolom3
            End If
        Next
        dgv_induk_penyusutan_mesin.Rows(0).Cells(2).Value = 0

        For Each column As DataGridViewColumn In dgv_induk_penyusutan_mesin.Columns
            column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        Next
        dgv_induk_penyusutan_mesin.Columns(0).Width = 60
        dgv_induk_penyusutan_mesin.Columns(1).Width = 100
        dgv_induk_penyusutan_mesin.Columns(2).Width = 100
        dgv_induk_penyusutan_mesin.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_induk_penyusutan_mesin.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_induk_penyusutan_mesin.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_induk_penyusutan_mesin.Columns(1).DefaultCellStyle.Format = "#,##0"
        dgv_induk_penyusutan_mesin.Columns(2).DefaultCellStyle.Format = "#,##0"

        dgv_induk_penyusutan_tanki.Columns.Clear()
        dgv_induk_penyusutan_tanki.Columns.Add("Tahun", "Tahun")
        dgv_induk_penyusutan_tanki.Columns.Add("PerolehanTahun", "Perolehan Tahun")
        dgv_induk_penyusutan_tanki.Columns.Add("Penambahan", "Penambahan")
        Dim query1 As String = "SELECT tahun, SUM(nilai_buku) AS penambahan " &
                      "FROM tbindukpenyusutan " &
                      "WHERE kategori_aset = 'TANKI PENGOLAH LIMBAH' " &
                      "GROUP BY tahun " &
                      "ORDER BY tahun"
        Using conn As New MySqlConnection(sLocalConn)
            conn.Open()
            Using cmd As New MySqlCommand(query1, conn)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    dgv_induk_penyusutan_tanki.Rows.Clear()
                    While reader.Read()
                        Dim tahun As String = reader("tahun").ToString()
                        Dim penambahan As Decimal = Convert.ToDecimal(reader("penambahan"))

                        dgv_induk_penyusutan_tanki.Rows.Add(tahun, 0, If(penambahan = 0, "-", penambahan.ToString("#,##0")))
                    End While
                End Using
            End Using
        End Using

        For i As Integer = 0 To dgv_induk_penyusutan_tanki.Rows.Count - 1
            If i = 0 Then
                dgv_induk_penyusutan_tanki.Rows(i).Cells(1).Value = dgv_induk_penyusutan_tanki.Rows(i).Cells(2).Value
            Else
                Dim nilaiSebelumnya As Decimal = Convert.ToDecimal(dgv_induk_penyusutan_tanki.Rows(i - 1).Cells(1).Value)
                Dim nilaiKolom3 As Decimal = Convert.ToDecimal(dgv_induk_penyusutan_tanki.Rows(i).Cells(2).Value)
                dgv_induk_penyusutan_tanki.Rows(i).Cells(1).Value = nilaiSebelumnya + nilaiKolom3
            End If
        Next
        dgv_induk_penyusutan_tanki.Rows(0).Cells(2).Value = 0

        For Each column As DataGridViewColumn In dgv_induk_penyusutan_tanki.Columns
            column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        Next
        dgv_induk_penyusutan_tanki.Columns(0).Width = 60
        dgv_induk_penyusutan_tanki.Columns(1).Width = 100
        dgv_induk_penyusutan_tanki.Columns(2).Width = 100
        dgv_induk_penyusutan_tanki.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_induk_penyusutan_tanki.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_induk_penyusutan_tanki.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_induk_penyusutan_tanki.Columns(1).DefaultCellStyle.Format = "#,##0"
        dgv_induk_penyusutan_tanki.Columns(2).DefaultCellStyle.Format = "#,##0"

        dgv_induk_penyusutan_inventaris.Columns.Clear()
        dgv_induk_penyusutan_inventaris.Columns.Add("Tahun", "Tahun")
        dgv_induk_penyusutan_inventaris.Columns.Add("PerolehanTahun", "Perolehan Tahun")
        dgv_induk_penyusutan_inventaris.Columns.Add("Penambahan", "Penambahan")
        Dim query2 As String = "SELECT tahun, SUM(nilai_buku) AS penambahan " &
                      "FROM tbindukpenyusutan " &
                      "WHERE kategori_aset = 'INVENTARIS' " &
                      "GROUP BY tahun " &
                      "ORDER BY tahun"
        Using conn As New MySqlConnection(sLocalConn)
            conn.Open()
            Using cmd As New MySqlCommand(query2, conn)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    dgv_induk_penyusutan_inventaris.Rows.Clear()
                    While reader.Read()
                        Dim tahun As String = reader("tahun").ToString()
                        Dim penambahan As Decimal = Convert.ToDecimal(reader("penambahan"))

                        dgv_induk_penyusutan_inventaris.Rows.Add(tahun, 0, If(penambahan = 0, "-", penambahan.ToString("#,##0")))
                    End While
                End Using
            End Using
        End Using

        For i As Integer = 0 To dgv_induk_penyusutan_inventaris.Rows.Count - 1
            If i = 0 Then
                dgv_induk_penyusutan_inventaris.Rows(i).Cells(1).Value = dgv_induk_penyusutan_inventaris.Rows(i).Cells(2).Value
            Else
                Dim nilaiSebelumnya As Decimal = Convert.ToDecimal(dgv_induk_penyusutan_inventaris.Rows(i - 1).Cells(1).Value)
                Dim nilaiKolom3 As Decimal = Convert.ToDecimal(dgv_induk_penyusutan_inventaris.Rows(i).Cells(2).Value)
                dgv_induk_penyusutan_inventaris.Rows(i).Cells(1).Value = nilaiSebelumnya + nilaiKolom3
            End If
        Next
        dgv_induk_penyusutan_inventaris.Rows(0).Cells(2).Value = 0

        For Each column As DataGridViewColumn In dgv_induk_penyusutan_inventaris.Columns
            column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        Next
        dgv_induk_penyusutan_inventaris.Columns(0).Width = 60
        dgv_induk_penyusutan_inventaris.Columns(1).Width = 100
        dgv_induk_penyusutan_inventaris.Columns(2).Width = 100
        dgv_induk_penyusutan_inventaris.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_induk_penyusutan_inventaris.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_induk_penyusutan_inventaris.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_induk_penyusutan_inventaris.Columns(1).DefaultCellStyle.Format = "#,##0"
        dgv_induk_penyusutan_inventaris.Columns(2).DefaultCellStyle.Format = "#,##0"

        dgv_induk_penyusutan_bangunan.Columns.Clear()
        dgv_induk_penyusutan_bangunan.Columns.Add("Tahun", "Tahun")
        dgv_induk_penyusutan_bangunan.Columns.Add("PerolehanTahun", "Perolehan Tahun")
        dgv_induk_penyusutan_bangunan.Columns.Add("Penambahan", "Penambahan")
        Dim query3 As String = "SELECT tahun, SUM(nilai_buku) AS penambahan " &
                      "FROM tbindukpenyusutan " &
                      "WHERE kategori_aset = 'BANGUNAN' " &
                      "GROUP BY tahun " &
                      "ORDER BY tahun"
        Using conn As New MySqlConnection(sLocalConn)
            conn.Open()
            Using cmd As New MySqlCommand(query3, conn)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    dgv_induk_penyusutan_bangunan.Rows.Clear()
                    While reader.Read()
                        Dim tahun As String = reader("tahun").ToString()
                        Dim penambahan As Decimal = Convert.ToDecimal(reader("penambahan"))

                        dgv_induk_penyusutan_bangunan.Rows.Add(tahun, 0, If(penambahan = 0, "-", penambahan.ToString("#,##0")))
                    End While
                End Using
            End Using
        End Using

        For i As Integer = 0 To dgv_induk_penyusutan_bangunan.Rows.Count - 1
            If i = 0 Then
                dgv_induk_penyusutan_bangunan.Rows(i).Cells(1).Value = dgv_induk_penyusutan_bangunan.Rows(i).Cells(2).Value
            Else
                Dim nilaiSebelumnya As Decimal = Convert.ToDecimal(dgv_induk_penyusutan_bangunan.Rows(i - 1).Cells(1).Value)
                Dim nilaiKolom3 As Decimal = Convert.ToDecimal(dgv_induk_penyusutan_bangunan.Rows(i).Cells(2).Value)
                dgv_induk_penyusutan_bangunan.Rows(i).Cells(1).Value = nilaiSebelumnya + nilaiKolom3
            End If
        Next
        dgv_induk_penyusutan_bangunan.Rows(0).Cells(2).Value = 0

        For Each column As DataGridViewColumn In dgv_induk_penyusutan_bangunan.Columns
            column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        Next
        dgv_induk_penyusutan_bangunan.Columns(0).Width = 60
        dgv_induk_penyusutan_bangunan.Columns(1).Width = 100
        dgv_induk_penyusutan_bangunan.Columns(2).Width = 100
        dgv_induk_penyusutan_bangunan.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_induk_penyusutan_bangunan.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_induk_penyusutan_bangunan.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_induk_penyusutan_bangunan.Columns(1).DefaultCellStyle.Format = "#,##0"
        dgv_induk_penyusutan_bangunan.Columns(2).DefaultCellStyle.Format = "#,##0"

        dgv_induk_penyusutan_kendaraan.Columns.Clear()
        dgv_induk_penyusutan_kendaraan.Columns.Add("Tahun", "Tahun")
        dgv_induk_penyusutan_kendaraan.Columns.Add("PerolehanTahun", "Perolehan Tahun")
        dgv_induk_penyusutan_kendaraan.Columns.Add("Penambahan", "Penambahan")
        Dim query4 As String = "SELECT tahun, SUM(nilai_buku) AS penambahan " &
                      "FROM tbindukpenyusutan " &
                      "WHERE kategori_aset = 'KENDARAAN' " &
                      "GROUP BY tahun " &
                      "ORDER BY tahun"
        Using conn As New MySqlConnection(sLocalConn)
            conn.Open()
            Using cmd As New MySqlCommand(query4, conn)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    dgv_induk_penyusutan_kendaraan.Rows.Clear()
                    While reader.Read()
                        Dim tahun As String = reader("tahun").ToString()
                        Dim penambahan As Decimal = Convert.ToDecimal(reader("penambahan"))

                        dgv_induk_penyusutan_kendaraan.Rows.Add(tahun, 0, If(penambahan = 0, "-", penambahan.ToString("#,##0")))
                    End While
                End Using
            End Using
        End Using

        For i As Integer = 0 To dgv_induk_penyusutan_kendaraan.Rows.Count - 1
            If i = 0 Then
                dgv_induk_penyusutan_kendaraan.Rows(i).Cells(1).Value = dgv_induk_penyusutan_kendaraan.Rows(i).Cells(2).Value
            Else
                Dim nilaiSebelumnya As Decimal = Convert.ToDecimal(dgv_induk_penyusutan_kendaraan.Rows(i - 1).Cells(1).Value)
                Dim nilaiKolom3 As Decimal = Convert.ToDecimal(dgv_induk_penyusutan_kendaraan.Rows(i).Cells(2).Value)
                dgv_induk_penyusutan_kendaraan.Rows(i).Cells(1).Value = nilaiSebelumnya + nilaiKolom3
            End If
        Next
        dgv_induk_penyusutan_kendaraan.Rows(0).Cells(2).Value = 0

        For Each column As DataGridViewColumn In dgv_induk_penyusutan_kendaraan.Columns
            column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        Next
        dgv_induk_penyusutan_kendaraan.Columns(0).Width = 60
        dgv_induk_penyusutan_kendaraan.Columns(1).Width = 100
        dgv_induk_penyusutan_kendaraan.Columns(2).Width = 100
        dgv_induk_penyusutan_kendaraan.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_induk_penyusutan_kendaraan.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_induk_penyusutan_kendaraan.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_induk_penyusutan_kendaraan.Columns(1).DefaultCellStyle.Format = "#,##0"
        dgv_induk_penyusutan_kendaraan.Columns(2).DefaultCellStyle.Format = "#,##0"

        dgv_induk_penyusutan_mesin.RowHeadersVisible = False
        dgv_induk_penyusutan_inventaris.RowHeadersVisible = False
        dgv_induk_penyusutan_tanki.RowHeadersVisible = False
        dgv_induk_penyusutan_bangunan.RowHeadersVisible = False
        dgv_induk_penyusutan_kendaraan.RowHeadersVisible = False

    End Sub
    Private Sub tampil_data_penyusutan()
        dgv_penyusutan_mesin.Columns.Clear()
        dgv_penyusutan_mesin.ColumnHeadersVisible = False
        dgv_penyusutan_mesin.RowHeadersVisible = False
        dgv_penyusutan_mesin.ColumnCount = 5
        dgv_penyusutan_mesin.Columns(0).Width = 80 ' Lebar kolom 1
        dgv_penyusutan_mesin.Columns(1).Width = 60 ' Lebar kolom 2
        dgv_penyusutan_mesin.Columns(2).Width = 90 ' Lebar kolom 3
        dgv_penyusutan_mesin.Columns(3).Width = 100 ' Lebar kolom 4
        dgv_penyusutan_mesin.Columns(4).Visible = False ' Sembunyikan kolom kode
        dgv_penyusutan_mesin.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_penyusutan_mesin.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_penyusutan_mesin.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_penyusutan_mesin.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        ' Ambil data dari tbindukpenyusutan
        Using conn As New MySqlConnection(sLocalConn)
            Dim queryInduk As String = "SELECT kode, nama_aset, nilai_buku FROM tbindukpenyusutan WHERE kategori_aset = 'MESIN' ORDER BY tahun"
            Dim cmdInduk As New MySqlCommand(queryInduk, conn)
            conn.Open()

            Using drInduk As MySqlDataReader = cmdInduk.ExecuteReader()
                If drInduk.HasRows Then
                    While drInduk.Read()
                        ' Baris 1: Tampilkan nama_aset dan "NILAI BUKU"
                        dgv_penyusutan_mesin.Rows.Add(drInduk("nama_aset").ToString(), "", "", "NILAI BUKU", drInduk("kode").ToString())

                        ' Baris 2: Tampilkan nilai_buku
                        dgv_penyusutan_mesin.Rows.Add("", "", "", Format(CDec(drInduk("nilai_buku")), "#,##0"), drInduk("kode").ToString())

                        ' Ambil kode sebagai referensi
                        Dim kodeRef As String = drInduk("kode").ToString()

                        ' Gunakan koneksi baru untuk query kedua
                        Using conn2 As New MySqlConnection(sLocalConn)
                            conn2.Open()

                            ' Query untuk mengambil data tbdatapenyusutan berdasarkan kode
                            Dim queryPenyusutan As String = "SELECT tahun, persentase, nilai_penyusutan, nilai_buku FROM tbdatapenyusutan WHERE kode = @kode ORDER BY tahun"
                            Using cmdPenyusutan As New MySqlCommand(queryPenyusutan, conn2)
                                cmdPenyusutan.Parameters.AddWithValue("@kode", kodeRef)

                                Using drPenyusutan As MySqlDataReader = cmdPenyusutan.ExecuteReader()
                                    If drPenyusutan.HasRows Then
                                        While drPenyusutan.Read()
                                            ' Tampilkan data penyusutan
                                            dgv_penyusutan_mesin.Rows.Add(drPenyusutan("tahun").ToString(), _
                                                          drPenyusutan("persentase").ToString(), _
                                                          Format(CDec(drPenyusutan("nilai_penyusutan")), "#,##0"), _
                                                          Format(CDec(drPenyusutan("nilai_buku")), "#,##0"), _
                                                          kodeRef)
                                        End While
                                    End If
                                End Using
                            End Using
                        End Using

                        ' Tambahkan satu baris kosong
                        dgv_penyusutan_mesin.Rows.Add("", "", "", "", "")
                    End While
                End If
            End Using
        End Using

        dgv_gabungan_penyusutan_mesin.Columns.Clear()
        dgv_gabungan_penyusutan_mesin.ColumnHeadersVisible = False
        dgv_gabungan_penyusutan_mesin.RowHeadersVisible = False
        dgv_gabungan_penyusutan_mesin.ColumnCount = 4
        ' Query untuk menghitung jumlah unik kode pada tbdatapenyusutan kategori MESIN
        Dim queryHitung As String = "SELECT COUNT(DISTINCT kode) AS jumlah_mesin " &
                            "FROM tbdatapenyusutan " &
                            "WHERE kode IN (SELECT kode FROM tbindukpenyusutan WHERE kategori_aset = 'MESIN')"
        Using connHitung As New MySqlConnection(sLocalConn)
            Dim cmdHitung As New MySqlCommand(queryHitung, connHitung)
            connHitung.Open()
            Dim jumlahMesin As Integer = CInt(cmdHitung.ExecuteScalar())
            ' Cek apakah lebih dari satu
            If jumlahMesin > 1 Then
                ' Dapatkan Total Nilai Buku Awal dari tbindukpenyusutan
                Dim totalNilaiBukuAwal As Decimal
                Dim queryNilaiBukuAwal As String = "SELECT SUM(nilai_buku) AS total_nilai_buku_awal FROM tbindukpenyusutan WHERE kategori_aset = 'MESIN'"
                Using connTotal As New MySqlConnection(sLocalConn)
                    Dim cmdTotal As New MySqlCommand(queryNilaiBukuAwal, connTotal)
                    connTotal.Open()
                    totalNilaiBukuAwal = CDec(cmdTotal.ExecuteScalar())
                End Using
                ' Tambahkan header untuk data gabungan
                dgv_gabungan_penyusutan_mesin.Rows.Add("MESIN GABUNGAN", "", "", "", "")
                dgv_gabungan_penyusutan_mesin.Rows.Add("", "", "", "", "")
                ' Query untuk menggabungkan data penyusutan per tahun
                Dim queryGabungan As String = "SELECT tahun, SUM(nilai_penyusutan) AS total_penyusutan FROM(tbdatapenyusutan) " &
                    "WHERE kode IN (SELECT kode FROM tbindukpenyusutan WHERE kategori_aset = 'MESIN') GROUP BY tahun ORDER BY tahun"
                Using connGabungan As New MySqlConnection(sLocalConn)
                    Dim cmdGabungan As New MySqlCommand(queryGabungan, connGabungan)
                    connGabungan.Open()

                    Using drGabungan As MySqlDataReader = cmdGabungan.ExecuteReader()
                        If drGabungan.HasRows Then
                            Dim akumPenyusutan As Decimal = 0  ' Inisialisasi Akumulasi Penyusutan
                            Dim nilaiBuku As Decimal = totalNilaiBukuAwal ' Inisialisasi Nilai Buku Awal

                            ' Tambahkan header untuk kolom
                            dgv_gabungan_penyusutan_mesin.Rows.Add("Tahun", "Penyusutan", "Akum Penyusutan", "Nilai Buku", "")

                            While drGabungan.Read()
                                ' Perhitungan Akumulasi Penyusutan
                                akumPenyusutan += CDec(drGabungan("total_penyusutan"))

                                ' Hitung Nilai Buku
                                nilaiBuku = totalNilaiBukuAwal - akumPenyusutan

                                ' Tampilkan data gabungan
                                dgv_gabungan_penyusutan_mesin.Rows.Add(
                                    drGabungan("tahun").ToString(), _
                                    Format(CDec(drGabungan("total_penyusutan")), "#,##0"), _
                                    Format(akumPenyusutan, "#,##0"), _
                                    If(nilaiBuku > 0, Format(nilaiBuku, "#,##0"), "-"), _
                                    "GABUNGAN")
                            End While
                        End If
                    End Using
                End Using
            End If
        End Using

        dgv_penyusutan_tanki.Columns.Clear()
        dgv_penyusutan_tanki.ColumnHeadersVisible = False
        dgv_penyusutan_tanki.RowHeadersVisible = False
        dgv_penyusutan_tanki.ColumnCount = 5
        dgv_penyusutan_tanki.Columns(0).Width = 80 ' Lebar kolom 1
        dgv_penyusutan_tanki.Columns(1).Width = 60 ' Lebar kolom 2
        dgv_penyusutan_tanki.Columns(2).Width = 90 ' Lebar kolom 3
        dgv_penyusutan_tanki.Columns(3).Width = 100 ' Lebar kolom 4
        dgv_penyusutan_tanki.Columns(4).Visible = False ' Sembunyikan kolom kode
        dgv_penyusutan_tanki.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_penyusutan_tanki.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_penyusutan_tanki.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_penyusutan_tanki.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        ' Ambil data dari tbindukpenyusutan
        Using conn As New MySqlConnection(sLocalConn)
            Dim queryInduk As String = "SELECT kode, nama_aset, nilai_buku FROM tbindukpenyusutan WHERE kategori_aset = 'TANKI PENGOLAH LIMBAH' ORDER BY tahun"
            Dim cmdInduk As New MySqlCommand(queryInduk, conn)
            conn.Open()

            Using drInduk As MySqlDataReader = cmdInduk.ExecuteReader()
                If drInduk.HasRows Then
                    While drInduk.Read()
                        ' Baris 1: Tampilkan nama_aset dan "NILAI BUKU"
                        dgv_penyusutan_tanki.Rows.Add(drInduk("nama_aset").ToString(), "", "", "NILAI BUKU", drInduk("kode").ToString())

                        ' Baris 2: Tampilkan nilai_buku
                        dgv_penyusutan_tanki.Rows.Add("", "", "", Format(CDec(drInduk("nilai_buku")), "#,##0"), drInduk("kode").ToString())

                        ' Ambil kode sebagai referensi
                        Dim kodeRef As String = drInduk("kode").ToString()

                        ' Gunakan koneksi baru untuk query kedua
                        Using conn2 As New MySqlConnection(sLocalConn)
                            conn2.Open()

                            ' Query untuk mengambil data tbdatapenyusutan berdasarkan kode
                            Dim queryPenyusutan As String = "SELECT tahun, persentase, nilai_penyusutan, nilai_buku FROM tbdatapenyusutan WHERE kode = @kode ORDER BY tahun"
                            Using cmdPenyusutan As New MySqlCommand(queryPenyusutan, conn2)
                                cmdPenyusutan.Parameters.AddWithValue("@kode", kodeRef)

                                Using drPenyusutan As MySqlDataReader = cmdPenyusutan.ExecuteReader()
                                    If drPenyusutan.HasRows Then
                                        While drPenyusutan.Read()
                                            ' Tampilkan data penyusutan
                                            dgv_penyusutan_tanki.Rows.Add(drPenyusutan("tahun").ToString(), _
                                                          drPenyusutan("persentase").ToString(), _
                                                          Format(CDec(drPenyusutan("nilai_penyusutan")), "#,##0"), _
                                                          Format(CDec(drPenyusutan("nilai_buku")), "#,##0"), _
                                                          kodeRef)
                                        End While
                                    End If
                                End Using
                            End Using
                        End Using

                        ' Tambahkan satu baris kosong
                        dgv_penyusutan_tanki.Rows.Add("", "", "", "", "")
                    End While
                End If
            End Using
        End Using

        dgv_gabungan_penyusutan_tanki.Columns.Clear()
        dgv_gabungan_penyusutan_tanki.ColumnHeadersVisible = False
        dgv_gabungan_penyusutan_tanki.RowHeadersVisible = False
        dgv_gabungan_penyusutan_tanki.ColumnCount = 4
        ' Query untuk menghitung jumlah unik kode pada tbdatapenyusutan kategori MESIN
        Dim queryHitungtanki As String = "SELECT COUNT(DISTINCT kode) AS jumlah_mesin " &
                            "FROM tbdatapenyusutan " &
                            "WHERE kode IN (SELECT kode FROM tbindukpenyusutan WHERE kategori_aset = 'TANKI PENGOLAH LIMBAH')"
        Using connHitung As New MySqlConnection(sLocalConn)
            Dim cmdHitung As New MySqlCommand(queryHitungtanki, connHitung)
            connHitung.Open()
            Dim jumlahMesin As Integer = CInt(cmdHitung.ExecuteScalar())
            ' Cek apakah lebih dari satu
            If jumlahMesin > 1 Then
                ' Dapatkan Total Nilai Buku Awal dari tbindukpenyusutan
                Dim totalNilaiBukuAwal As Decimal
                Dim queryNilaiBukuAwal As String = "SELECT SUM(nilai_buku) AS total_nilai_buku_awal FROM tbindukpenyusutan WHERE kategori_aset = 'TANKI PENGOLAH LIMBAH'"
                Using connTotal As New MySqlConnection(sLocalConn)
                    Dim cmdTotal As New MySqlCommand(queryNilaiBukuAwal, connTotal)
                    connTotal.Open()
                    totalNilaiBukuAwal = CDec(cmdTotal.ExecuteScalar())
                End Using
                ' Tambahkan header untuk data gabungan
                dgv_gabungan_penyusutan_tanki.Rows.Add("TANKI GABUNGAN", "", "", "", "")
                dgv_gabungan_penyusutan_tanki.Rows.Add("", "", "", "", "")
                ' Query untuk menggabungkan data penyusutan per tahun
                Dim queryGabungan As String = "SELECT tahun, SUM(nilai_penyusutan) AS total_penyusutan FROM(tbdatapenyusutan) " &
                    "WHERE kode IN (SELECT kode FROM tbindukpenyusutan WHERE kategori_aset = 'TANKI PENGOLAH LIMBAH') GROUP BY tahun ORDER BY tahun"
                Using connGabungan As New MySqlConnection(sLocalConn)
                    Dim cmdGabungan As New MySqlCommand(queryGabungan, connGabungan)
                    connGabungan.Open()

                    Using drGabungan As MySqlDataReader = cmdGabungan.ExecuteReader()
                        If drGabungan.HasRows Then
                            Dim akumPenyusutan As Decimal = 0  ' Inisialisasi Akumulasi Penyusutan
                            Dim nilaiBuku As Decimal = totalNilaiBukuAwal ' Inisialisasi Nilai Buku Awal

                            ' Tambahkan header untuk kolom
                            dgv_gabungan_penyusutan_tanki.Rows.Add("Tahun", "Penyusutan", "Akum Penyusutan", "Nilai Buku", "")

                            While drGabungan.Read()
                                ' Perhitungan Akumulasi Penyusutan
                                akumPenyusutan += CDec(drGabungan("total_penyusutan"))

                                ' Hitung Nilai Buku
                                nilaiBuku = totalNilaiBukuAwal - akumPenyusutan

                                ' Tampilkan data gabungan
                                dgv_gabungan_penyusutan_tanki.Rows.Add(
                                    drGabungan("tahun").ToString(), _
                                    Format(CDec(drGabungan("total_penyusutan")), "#,##0"), _
                                    Format(akumPenyusutan, "#,##0"), _
                                    If(nilaiBuku > 0, Format(nilaiBuku, "#,##0"), "-"), _
                                    "GABUNGAN")
                            End While
                        End If
                    End Using
                End Using
            End If
        End Using

        'Inventaris
        dgv_penyusutan_inventaris.Columns.Clear()
        dgv_penyusutan_inventaris.ColumnHeadersVisible = False
        dgv_penyusutan_inventaris.RowHeadersVisible = False
        dgv_penyusutan_inventaris.ColumnCount = 5
        dgv_penyusutan_inventaris.Columns(0).Width = 80 ' Lebar kolom 1
        dgv_penyusutan_inventaris.Columns(1).Width = 60 ' Lebar kolom 2
        dgv_penyusutan_inventaris.Columns(2).Width = 90 ' Lebar kolom 3
        dgv_penyusutan_inventaris.Columns(3).Width = 100 ' Lebar kolom 4
        dgv_penyusutan_inventaris.Columns(4).Visible = False ' Sembunyikan kolom kode
        dgv_penyusutan_inventaris.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_penyusutan_inventaris.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_penyusutan_inventaris.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_penyusutan_inventaris.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        ' Ambil data dari tbindukpenyusutan
        Using conn As New MySqlConnection(sLocalConn)
            Dim queryInduk As String = "SELECT kode, nama_aset, nilai_buku FROM tbindukpenyusutan WHERE kategori_aset = 'INVENTARIS' ORDER BY tahun"
            Dim cmdInduk As New MySqlCommand(queryInduk, conn)
            conn.Open()

            Using drInduk As MySqlDataReader = cmdInduk.ExecuteReader()
                If drInduk.HasRows Then
                    While drInduk.Read()
                        ' Baris 1: Tampilkan nama_aset dan "NILAI BUKU"
                        dgv_penyusutan_inventaris.Rows.Add(drInduk("nama_aset").ToString(), "", "", "NILAI BUKU", drInduk("kode").ToString())

                        ' Baris 2: Tampilkan nilai_buku
                        dgv_penyusutan_inventaris.Rows.Add("", "", "", Format(CDec(drInduk("nilai_buku")), "#,##0"), drInduk("kode").ToString())

                        ' Ambil kode sebagai referensi
                        Dim kodeRef As String = drInduk("kode").ToString()

                        ' Gunakan koneksi baru untuk query kedua
                        Using conn2 As New MySqlConnection(sLocalConn)
                            conn2.Open()

                            ' Query untuk mengambil data tbdatapenyusutan berdasarkan kode
                            Dim queryPenyusutan As String = "SELECT tahun, persentase, nilai_penyusutan, nilai_buku FROM tbdatapenyusutan WHERE kode = @kode ORDER BY tahun"
                            Using cmdPenyusutan As New MySqlCommand(queryPenyusutan, conn2)
                                cmdPenyusutan.Parameters.AddWithValue("@kode", kodeRef)

                                Using drPenyusutan As MySqlDataReader = cmdPenyusutan.ExecuteReader()
                                    If drPenyusutan.HasRows Then
                                        While drPenyusutan.Read()
                                            ' Tampilkan data penyusutan
                                            dgv_penyusutan_inventaris.Rows.Add(drPenyusutan("tahun").ToString(), _
                                                          drPenyusutan("persentase").ToString(), _
                                                          Format(CDec(drPenyusutan("nilai_penyusutan")), "#,##0"), _
                                                          Format(CDec(drPenyusutan("nilai_buku")), "#,##0"), _
                                                          kodeRef)
                                        End While
                                    End If
                                End Using
                            End Using
                        End Using

                        ' Tambahkan satu baris kosong
                        dgv_penyusutan_inventaris.Rows.Add("", "", "", "", "")
                    End While
                End If
            End Using
        End Using

        dgv_gabungan_penyusutan_inventaris.Columns.Clear()
        dgv_gabungan_penyusutan_inventaris.ColumnHeadersVisible = False
        dgv_gabungan_penyusutan_inventaris.RowHeadersVisible = False
        dgv_gabungan_penyusutan_inventaris.ColumnCount = 4
        ' Query untuk menghitung jumlah unik kode pada tbdatapenyusutan kategori MESIN
        Dim queryHitunginventaris As String = "SELECT COUNT(DISTINCT kode) AS jumlah_mesin " &
                            "FROM tbdatapenyusutan " &
                            "WHERE kode IN (SELECT kode FROM tbindukpenyusutan WHERE kategori_aset = 'INVENTARIS')"
        Using connHitung As New MySqlConnection(sLocalConn)
            Dim cmdHitung As New MySqlCommand(queryHitunginventaris, connHitung)
            connHitung.Open()
            Dim jumlahMesin As Integer = CInt(cmdHitung.ExecuteScalar())
            ' Cek apakah lebih dari satu
            If jumlahMesin > 1 Then
                ' Dapatkan Total Nilai Buku Awal dari tbindukpenyusutan
                Dim totalNilaiBukuAwal As Decimal
                Dim queryNilaiBukuAwal As String = "SELECT SUM(nilai_buku) AS total_nilai_buku_awal FROM tbindukpenyusutan WHERE kategori_aset = 'INVENTARIS'"
                Using connTotal As New MySqlConnection(sLocalConn)
                    Dim cmdTotal As New MySqlCommand(queryNilaiBukuAwal, connTotal)
                    connTotal.Open()
                    totalNilaiBukuAwal = CDec(cmdTotal.ExecuteScalar())
                End Using
                ' Tambahkan header untuk data gabungan
                dgv_gabungan_penyusutan_inventaris.Rows.Add("INVENTARIS GABUNGAN", "", "", "", "")
                dgv_gabungan_penyusutan_inventaris.Rows.Add("", "", "", "", "")
                ' Query untuk menggabungkan data penyusutan per tahun
                Dim queryGabungan As String = "SELECT tahun, SUM(nilai_penyusutan) AS total_penyusutan FROM(tbdatapenyusutan) " &
                    "WHERE kode IN (SELECT kode FROM tbindukpenyusutan WHERE kategori_aset = 'INVENTARIS') GROUP BY tahun ORDER BY tahun"
                Using connGabungan As New MySqlConnection(sLocalConn)
                    Dim cmdGabungan As New MySqlCommand(queryGabungan, connGabungan)
                    connGabungan.Open()

                    Using drGabungan As MySqlDataReader = cmdGabungan.ExecuteReader()
                        If drGabungan.HasRows Then
                            Dim akumPenyusutan As Decimal = 0  ' Inisialisasi Akumulasi Penyusutan
                            Dim nilaiBuku As Decimal = totalNilaiBukuAwal ' Inisialisasi Nilai Buku Awal

                            ' Tambahkan header untuk kolom
                            dgv_gabungan_penyusutan_inventaris.Rows.Add("Tahun", "Penyusutan", "Akum Penyusutan", "Nilai Buku", "")

                            While drGabungan.Read()
                                ' Perhitungan Akumulasi Penyusutan
                                akumPenyusutan += CDec(drGabungan("total_penyusutan"))

                                ' Hitung Nilai Buku
                                nilaiBuku = totalNilaiBukuAwal - akumPenyusutan

                                ' Tampilkan data gabungan
                                dgv_gabungan_penyusutan_inventaris.Rows.Add(
                                    drGabungan("tahun").ToString(), _
                                    Format(CDec(drGabungan("total_penyusutan")), "#,##0"), _
                                    Format(akumPenyusutan, "#,##0"), _
                                    If(nilaiBuku > 0, Format(nilaiBuku, "#,##0"), "-"), _
                                    "GABUNGAN")
                            End While
                        End If
                    End Using
                End Using
            End If
        End Using

        'Bangunan
        dgv_penyusutan_bangunan.Columns.Clear()
        dgv_penyusutan_bangunan.ColumnHeadersVisible = False
        dgv_penyusutan_bangunan.RowHeadersVisible = False
        dgv_penyusutan_bangunan.ColumnCount = 5
        dgv_penyusutan_bangunan.Columns(0).Width = 80 ' Lebar kolom 1
        dgv_penyusutan_bangunan.Columns(1).Width = 60 ' Lebar kolom 2
        dgv_penyusutan_bangunan.Columns(2).Width = 90 ' Lebar kolom 3
        dgv_penyusutan_bangunan.Columns(3).Width = 100 ' Lebar kolom 4
        dgv_penyusutan_bangunan.Columns(4).Visible = False ' Sembunyikan kolom kode
        dgv_penyusutan_bangunan.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_penyusutan_bangunan.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_penyusutan_bangunan.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_penyusutan_bangunan.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        ' Ambil data dari tbindukpenyusutan
        Using conn As New MySqlConnection(sLocalConn)
            Dim queryInduk As String = "SELECT kode, nama_aset, nilai_buku FROM tbindukpenyusutan WHERE kategori_aset = 'BANGUNAN' ORDER BY tahun"
            Dim cmdInduk As New MySqlCommand(queryInduk, conn)
            conn.Open()

            Using drInduk As MySqlDataReader = cmdInduk.ExecuteReader()
                If drInduk.HasRows Then
                    While drInduk.Read()
                        ' Baris 1: Tampilkan nama_aset dan "NILAI BUKU"
                        dgv_penyusutan_bangunan.Rows.Add(drInduk("nama_aset").ToString(), "", "", "NILAI BUKU", drInduk("kode").ToString())

                        ' Baris 2: Tampilkan nilai_buku
                        dgv_penyusutan_bangunan.Rows.Add("", "", "", Format(CDec(drInduk("nilai_buku")), "#,##0"), drInduk("kode").ToString())

                        ' Ambil kode sebagai referensi
                        Dim kodeRef As String = drInduk("kode").ToString()

                        ' Gunakan koneksi baru untuk query kedua
                        Using conn2 As New MySqlConnection(sLocalConn)
                            conn2.Open()

                            ' Query untuk mengambil data tbdatapenyusutan berdasarkan kode
                            Dim queryPenyusutan As String = "SELECT tahun, persentase, nilai_penyusutan, nilai_buku FROM tbdatapenyusutan WHERE kode = @kode ORDER BY tahun"
                            Using cmdPenyusutan As New MySqlCommand(queryPenyusutan, conn2)
                                cmdPenyusutan.Parameters.AddWithValue("@kode", kodeRef)

                                Using drPenyusutan As MySqlDataReader = cmdPenyusutan.ExecuteReader()
                                    If drPenyusutan.HasRows Then
                                        While drPenyusutan.Read()
                                            ' Tampilkan data penyusutan
                                            dgv_penyusutan_bangunan.Rows.Add(drPenyusutan("tahun").ToString(), _
                                                          drPenyusutan("persentase").ToString(), _
                                                          Format(CDec(drPenyusutan("nilai_penyusutan")), "#,##0"), _
                                                          Format(CDec(drPenyusutan("nilai_buku")), "#,##0"), _
                                                          kodeRef)
                                        End While
                                    End If
                                End Using
                            End Using
                        End Using

                        ' Tambahkan satu baris kosong
                        dgv_penyusutan_bangunan.Rows.Add("", "", "", "", "")
                    End While
                End If
            End Using
        End Using

        dgv_gabungan_penyusutan_bangunan.Columns.Clear()
        dgv_gabungan_penyusutan_bangunan.ColumnHeadersVisible = False
        dgv_gabungan_penyusutan_bangunan.RowHeadersVisible = False
        dgv_gabungan_penyusutan_bangunan.ColumnCount = 4
        ' Query untuk menghitung jumlah unik kode pada tbdatapenyusutan kategori MESIN
        Dim queryHitungBANGUNAN As String = "SELECT COUNT(DISTINCT kode) AS jumlah_mesin " &
                            "FROM tbdatapenyusutan " &
                            "WHERE kode IN (SELECT kode FROM tbindukpenyusutan WHERE kategori_aset = 'BANGUNAN')"
        Using connHitung As New MySqlConnection(sLocalConn)
            Dim cmdHitung As New MySqlCommand(queryHitungBANGUNAN, connHitung)
            connHitung.Open()
            Dim jumlahMesin As Integer = CInt(cmdHitung.ExecuteScalar())
            ' Cek apakah lebih dari satu
            If jumlahMesin > 1 Then
                ' Dapatkan Total Nilai Buku Awal dari tbindukpenyusutan
                Dim totalNilaiBukuAwal As Decimal
                Dim queryNilaiBukuAwal As String = "SELECT SUM(nilai_buku) AS total_nilai_buku_awal FROM tbindukpenyusutan WHERE kategori_aset = 'BANGUNAN'"
                Using connTotal As New MySqlConnection(sLocalConn)
                    Dim cmdTotal As New MySqlCommand(queryNilaiBukuAwal, connTotal)
                    connTotal.Open()
                    totalNilaiBukuAwal = CDec(cmdTotal.ExecuteScalar())
                End Using
                ' Tambahkan header untuk data gabungan
                dgv_gabungan_penyusutan_bangunan.Rows.Add("BANGUNAN GABUNGAN", "", "", "", "")
                dgv_gabungan_penyusutan_bangunan.Rows.Add("", "", "", "", "")
                ' Query untuk menggabungkan data penyusutan per tahun
                Dim queryGabungan As String = "SELECT tahun, SUM(nilai_penyusutan) AS total_penyusutan FROM(tbdatapenyusutan) " &
                    "WHERE kode IN (SELECT kode FROM tbindukpenyusutan WHERE kategori_aset = 'BANGUNAN') GROUP BY tahun ORDER BY tahun"
                Using connGabungan As New MySqlConnection(sLocalConn)
                    Dim cmdGabungan As New MySqlCommand(queryGabungan, connGabungan)
                    connGabungan.Open()

                    Using drGabungan As MySqlDataReader = cmdGabungan.ExecuteReader()
                        If drGabungan.HasRows Then
                            Dim akumPenyusutan As Decimal = 0  ' Inisialisasi Akumulasi Penyusutan
                            Dim nilaiBuku As Decimal = totalNilaiBukuAwal ' Inisialisasi Nilai Buku Awal

                            ' Tambahkan header untuk kolom
                            dgv_gabungan_penyusutan_bangunan.Rows.Add("Tahun", "Penyusutan", "Akum Penyusutan", "Nilai Buku", "")

                            While drGabungan.Read()
                                ' Perhitungan Akumulasi Penyusutan
                                akumPenyusutan += CDec(drGabungan("total_penyusutan"))

                                ' Hitung Nilai Buku
                                nilaiBuku = totalNilaiBukuAwal - akumPenyusutan

                                ' Tampilkan data gabungan
                                dgv_gabungan_penyusutan_bangunan.Rows.Add(
                                    drGabungan("tahun").ToString(), _
                                    Format(CDec(drGabungan("total_penyusutan")), "#,##0"), _
                                    Format(akumPenyusutan, "#,##0"), _
                                    If(nilaiBuku > 0, Format(nilaiBuku, "#,##0"), "-"), _
                                    "GABUNGAN")
                            End While
                        End If
                    End Using
                End Using
            End If
        End Using

        'kendaraan
        dgv_penyusutan_kendaraan.Columns.Clear()
        dgv_penyusutan_kendaraan.ColumnHeadersVisible = False
        dgv_penyusutan_kendaraan.RowHeadersVisible = False
        dgv_penyusutan_kendaraan.ColumnCount = 5
        dgv_penyusutan_kendaraan.Columns(0).Width = 80 ' Lebar kolom 1
        dgv_penyusutan_kendaraan.Columns(1).Width = 60 ' Lebar kolom 2
        dgv_penyusutan_kendaraan.Columns(2).Width = 90 ' Lebar kolom 3
        dgv_penyusutan_kendaraan.Columns(3).Width = 100 ' Lebar kolom 4
        dgv_penyusutan_kendaraan.Columns(4).Visible = False ' Sembunyikan kolom kode
        dgv_penyusutan_kendaraan.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_penyusutan_kendaraan.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgv_penyusutan_kendaraan.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_penyusutan_kendaraan.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        ' Ambil data dari tbindukpenyusutan
        Using conn As New MySqlConnection(sLocalConn)
            Dim queryInduk As String = "SELECT kode, nama_aset, nilai_buku FROM tbindukpenyusutan WHERE kategori_aset = 'KENDARAAN' ORDER BY tahun"
            Dim cmdInduk As New MySqlCommand(queryInduk, conn)
            conn.Open()

            Using drInduk As MySqlDataReader = cmdInduk.ExecuteReader()
                If drInduk.HasRows Then
                    While drInduk.Read()
                        ' Baris 1: Tampilkan nama_aset dan "NILAI BUKU"
                        dgv_penyusutan_kendaraan.Rows.Add(drInduk("nama_aset").ToString(), "", "", "NILAI BUKU", drInduk("kode").ToString())

                        ' Baris 2: Tampilkan nilai_buku
                        dgv_penyusutan_kendaraan.Rows.Add("", "", "", Format(CDec(drInduk("nilai_buku")), "#,##0"), drInduk("kode").ToString())

                        ' Ambil kode sebagai referensi
                        Dim kodeRef As String = drInduk("kode").ToString()

                        ' Gunakan koneksi baru untuk query kedua
                        Using conn2 As New MySqlConnection(sLocalConn)
                            conn2.Open()

                            ' Query untuk mengambil data tbdatapenyusutan berdasarkan kode
                            Dim queryPenyusutan As String = "SELECT tahun, persentase, nilai_penyusutan, nilai_buku FROM tbdatapenyusutan WHERE kode = @kode ORDER BY tahun"
                            Using cmdPenyusutan As New MySqlCommand(queryPenyusutan, conn2)
                                cmdPenyusutan.Parameters.AddWithValue("@kode", kodeRef)

                                Using drPenyusutan As MySqlDataReader = cmdPenyusutan.ExecuteReader()
                                    If drPenyusutan.HasRows Then
                                        While drPenyusutan.Read()
                                            ' Tampilkan data penyusutan
                                            dgv_penyusutan_kendaraan.Rows.Add(drPenyusutan("tahun").ToString(), _
                                                          drPenyusutan("persentase").ToString(), _
                                                          Format(CDec(drPenyusutan("nilai_penyusutan")), "#,##0"), _
                                                          Format(CDec(drPenyusutan("nilai_buku")), "#,##0"), _
                                                          kodeRef)
                                        End While
                                    End If
                                End Using
                            End Using
                        End Using

                        ' Tambahkan satu baris kosong
                        dgv_penyusutan_kendaraan.Rows.Add("", "", "", "", "")
                    End While
                End If
            End Using
        End Using

        dgv_gabungan_penyusutan_kendaraan.Columns.Clear()
        dgv_gabungan_penyusutan_kendaraan.ColumnHeadersVisible = False
        dgv_gabungan_penyusutan_kendaraan.RowHeadersVisible = False
        dgv_gabungan_penyusutan_kendaraan.ColumnCount = 4
        ' Query untuk menghitung jumlah unik kode pada tbdatapenyusutan kategori MESIN
        Dim queryHitungKENDARAAN As String = "SELECT COUNT(DISTINCT kode) AS jumlah_mesin " &
                            "FROM tbdatapenyusutan " &
                            "WHERE kode IN (SELECT kode FROM tbindukpenyusutan WHERE kategori_aset = 'KENDARAAN')"
        Using connHitung As New MySqlConnection(sLocalConn)
            Dim cmdHitung As New MySqlCommand(queryHitungKENDARAAN, connHitung)
            connHitung.Open()
            Dim jumlahMesin As Integer = CInt(cmdHitung.ExecuteScalar())
            ' Cek apakah lebih dari satu
            If jumlahMesin > 1 Then
                ' Dapatkan Total Nilai Buku Awal dari tbindukpenyusutan
                Dim totalNilaiBukuAwal As Decimal
                Dim queryNilaiBukuAwal As String = "SELECT SUM(nilai_buku) AS total_nilai_buku_awal FROM tbindukpenyusutan WHERE kategori_aset = 'KENDARAAN'"
                Using connTotal As New MySqlConnection(sLocalConn)
                    Dim cmdTotal As New MySqlCommand(queryNilaiBukuAwal, connTotal)
                    connTotal.Open()
                    totalNilaiBukuAwal = CDec(cmdTotal.ExecuteScalar())
                End Using
                ' Tambahkan header untuk data gabungan
                dgv_gabungan_penyusutan_kendaraan.Rows.Add("KENDARAAN GABUNGAN", "", "", "", "")
                dgv_gabungan_penyusutan_kendaraan.Rows.Add("", "", "", "", "")
                ' Query untuk menggabungkan data penyusutan per tahun
                Dim queryGabungan As String = "SELECT tahun, SUM(nilai_penyusutan) AS total_penyusutan FROM(tbdatapenyusutan) " &
                    "WHERE kode IN (SELECT kode FROM tbindukpenyusutan WHERE kategori_aset = 'KENDARAAN') GROUP BY tahun ORDER BY tahun"
                Using connGabungan As New MySqlConnection(sLocalConn)
                    Dim cmdGabungan As New MySqlCommand(queryGabungan, connGabungan)
                    connGabungan.Open()

                    Using drGabungan As MySqlDataReader = cmdGabungan.ExecuteReader()
                        If drGabungan.HasRows Then
                            Dim akumPenyusutan As Decimal = 0  ' Inisialisasi Akumulasi Penyusutan
                            Dim nilaiBuku As Decimal = totalNilaiBukuAwal ' Inisialisasi Nilai Buku Awal

                            ' Tambahkan header untuk kolom
                            dgv_gabungan_penyusutan_kendaraan.Rows.Add("Tahun", "Penyusutan", "Akum Penyusutan", "Nilai Buku", "")

                            While drGabungan.Read()
                                ' Perhitungan Akumulasi Penyusutan
                                akumPenyusutan += CDec(drGabungan("total_penyusutan"))

                                ' Hitung Nilai Buku
                                nilaiBuku = totalNilaiBukuAwal - akumPenyusutan

                                ' Tampilkan data gabungan
                                dgv_gabungan_penyusutan_kendaraan.Rows.Add(
                                    drGabungan("tahun").ToString(), _
                                    Format(CDec(drGabungan("total_penyusutan")), "#,##0"), _
                                    Format(akumPenyusutan, "#,##0"), _
                                    If(nilaiBuku > 0, Format(nilaiBuku, "#,##0"), "-"), _
                                    "GABUNGAN")
                            End While
                        End If
                    End Using
                End Using
            End If
        End Using
    End Sub

    Private Sub Export(ByVal filePath As String)
        Try
            Dim txttahun As New TextBox
            txttahun.Text = dtp_tahun.Value.ToString("yyyy")

            Using package As New ExcelPackage()

                ' Sheet 4: MASUKAN
                Dim ws4 As ExcelWorksheet = package.Workbook.Worksheets.Add("MASUKAN")
                ws4.Cells(1, 1).Value = "DATA MASUKAN TAHUN " & txttahun.Text
                ws4.Cells(1, 1, 1, dgv_masukan.Columns.Count).Merge = True
                For col As Integer = 0 To dgv_masukan.Columns.Count - 1
                    ws4.Cells(3, col + 1).Value = dgv_masukan.Columns(col).HeaderText
                    ws4.Cells(3, col + 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws4.Cells(3, col + 1).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                Next
                For row As Integer = 0 To dgv_masukan.Rows.Count - 1
                    For col As Integer = 0 To dgv_masukan.Columns.Count - 1
                        ws4.Cells(row + 4, col + 1).Value = dgv_masukan.Rows(row).Cells(col).Value
                        ws4.Cells(row + 4, col + 1).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                        Dim cell = ws4.Cells(row + 4, col + 1)
                        Dim value = dgv_masukan.Rows(row).Cells(col).Value
                        If TypeOf value Is Double Or TypeOf value Is Decimal Then
                            If value < 0 Then
                                ' Format nilai negatif dengan tanda kurung
                                cell.Value = value
                                cell.Style.Numberformat.Format = "#,##0;(#,##0.00)" ' Format Excel untuk tanda kurung
                            Else
                                ' Format nilai positif biasa
                                cell.Value = value
                                cell.Style.Numberformat.Format = "#,##0.00"
                            End If
                        Else
                            cell.Value = value
                        End If
                    Next
                Next

                Dim totalrowmasukan As Integer = dgv_masukan.Rows.Count + 6
                For row As Integer = 0 To dgv_list_masukan.Rows.Count - 1
                    For col As Integer = 0 To dgv_list_masukan.Columns.Count - 1
                        Dim cell = ws4.Cells(row + totalrowmasukan, col + 1)
                        Dim value = dgv_list_masukan(col, row).Value
                        If TypeOf value Is Double Or TypeOf value Is Decimal Then
                            If value < 0 Then
                                ' Format nilai negatif dengan tanda kurung
                                cell.Value = value
                                cell.Style.Numberformat.Format = "#,##0;(#,##0.00)" ' Format Excel untuk tanda kurung
                            Else
                                ' Format nilai positif biasa
                                cell.Value = value
                                cell.Style.Numberformat.Format = "#,##0.00"
                            End If
                        Else
                            cell.Value = value
                        End If
                        cell.Style.Border.BorderAround(ExcelBorderStyle.Thin)
                    Next
                Next

                ws4.Cells(ws4.Dimension.Address).AutoFitColumns()
                ' Akhir Sheet 4

                ' Sheet 5: KELUARAN
                Dim ws5 As ExcelWorksheet = package.Workbook.Worksheets.Add("KELUARAN")
                ws5.Cells(1, 1).Value = "DATA KELUARAN TAHUN " & txttahun.Text
                ws5.Cells(1, 1, 1, dgv_keluaran.Columns.Count).Merge = True
                For col As Integer = 0 To dgv_keluaran.Columns.Count - 1
                    ws5.Cells(3, col + 1).Value = dgv_keluaran.Columns(col).HeaderText
                    ws5.Cells(3, col + 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws5.Cells(3, col + 1).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                Next
                For row As Integer = 0 To dgv_keluaran.Rows.Count - 1
                    For col As Integer = 0 To dgv_keluaran.Columns.Count - 1
                        ws5.Cells(row + 4, col + 1).Value = dgv_keluaran.Rows(row).Cells(col).Value
                        ws5.Cells(row + 4, col + 1).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                        Dim cell = ws5.Cells(row + 4, col + 1)
                        Dim value = dgv_keluaran.Rows(row).Cells(col).Value
                        If TypeOf value Is Double Or TypeOf value Is Decimal Then
                            If value < 0 Then
                                ' Format nilai negatif dengan tanda kurung
                                cell.Value = value
                                cell.Style.Numberformat.Format = "#,##0;(#,##0.00)" ' Format Excel untuk tanda kurung
                            Else
                                ' Format nilai positif biasa
                                cell.Value = value
                                cell.Style.Numberformat.Format = "#,##0.00"
                            End If
                        Else
                            cell.Value = value
                        End If

                        Dim dgvCell = dgv_keluaran.Rows(row).Cells(col)
                        ' Terapkan warna teks (ForeColor)
                        Dim foreColor As Color = dgvCell.Style.ForeColor
                        If foreColor <> Color.Empty Then
                            cell.Style.Font.Color.SetColor(foreColor)
                        End If

                        ' Terapkan warna latar belakang (BackColor)
                        Dim backColor As Color = dgvCell.Style.BackColor
                        If backColor <> Color.Empty Then
                            cell.Style.Fill.PatternType = ExcelFillStyle.Solid
                            cell.Style.Fill.BackgroundColor.SetColor(backColor)
                        End If
                    Next
                Next

                Dim totalrowkeluaran As Integer = dgv_keluaran.Rows.Count + 6
                For row As Integer = 0 To dgv_list_keluaran.Rows.Count - 1
                    For col As Integer = 0 To dgv_list_keluaran.Columns.Count - 1
                        Dim cell = ws5.Cells(row + totalrowkeluaran, col + 1)
                        Dim value = dgv_list_keluaran(col, row).Value
                        If TypeOf value Is Double Or TypeOf value Is Decimal Then
                            If value < 0 Then
                                ' Format nilai negatif dengan tanda kurung
                                cell.Value = value
                                cell.Style.Numberformat.Format = "#,##0;(#,##0.00)" ' Format Excel untuk tanda kurung
                            Else
                                ' Format nilai positif biasa
                                cell.Value = value
                                cell.Style.Numberformat.Format = "#,##0.00"
                            End If
                        Else
                            cell.Value = value
                        End If
                        cell.Style.Border.BorderAround(ExcelBorderStyle.Thin)
                    Next
                Next

                Dim totalrowsatuan As Integer = dgv_keluaran.Rows.Count + 6
                For row As Integer = 0 To dgv_keluaran_satuan.Rows.Count - 1
                    For col As Integer = 0 To dgv_keluaran_satuan.Columns.Count - 1
                        Dim cell = ws5.Cells(row + totalrowsatuan, col + 4)
                        Dim value = dgv_keluaran_satuan(col, row).Value
                        If TypeOf value Is Double Or TypeOf value Is Decimal Then
                            If value < 0 Then
                                ' Format nilai negatif dengan tanda kurung
                                cell.Value = value
                                cell.Style.Numberformat.Format = "#,##0;(#,##0.00)" ' Format Excel untuk tanda kurung
                            Else
                                ' Format nilai positif biasa
                                cell.Value = value
                                cell.Style.Numberformat.Format = "#,##0.00"
                            End If
                        Else
                            cell.Value = value
                        End If
                        cell.Style.Border.BorderAround(ExcelBorderStyle.Thin)
                    Next
                Next
                ws5.Cells(3, 2).Value = "DPP CELUPAN"
                ws5.Cells(3, 3).Value = "DPP KAIN"
                ws5.Cells(3, 4).Value = "DPP TOTAL"
                ws5.Cells(3, 5).Value = "DPP SESUAI SPT"
                ws5.Cells(3, 6).Value = "SELISIH"
                ws5.Cells(3, 7).Value = ""
                ws5.Cells(3, 8).Value = "KG CELUPAN"
                ws5.Cells(3, 9).Value = "MTR KAIN"
                ws5.Cells(3, 10).Value = "YARD KAIN"

                ws5.Cells(ws5.Dimension.Address).AutoFitColumns()
                ' Akhir Sheet 5

                ' Sheet 6: SPT Masa PPN
                Dim ws6 As ExcelWorksheet = package.Workbook.Worksheets.Add("SPT Masa PPN")
                ws6.Cells(1, 1).Value = "SPT MASA PPN EFAKTUR TAHUN " & txttahun.Text
                ws6.Cells(1, 1, 1, dgv_spt_clone.Columns.Count).Merge = True
                For col As Integer = 0 To dgv_spt_clone.Columns.Count - 1
                    ws6.Cells(3, col + 1).Value = dgv_spt_clone.Columns(col).HeaderText
                    ws6.Cells(3, col + 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws6.Cells(3, col + 1).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                Next
                For row As Integer = 0 To dgv_spt_clone.Rows.Count - 1
                    For col As Integer = 0 To dgv_spt_clone.Columns.Count - 1
                        Dim cell = ws6.Cells(row + 4, col + 1)
                        Dim value = dgv_spt_clone(col, row).Value
                        If TypeOf value Is Double Or TypeOf value Is Decimal Then
                            If value < 0 Then
                                ' Format nilai negatif dengan tanda kurung
                                cell.Value = value
                                cell.Style.Numberformat.Format = "#,##0;(#,##0.00)" ' Format Excel untuk tanda kurung
                            Else
                                ' Format nilai positif biasa
                                cell.Value = value
                                cell.Style.Numberformat.Format = "#,##0.00"
                            End If
                        Else
                            cell.Value = value
                        End If
                        cell.Style.Border.BorderAround(ExcelBorderStyle.Thin)
                    Next
                Next
                For col As Integer = 1 To dgv_spt_clone.Columns.Count + 1
                    ws6.Column(col).Width = 145 / 7.5 ' Mengonversi px ke Excel units
                Next

                ' Tambahkan baris total
                Dim totalRow As Integer = dgv_spt_clone.Rows.Count + 4
                For col As Integer = 1 To dgv_spt_clone.Columns.Count - 1
                    ws6.Cells(totalRow, col + 1).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                Next
                Dim nilaimasukan As Decimal = 0
                Dim nilaikeluaran As Decimal = 0
                Dim ppnmasukan As Decimal = 0
                Dim ppnkeluaran As Decimal = 0
                Dim ppndisetor As Decimal = 0
                For row As Integer = 0 To dgv_spt_clone.Rows.Count - 1
                    nilaimasukan += dgv_spt_clone(1, row).Value
                    nilaikeluaran += dgv_spt_clone(2, row).Value
                    ppnmasukan += dgv_spt_clone(5, row).Value
                    ppnkeluaran += dgv_spt_clone(6, row).Value
                    ppndisetor += dgv_spt_clone(7, row).Value
                Next
                ws6.Cells(totalRow, 2).Value = nilaimasukan
                ws6.Cells(totalRow, 3).Value = nilaikeluaran
                ws6.Cells(totalRow, 6).Value = ppnmasukan
                ws6.Cells(totalRow, 7).Value = ppnkeluaran
                ws6.Cells(totalRow, 8).Value = ppndisetor
                For i As Integer = 2 To 8
                    ws6.Cells(totalRow, i).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                    ws6.Cells(totalRow, i).Style.Numberformat.Format = "#,##0.00"
                Next

                ws6.Cells(totalRow + 2, 1).Value = "SPT MASA PPN AML TAHUN " & txttahun.Text
                ws6.Cells(totalRow + 2, 1, totalRow + 2, dgv_spt_aml.Columns.Count).Merge = True
                For col As Integer = 0 To dgv_spt_aml.Columns.Count - 1
                    ws6.Cells(totalRow + 4, col + 1).Value = dgv_spt_aml.Columns(col).HeaderText
                    ws6.Cells(totalRow + 4, col + 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws6.Cells(totalRow + 4, col + 1).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                Next
                For row As Integer = 0 To dgv_spt_aml.Rows.Count - 1
                    For col As Integer = 0 To dgv_spt_aml.Columns.Count - 1
                        Dim cell = ws6.Cells(row + totalRow + 5, col + 1)
                        Dim value = dgv_spt_aml(col, row).Value
                        If TypeOf value Is Double Or TypeOf value Is Decimal Then
                            If value < 0 Then
                                ' Format nilai negatif dengan tanda kurung
                                cell.Value = value
                                cell.Style.Numberformat.Format = "#,##0;(#,##0.00)" ' Format Excel untuk tanda kurung
                            Else
                                ' Format nilai positif biasa
                                cell.Value = value
                                cell.Style.Numberformat.Format = "#,##0.00"
                            End If
                        Else
                            cell.Value = value
                        End If
                        cell.Style.Border.BorderAround(ExcelBorderStyle.Thin)
                    Next
                Next

                ' Tambahkan baris total
                Dim akhirbaris As Integer = dgv_spt_aml.Rows.Count + totalRow + 5
                For col As Integer = 1 To dgv_spt_aml.Columns.Count - 1
                    ws6.Cells(akhirbaris, col + 1).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                Next
                Dim nilaimasukanaml As Decimal = 0
                Dim nilaikeluaranaml As Decimal = 0
                Dim ppnmasukanaml As Decimal = 0
                Dim ppnkeluaranaml As Decimal = 0
                Dim ppndisetoraml As Decimal = 0
                For row As Integer = 0 To dgv_spt_aml.Rows.Count - 1
                    nilaimasukanaml += dgv_spt_aml(1, row).Value
                    nilaikeluaranaml += dgv_spt_aml(2, row).Value
                    ppnmasukanaml += dgv_spt_aml(5, row).Value
                    ppnkeluaranaml += dgv_spt_aml(6, row).Value
                    ppndisetoraml += dgv_spt_aml(7, row).Value
                Next
                ws6.Cells(akhirbaris, 2).Value = nilaimasukanaml
                ws6.Cells(akhirbaris, 3).Value = nilaikeluaranaml
                ws6.Cells(akhirbaris, 6).Value = ppnmasukanaml
                ws6.Cells(akhirbaris, 7).Value = ppnkeluaranaml
                ws6.Cells(akhirbaris, 8).Value = ppndisetoraml
                For i As Integer = 2 To 8
                    ws6.Cells(akhirbaris, i).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                    ws6.Cells(akhirbaris, i).Style.Numberformat.Format = "#,##0.00"
                Next
                ' Akhir sheet 6

                ' Sheet 7: PLN GARAM COAL
                Dim ws7 As ExcelWorksheet = package.Workbook.Worksheets.Add("PLN GARAM COAL")
                ws7.Cells(1, 1).Value = "DATA PLN GARAM COAL TAHUN " & txttahun.Text
                ws7.Cells(1, 1, 1, dgv_pln.Columns.Count).Merge = True
                'ws7.Cells(1, 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                'ws7.Cells(1, 1).Style.Font.Bold = True
                'Header PLN GARAM COAL
                For col As Integer = 0 To dgv_pln.Columns.Count - 1
                    ws7.Cells(3, col + 1).Value = dgv_pln.Columns(col).HeaderText
                    'ws7.Cells(3, col + 1).Style.Font.Bold = True
                    ws7.Cells(3, col + 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws7.Cells(3, col + 1).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                Next
                ' Data PLN GARAM COAL
                For row As Integer = 0 To dgv_pln.Rows.Count - 1
                    For col As Integer = 0 To dgv_pln.Columns.Count - 1
                        ws7.Cells(row + 4, col + 1).Value = dgv_pln.Rows(row).Cells(col).Value
                        ws7.Cells(row + 4, col + 1).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                        Dim cell = ws7.Cells(row + 4, col + 1)
                        Dim value = dgv_pln.Rows(row).Cells(col).Value
                        If TypeOf value Is Double Or TypeOf value Is Decimal Then
                            If value < 0 Then
                                ' Format nilai negatif dengan tanda kurung
                                cell.Value = value
                                cell.Style.Numberformat.Format = "#,##0;(#,##0.00)" ' Format Excel untuk tanda kurung
                            Else
                                ' Format nilai positif biasa
                                cell.Value = value
                                cell.Style.Numberformat.Format = "#,##0.00"
                            End If
                        Else
                            cell.Value = value
                        End If
                    Next
                Next
                'ws7.Cells(ws7.Dimension.Address).AutoFitColumns()
                For col As Integer = 1 To dgv_pln.Columns.Count + 1
                    ws7.Column(col).Width = 135 / 7.5 ' Mengonversi px ke Excel units
                Next
                ws7.Cells(3, 2).Value = "PLN"
                ws7.Cells(3, 3).Value = "GARAM"
                ws7.Cells(3, 4).Value = "COAL"
                ws7.Cells(3, 5).Value = "PPH 22 COAL"

                ' Akhir Sheet 7

                ' Sheet 8: DAFTAR BUKTI POTONG
                Dim ws8 As ExcelWorksheet = package.Workbook.Worksheets.Add("DAFTAR BUKTI POTONG")
                ws8.Cells(1, 1, 1, dgv_bukpot.Columns.Count - 1).Merge = True
                ws8.Cells(1, 1).Value = "DAFTAR BUKTI POTONG TAHUN PAJAK " & txttahun.Text
                'ws8.Cells(1, 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                'ws8.Cells(1, 1).Style.Font.Bold = True
                ' Header DAFTAR BUKTI POTONG
                Dim headers = {"NO", "NAMA CUSTOMER PEMOTONG", "NPWP CUSTOMER", "TANGGAL FP", "NO FAKTUR PAJAK", "NILAI DPP", "PPN", "PPH23", "PPH23 ACTUAL", "NO BUKPOT", "TGL BUKPOT", "MASA BUKPOT"}
                For col As Integer = 0 To headers.Length - 1
                    ws8.Cells(3, col + 1).Value = headers(col)
                    'ws8.Cells(3, col + 1).Style.Font.Bold = True
                    ws8.Cells(3, col + 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws8.Cells(3, col + 1).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                    'ws8.Cells(3, col + 1).Style.Fill.PatternType = ExcelFillStyle.Solid
                    'ws8.Cells(3, col + 1).Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightGray)
                Next
                ' Mengelompokkan data berdasarkan nilai gabung_bukpot
                Dim groupedData As New List(Of Dictionary(Of String, Object))
                Dim tempGroup As Dictionary(Of String, Object) = Nothing
                For row As Integer = 0 To dgv_bukpot.Rows.Count - 1
                    Dim gabung_bukpot = dgv_bukpot.Rows(row).Cells("gabung_bukpot").Value.ToString()
                    If tempGroup IsNot Nothing AndAlso tempGroup("gabung_bukpot").ToString() = gabung_bukpot Then
                        ' Gabungkan nilai pph23_actual
                        tempGroup("pph23_actual") = CDbl(tempGroup("pph23_actual")) + CDbl(dgv_bukpot.Rows(row).Cells("pph23_actual").Value)
                        tempGroup("Rows").Add(row)
                    Else
                        ' Tambahkan grup baru
                        If tempGroup IsNot Nothing Then groupedData.Add(tempGroup)
                        tempGroup = New Dictionary(Of String, Object) From {
                            {"gabung_bukpot", gabung_bukpot},
                            {"pph23_actual", dgv_bukpot.Rows(row).Cells("pph23_actual").Value},
                            {"Rows", New List(Of Integer) From {row}}
                        }
                    End If
                Next
                If tempGroup IsNot Nothing Then groupedData.Add(tempGroup)

                ' Mengisi data ke Excel
                Dim rowIndex As Integer = 4
                For Each group In groupedData
                    Dim Rows = group("Rows")
                    Dim startRow = rowIndex
                    Dim endRow = rowIndex + Rows.Count - 1

                    For Each rowIndexInGroup In Rows
                        ' Menulis nomor urut
                        ws8.Cells(rowIndex, 1).Value = rowIndex - 3
                        ws8.Cells(rowIndex, 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                        ws8.Cells(rowIndex, 1).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                        ' Menulis data ke kolom lain
                        Dim colIndexData As Integer = 1
                        For col As Integer = 0 To dgv_bukpot.Columns.Count - 1
                            If dgv_bukpot.Columns(col).Name <> "id_jual" AndAlso dgv_bukpot.Columns(col).Name <> "gabung_bukpot" Then
                                colIndexData += 1
                                Dim cell = ws8.Cells(rowIndex, colIndexData)
                                Dim value = dgv_bukpot.Rows(rowIndexInGroup).Cells(col).Value

                                ' Format khusus untuk kolom tertentu
                                Select Case dgv_bukpot.Columns(col).Name
                                    Case "tanggal", "tgl_bukpot"
                                        ' Format tanggal menjadi 19-Jan-2024
                                        If value IsNot Nothing AndAlso IsDate(value) Then
                                            cell.Value = CDate(value)
                                            cell.Style.Numberformat.Format = "dd-MMM-yyyy"
                                        End If
                                    Case "masa_bukpot"
                                        ' Format masa_bukpot menjadi Januari-24
                                        If value IsNot Nothing AndAlso IsDate(value) Then
                                            cell.Value = CDate(value).ToString("MMMM-yy")
                                        End If
                                        cell.Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                                    Case "no_bukpot"
                                        ' Rata kanan untuk no_bukpot
                                        cell.Value = value.ToString()
                                        cell.Style.Numberformat.Format = "@"
                                        cell.Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                                    Case "pph23_actual"
                                        If rowIndex = startRow Then
                                            ' Tuliskan nilai hasil penjumlahan pada baris pertama
                                            cell.Value = CDbl(group("pph23_actual"))
                                            cell.Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                                            cell.Style.Numberformat.Format = "#,##0.00"
                                            cell.Style.VerticalAlignment = ExcelVerticalAlignment.Center
                                            ' Merge cell pph23_actual
                                            ws8.Cells(startRow, colIndexData, endRow, colIndexData).Merge = True
                                        End If
                                    Case Else
                                        ' Default untuk kolom lainnya
                                        If TypeOf value Is Double Or TypeOf value Is Decimal Then
                                            cell.Value = value
                                            cell.Style.Numberformat.Format = "#,##0.00"
                                        Else
                                            cell.Value = value.ToString()
                                        End If
                                End Select
                                cell.Style.Border.BorderAround(ExcelBorderStyle.Thin)
                            End If
                        Next
                        rowIndex += 1
                    Next
                Next
                ' Menyesuaikan lebar kolom
                ws8.Cells(ws8.Dimension.Address).AutoFitColumns()
                'Akhir sheet 8

                'Sheet 9 : Rincian penyusutan
                Dim ws9 As ExcelWorksheet = package.Workbook.Worksheets.Add("RINCIAN PENYUSUTAN")
                ws9.Cells(2, 2).Value = "MESIN"
                ws9.Cells(2, 2).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                For col As Integer = 0 To dgv_induk_penyusutan_mesin.Columns.Count - 1
                    ws9.Cells(2, col + 3).Value = dgv_induk_penyusutan_mesin.Columns(col).HeaderText
                    ws9.Cells(2, col + 3).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws9.Cells(2, col + 3).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                Next
                Dim baris_mesin As Integer = 0
                'For row As Integer = 0 To dgv_induk_penyusutan_mesin.Rows.Count - 1
                '    For col As Integer = 0 To dgv_induk_penyusutan_mesin.Columns.Count - 1
                '        ws9.Cells(row + 3, col + 3).Value = dgv_induk_penyusutan_mesin.Rows(row).Cells(col).Value
                '        ws9.Cells(row + 3, col + 3).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                '        Dim cell = ws9.Cells(row + 3, col + 3)
                '        Dim value = dgv_induk_penyusutan_mesin.Rows(row).Cells(col).Value
                '        If TypeOf value Is Double Or TypeOf value Is Decimal Then
                '            If value < 0 Then
                '                cell.Value = value
                '                cell.Style.Numberformat.Format = "#,##0;(#,##0)" ' Format Excel untuk tanda kurung
                '            Else
                '                cell.Value = value
                '                cell.Style.Numberformat.Format = "#,##0"
                '            End If
                '        Else
                '            cell.Value = value
                '        End If
                '        ws9.Cells(row + 3, 3).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                '        ws9.Cells(row + 3, 4).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                '        ws9.Cells(row + 3, 5).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                '    Next
                '    baris_mesin += 1
                'Next

                For row As Integer = 0 To dgv_induk_penyusutan_mesin.Rows.Count - 1
                    For col As Integer = 0 To dgv_induk_penyusutan_mesin.Columns.Count - 1
                        ws9.Cells(row + 3, col + 3).Value = dgv_induk_penyusutan_mesin.Rows(row).Cells(col).Value
                        ws9.Cells(row + 3, col + 3).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                        Dim cell = ws9.Cells(row + 3, col + 3)
                        Dim value = dgv_induk_penyusutan_mesin.Rows(row).Cells(col).Value
                        If value IsNot Nothing AndAlso Not IsDBNull(value) Then
                            Dim numericValue As Decimal
                            If col = 0 Then
                                cell.Value = value
                            Else
                                If Decimal.TryParse(value.ToString(), numericValue) Then
                                    ' Jika angka negatif, gunakan format Excel dengan tanda kurung
                                    If numericValue < 0 Then
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0;(#,##0)"
                                    Else
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0"
                                    End If
                                Else
                                    ' Jika bukan angka, tetap masukkan sebagai teks
                                    cell.Value = value.ToString()
                                End If
                            End If
                        Else
                            cell.Value = "" ' Pastikan tidak ada null di Excel
                        End If
                        ws9.Cells(row + 3, 3).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                        ws9.Cells(row + 3, 4).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                        ws9.Cells(row + 3, 5).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                    Next
                    baris_mesin += 1
                Next
                ws9.Cells(2, 2, baris_mesin + 2, 2).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                ws9.Cells(2, 2, baris_mesin + 2, 2).Style.VerticalAlignment = ExcelVerticalAlignment.Center
                ws9.Cells(2, 2, baris_mesin + 2, 2).Merge = True
                ws9.Cells(2, 2, baris_mesin + 2, 2).Style.Border.BorderAround(ExcelBorderStyle.Thin)

                ws9.Cells(2, 7).Value = "TANKI"
                ws9.Cells(2, 7).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                For col As Integer = 0 To dgv_induk_penyusutan_tanki.Columns.Count - 1
                    ws9.Cells(2, col + 8).Value = dgv_induk_penyusutan_tanki.Columns(col).HeaderText
                    ws9.Cells(2, col + 8).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws9.Cells(2, col + 8).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                Next
                Dim baris_tanki As Integer = 0
                For row As Integer = 0 To dgv_induk_penyusutan_tanki.Rows.Count - 1
                    For col As Integer = 0 To dgv_induk_penyusutan_tanki.Columns.Count - 1
                        ws9.Cells(row + 3, col + 8).Value = dgv_induk_penyusutan_tanki.Rows(row).Cells(col).Value
                        ws9.Cells(row + 3, col + 8).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                        Dim cell = ws9.Cells(row + 3, col + 8)
                        Dim value = dgv_induk_penyusutan_tanki.Rows(row).Cells(col).Value
                        'If TypeOf value Is Double Or TypeOf value Is Decimal Then
                        '    If value < 0 Then
                        '        cell.Value = value
                        '        cell.Style.Numberformat.Format = "#,##0;(#,##0)" ' Format Excel untuk tanda kurung
                        '    Else
                        '        cell.Value = value
                        '        cell.Style.Numberformat.Format = "#,##0"
                        '    End If
                        'Else
                        '    cell.Value = value
                        'End If
                        If value IsNot Nothing AndAlso Not IsDBNull(value) Then
                            Dim numericValue As Decimal
                            If col = 0 Then
                                cell.Value = value
                            Else
                                If Decimal.TryParse(value.ToString(), numericValue) Then
                                    ' Jika angka negatif, gunakan format Excel dengan tanda kurung
                                    If numericValue < 0 Then
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0;(#,##0)"
                                    Else
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0"
                                    End If
                                Else
                                    ' Jika bukan angka, tetap masukkan sebagai teks
                                    cell.Value = value.ToString()
                                End If
                            End If
                        Else
                            cell.Value = "" ' Pastikan tidak ada null di Excel
                        End If
                        ws9.Cells(row + 3, 8).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                        ws9.Cells(row + 3, 9).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                        ws9.Cells(row + 3, 10).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                    Next
                    baris_tanki += 1
                Next
                ws9.Cells(2, 7, baris_tanki + 2, 7).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                ws9.Cells(2, 7, baris_tanki + 2, 7).Style.VerticalAlignment = ExcelVerticalAlignment.Center
                ws9.Cells(2, 7, baris_tanki + 2, 7).Merge = True
                ws9.Cells(2, 7, baris_tanki + 2, 7).Style.Border.BorderAround(ExcelBorderStyle.Thin)

                ws9.Cells(2, 12).Value = "INVENTARIS"
                ws9.Cells(2, 12).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                For col As Integer = 0 To dgv_induk_penyusutan_inventaris.Columns.Count - 1
                    ws9.Cells(2, col + 13).Value = dgv_induk_penyusutan_inventaris.Columns(col).HeaderText
                    ws9.Cells(2, col + 13).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws9.Cells(2, col + 13).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                Next
                Dim baris_inventaris As Integer = 0
                For row As Integer = 0 To dgv_induk_penyusutan_inventaris.Rows.Count - 1
                    For col As Integer = 0 To dgv_induk_penyusutan_inventaris.Columns.Count - 1
                        ws9.Cells(row + 3, col + 13).Value = dgv_induk_penyusutan_inventaris.Rows(row).Cells(col).Value
                        ws9.Cells(row + 3, col + 13).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                        Dim cell = ws9.Cells(row + 3, col + 13)
                        Dim value = dgv_induk_penyusutan_inventaris.Rows(row).Cells(col).Value
                        'If TypeOf value Is Double Or TypeOf value Is Decimal Then
                        '    If value < 0 Then
                        '        cell.Value = value
                        '        cell.Style.Numberformat.Format = "#,##0;(#,##0)" ' Format Excel untuk tanda kurung
                        '    Else
                        '        cell.Value = value
                        '        cell.Style.Numberformat.Format = "#,##0"
                        '    End If
                        'Else
                        '    cell.Value = value
                        'End If
                        If value IsNot Nothing AndAlso Not IsDBNull(value) Then
                            Dim numericValue As Decimal
                            If col = 0 Then
                                cell.Value = value
                            Else
                                If Decimal.TryParse(value.ToString(), numericValue) Then
                                    ' Jika angka negatif, gunakan format Excel dengan tanda kurung
                                    If numericValue < 0 Then
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0;(#,##0)"
                                    Else
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0"
                                    End If
                                Else
                                    ' Jika bukan angka, tetap masukkan sebagai teks
                                    cell.Value = value.ToString()
                                End If
                            End If
                        Else
                            cell.Value = "" ' Pastikan tidak ada null di Excel
                        End If
                        ws9.Cells(row + 3, 13).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                        ws9.Cells(row + 3, 14).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                        ws9.Cells(row + 3, 15).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                    Next
                    baris_inventaris += 1
                Next
                ws9.Cells(2, 12, baris_inventaris + 2, 12).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                ws9.Cells(2, 12, baris_inventaris + 2, 12).Style.VerticalAlignment = ExcelVerticalAlignment.Center
                ws9.Cells(2, 12, baris_inventaris + 2, 12).Merge = True
                ws9.Cells(2, 12, baris_inventaris + 2, 12).Style.Border.BorderAround(ExcelBorderStyle.Thin)

                ws9.Cells(2, 17).Value = "BANGUNAN"
                ws9.Cells(2, 17).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                For col As Integer = 0 To dgv_induk_penyusutan_bangunan.Columns.Count - 1
                    ws9.Cells(2, col + 18).Value = dgv_induk_penyusutan_bangunan.Columns(col).HeaderText
                    ws9.Cells(2, col + 18).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws9.Cells(2, col + 18).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                Next
                Dim baris_bangunan As Integer = 0
                For row As Integer = 0 To dgv_induk_penyusutan_bangunan.Rows.Count - 1
                    For col As Integer = 0 To dgv_induk_penyusutan_bangunan.Columns.Count - 1
                        ws9.Cells(row + 3, col + 18).Value = dgv_induk_penyusutan_bangunan.Rows(row).Cells(col).Value
                        ws9.Cells(row + 3, col + 18).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                        Dim cell = ws9.Cells(row + 3, col + 18)
                        Dim value = dgv_induk_penyusutan_bangunan.Rows(row).Cells(col).Value
                        'If TypeOf value Is Double Or TypeOf value Is Decimal Then
                        '    If value < 0 Then
                        '        cell.Value = value
                        '        cell.Style.Numberformat.Format = "#,##0;(#,##0)" ' Format Excel untuk tanda kurung
                        '    Else
                        '        cell.Value = value
                        '        cell.Style.Numberformat.Format = "#,##0"
                        '    End If
                        'Else
                        '    cell.Value = value
                        'End If
                        If value IsNot Nothing AndAlso Not IsDBNull(value) Then
                            Dim numericValue As Decimal
                            If col = 0 Then
                                cell.Value = value
                            Else
                                If Decimal.TryParse(value.ToString(), numericValue) Then
                                    ' Jika angka negatif, gunakan format Excel dengan tanda kurung
                                    If numericValue < 0 Then
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0;(#,##0)"
                                    Else
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0"
                                    End If
                                Else
                                    ' Jika bukan angka, tetap masukkan sebagai teks
                                    cell.Value = value.ToString()
                                End If
                            End If
                        Else
                            cell.Value = "" ' Pastikan tidak ada null di Excel
                        End If
                        ws9.Cells(row + 3, 18).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                        ws9.Cells(row + 3, 19).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                        ws9.Cells(row + 3, 20).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                    Next
                    baris_bangunan += 1
                Next
                ws9.Cells(2, 17, baris_bangunan + 2, 17).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                ws9.Cells(2, 17, baris_bangunan + 2, 17).Style.VerticalAlignment = ExcelVerticalAlignment.Center
                ws9.Cells(2, 17, baris_bangunan + 2, 17).Merge = True
                ws9.Cells(2, 17, baris_bangunan + 2, 17).Style.Border.BorderAround(ExcelBorderStyle.Thin)

                ws9.Cells(2, 22).Value = "KENDARAAN"
                ws9.Cells(2, 22).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                For col As Integer = 0 To dgv_induk_penyusutan_kendaraan.Columns.Count - 1
                    ws9.Cells(2, col + 23).Value = dgv_induk_penyusutan_kendaraan.Columns(col).HeaderText
                    ws9.Cells(2, col + 23).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws9.Cells(2, col + 23).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                Next
                Dim baris_kendaraan As Integer = 0
                For row As Integer = 0 To dgv_induk_penyusutan_kendaraan.Rows.Count - 1
                    For col As Integer = 0 To dgv_induk_penyusutan_kendaraan.Columns.Count - 1
                        ws9.Cells(row + 3, col + 23).Value = dgv_induk_penyusutan_kendaraan.Rows(row).Cells(col).Value
                        ws9.Cells(row + 3, col + 23).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                        Dim cell = ws9.Cells(row + 3, col + 23)
                        Dim value = dgv_induk_penyusutan_kendaraan.Rows(row).Cells(col).Value
                        'If TypeOf value Is Double Or TypeOf value Is Decimal Then
                        '    If value < 0 Then
                        '        cell.Value = value
                        '        cell.Style.Numberformat.Format = "#,##0;(#,##0)" ' Format Excel untuk tanda kurung
                        '    Else
                        '        cell.Value = value
                        '        cell.Style.Numberformat.Format = "#,##0"
                        '    End If
                        'Else
                        '    cell.Value = value
                        'End If
                        If value IsNot Nothing AndAlso Not IsDBNull(value) Then
                            Dim numericValue As Decimal
                            If col = 0 Then
                                cell.Value = value
                            Else
                                If Decimal.TryParse(value.ToString(), numericValue) Then
                                    ' Jika angka negatif, gunakan format Excel dengan tanda kurung
                                    If numericValue < 0 Then
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0;(#,##0)"
                                    Else
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0"
                                    End If
                                Else
                                    ' Jika bukan angka, tetap masukkan sebagai teks
                                    cell.Value = value.ToString()
                                End If
                            End If
                        Else
                            cell.Value = "" ' Pastikan tidak ada null di Excel
                        End If
                        ws9.Cells(row + 3, 23).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                        ws9.Cells(row + 3, 24).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                        ws9.Cells(row + 3, 25).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                    Next
                    baris_kendaraan += 1
                Next
                ws9.Cells(2, 22, baris_kendaraan + 2, 22).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                ws9.Cells(2, 22, baris_kendaraan + 2, 22).Style.VerticalAlignment = ExcelVerticalAlignment.Center
                ws9.Cells(2, 22, baris_kendaraan + 2, 22).Merge = True
                ws9.Cells(2, 22, baris_kendaraan + 2, 22).Style.Border.BorderAround(ExcelBorderStyle.Thin)

                ws9.Cells(ws9.Dimension.Address).AutoFitColumns()
                ws9.Column(2).Width = 13
                ws9.Column(3).Width = 13
                ws9.Column(7).Width = 13
                ws9.Column(8).Width = 13
                ws9.Column(12).Width = 13
                ws9.Column(13).Width = 13
                ws9.Column(17).Width = 13
                ws9.Column(18).Width = 13
                ws9.Column(22).Width = 13
                ws9.Column(23).Width = 13

                'Data Penyusutan
                'MESIN
                'For row As Integer = 0 To dgv_penyusutan_mesin.Rows.Count - 1
                '    For col As Integer = 0 To dgv_penyusutan_mesin.Columns.Count - 2
                '        ws9.Cells(row + 3 + baris_mesin + 1, col + 2).Value = dgv_penyusutan_mesin.Rows(row).Cells(col).Value
                '        ws9.Cells(row + 3 + baris_mesin + 1, col + 2).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                '        Dim cell = ws9.Cells(row + 3 + baris_mesin + 1, col + 2)
                '        Dim value = dgv_penyusutan_mesin.Rows(row).Cells(col).Value
                '        If TypeOf value Is Double Or TypeOf value Is Decimal Then
                '            If value < 0 Then
                '                cell.Value = value
                '                cell.Style.Numberformat.Format = "#,##0;(#,##0)" ' Format Excel untuk tanda kurung
                '            Else
                '                cell.Value = value
                '                cell.Style.Numberformat.Format = "#,##0"
                '            End If
                '        Else
                '            cell.Value = value
                '        End If
                '        ws9.Cells(row + 3 + baris_mesin + 1, 2).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                '        ws9.Cells(row + 3 + baris_mesin + 1, 3).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                '        ws9.Cells(row + 3 + baris_mesin + 1, 4).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                '        ws9.Cells(row + 3 + baris_mesin + 1, 5).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                '    Next
                'Next
                For row As Integer = 0 To dgv_penyusutan_mesin.Rows.Count - 1
                    For col As Integer = 0 To dgv_penyusutan_mesin.Columns.Count - 2
                        Dim cell = ws9.Cells(row + 3 + baris_mesin + 1, col + 2)
                        Dim value As Object = dgv_penyusutan_mesin.Rows(row).Cells(col).Value

                        ' Pastikan nilai tidak Null

                        If value IsNot Nothing AndAlso Not IsDBNull(value) Then
                            Dim numericValue As Decimal
                            If col = 0 Then
                                cell.Value = value
                            Else
                                If Decimal.TryParse(value.ToString(), numericValue) Then
                                    ' Jika angka negatif, gunakan format Excel dengan tanda kurung
                                    If numericValue < 0 Then
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0;(#,##0)"
                                    Else
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0"
                                    End If
                                Else
                                    ' Jika bukan angka, tetap masukkan sebagai teks
                                    cell.Value = value.ToString()
                                End If
                            End If
                        Else
                            cell.Value = "" ' Pastikan tidak ada null di Excel
                        End If

                        ' Tambahkan Border untuk setiap sel
                        cell.Style.Border.BorderAround(ExcelBorderStyle.Thin)

                        ' Atur Alignment
                        ws9.Cells(row + 3 + baris_mesin + 1, 2).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                        ws9.Cells(row + 3 + baris_mesin + 1, 3).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                        ws9.Cells(row + 3 + baris_mesin + 1, 4).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                        ws9.Cells(row + 3 + baris_mesin + 1, 5).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                    Next
                Next
                For i As Integer = 0 To baris_mesin + dgv_penyusutan_mesin.Rows.Count - 18
                    ws9.Cells(3 + baris_mesin + 1 + i, 2, 3 + baris_mesin + 2 + i, 4).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws9.Cells(3 + baris_mesin + 1 + i, 2, 3 + baris_mesin + 2 + i, 4).Style.VerticalAlignment = ExcelVerticalAlignment.Center
                    ws9.Cells(3 + baris_mesin + 1 + i, 2, 3 + baris_mesin + 2 + i, 4).Merge = True
                    ws9.Cells(3 + baris_mesin + 1 + i, 2, 3 + baris_mesin + 2 + i, 4).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                    ws9.Cells(3 + baris_mesin + 1 + i, 5).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    i += 18
                Next
                For i As Integer = 0 To baris_mesin + dgv_penyusutan_mesin.Rows.Count - 18
                    Dim range = ws9.Cells(3 + baris_mesin + 19 + i, 2, 3 + baris_mesin + 19 + i, 5)
                    range.Style.Border.Top.Style = ExcelBorderStyle.None
                    range.Style.Border.Left.Style = ExcelBorderStyle.None
                    range.Style.Border.Right.Style = ExcelBorderStyle.None
                    ' Cek apakah ini iterasi terakhir
                    If i + 18 > baris_mesin + dgv_penyusutan_mesin.Rows.Count - 18 Then
                        range.Style.Border.Bottom.Style = ExcelBorderStyle.None
                    Else
                        range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin
                    End If
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin
                    i += 18
                Next
                baris_mesin += dgv_penyusutan_mesin.Rows.Count
                For row As Integer = 0 To dgv_gabungan_penyusutan_mesin.Rows.Count - 1
                    For col As Integer = 0 To dgv_gabungan_penyusutan_mesin.Columns.Count - 1
                        ws9.Cells(row + 3 + baris_mesin + 1, col + 2).Value = dgv_gabungan_penyusutan_mesin.Rows(row).Cells(col).Value
                        ws9.Cells(row + 3 + baris_mesin + 1, col + 2).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                        Dim cell = ws9.Cells(row + 3 + baris_mesin + 1, col + 2)
                        Dim value = dgv_gabungan_penyusutan_mesin.Rows(row).Cells(col).Value
                        'If TypeOf value Is Double Or TypeOf value Is Decimal Then
                        '    If value < 0 Then
                        '        cell.Value = value
                        '        cell.Style.Numberformat.Format = "#,##0;(#,##0)" ' Format Excel untuk tanda kurung
                        '    Else
                        '        cell.Value = value
                        '        cell.Style.Numberformat.Format = "#,##0"
                        '    End If
                        'Else
                        '    cell.Value = value
                        'End If
                        If value IsNot Nothing AndAlso Not IsDBNull(value) Then
                            Dim numericValue As Decimal
                            If col = 0 Then
                                cell.Value = value
                            Else
                                If Decimal.TryParse(value.ToString(), numericValue) Then
                                    ' Jika angka negatif, gunakan format Excel dengan tanda kurung
                                    If numericValue < 0 Then
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0;(#,##0)"
                                    Else
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0"
                                    End If
                                Else
                                    ' Jika bukan angka, tetap masukkan sebagai teks
                                    cell.Value = value.ToString()
                                End If
                            End If
                        Else
                            cell.Value = "" ' Pastikan tidak ada null di Excel
                        End If
                        ws9.Cells(row + 3 + baris_mesin + 1, 2).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                        ws9.Cells(row + 3 + baris_mesin + 1, 3).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                        ws9.Cells(row + 3 + baris_mesin + 1, 4).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                        ws9.Cells(row + 3 + baris_mesin + 1, 5).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                    Next
                Next
                If dgv_gabungan_penyusutan_mesin.RowCount <> 0 Then
                    ws9.Cells(3 + baris_mesin + 1, 2, 3 + baris_mesin + 2, 5).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws9.Cells(3 + baris_mesin + 1, 2, 3 + baris_mesin + 2, 5).Style.VerticalAlignment = ExcelVerticalAlignment.Center
                    ws9.Cells(3 + baris_mesin + 1, 2, 3 + baris_mesin + 2, 5).Merge = True
                    ws9.Cells(3 + baris_mesin + 1, 2, 3 + baris_mesin + 2, 5).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                    ws9.Cells(3 + baris_mesin + 3, 3).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws9.Cells(3 + baris_mesin + 3, 5).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                End If

                'TANKI
                'For row As Integer = 0 To dgv_penyusutan_tanki.Rows.Count - 1
                '    For col As Integer = 0 To dgv_penyusutan_tanki.Columns.Count - 2
                '        ws9.Cells(row + 3 + baris_tanki + 1, col + 7).Value = dgv_penyusutan_tanki.Rows(row).Cells(col).Value
                '        ws9.Cells(row + 3 + baris_tanki + 1, col + 7).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                '        Dim cell = ws9.Cells(row + 3 + baris_tanki + 1, col + 7)
                '        Dim value = dgv_penyusutan_tanki.Rows(row).Cells(col).Value
                '        If TypeOf value Is Double Or TypeOf value Is Decimal Then
                '            If value < 0 Then
                '                cell.Value = value
                '                cell.Style.Numberformat.Format = "#,##0;(#,##0)" ' Format Excel untuk tanda kurung
                '            Else
                '                cell.Value = value
                '                cell.Style.Numberformat.Format = "#,##0"
                '            End If
                '        Else
                '            cell.Value = value
                '        End If
                '        ws9.Cells(row + 3 + baris_tanki + 1, 7).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                '        ws9.Cells(row + 3 + baris_tanki + 1, 8).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                '        ws9.Cells(row + 3 + baris_tanki + 1, 9).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                '        ws9.Cells(row + 3 + baris_tanki + 1, 10).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                '    Next
                'Next
                For row As Integer = 0 To dgv_penyusutan_tanki.Rows.Count - 1
                    For col As Integer = 0 To dgv_penyusutan_tanki.Columns.Count - 2
                        Dim cell = ws9.Cells(row + 3 + baris_tanki + 1, col + 7)
                        Dim value As Object = dgv_penyusutan_tanki.Rows(row).Cells(col).Value

                        ' Pastikan nilai tidak Null atau DBNull
                        If value IsNot Nothing AndAlso Not IsDBNull(value) Then
                            Dim numericValue As Decimal
                            If col = 0 Then
                                cell.Value = value
                            Else
                                If Decimal.TryParse(value.ToString(), numericValue) Then
                                    ' Jika angka negatif, gunakan format Excel dengan tanda kurung
                                    If numericValue < 0 Then
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0;(#,##0)"
                                    Else
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0"
                                    End If
                                Else
                                    ' Jika bukan angka, tetap masukkan sebagai teks
                                    cell.Value = value.ToString()
                                End If
                            End If
                        Else
                            cell.Value = "" ' Pastikan tidak ada null di Excel
                        End If

                        ' Tambahkan Border untuk setiap sel
                        cell.Style.Border.BorderAround(ExcelBorderStyle.Thin)
                    Next

                    ' Atur perataan teks di kolom sesuai dengan posisi data
                    ws9.Cells(row + 3 + baris_tanki + 1, 7).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws9.Cells(row + 3 + baris_tanki + 1, 8).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws9.Cells(row + 3 + baris_tanki + 1, 9).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                    ws9.Cells(row + 3 + baris_tanki + 1, 10).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                Next
                For i As Integer = 0 To baris_tanki + dgv_penyusutan_tanki.Rows.Count - 19
                    ws9.Cells(3 + baris_tanki + 1 + i, 7, 3 + baris_tanki + 2 + i, 9).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws9.Cells(3 + baris_tanki + 1 + i, 7, 3 + baris_tanki + 2 + i, 9).Style.VerticalAlignment = ExcelVerticalAlignment.Center
                    ws9.Cells(3 + baris_tanki + 1 + i, 7, 3 + baris_tanki + 2 + i, 9).Merge = True
                    ws9.Cells(3 + baris_tanki + 1 + i, 7, 3 + baris_tanki + 2 + i, 9).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                    ws9.Cells(3 + baris_tanki + 1 + i, 10).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    i += 19
                Next
                For i As Integer = 0 To baris_tanki + dgv_penyusutan_tanki.Rows.Count - 19
                    Dim range = ws9.Cells(3 + baris_tanki + 20 + i, 7, 3 + baris_tanki + 20 + i, 10)
                    range.Style.Border.Top.Style = ExcelBorderStyle.None
                    range.Style.Border.Left.Style = ExcelBorderStyle.None
                    range.Style.Border.Right.Style = ExcelBorderStyle.None
                    ' Cek apakah ini iterasi terakhir
                    If i + 19 > baris_tanki + dgv_penyusutan_tanki.Rows.Count - 19 Then
                        range.Style.Border.Bottom.Style = ExcelBorderStyle.None
                    Else
                        range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin
                    End If
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin
                    i += 19
                Next
                baris_tanki += dgv_penyusutan_tanki.Rows.Count
                For row As Integer = 0 To dgv_gabungan_penyusutan_tanki.Rows.Count - 1
                    For col As Integer = 0 To dgv_gabungan_penyusutan_tanki.Columns.Count - 1
                        ws9.Cells(row + 3 + baris_tanki + 1, col + 7).Value = dgv_gabungan_penyusutan_tanki.Rows(row).Cells(col).Value
                        ws9.Cells(row + 3 + baris_tanki + 1, col + 7).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                        Dim cell = ws9.Cells(row + 3 + baris_tanki + 1, col + 7)
                        Dim value = dgv_gabungan_penyusutan_tanki.Rows(row).Cells(col).Value
                        'If TypeOf value Is Double Or TypeOf value Is Decimal Then
                        '    If value < 0 Then
                        '        cell.Value = value
                        '        cell.Style.Numberformat.Format = "#,##0;(#,##0)" ' Format Excel untuk tanda kurung
                        '    Else
                        '        cell.Value = value
                        '        cell.Style.Numberformat.Format = "#,##0"
                        '    End If
                        'Else
                        '    cell.Value = value
                        'End If
                        If value IsNot Nothing AndAlso Not IsDBNull(value) Then
                            Dim numericValue As Decimal
                            If col = 0 Then
                                cell.Value = value
                            Else
                                If Decimal.TryParse(value.ToString(), numericValue) Then
                                    ' Jika angka negatif, gunakan format Excel dengan tanda kurung
                                    If numericValue < 0 Then
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0;(#,##0)"
                                    Else
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0"
                                    End If
                                Else
                                    ' Jika bukan angka, tetap masukkan sebagai teks
                                    cell.Value = value.ToString()
                                End If
                            End If
                        Else
                            cell.Value = "" ' Pastikan tidak ada null di Excel
                        End If
                        ws9.Cells(row + 3 + baris_tanki + 1, 7).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                        ws9.Cells(row + 3 + baris_tanki + 1, 8).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                        ws9.Cells(row + 3 + baris_tanki + 1, 9).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                        ws9.Cells(row + 3 + baris_tanki + 1, 10).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                    Next
                Next
                If dgv_gabungan_penyusutan_tanki.RowCount <> 0 Then
                    ws9.Cells(3 + baris_tanki + 1, 7, 3 + baris_tanki + 2, 10).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws9.Cells(3 + baris_tanki + 1, 7, 3 + baris_tanki + 2, 10).Style.VerticalAlignment = ExcelVerticalAlignment.Center
                    ws9.Cells(3 + baris_tanki + 1, 7, 3 + baris_tanki + 2, 10).Merge = True
                    ws9.Cells(3 + baris_tanki + 1, 7, 3 + baris_tanki + 2, 10).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                    ws9.Cells(3 + baris_tanki + 3, 8).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws9.Cells(3 + baris_tanki + 3, 10).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                End If

                'INVENTARIS
                'For row As Integer = 0 To dgv_penyusutan_inventaris.Rows.Count - 1
                '    For col As Integer = 0 To dgv_penyusutan_inventaris.Columns.Count - 2
                '        ws9.Cells(row + 3 + baris_inventaris + 1, col + 12).Value = dgv_penyusutan_inventaris.Rows(row).Cells(col).Value
                '        ws9.Cells(row + 3 + baris_inventaris + 1, col + 12).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                '        Dim cell = ws9.Cells(row + 3 + baris_inventaris + 1, col + 12)
                '        Dim value = dgv_penyusutan_inventaris.Rows(row).Cells(col).Value
                '        If TypeOf value Is Double Or TypeOf value Is Decimal Then
                '            If value < 0 Then
                '                cell.Value = value
                '                cell.Style.Numberformat.Format = "#,##0;(#,##0)" ' Format Excel untuk tanda kurung
                '            Else
                '                cell.Value = value
                '                cell.Style.Numberformat.Format = "#,##0"
                '            End If
                '        Else
                '            cell.Value = value
                '        End If
                '        ws9.Cells(row + 3 + baris_inventaris + 1, 12).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                '        ws9.Cells(row + 3 + baris_inventaris + 1, 13).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                '        ws9.Cells(row + 3 + baris_inventaris + 1, 14).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                '        ws9.Cells(row + 3 + baris_inventaris + 1, 15).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                '    Next
                'Next
                For row As Integer = 0 To dgv_penyusutan_inventaris.Rows.Count - 1
                    For col As Integer = 0 To dgv_penyusutan_inventaris.Columns.Count - 2
                        Dim cell = ws9.Cells(row + 3 + baris_inventaris + 1, col + 12)
                        Dim value As Object = dgv_penyusutan_inventaris.Rows(row).Cells(col).Value

                        If value IsNot Nothing AndAlso Not IsDBNull(value) Then
                            Dim numericValue As Decimal
                            If col = 0 Then
                                cell.Value = value
                            Else
                                If Decimal.TryParse(value.ToString(), numericValue) Then
                                    If numericValue < 0 Then
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0;(#,##0)"
                                    Else
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0"
                                    End If
                                Else
                                    cell.Value = value.ToString()
                                End If
                            End If
                        Else
                            cell.Value = ""
                        End If

                        cell.Style.Border.BorderAround(ExcelBorderStyle.Thin)
                    Next

                    ws9.Cells(row + 3 + baris_inventaris + 1, 12).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws9.Cells(row + 3 + baris_inventaris + 1, 13).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws9.Cells(row + 3 + baris_inventaris + 1, 14).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                    ws9.Cells(row + 3 + baris_inventaris + 1, 15).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                Next

                For i As Integer = 0 To baris_inventaris + dgv_penyusutan_inventaris.Rows.Count - 6
                    ws9.Cells(3 + baris_inventaris + 1 + i, 12, 3 + baris_inventaris + 2 + i, 14).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws9.Cells(3 + baris_inventaris + 1 + i, 12, 3 + baris_inventaris + 2 + i, 14).Style.VerticalAlignment = ExcelVerticalAlignment.Center
                    ws9.Cells(3 + baris_inventaris + 1 + i, 12, 3 + baris_inventaris + 2 + i, 14).Merge = True
                    ws9.Cells(3 + baris_inventaris + 1 + i, 12, 3 + baris_inventaris + 2 + i, 14).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                    ws9.Cells(3 + baris_inventaris + 1 + i, 15).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    i += 6
                Next
                For i As Integer = 0 To baris_inventaris + dgv_penyusutan_inventaris.Rows.Count - 6
                    Dim range = ws9.Cells(3 + baris_inventaris + 7 + i, 12, 3 + baris_inventaris + 7 + i, 15)
                    range.Style.Border.Top.Style = ExcelBorderStyle.None
                    range.Style.Border.Left.Style = ExcelBorderStyle.None
                    range.Style.Border.Right.Style = ExcelBorderStyle.None
                    If i + 6 > baris_inventaris + dgv_penyusutan_inventaris.Rows.Count - 6 Then
                        range.Style.Border.Bottom.Style = ExcelBorderStyle.None
                    Else
                        range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin
                    End If
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin
                    i += 6
                Next
                baris_inventaris += dgv_penyusutan_inventaris.Rows.Count
                For row As Integer = 0 To dgv_gabungan_penyusutan_inventaris.Rows.Count - 1
                    For col As Integer = 0 To dgv_gabungan_penyusutan_inventaris.Columns.Count - 1
                        ws9.Cells(row + 3 + baris_inventaris + 1, col + 12).Value = dgv_gabungan_penyusutan_inventaris.Rows(row).Cells(col).Value
                        ws9.Cells(row + 3 + baris_inventaris + 1, col + 12).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                        Dim cell = ws9.Cells(row + 3 + baris_inventaris + 1, col + 12)
                        Dim value = dgv_gabungan_penyusutan_inventaris.Rows(row).Cells(col).Value
                        'If TypeOf value Is Double Or TypeOf value Is Decimal Then
                        '    If value < 0 Then
                        '        cell.Value = value
                        '        cell.Style.Numberformat.Format = "#,##0;(#,##0)" ' Format Excel untuk tanda kurung
                        '    Else
                        '        cell.Value = value
                        '        cell.Style.Numberformat.Format = "#,##0"
                        '    End If
                        'Else
                        '    cell.Value = value
                        'End If
                        If value IsNot Nothing AndAlso Not IsDBNull(value) Then
                            Dim numericValue As Decimal
                            If col = 0 Then
                                cell.Value = value
                            Else
                                If Decimal.TryParse(value.ToString(), numericValue) Then
                                    ' Jika angka negatif, gunakan format Excel dengan tanda kurung
                                    If numericValue < 0 Then
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0;(#,##0)"
                                    Else
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0"
                                    End If
                                Else
                                    ' Jika bukan angka, tetap masukkan sebagai teks
                                    cell.Value = value.ToString()
                                End If
                            End If
                        Else
                            cell.Value = "" ' Pastikan tidak ada null di Excel
                        End If
                        ws9.Cells(row + 3 + baris_inventaris + 1, 12).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                        ws9.Cells(row + 3 + baris_inventaris + 1, 13).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                        ws9.Cells(row + 3 + baris_inventaris + 1, 14).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                        ws9.Cells(row + 3 + baris_inventaris + 1, 15).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                    Next
                Next
                If dgv_gabungan_penyusutan_inventaris.RowCount <> 0 Then
                    ws9.Cells(3 + baris_inventaris + 1, 12, 3 + baris_inventaris + 2, 15).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws9.Cells(3 + baris_inventaris + 1, 12, 3 + baris_inventaris + 2, 15).Style.VerticalAlignment = ExcelVerticalAlignment.Center
                    ws9.Cells(3 + baris_inventaris + 1, 12, 3 + baris_inventaris + 2, 15).Merge = True
                    ws9.Cells(3 + baris_inventaris + 1, 12, 3 + baris_inventaris + 2, 15).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                    ws9.Cells(3 + baris_inventaris + 3, 13).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws9.Cells(3 + baris_inventaris + 3, 15).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                End If

                'BANGUNAN
                'For row As Integer = 0 To dgv_penyusutan_bangunan.Rows.Count - 1
                '    For col As Integer = 0 To dgv_penyusutan_bangunan.Columns.Count - 2
                '        ws9.Cells(row + 3 + baris_bangunan + 1, col + 17).Value = dgv_penyusutan_bangunan.Rows(row).Cells(col).Value
                '        ws9.Cells(row + 3 + baris_bangunan + 1, col + 17).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                '        Dim cell = ws9.Cells(row + 3 + baris_bangunan + 1, col + 17)
                '        Dim value = dgv_penyusutan_bangunan.Rows(row).Cells(col).Value
                '        If TypeOf value Is Double Or TypeOf value Is Decimal Then
                '            If value < 0 Then
                '                cell.Value = value
                '                cell.Style.Numberformat.Format = "#,##0;(#,##0)" ' Format Excel untuk tanda kurung
                '            Else
                '                cell.Value = value
                '                cell.Style.Numberformat.Format = "#,##0"
                '            End If
                '        Else
                '            cell.Value = value
                '        End If
                '        ws9.Cells(row + 3 + baris_bangunan + 1, 17).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                '        ws9.Cells(row + 3 + baris_bangunan + 1, 18).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                '        ws9.Cells(row + 3 + baris_bangunan + 1, 19).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                '        ws9.Cells(row + 3 + baris_bangunan + 1, 20).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                '    Next
                'Next
                For row As Integer = 0 To dgv_penyusutan_bangunan.Rows.Count - 1
                    For col As Integer = 0 To dgv_penyusutan_bangunan.Columns.Count - 2
                        Dim cell = ws9.Cells(row + 3 + baris_bangunan + 1, col + 17)
                        Dim value As Object = dgv_penyusutan_bangunan.Rows(row).Cells(col).Value

                        ' Pastikan nilai tidak Null
                        If value IsNot Nothing AndAlso Not IsDBNull(value) Then
                            Dim numericValue As Decimal
                            If col = 0 Then
                                cell.Value = value
                            Else
                                If Decimal.TryParse(value.ToString(), numericValue) Then
                                    ' Jika angka negatif, gunakan format Excel dengan tanda kurung
                                    If numericValue < 0 Then
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0;(#,##0)"
                                    Else
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0"
                                    End If
                                Else
                                    ' Jika bukan angka, tetap masukkan sebagai teks
                                    cell.Value = value.ToString()
                                End If
                            End If
                        Else
                            cell.Value = "" ' Pastikan tidak ada null di Excel
                        End If

                        ' Tambahkan Border untuk setiap sel
                        cell.Style.Border.BorderAround(ExcelBorderStyle.Thin)

                        ' Atur Alignment
                        ws9.Cells(row + 3 + baris_bangunan + 1, 17).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                        ws9.Cells(row + 3 + baris_bangunan + 1, 18).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                        ws9.Cells(row + 3 + baris_bangunan + 1, 19).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                        ws9.Cells(row + 3 + baris_bangunan + 1, 20).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                    Next
                Next
                For i As Integer = 0 To baris_bangunan + dgv_penyusutan_bangunan.Rows.Count - 22
                    ws9.Cells(3 + baris_bangunan + 1 + i, 17, 3 + baris_bangunan + 2 + i, 19).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws9.Cells(3 + baris_bangunan + 1 + i, 17, 3 + baris_bangunan + 2 + i, 19).Style.VerticalAlignment = ExcelVerticalAlignment.Center
                    ws9.Cells(3 + baris_bangunan + 1 + i, 17, 3 + baris_bangunan + 2 + i, 19).Merge = True
                    ws9.Cells(3 + baris_bangunan + 1 + i, 17, 3 + baris_bangunan + 2 + i, 19).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                    ws9.Cells(3 + baris_bangunan + 1 + i, 20).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    i += 22
                Next
                For i As Integer = 0 To baris_bangunan + dgv_penyusutan_bangunan.Rows.Count - 22
                    Dim range = ws9.Cells(3 + baris_bangunan + 23 + i, 17, 3 + baris_bangunan + 23 + i, 20)
                    range.Style.Border.Top.Style = ExcelBorderStyle.None
                    range.Style.Border.Left.Style = ExcelBorderStyle.None
                    range.Style.Border.Right.Style = ExcelBorderStyle.None
                    If i + 22 > baris_bangunan + dgv_penyusutan_bangunan.Rows.Count - 22 Then
                        range.Style.Border.Bottom.Style = ExcelBorderStyle.None
                    Else
                        range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin
                    End If
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin
                    i += 22
                Next
                baris_bangunan += dgv_penyusutan_bangunan.Rows.Count
                For row As Integer = 0 To dgv_gabungan_penyusutan_bangunan.Rows.Count - 1
                    For col As Integer = 0 To dgv_gabungan_penyusutan_bangunan.Columns.Count - 1
                        ws9.Cells(row + 3 + baris_bangunan + 1, col + 17).Value = dgv_gabungan_penyusutan_bangunan.Rows(row).Cells(col).Value
                        ws9.Cells(row + 3 + baris_bangunan + 1, col + 17).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                        Dim cell = ws9.Cells(row + 3 + baris_bangunan + 1, col + 17)
                        Dim value = dgv_gabungan_penyusutan_bangunan.Rows(row).Cells(col).Value
                        'If TypeOf value Is Double Or TypeOf value Is Decimal Then
                        '    If value < 0 Then
                        '        cell.Value = value
                        '        cell.Style.Numberformat.Format = "#,##0;(#,##0)" ' Format Excel untuk tanda kurung
                        '    Else
                        '        cell.Value = value
                        '        cell.Style.Numberformat.Format = "#,##0"
                        '    End If
                        'Else
                        '    cell.Value = value
                        'End If
                        If value IsNot Nothing AndAlso Not IsDBNull(value) Then
                            Dim numericValue As Decimal
                            If col = 0 Then
                                cell.Value = value
                            Else
                                If Decimal.TryParse(value.ToString(), numericValue) Then
                                    ' Jika angka negatif, gunakan format Excel dengan tanda kurung
                                    If numericValue < 0 Then
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0;(#,##0)"
                                    Else
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0"
                                    End If
                                Else
                                    ' Jika bukan angka, tetap masukkan sebagai teks
                                    cell.Value = value.ToString()
                                End If
                            End If
                        Else
                            cell.Value = "" ' Pastikan tidak ada null di Excel
                        End If
                        ws9.Cells(row + 3 + baris_bangunan + 1, 17).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                        ws9.Cells(row + 3 + baris_bangunan + 1, 18).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                        ws9.Cells(row + 3 + baris_bangunan + 1, 19).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                        ws9.Cells(row + 3 + baris_bangunan + 1, 20).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                    Next
                Next
                If dgv_gabungan_penyusutan_bangunan.RowCount <> 0 Then
                    ws9.Cells(3 + baris_bangunan + 1, 17, 3 + baris_bangunan + 2, 20).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws9.Cells(3 + baris_bangunan + 1, 17, 3 + baris_bangunan + 2, 20).Style.VerticalAlignment = ExcelVerticalAlignment.Center
                    ws9.Cells(3 + baris_bangunan + 1, 17, 3 + baris_bangunan + 2, 20).Merge = True
                    ws9.Cells(3 + baris_bangunan + 1, 17, 3 + baris_bangunan + 2, 20).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                    ws9.Cells(3 + baris_bangunan + 3, 18).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws9.Cells(3 + baris_bangunan + 3, 20).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                End If

                'KENDARAAN
                'For row As Integer = 0 To dgv_penyusutan_kendaraan.Rows.Count - 1
                '    For col As Integer = 0 To dgv_penyusutan_kendaraan.Columns.Count - 2
                '        ws9.Cells(row + 3 + baris_kendaraan + 1, col + 22).Value = dgv_penyusutan_kendaraan.Rows(row).Cells(col).Value
                '        ws9.Cells(row + 3 + baris_kendaraan + 1, col + 22).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                '        Dim cell = ws9.Cells(row + 3 + baris_kendaraan + 1, col + 22)
                '        Dim value = dgv_penyusutan_kendaraan.Rows(row).Cells(col).Value
                '        If TypeOf value Is Double Or TypeOf value Is Decimal Then
                '            If value < 0 Then
                '                cell.Value = value
                '                cell.Style.Numberformat.Format = "#,##0;(#,##0)" ' Format Excel untuk tanda kurung
                '            Else
                '                cell.Value = value
                '                cell.Style.Numberformat.Format = "#,##0"
                '            End If
                '        Else
                '            cell.Value = value
                '        End If
                '        ws9.Cells(row + 3 + baris_kendaraan + 1, 22).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                '        ws9.Cells(row + 3 + baris_kendaraan + 1, 23).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                '        ws9.Cells(row + 3 + baris_kendaraan + 1, 24).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                '        ws9.Cells(row + 3 + baris_kendaraan + 1, 25).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                '    Next
                'Next
                For row As Integer = 0 To dgv_penyusutan_kendaraan.Rows.Count - 1
                    For col As Integer = 0 To dgv_penyusutan_kendaraan.Columns.Count - 2
                        Dim cell = ws9.Cells(row + 3 + baris_kendaraan + 1, col + 22)
                        Dim value As Object = dgv_penyusutan_kendaraan.Rows(row).Cells(col).Value

                        ' Pastikan nilai tidak Null
                        If value IsNot Nothing AndAlso Not IsDBNull(value) Then
                            Dim numericValue As Decimal
                            If col = 0 Then
                                cell.Value = value
                            Else
                                If Decimal.TryParse(value.ToString(), numericValue) Then
                                    ' Jika angka negatif, gunakan format Excel dengan tanda kurung
                                    If numericValue < 0 Then
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0;(#,##0)"
                                    Else
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0"
                                    End If
                                Else
                                    ' Jika bukan angka, tetap masukkan sebagai teks
                                    cell.Value = value.ToString()
                                End If
                            End If
                        Else
                            cell.Value = "" ' Pastikan tidak ada null di Excel
                        End If

                        ' Tambahkan Border untuk setiap sel
                        cell.Style.Border.BorderAround(ExcelBorderStyle.Thin)

                        ' Atur Alignment
                        ws9.Cells(row + 3 + baris_kendaraan + 1, 22).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                        ws9.Cells(row + 3 + baris_kendaraan + 1, 23).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                        ws9.Cells(row + 3 + baris_kendaraan + 1, 24).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                        ws9.Cells(row + 3 + baris_kendaraan + 1, 25).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                    Next
                Next

                For i As Integer = 0 To baris_kendaraan + dgv_penyusutan_kendaraan.Rows.Count - 6
                    ws9.Cells(3 + baris_kendaraan + 1 + i, 22, 3 + baris_kendaraan + 2 + i, 24).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws9.Cells(3 + baris_kendaraan + 1 + i, 22, 3 + baris_kendaraan + 2 + i, 24).Style.VerticalAlignment = ExcelVerticalAlignment.Center
                    ws9.Cells(3 + baris_kendaraan + 1 + i, 22, 3 + baris_kendaraan + 2 + i, 24).Merge = True
                    ws9.Cells(3 + baris_kendaraan + 1 + i, 22, 3 + baris_kendaraan + 2 + i, 24).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                    ws9.Cells(3 + baris_kendaraan + 1 + i, 25).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    i += 6
                Next
                For i As Integer = 0 To baris_kendaraan + dgv_penyusutan_kendaraan.Rows.Count - 6
                    Dim range = ws9.Cells(3 + baris_kendaraan + 7 + i, 22, 3 + baris_kendaraan + 7 + i, 25)
                    range.Style.Border.Top.Style = ExcelBorderStyle.None
                    range.Style.Border.Left.Style = ExcelBorderStyle.None
                    range.Style.Border.Right.Style = ExcelBorderStyle.None
                    If i + 6 > baris_kendaraan + dgv_penyusutan_kendaraan.Rows.Count - 6 Then
                        range.Style.Border.Bottom.Style = ExcelBorderStyle.None
                    Else
                        range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin
                    End If
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin
                    i += 6
                Next
                baris_kendaraan += dgv_penyusutan_kendaraan.Rows.Count
                For row As Integer = 0 To dgv_gabungan_penyusutan_kendaraan.Rows.Count - 1
                    For col As Integer = 0 To dgv_gabungan_penyusutan_kendaraan.Columns.Count - 1
                        ws9.Cells(row + 3 + baris_kendaraan + 1, col + 22).Value = dgv_gabungan_penyusutan_kendaraan.Rows(row).Cells(col).Value
                        ws9.Cells(row + 3 + baris_kendaraan + 1, col + 22).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                        Dim cell = ws9.Cells(row + 3 + baris_kendaraan + 1, col + 22)
                        Dim value = dgv_gabungan_penyusutan_kendaraan.Rows(row).Cells(col).Value
                        'If TypeOf value Is Double Or TypeOf value Is Decimal Then
                        '    If value < 0 Then
                        '        cell.Value = value
                        '        cell.Style.Numberformat.Format = "#,##0;(#,##0)" ' Format Excel untuk tanda kurung
                        '    Else
                        '        cell.Value = value
                        '        cell.Style.Numberformat.Format = "#,##0"
                        '    End If
                        'Else
                        '    cell.Value = value
                        'End If
                        If value IsNot Nothing AndAlso Not IsDBNull(value) Then
                            Dim numericValue As Decimal
                            If col = 0 Then
                                cell.Value = value
                            Else
                                If Decimal.TryParse(value.ToString(), numericValue) Then
                                    ' Jika angka negatif, gunakan format Excel dengan tanda kurung
                                    If numericValue < 0 Then
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0;(#,##0)"
                                    Else
                                        cell.Value = numericValue
                                        cell.Style.Numberformat.Format = "#,##0"
                                    End If
                                Else
                                    ' Jika bukan angka, tetap masukkan sebagai teks
                                    cell.Value = value.ToString()
                                End If
                            End If
                        Else
                            cell.Value = "" ' Pastikan tidak ada null di Excel
                        End If
                        ws9.Cells(row + 3 + baris_kendaraan + 1, 22).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                        ws9.Cells(row + 3 + baris_kendaraan + 1, 23).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                        ws9.Cells(row + 3 + baris_kendaraan + 1, 24).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                        ws9.Cells(row + 3 + baris_kendaraan + 1, 25).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                    Next
                Next
                If dgv_gabungan_penyusutan_kendaraan.RowCount <> 0 Then
                    ws9.Cells(3 + baris_kendaraan + 1, 22, 3 + baris_kendaraan + 2, 25).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws9.Cells(3 + baris_kendaraan + 1, 22, 3 + baris_kendaraan + 2, 25).Style.VerticalAlignment = ExcelVerticalAlignment.Center
                    ws9.Cells(3 + baris_kendaraan + 1, 22, 3 + baris_kendaraan + 2, 25).Merge = True
                    ws9.Cells(3 + baris_kendaraan + 1, 22, 3 + baris_kendaraan + 2, 25).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                    ws9.Cells(3 + baris_kendaraan + 3, 23).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws9.Cells(3 + baris_kendaraan + 3, 25).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                End If

                'Akhir Sheet 9

                ' Simpan file Excel
                Dim fi As New FileInfo(filePath)
                package.SaveAs(fi)
                MessageBox.Show("Ekspor Data ke Excel Berhasil!")
            End Using
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub

    Private Sub btn_reset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_reset.Click
        Me.Close() ' Menutup form saat ini
        Dim newForm As New form_laporan_keuangan() ' Membuat instance baru dari form
        newForm.Show() ' Menampilkan ulang form
    End Sub

End Class