﻿Imports MySql.Data.MySqlClient

Public Class form_parameter_ppn

    Private Sub form_parameter_ppn_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call tampil_ppn()
    End Sub

    Private Sub tampil_ppn()
        Try
            Using conx As New MySqlConnection(sLocalConn)
                conx.Open()
                Dim sqlx = "SELECT ppn,pph23 FROM tbppn WHERE id='ppn'"
                Using cmdx As New MySqlCommand(sqlx, conx)
                    Using reader As MySqlDataReader = cmdx.ExecuteReader()
                        If reader.Read() Then
                            lbl_ppn.Text = reader("ppn").ToString() & " %"
                            lbl_pph.Text = reader("pph23").ToString() & " %"
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub BtnKeluar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnKeluar.Click
        Me.Close()
    End Sub

    Private Sub txt_ppn_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txt_ppn.KeyPress, txt_pph23.KeyPress
        If Not Char.IsDigit(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub BtnGanti_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnGanti.Click
        If txt_pph23.Text = "" And txt_ppn.Text = "" Then
            MsgBox("Nilai PPN atau PPh 23 belum diinput")
            txt_ppn.Focus()
        ElseIf txt_pph23.Text = "" And Not txt_ppn.Text = "" Then
            Call update_ppn()
            Call tampil_ppn()
            txt_ppn.Text = ""
            txt_pph23.Text = ""
        ElseIf txt_ppn.Text = "" And Not txt_pph23.Text = "" Then
            Call update_pph23()
            Call tampil_ppn()
            txt_ppn.Text = ""
            txt_pph23.Text = ""
        ElseIf Not txt_ppn.Text = "" And Not txt_pph23.Text = "" Then
            Call update_ppn_pph23()
            Call tampil_ppn()
            txt_ppn.Text = ""
            txt_pph23.Text = ""
        End If
    End Sub

    Private Sub update_ppn()
        Using cony As New MySqlConnection(sLocalConn)
            cony.Open()
            Dim sqly = "UPDATE tbppn SET ppn=@1 WHERE id='ppn'"
            Using cmdy As New MySqlCommand(sqly, cony)
                With cmdy
                    .Parameters.Clear()
                    .Parameters.AddWithValue("@1", (txt_ppn.Text))
                    .ExecuteNonQuery()
                End With
                MsgBox("Nilai PPN Berhasil Diubah")
                form_jenis_biaya.Focus()
            End Using
        End Using
    End Sub

    Private Sub update_pph23()
        Using cony As New MySqlConnection(sLocalConn)
            cony.Open()
            Dim sqly = "UPDATE tbppn SET pph23=@1 WHERE id='ppn'"
            Using cmdy As New MySqlCommand(sqly, cony)
                With cmdy
                    .Parameters.Clear()
                    .Parameters.AddWithValue("@1", (txt_pph23.Text))
                    .ExecuteNonQuery()
                End With
                MsgBox("Nilai PPh 23 Berhasil Diubah")
                form_jenis_biaya.Focus()
            End Using
        End Using
    End Sub

    Private Sub update_ppn_pph23()
        Using cony As New MySqlConnection(sLocalConn)
            cony.Open()
            Dim sqly = "UPDATE tbppn SET ppn=@1,pph23=@2 WHERE id='ppn'"
            Using cmdy As New MySqlCommand(sqly, cony)
                With cmdy
                    .Parameters.Clear()
                    .Parameters.AddWithValue("@1", (txt_ppn.Text))
                    .Parameters.AddWithValue("@2", (txt_pph23.Text))
                    .ExecuteNonQuery()
                End With
                MsgBox("Nilai PPN dan PPh 23 Berhasil Diubah")
                form_jenis_biaya.Focus()
            End Using
        End Using
    End Sub

End Class