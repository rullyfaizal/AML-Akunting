﻿Imports MySql.Data.MySqlClient
Imports System.Globalization

Public Class form_export_excel_coretax

    Dim bulan, tahun As Integer
    Dim npwparta As String = My.Settings.npwpartha

    Private Sub form_export_excel_coretax_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txt_kode_transaksi.Text = "04"
    End Sub

    Private Sub txt_tanggal_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_tanggal.TextChanged
        btn_generate.Text = "GENERATE"
        dgv1.Columns.Clear()
    End Sub

    Private Sub dtp_tanggal_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtp_tanggal.ValueChanged
        Dim selectedDate As DateTime = dtp_tanggal.Value
        Dim cultureInfo As New CultureInfo("id-ID")
        Dim formattedDate As String = selectedDate.ToString("MMMM yyyy", cultureInfo)
        txt_tanggal.Text = formattedDate
        bulan = Month(dtp_tanggal.Value)
        tahun = Year(dtp_tanggal.Value)
        txtbulan.Text = bulan
        txttahun.Text = tahun
    End Sub

    Private Sub btn_kosong_tanggal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_kosong_tanggal.Click
        If Not txt_tanggal.Text = "" Then
            txt_tanggal.Text = ""
            txtbulan.Text = ""
            txttahun.Text = ""
        End If
    End Sub

    Private Sub setup_dgv1()
        dgv1.ColumnCount = 17
        dgv1.Columns(0).Name = "Baris"
        dgv1.Columns(1).Name = "Tanggal Faktur"
        dgv1.Columns(2).Name = "Jenis Faktur"
        dgv1.Columns(3).Name = "Kode Transaksi"
        dgv1.Columns(4).Name = "Keterangan Tambahan"
        dgv1.Columns(5).Name = "Dokumen Pendukung"
        dgv1.Columns(6).Name = "Referensi"
        dgv1.Columns(7).Name = "Cap Fasilitas"
        dgv1.Columns(8).Name = "ID TKU Penjual"
        dgv1.Columns(9).Name = "NPWP/NIK Pembeli"
        dgv1.Columns(10).Name = "Jenis ID Pembeli"
        dgv1.Columns(11).Name = "Negara Pembeli"
        dgv1.Columns(12).Name = "Nomor Dokumen Pembeli"
        dgv1.Columns(13).Name = "Nama Pembeli"
        dgv1.Columns(14).Name = "Alamat Pembeli"
        dgv1.Columns(15).Name = "Email Pembeli"
        dgv1.Columns(16).Name = "ID TKU Pembeli"

        dgv1.Columns(0).Width = 50
        dgv1.Columns(1).Width = 90
        dgv1.Columns(2).Width = 70
        dgv1.Columns(3).Width = 70
        dgv1.Columns(4).Width = 50
        dgv1.Columns(5).Width = 50
        dgv1.Columns(6).Width = 50
        dgv1.Columns(7).Width = 50
        dgv1.Columns(8).Width = 200
        dgv1.Columns(9).Width = 150
        dgv1.Columns(10).Width = 70
        dgv1.Columns(11).Width = 70
        dgv1.Columns(12).Width = 70
        dgv1.Columns(13).Width = 150
        dgv1.Columns(14).Width = 200
        dgv1.Columns(15).Width = 70
        dgv1.Columns(16).Width = 200
    End Sub

    Private Sub load_dgv1()
        dgv1.Columns.Clear()
        Call setup_dgv1()

        Dim tahun As Integer = dtp_tanggal.Value.Year
        Dim bulan As Integer = dtp_tanggal.Value.Month

        Dim query1 As String = "SELECT tanggal, supplier FROM tbpenjualan WHERE YEAR(tanggal) = @tahun AND MONTH(tanggal) = @bulan " &
            "ORDER BY tanggal ASC, supplier ASC, FIELD(jenis_biaya, 'kain', 'obat', 'jasa');"

        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Using cmd As New MySqlCommand(query1, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                cmd.Parameters.AddWithValue("@bulan", bulan)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    Dim nomorUrut As Integer = 1 ' Inisialisasi nomor urut
                    Dim kodeTransaksi As String = txt_kode_transaksi.Text
                    While reader.Read()
                        Dim tanggalFaktur As Date = reader.GetDateTime("tanggal")
                        Dim pembeli As String = reader.GetString("supplier")
                        Dim alamat As String = ""
                        Dim npwppembeli As String = ""
                        Using cony As New MySqlConnection(sLocalConn)
                            cony.Open()
                            Dim queryy As String = "SELECT alamat, npwp FROM tbclient WHERE nama = @pembeli;"
                            Using cmdy As New MySqlCommand(queryy, cony)
                                cmdy.Parameters.AddWithValue("@pembeli", pembeli)
                                Using readery As MySqlDataReader = cmdy.ExecuteReader()
                                    If readery.Read() Then ' Pastikan ada data sebelum membaca
                                        alamat = readery("alamat").ToString() ' Hindari NullReferenceException
                                        npwppembeli = readery("npwp").ToString()
                                    End If
                                End Using
                            End Using
                        End Using
                        dgv1.Rows.Add(nomorUrut, tanggalFaktur.ToString("dd/MM/yyyy"), "Normal", kodeTransaksi, "", "", "", "" _
                                      , npwparta & "000000", npwppembeli, "TIN", "IDN", "-", pembeli, alamat, "", npwppembeli & "000000") ' Isi kolom "Baris" dengan nomor urut
                        nomorUrut += 1 ' Tambah nomor urut
                    End While
                End Using
            End Using
        End Using

    End Sub

    Private Sub btn_generate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_generate.Click
        If btn_generate.Text = "GENERATE" Then
            btn_generate.Text = "EKSPOR"
            Call load_dgv1()

        Else
            btn_generate.Text = "GENERATE"
            txt_tanggal.Text = ""
            txttahun.Text = ""
            txtbulan.Text = ""
            dgv1.Columns.Clear()
        End If
    End Sub

  
End Class