﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class form_menu_utama
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle45 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle46 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle47 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle48 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle49 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle50 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle51 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle52 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle53 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle54 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle55 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle56 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle57 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle58 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle59 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle60 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle61 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle62 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle63 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle64 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle65 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle66 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle67 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle68 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle69 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle70 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle71 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle72 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle73 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle74 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle75 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle76 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle77 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle78 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle79 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle80 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle81 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle82 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle83 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle84 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle85 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle86 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle87 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle88 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.SISTEMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LOGINToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LOGOUTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PenggunaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
        Me.KELUARToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DatabaseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CLIENTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SupplierToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.JenisBiayaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NamaSpecsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PPNPPh23ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PembelianToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DataPembelianToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UploadPembelianToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExportUploadPembelianToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CariNamaBarangSpecsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PenjualanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DataPenjualanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InputPenjualanKainToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InputPenjualanCelupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem6 = New System.Windows.Forms.ToolStripSeparator()
        Me.BuktiPotongToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OmsetPenjualanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GenerateSuratJalanDanFakturToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripSeparator()
        Me.UploadPenjualanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExportUploadPenjualanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.PrintEksporInvoiceBulananToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ts_print_sj_bulanan = New System.Windows.Forms.ToolStripMenuItem()
        Me.GreyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DataGreyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NeracaGreyBaruToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InputNamaHargaJualGreyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PenyusutanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UPAHDanGAJIToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BiayaTahunanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AngsuranPPh25ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaldoLaporanHPPToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SPTMasaPPNEfakturToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripSeparator()
        Me.LaporanKeuanganToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EksporExcelCoretaxToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchUpahDanGajiV129ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchHPPV126ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchAngsuranPPh25V126ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchPenyusutanV121ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchBiayaTahunanV125ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchBukpotV121aToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchPPNPPHV121ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchSPTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchBukpotToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchPenjualanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchSupplierToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchPembelianToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchGreyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchOmsetToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.Status1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Status2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.dgv1 = New System.Windows.Forms.DataGridView()
        Me.panel_bukpot = New System.Windows.Forms.Panel()
        Me.btn_refresh_bukpot = New System.Windows.Forms.Button()
        Me.txt_jumlah_bukpot = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dtp_bukpot = New System.Windows.Forms.DateTimePicker()
        Me.dgv_bukpot = New System.Windows.Forms.DataGridView()
        Me.btn_hitung_bukpot = New System.Windows.Forms.Button()
        Me.pn_laba_rugi = New System.Windows.Forms.Panel()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.dgv_hpp = New System.Windows.Forms.DataGridView()
        Me.dgv_saldo3 = New System.Windows.Forms.DataGridView()
        Me.dgv_saldo2 = New System.Windows.Forms.DataGridView()
        Me.dgv_saldo1 = New System.Windows.Forms.DataGridView()
        Me.dtp_akhir = New System.Windows.Forms.DateTimePicker()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lbl_hpp_tahun = New System.Windows.Forms.Label()
        Me.dtp_awal = New System.Windows.Forms.DateTimePicker()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.dgv_lapkeu_2 = New System.Windows.Forms.DataGridView()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lbl_lapkeu = New System.Windows.Forms.Label()
        Me.dgv_lapkeu = New System.Windows.Forms.DataGridView()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.dgv_biaya = New System.Windows.Forms.DataGridView()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.dgv_list_masukan = New System.Windows.Forms.DataGridView()
        Me.dgv_masukan = New System.Windows.Forms.DataGridView()
        Me.dgv_list_lain2 = New System.Windows.Forms.DataGridView()
        Me.dgv_list_batubara = New System.Windows.Forms.DataGridView()
        Me.dgv_list_obat = New System.Windows.Forms.DataGridView()
        Me.dgv_list_kain = New System.Windows.Forms.DataGridView()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.dgv_keluaran = New System.Windows.Forms.DataGridView()
        Me.dgv_keluaran_satuan = New System.Windows.Forms.DataGridView()
        Me.dgv_satuan_kg = New System.Windows.Forms.DataGridView()
        Me.dgv_satuan_mtr = New System.Windows.Forms.DataGridView()
        Me.dgv_list_keluaran = New System.Windows.Forms.DataGridView()
        Me.dgv_satuan_yard = New System.Windows.Forms.DataGridView()
        Me.dgv_list_keluaran_total = New System.Windows.Forms.DataGridView()
        Me.dgv_list_keluaran_kain = New System.Windows.Forms.DataGridView()
        Me.dgv_list_celup = New System.Windows.Forms.DataGridView()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.dgv_spt_clone = New System.Windows.Forms.DataGridView()
        Me.dgv_spt_aml = New System.Windows.Forms.DataGridView()
        Me.dgv_spt_efaktur = New System.Windows.Forms.DataGridView()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.dgv_pln = New System.Windows.Forms.DataGridView()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.dgv_bukpot_lapkeu = New System.Windows.Forms.DataGridView()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.dgv_gabungan_penyusutan_kendaraan = New System.Windows.Forms.DataGridView()
        Me.dgv_penyusutan_kendaraan = New System.Windows.Forms.DataGridView()
        Me.dgv_gabungan_penyusutan_bangunan = New System.Windows.Forms.DataGridView()
        Me.dgv_penyusutan_bangunan = New System.Windows.Forms.DataGridView()
        Me.dgv_gabungan_penyusutan_inventaris = New System.Windows.Forms.DataGridView()
        Me.dgv_penyusutan_inventaris = New System.Windows.Forms.DataGridView()
        Me.dgv_gabungan_penyusutan_tanki = New System.Windows.Forms.DataGridView()
        Me.dgv_penyusutan_tanki = New System.Windows.Forms.DataGridView()
        Me.dgv_gabungan_penyusutan_mesin = New System.Windows.Forms.DataGridView()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.dgv_induk_penyusutan_kendaraan = New System.Windows.Forms.DataGridView()
        Me.dgv_induk_penyusutan_bangunan = New System.Windows.Forms.DataGridView()
        Me.dgv_induk_penyusutan_inventaris = New System.Windows.Forms.DataGridView()
        Me.dgv_induk_penyusutan_tanki = New System.Windows.Forms.DataGridView()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.dgv_penyusutan_mesin = New System.Windows.Forms.DataGridView()
        Me.dgv_induk_penyusutan_mesin = New System.Windows.Forms.DataGridView()
        Me.btn_generate = New System.Windows.Forms.Button()
        Me.dtp_tahun = New System.Windows.Forms.DateTimePicker()
        Me.lbl_dgv1 = New System.Windows.Forms.Label()
        Me.btn_reset = New System.Windows.Forms.Button()
        Me.pn_nilai_laba_rugi = New System.Windows.Forms.Panel()
        Me.ck_akhir_kain_warna = New System.Windows.Forms.CheckBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.ck_awal_kain_warna = New System.Windows.Forms.CheckBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.ck_akhir_kain_proses = New System.Windows.Forms.CheckBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.ck_awal_kain_proses = New System.Windows.Forms.CheckBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.ck_akhir_tahun_obat = New System.Windows.Forms.CheckBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.ck_awal_tahun_obat = New System.Windows.Forms.CheckBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.ck_pbb = New System.Windows.Forms.CheckBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.ck_sewa_kantor = New System.Windows.Forms.CheckBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.ck_sewa_pabrik = New System.Windows.Forms.CheckBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.ck_ap1 = New System.Windows.Forms.CheckBox()
        Me.ck_ap12 = New System.Windows.Forms.CheckBox()
        Me.ck_ap11 = New System.Windows.Forms.CheckBox()
        Me.ck_ap10 = New System.Windows.Forms.CheckBox()
        Me.ck_ap9 = New System.Windows.Forms.CheckBox()
        Me.ck_ap8 = New System.Windows.Forms.CheckBox()
        Me.ck_ap7 = New System.Windows.Forms.CheckBox()
        Me.ck_ap6 = New System.Windows.Forms.CheckBox()
        Me.ck_ap5 = New System.Windows.Forms.CheckBox()
        Me.ck_ap4 = New System.Windows.Forms.CheckBox()
        Me.ck_ap3 = New System.Windows.Forms.CheckBox()
        Me.ck_ap2 = New System.Windows.Forms.CheckBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.ck_sp1 = New System.Windows.Forms.CheckBox()
        Me.ck_sp12 = New System.Windows.Forms.CheckBox()
        Me.ck_sp11 = New System.Windows.Forms.CheckBox()
        Me.ck_sp10 = New System.Windows.Forms.CheckBox()
        Me.ck_sp9 = New System.Windows.Forms.CheckBox()
        Me.ck_sp8 = New System.Windows.Forms.CheckBox()
        Me.ck_sp7 = New System.Windows.Forms.CheckBox()
        Me.ck_sp6 = New System.Windows.Forms.CheckBox()
        Me.ck_sp5 = New System.Windows.Forms.CheckBox()
        Me.ck_sp4 = New System.Windows.Forms.CheckBox()
        Me.ck_sp3 = New System.Windows.Forms.CheckBox()
        Me.ck_sp2 = New System.Windows.Forms.CheckBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.ck_uh1 = New System.Windows.Forms.CheckBox()
        Me.btn_refresh_generate = New System.Windows.Forms.Button()
        Me.ck_uh12 = New System.Windows.Forms.CheckBox()
        Me.lbl_nilai_laba_rugi = New System.Windows.Forms.Label()
        Me.ck_uh11 = New System.Windows.Forms.CheckBox()
        Me.lbl_laba_rugi = New System.Windows.Forms.Label()
        Me.ck_uh10 = New System.Windows.Forms.CheckBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.ck_uh9 = New System.Windows.Forms.CheckBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.ck_uh8 = New System.Windows.Forms.CheckBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.ck_uh7 = New System.Windows.Forms.CheckBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.ck_uh6 = New System.Windows.Forms.CheckBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.ck_uh5 = New System.Windows.Forms.CheckBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.ck_uh4 = New System.Windows.Forms.CheckBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.ck_uh3 = New System.Windows.Forms.CheckBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.ck_uh2 = New System.Windows.Forms.CheckBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panel_bukpot.SuspendLayout()
        CType(Me.dgv_bukpot, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pn_laba_rugi.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.dgv_hpp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_saldo3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_saldo2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_saldo1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.dgv_lapkeu_2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.dgv_lapkeu, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        CType(Me.dgv_biaya, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        CType(Me.dgv_list_masukan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_masukan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_list_lain2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_list_batubara, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_list_obat, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_list_kain, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage5.SuspendLayout()
        CType(Me.dgv_keluaran, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_keluaran_satuan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_satuan_kg, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_satuan_mtr, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_list_keluaran, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_satuan_yard, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_list_keluaran_total, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_list_keluaran_kain, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_list_celup, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage6.SuspendLayout()
        CType(Me.dgv_spt_clone, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_spt_aml, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_spt_efaktur, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage7.SuspendLayout()
        CType(Me.dgv_pln, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage8.SuspendLayout()
        CType(Me.dgv_bukpot_lapkeu, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage9.SuspendLayout()
        CType(Me.dgv_gabungan_penyusutan_kendaraan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_penyusutan_kendaraan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_gabungan_penyusutan_bangunan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_penyusutan_bangunan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_gabungan_penyusutan_inventaris, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_penyusutan_inventaris, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_gabungan_penyusutan_tanki, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_penyusutan_tanki, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_gabungan_penyusutan_mesin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_induk_penyusutan_kendaraan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_induk_penyusutan_bangunan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_induk_penyusutan_inventaris, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_induk_penyusutan_tanki, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_penyusutan_mesin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_induk_penyusutan_mesin, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pn_nilai_laba_rugi.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SISTEMToolStripMenuItem, Me.DatabaseToolStripMenuItem, Me.PembelianToolStripMenuItem, Me.PenjualanToolStripMenuItem, Me.GreyToolStripMenuItem, Me.ToolStripMenuItem2, Me.PatchToolStripMenuItem})
        Me.MenuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1244, 26)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'SISTEMToolStripMenuItem
        '
        Me.SISTEMToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LOGINToolStripMenuItem, Me.LOGOUTToolStripMenuItem, Me.PenggunaToolStripMenuItem, Me.ToolStripMenuItem1, Me.KELUARToolStripMenuItem})
        Me.SISTEMToolStripMenuItem.Name = "SISTEMToolStripMenuItem"
        Me.SISTEMToolStripMenuItem.Size = New System.Drawing.Size(80, 22)
        Me.SISTEMToolStripMenuItem.Text = "System"
        '
        'LOGINToolStripMenuItem
        '
        Me.LOGINToolStripMenuItem.Name = "LOGINToolStripMenuItem"
        Me.LOGINToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.LOGINToolStripMenuItem.Text = "Login"
        '
        'LOGOUTToolStripMenuItem
        '
        Me.LOGOUTToolStripMenuItem.Name = "LOGOUTToolStripMenuItem"
        Me.LOGOUTToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.LOGOUTToolStripMenuItem.Text = "Logout"
        '
        'PenggunaToolStripMenuItem
        '
        Me.PenggunaToolStripMenuItem.Name = "PenggunaToolStripMenuItem"
        Me.PenggunaToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.PenggunaToolStripMenuItem.Text = "Pengguna"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(153, 6)
        '
        'KELUARToolStripMenuItem
        '
        Me.KELUARToolStripMenuItem.Name = "KELUARToolStripMenuItem"
        Me.KELUARToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.KELUARToolStripMenuItem.Text = "Keluar"
        '
        'DatabaseToolStripMenuItem
        '
        Me.DatabaseToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CLIENTToolStripMenuItem, Me.SupplierToolStripMenuItem1, Me.JenisBiayaToolStripMenuItem, Me.NamaSpecsToolStripMenuItem, Me.PPNPPh23ToolStripMenuItem})
        Me.DatabaseToolStripMenuItem.Name = "DatabaseToolStripMenuItem"
        Me.DatabaseToolStripMenuItem.Size = New System.Drawing.Size(98, 22)
        Me.DatabaseToolStripMenuItem.Text = "Database"
        '
        'CLIENTToolStripMenuItem
        '
        Me.CLIENTToolStripMenuItem.Name = "CLIENTToolStripMenuItem"
        Me.CLIENTToolStripMenuItem.Size = New System.Drawing.Size(286, 22)
        Me.CLIENTToolStripMenuItem.Text = "Client"
        '
        'SupplierToolStripMenuItem1
        '
        Me.SupplierToolStripMenuItem1.Name = "SupplierToolStripMenuItem1"
        Me.SupplierToolStripMenuItem1.Size = New System.Drawing.Size(286, 22)
        Me.SupplierToolStripMenuItem1.Text = "Supplier"
        '
        'JenisBiayaToolStripMenuItem
        '
        Me.JenisBiayaToolStripMenuItem.Name = "JenisBiayaToolStripMenuItem"
        Me.JenisBiayaToolStripMenuItem.Size = New System.Drawing.Size(286, 22)
        Me.JenisBiayaToolStripMenuItem.Text = "Jenis Biaya"
        '
        'NamaSpecsToolStripMenuItem
        '
        Me.NamaSpecsToolStripMenuItem.Name = "NamaSpecsToolStripMenuItem"
        Me.NamaSpecsToolStripMenuItem.Size = New System.Drawing.Size(286, 22)
        Me.NamaSpecsToolStripMenuItem.Text = "Nama / Specs"
        '
        'PPNPPh23ToolStripMenuItem
        '
        Me.PPNPPh23ToolStripMenuItem.Name = "PPNPPh23ToolStripMenuItem"
        Me.PPNPPh23ToolStripMenuItem.Size = New System.Drawing.Size(286, 22)
        Me.PPNPPh23ToolStripMenuItem.Text = "Parameter (PPN, PPh, dll)"
        '
        'PembelianToolStripMenuItem
        '
        Me.PembelianToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DataPembelianToolStripMenuItem, Me.UploadPembelianToolStripMenuItem, Me.ToolStripMenuItem3, Me.ExportUploadPembelianToolStripMenuItem, Me.CariNamaBarangSpecsToolStripMenuItem})
        Me.PembelianToolStripMenuItem.Name = "PembelianToolStripMenuItem"
        Me.PembelianToolStripMenuItem.Size = New System.Drawing.Size(105, 22)
        Me.PembelianToolStripMenuItem.Text = "Pembelian"
        '
        'DataPembelianToolStripMenuItem
        '
        Me.DataPembelianToolStripMenuItem.Name = "DataPembelianToolStripMenuItem"
        Me.DataPembelianToolStripMenuItem.Size = New System.Drawing.Size(290, 22)
        Me.DataPembelianToolStripMenuItem.Text = "Data Pembelian"
        '
        'UploadPembelianToolStripMenuItem
        '
        Me.UploadPembelianToolStripMenuItem.Name = "UploadPembelianToolStripMenuItem"
        Me.UploadPembelianToolStripMenuItem.Size = New System.Drawing.Size(290, 22)
        Me.UploadPembelianToolStripMenuItem.Text = "Upload Pembelian"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(290, 22)
        Me.ToolStripMenuItem3.Text = "Input Pembelian Baru"
        '
        'ExportUploadPembelianToolStripMenuItem
        '
        Me.ExportUploadPembelianToolStripMenuItem.Name = "ExportUploadPembelianToolStripMenuItem"
        Me.ExportUploadPembelianToolStripMenuItem.Size = New System.Drawing.Size(290, 22)
        Me.ExportUploadPembelianToolStripMenuItem.Text = "Export Upload Pembelian"
        '
        'CariNamaBarangSpecsToolStripMenuItem
        '
        Me.CariNamaBarangSpecsToolStripMenuItem.Name = "CariNamaBarangSpecsToolStripMenuItem"
        Me.CariNamaBarangSpecsToolStripMenuItem.Size = New System.Drawing.Size(290, 22)
        Me.CariNamaBarangSpecsToolStripMenuItem.Text = "Cari Nama Barang / Specs"
        '
        'PenjualanToolStripMenuItem
        '
        Me.PenjualanToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DataPenjualanToolStripMenuItem, Me.InputPenjualanKainToolStripMenuItem, Me.InputPenjualanCelupToolStripMenuItem, Me.ToolStripMenuItem6, Me.BuktiPotongToolStripMenuItem, Me.OmsetPenjualanToolStripMenuItem, Me.GenerateSuratJalanDanFakturToolStripMenuItem, Me.ToolStripMenuItem5, Me.UploadPenjualanToolStripMenuItem, Me.ExportUploadPenjualanToolStripMenuItem, Me.ToolStripSeparator1, Me.PrintEksporInvoiceBulananToolStripMenuItem, Me.ts_print_sj_bulanan})
        Me.PenjualanToolStripMenuItem.Name = "PenjualanToolStripMenuItem"
        Me.PenjualanToolStripMenuItem.Size = New System.Drawing.Size(101, 22)
        Me.PenjualanToolStripMenuItem.Text = "Penjualan"
        '
        'DataPenjualanToolStripMenuItem
        '
        Me.DataPenjualanToolStripMenuItem.Name = "DataPenjualanToolStripMenuItem"
        Me.DataPenjualanToolStripMenuItem.Size = New System.Drawing.Size(344, 22)
        Me.DataPenjualanToolStripMenuItem.Text = "Data Penjualan"
        '
        'InputPenjualanKainToolStripMenuItem
        '
        Me.InputPenjualanKainToolStripMenuItem.Name = "InputPenjualanKainToolStripMenuItem"
        Me.InputPenjualanKainToolStripMenuItem.Size = New System.Drawing.Size(344, 22)
        Me.InputPenjualanKainToolStripMenuItem.Text = "Input Penjualan Kain"
        '
        'InputPenjualanCelupToolStripMenuItem
        '
        Me.InputPenjualanCelupToolStripMenuItem.Name = "InputPenjualanCelupToolStripMenuItem"
        Me.InputPenjualanCelupToolStripMenuItem.Size = New System.Drawing.Size(344, 22)
        Me.InputPenjualanCelupToolStripMenuItem.Text = "Input Penjualan Celup"
        '
        'ToolStripMenuItem6
        '
        Me.ToolStripMenuItem6.Name = "ToolStripMenuItem6"
        Me.ToolStripMenuItem6.Size = New System.Drawing.Size(341, 6)
        '
        'BuktiPotongToolStripMenuItem
        '
        Me.BuktiPotongToolStripMenuItem.Name = "BuktiPotongToolStripMenuItem"
        Me.BuktiPotongToolStripMenuItem.Size = New System.Drawing.Size(344, 22)
        Me.BuktiPotongToolStripMenuItem.Text = "Bukti Potong"
        '
        'OmsetPenjualanToolStripMenuItem
        '
        Me.OmsetPenjualanToolStripMenuItem.Name = "OmsetPenjualanToolStripMenuItem"
        Me.OmsetPenjualanToolStripMenuItem.Size = New System.Drawing.Size(344, 22)
        Me.OmsetPenjualanToolStripMenuItem.Text = "Omset Penjualan"
        '
        'GenerateSuratJalanDanFakturToolStripMenuItem
        '
        Me.GenerateSuratJalanDanFakturToolStripMenuItem.Name = "GenerateSuratJalanDanFakturToolStripMenuItem"
        Me.GenerateSuratJalanDanFakturToolStripMenuItem.Size = New System.Drawing.Size(344, 22)
        Me.GenerateSuratJalanDanFakturToolStripMenuItem.Text = "Generate Surat Jalan"
        '
        'ToolStripMenuItem5
        '
        Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
        Me.ToolStripMenuItem5.Size = New System.Drawing.Size(341, 6)
        '
        'UploadPenjualanToolStripMenuItem
        '
        Me.UploadPenjualanToolStripMenuItem.Name = "UploadPenjualanToolStripMenuItem"
        Me.UploadPenjualanToolStripMenuItem.Size = New System.Drawing.Size(344, 22)
        Me.UploadPenjualanToolStripMenuItem.Text = "Upload Penjualan"
        '
        'ExportUploadPenjualanToolStripMenuItem
        '
        Me.ExportUploadPenjualanToolStripMenuItem.Name = "ExportUploadPenjualanToolStripMenuItem"
        Me.ExportUploadPenjualanToolStripMenuItem.Size = New System.Drawing.Size(344, 22)
        Me.ExportUploadPenjualanToolStripMenuItem.Text = "Export Upload Penjualan"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(341, 6)
        '
        'PrintEksporInvoiceBulananToolStripMenuItem
        '
        Me.PrintEksporInvoiceBulananToolStripMenuItem.Name = "PrintEksporInvoiceBulananToolStripMenuItem"
        Me.PrintEksporInvoiceBulananToolStripMenuItem.Size = New System.Drawing.Size(344, 22)
        Me.PrintEksporInvoiceBulananToolStripMenuItem.Text = "Print/Ekspor Invoice Bulanan"
        '
        'ts_print_sj_bulanan
        '
        Me.ts_print_sj_bulanan.Name = "ts_print_sj_bulanan"
        Me.ts_print_sj_bulanan.Size = New System.Drawing.Size(344, 22)
        Me.ts_print_sj_bulanan.Text = "Print/Ekspor Surat Jalan Bulanan"
        '
        'GreyToolStripMenuItem
        '
        Me.GreyToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DataGreyToolStripMenuItem, Me.NeracaGreyBaruToolStripMenuItem, Me.InputNamaHargaJualGreyToolStripMenuItem})
        Me.GreyToolStripMenuItem.Name = "GreyToolStripMenuItem"
        Me.GreyToolStripMenuItem.Size = New System.Drawing.Size(57, 22)
        Me.GreyToolStripMenuItem.Text = "Grey"
        '
        'DataGreyToolStripMenuItem
        '
        Me.DataGreyToolStripMenuItem.Name = "DataGreyToolStripMenuItem"
        Me.DataGreyToolStripMenuItem.Size = New System.Drawing.Size(255, 22)
        Me.DataGreyToolStripMenuItem.Text = "Data Grey"
        '
        'NeracaGreyBaruToolStripMenuItem
        '
        Me.NeracaGreyBaruToolStripMenuItem.Name = "NeracaGreyBaruToolStripMenuItem"
        Me.NeracaGreyBaruToolStripMenuItem.Size = New System.Drawing.Size(255, 22)
        Me.NeracaGreyBaruToolStripMenuItem.Text = "Neraca Grey"
        '
        'InputNamaHargaJualGreyToolStripMenuItem
        '
        Me.InputNamaHargaJualGreyToolStripMenuItem.Name = "InputNamaHargaJualGreyToolStripMenuItem"
        Me.InputNamaHargaJualGreyToolStripMenuItem.Size = New System.Drawing.Size(255, 22)
        Me.InputNamaHargaJualGreyToolStripMenuItem.Text = "Input Harga Jual Grey"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PenyusutanToolStripMenuItem, Me.UPAHDanGAJIToolStripMenuItem, Me.BiayaTahunanToolStripMenuItem, Me.AngsuranPPh25ToolStripMenuItem, Me.SaldoLaporanHPPToolStripMenuItem, Me.SPTMasaPPNEfakturToolStripMenuItem, Me.ToolStripMenuItem4, Me.LaporanKeuanganToolStripMenuItem, Me.EksporExcelCoretaxToolStripMenuItem})
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(85, 22)
        Me.ToolStripMenuItem2.Text = "Laporan"
        '
        'PenyusutanToolStripMenuItem
        '
        Me.PenyusutanToolStripMenuItem.Name = "PenyusutanToolStripMenuItem"
        Me.PenyusutanToolStripMenuItem.Size = New System.Drawing.Size(256, 22)
        Me.PenyusutanToolStripMenuItem.Text = "Penyusutan"
        '
        'UPAHDanGAJIToolStripMenuItem
        '
        Me.UPAHDanGAJIToolStripMenuItem.Name = "UPAHDanGAJIToolStripMenuItem"
        Me.UPAHDanGAJIToolStripMenuItem.Size = New System.Drawing.Size(256, 22)
        Me.UPAHDanGAJIToolStripMenuItem.Text = "Upah dan Gaji"
        '
        'BiayaTahunanToolStripMenuItem
        '
        Me.BiayaTahunanToolStripMenuItem.Name = "BiayaTahunanToolStripMenuItem"
        Me.BiayaTahunanToolStripMenuItem.Size = New System.Drawing.Size(256, 22)
        Me.BiayaTahunanToolStripMenuItem.Text = "Biaya Tahunan"
        '
        'AngsuranPPh25ToolStripMenuItem
        '
        Me.AngsuranPPh25ToolStripMenuItem.Name = "AngsuranPPh25ToolStripMenuItem"
        Me.AngsuranPPh25ToolStripMenuItem.Size = New System.Drawing.Size(256, 22)
        Me.AngsuranPPh25ToolStripMenuItem.Text = "Angsuran PPh 25"
        '
        'SaldoLaporanHPPToolStripMenuItem
        '
        Me.SaldoLaporanHPPToolStripMenuItem.Name = "SaldoLaporanHPPToolStripMenuItem"
        Me.SaldoLaporanHPPToolStripMenuItem.Size = New System.Drawing.Size(256, 22)
        Me.SaldoLaporanHPPToolStripMenuItem.Text = "Saldo Laporan HPP"
        '
        'SPTMasaPPNEfakturToolStripMenuItem
        '
        Me.SPTMasaPPNEfakturToolStripMenuItem.Name = "SPTMasaPPNEfakturToolStripMenuItem"
        Me.SPTMasaPPNEfakturToolStripMenuItem.Size = New System.Drawing.Size(256, 22)
        Me.SPTMasaPPNEfakturToolStripMenuItem.Text = "SPT Masa PPN Efaktur"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(253, 6)
        '
        'LaporanKeuanganToolStripMenuItem
        '
        Me.LaporanKeuanganToolStripMenuItem.Name = "LaporanKeuanganToolStripMenuItem"
        Me.LaporanKeuanganToolStripMenuItem.Size = New System.Drawing.Size(256, 22)
        Me.LaporanKeuanganToolStripMenuItem.Text = "Laporan Keuangan"
        '
        'EksporExcelCoretaxToolStripMenuItem
        '
        Me.EksporExcelCoretaxToolStripMenuItem.Name = "EksporExcelCoretaxToolStripMenuItem"
        Me.EksporExcelCoretaxToolStripMenuItem.Size = New System.Drawing.Size(256, 22)
        Me.EksporExcelCoretaxToolStripMenuItem.Text = "Ekspor Excel Coretax"
        '
        'PatchToolStripMenuItem
        '
        Me.PatchToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PatchUpahDanGajiV129ToolStripMenuItem, Me.PatchHPPV126ToolStripMenuItem, Me.PatchAngsuranPPh25V126ToolStripMenuItem, Me.PatchPenyusutanV121ToolStripMenuItem, Me.PatchBiayaTahunanV125ToolStripMenuItem, Me.PatchBukpotV121aToolStripMenuItem, Me.PatchPPNPPHV121ToolStripMenuItem, Me.PatchSPTToolStripMenuItem, Me.PatchBukpotToolStripMenuItem, Me.PatchToolStripMenuItem1, Me.PatchPenjualanToolStripMenuItem, Me.PatchSupplierToolStripMenuItem, Me.PatchPembelianToolStripMenuItem, Me.PatchGreyToolStripMenuItem, Me.PatchOmsetToolStripMenuItem})
        Me.PatchToolStripMenuItem.Name = "PatchToolStripMenuItem"
        Me.PatchToolStripMenuItem.Size = New System.Drawing.Size(65, 22)
        Me.PatchToolStripMenuItem.Text = "Patch"
        '
        'PatchUpahDanGajiV129ToolStripMenuItem
        '
        Me.PatchUpahDanGajiV129ToolStripMenuItem.Name = "PatchUpahDanGajiV129ToolStripMenuItem"
        Me.PatchUpahDanGajiV129ToolStripMenuItem.Size = New System.Drawing.Size(327, 22)
        Me.PatchUpahDanGajiV129ToolStripMenuItem.Text = "Patch Upah dan Gaji v.1.2.9"
        '
        'PatchHPPV126ToolStripMenuItem
        '
        Me.PatchHPPV126ToolStripMenuItem.Name = "PatchHPPV126ToolStripMenuItem"
        Me.PatchHPPV126ToolStripMenuItem.Size = New System.Drawing.Size(327, 22)
        Me.PatchHPPV126ToolStripMenuItem.Text = "Patch Laporan HPP v.1.2.6"
        Me.PatchHPPV126ToolStripMenuItem.Visible = False
        '
        'PatchAngsuranPPh25V126ToolStripMenuItem
        '
        Me.PatchAngsuranPPh25V126ToolStripMenuItem.Name = "PatchAngsuranPPh25V126ToolStripMenuItem"
        Me.PatchAngsuranPPh25V126ToolStripMenuItem.Size = New System.Drawing.Size(327, 22)
        Me.PatchAngsuranPPh25V126ToolStripMenuItem.Text = "Patch Angsuran PPh 25 v.1.2.6"
        Me.PatchAngsuranPPh25V126ToolStripMenuItem.Visible = False
        '
        'PatchPenyusutanV121ToolStripMenuItem
        '
        Me.PatchPenyusutanV121ToolStripMenuItem.Name = "PatchPenyusutanV121ToolStripMenuItem"
        Me.PatchPenyusutanV121ToolStripMenuItem.Size = New System.Drawing.Size(327, 22)
        Me.PatchPenyusutanV121ToolStripMenuItem.Text = "Patch Penyusutan v.1.2.5"
        Me.PatchPenyusutanV121ToolStripMenuItem.Visible = False
        '
        'PatchBiayaTahunanV125ToolStripMenuItem
        '
        Me.PatchBiayaTahunanV125ToolStripMenuItem.Name = "PatchBiayaTahunanV125ToolStripMenuItem"
        Me.PatchBiayaTahunanV125ToolStripMenuItem.Size = New System.Drawing.Size(327, 22)
        Me.PatchBiayaTahunanV125ToolStripMenuItem.Text = "Patch Biaya Tahunan v.1.2.5"
        Me.PatchBiayaTahunanV125ToolStripMenuItem.Visible = False
        '
        'PatchBukpotV121aToolStripMenuItem
        '
        Me.PatchBukpotV121aToolStripMenuItem.Name = "PatchBukpotV121aToolStripMenuItem"
        Me.PatchBukpotV121aToolStripMenuItem.Size = New System.Drawing.Size(327, 22)
        Me.PatchBukpotV121aToolStripMenuItem.Text = "Patch Bukpot v.1.2.2a"
        Me.PatchBukpotV121aToolStripMenuItem.Visible = False
        '
        'PatchPPNPPHV121ToolStripMenuItem
        '
        Me.PatchPPNPPHV121ToolStripMenuItem.Name = "PatchPPNPPHV121ToolStripMenuItem"
        Me.PatchPPNPPHV121ToolStripMenuItem.Size = New System.Drawing.Size(327, 22)
        Me.PatchPPNPPHV121ToolStripMenuItem.Text = "Patch PPN / PPH v.1.2.1"
        Me.PatchPPNPPHV121ToolStripMenuItem.Visible = False
        '
        'PatchSPTToolStripMenuItem
        '
        Me.PatchSPTToolStripMenuItem.Name = "PatchSPTToolStripMenuItem"
        Me.PatchSPTToolStripMenuItem.Size = New System.Drawing.Size(327, 22)
        Me.PatchSPTToolStripMenuItem.Text = "Patch SPT v.1.2.1"
        Me.PatchSPTToolStripMenuItem.Visible = False
        '
        'PatchBukpotToolStripMenuItem
        '
        Me.PatchBukpotToolStripMenuItem.Name = "PatchBukpotToolStripMenuItem"
        Me.PatchBukpotToolStripMenuItem.Size = New System.Drawing.Size(327, 22)
        Me.PatchBukpotToolStripMenuItem.Text = "Patch Bukpot v.1.2.0a"
        Me.PatchBukpotToolStripMenuItem.Visible = False
        '
        'PatchToolStripMenuItem1
        '
        Me.PatchToolStripMenuItem1.Name = "PatchToolStripMenuItem1"
        Me.PatchToolStripMenuItem1.Size = New System.Drawing.Size(327, 22)
        Me.PatchToolStripMenuItem1.Text = "Patch Revisi 10 Jan 2024"
        Me.PatchToolStripMenuItem1.Visible = False
        '
        'PatchPenjualanToolStripMenuItem
        '
        Me.PatchPenjualanToolStripMenuItem.Name = "PatchPenjualanToolStripMenuItem"
        Me.PatchPenjualanToolStripMenuItem.Size = New System.Drawing.Size(327, 22)
        Me.PatchPenjualanToolStripMenuItem.Text = "Patch Penjualan"
        Me.PatchPenjualanToolStripMenuItem.Visible = False
        '
        'PatchSupplierToolStripMenuItem
        '
        Me.PatchSupplierToolStripMenuItem.Enabled = False
        Me.PatchSupplierToolStripMenuItem.Name = "PatchSupplierToolStripMenuItem"
        Me.PatchSupplierToolStripMenuItem.Size = New System.Drawing.Size(327, 22)
        Me.PatchSupplierToolStripMenuItem.Text = "Patch Supplier"
        Me.PatchSupplierToolStripMenuItem.Visible = False
        '
        'PatchPembelianToolStripMenuItem
        '
        Me.PatchPembelianToolStripMenuItem.Enabled = False
        Me.PatchPembelianToolStripMenuItem.Name = "PatchPembelianToolStripMenuItem"
        Me.PatchPembelianToolStripMenuItem.Size = New System.Drawing.Size(327, 22)
        Me.PatchPembelianToolStripMenuItem.Text = "Patch Pembelian"
        Me.PatchPembelianToolStripMenuItem.Visible = False
        '
        'PatchGreyToolStripMenuItem
        '
        Me.PatchGreyToolStripMenuItem.Enabled = False
        Me.PatchGreyToolStripMenuItem.Name = "PatchGreyToolStripMenuItem"
        Me.PatchGreyToolStripMenuItem.Size = New System.Drawing.Size(327, 22)
        Me.PatchGreyToolStripMenuItem.Text = "Patch Grey"
        Me.PatchGreyToolStripMenuItem.Visible = False
        '
        'PatchOmsetToolStripMenuItem
        '
        Me.PatchOmsetToolStripMenuItem.Name = "PatchOmsetToolStripMenuItem"
        Me.PatchOmsetToolStripMenuItem.Size = New System.Drawing.Size(327, 22)
        Me.PatchOmsetToolStripMenuItem.Text = "Patch Omset"
        Me.PatchOmsetToolStripMenuItem.Visible = False
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Status1, Me.Status2})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 727)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Padding = New System.Windows.Forms.Padding(1, 0, 12, 0)
        Me.StatusStrip1.Size = New System.Drawing.Size(1244, 22)
        Me.StatusStrip1.TabIndex = 3
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'Status1
        '
        Me.Status1.Name = "Status1"
        Me.Status1.Size = New System.Drawing.Size(45, 17)
        Me.Status1.Text = "Status1"
        '
        'Status2
        '
        Me.Status2.Name = "Status2"
        Me.Status2.Size = New System.Drawing.Size(45, 17)
        Me.Status2.Text = "Status2"
        '
        'dgv1
        '
        Me.dgv1.AllowUserToAddRows = False
        Me.dgv1.AllowUserToDeleteRows = False
        Me.dgv1.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle45.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle45.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle45.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle45.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle45.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle45.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle45.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv1.DefaultCellStyle = DataGridViewCellStyle45
        Me.dgv1.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv1.Location = New System.Drawing.Point(13, 693)
        Me.dgv1.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv1.MultiSelect = False
        Me.dgv1.Name = "dgv1"
        Me.dgv1.ReadOnly = True
        Me.dgv1.Size = New System.Drawing.Size(393, 25)
        Me.dgv1.TabIndex = 24
        Me.dgv1.Visible = False
        '
        'panel_bukpot
        '
        Me.panel_bukpot.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.panel_bukpot.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel_bukpot.Controls.Add(Me.btn_refresh_bukpot)
        Me.panel_bukpot.Controls.Add(Me.txt_jumlah_bukpot)
        Me.panel_bukpot.Controls.Add(Me.Label1)
        Me.panel_bukpot.Controls.Add(Me.dtp_bukpot)
        Me.panel_bukpot.Controls.Add(Me.dgv_bukpot)
        Me.panel_bukpot.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.panel_bukpot.Location = New System.Drawing.Point(502, 43)
        Me.panel_bukpot.Name = "panel_bukpot"
        Me.panel_bukpot.Size = New System.Drawing.Size(730, 329)
        Me.panel_bukpot.TabIndex = 26
        Me.panel_bukpot.Visible = False
        '
        'btn_refresh_bukpot
        '
        Me.btn_refresh_bukpot.Location = New System.Drawing.Point(618, 18)
        Me.btn_refresh_bukpot.Name = "btn_refresh_bukpot"
        Me.btn_refresh_bukpot.Size = New System.Drawing.Size(95, 23)
        Me.btn_refresh_bukpot.TabIndex = 29
        Me.btn_refresh_bukpot.Text = "REFRESH"
        Me.btn_refresh_bukpot.UseVisualStyleBackColor = True
        '
        'txt_jumlah_bukpot
        '
        Me.txt_jumlah_bukpot.Location = New System.Drawing.Point(241, 18)
        Me.txt_jumlah_bukpot.Name = "txt_jumlah_bukpot"
        Me.txt_jumlah_bukpot.ReadOnly = True
        Me.txt_jumlah_bukpot.Size = New System.Drawing.Size(62, 22)
        Me.txt_jumlah_bukpot.TabIndex = 27
        Me.txt_jumlah_bukpot.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(18, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(219, 14)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "Jumlah Faktur Belum Bukti Potong"
        '
        'dtp_bukpot
        '
        Me.dtp_bukpot.Location = New System.Drawing.Point(332, 18)
        Me.dtp_bukpot.Name = "dtp_bukpot"
        Me.dtp_bukpot.Size = New System.Drawing.Size(150, 22)
        Me.dtp_bukpot.TabIndex = 0
        Me.dtp_bukpot.Visible = False
        '
        'dgv_bukpot
        '
        Me.dgv_bukpot.AllowUserToAddRows = False
        Me.dgv_bukpot.AllowUserToDeleteRows = False
        Me.dgv_bukpot.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_bukpot.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle46.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle46.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle46.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle46.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle46.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle46.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_bukpot.DefaultCellStyle = DataGridViewCellStyle46
        Me.dgv_bukpot.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_bukpot.Location = New System.Drawing.Point(18, 47)
        Me.dgv_bukpot.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_bukpot.MultiSelect = False
        Me.dgv_bukpot.Name = "dgv_bukpot"
        Me.dgv_bukpot.ReadOnly = True
        Me.dgv_bukpot.Size = New System.Drawing.Size(695, 264)
        Me.dgv_bukpot.TabIndex = 25
        '
        'btn_hitung_bukpot
        '
        Me.btn_hitung_bukpot.Location = New System.Drawing.Point(413, 695)
        Me.btn_hitung_bukpot.Name = "btn_hitung_bukpot"
        Me.btn_hitung_bukpot.Size = New System.Drawing.Size(125, 23)
        Me.btn_hitung_bukpot.TabIndex = 28
        Me.btn_hitung_bukpot.Text = "Hitung Bukpot"
        Me.btn_hitung_bukpot.UseVisualStyleBackColor = True
        Me.btn_hitung_bukpot.Visible = False
        '
        'pn_laba_rugi
        '
        Me.pn_laba_rugi.Controls.Add(Me.TabControl1)
        Me.pn_laba_rugi.Controls.Add(Me.btn_generate)
        Me.pn_laba_rugi.Controls.Add(Me.dtp_tahun)
        Me.pn_laba_rugi.Controls.Add(Me.lbl_dgv1)
        Me.pn_laba_rugi.Controls.Add(Me.btn_reset)
        Me.pn_laba_rugi.Location = New System.Drawing.Point(678, 228)
        Me.pn_laba_rugi.Name = "pn_laba_rugi"
        Me.pn_laba_rugi.Size = New System.Drawing.Size(351, 113)
        Me.pn_laba_rugi.TabIndex = 30
        Me.pn_laba_rugi.Visible = False
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Controls.Add(Me.TabPage8)
        Me.TabControl1.Controls.Add(Me.TabPage9)
        Me.TabControl1.Location = New System.Drawing.Point(18, 33)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1130, 554)
        Me.TabControl1.TabIndex = 56
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage1.Controls.Add(Me.dgv_hpp)
        Me.TabPage1.Controls.Add(Me.dgv_saldo3)
        Me.TabPage1.Controls.Add(Me.dgv_saldo2)
        Me.TabPage1.Controls.Add(Me.dgv_saldo1)
        Me.TabPage1.Controls.Add(Me.dtp_akhir)
        Me.TabPage1.Controls.Add(Me.Panel2)
        Me.TabPage1.Controls.Add(Me.dtp_awal)
        Me.TabPage1.Controls.Add(Me.TextBox1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "HPP"
        '
        'dgv_hpp
        '
        Me.dgv_hpp.AllowUserToAddRows = False
        Me.dgv_hpp.AllowUserToDeleteRows = False
        Me.dgv_hpp.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_hpp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle47.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle47.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle47.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle47.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle47.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle47.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_hpp.DefaultCellStyle = DataGridViewCellStyle47
        Me.dgv_hpp.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_hpp.Location = New System.Drawing.Point(66, 91)
        Me.dgv_hpp.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_hpp.MultiSelect = False
        Me.dgv_hpp.Name = "dgv_hpp"
        Me.dgv_hpp.ReadOnly = True
        Me.dgv_hpp.Size = New System.Drawing.Size(990, 428)
        Me.dgv_hpp.TabIndex = 52
        '
        'dgv_saldo3
        '
        Me.dgv_saldo3.AllowUserToAddRows = False
        Me.dgv_saldo3.AllowUserToDeleteRows = False
        Me.dgv_saldo3.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_saldo3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle48.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle48.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle48.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle48.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle48.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle48.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle48.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_saldo3.DefaultCellStyle = DataGridViewCellStyle48
        Me.dgv_saldo3.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_saldo3.Location = New System.Drawing.Point(848, 352)
        Me.dgv_saldo3.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_saldo3.MultiSelect = False
        Me.dgv_saldo3.Name = "dgv_saldo3"
        Me.dgv_saldo3.ReadOnly = True
        Me.dgv_saldo3.Size = New System.Drawing.Size(86, 68)
        Me.dgv_saldo3.TabIndex = 64
        '
        'dgv_saldo2
        '
        Me.dgv_saldo2.AllowUserToAddRows = False
        Me.dgv_saldo2.AllowUserToDeleteRows = False
        Me.dgv_saldo2.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_saldo2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle49.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle49.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle49.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle49.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle49.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle49.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle49.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_saldo2.DefaultCellStyle = DataGridViewCellStyle49
        Me.dgv_saldo2.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_saldo2.Location = New System.Drawing.Point(848, 273)
        Me.dgv_saldo2.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_saldo2.MultiSelect = False
        Me.dgv_saldo2.Name = "dgv_saldo2"
        Me.dgv_saldo2.ReadOnly = True
        Me.dgv_saldo2.Size = New System.Drawing.Size(94, 70)
        Me.dgv_saldo2.TabIndex = 63
        '
        'dgv_saldo1
        '
        Me.dgv_saldo1.AllowUserToAddRows = False
        Me.dgv_saldo1.AllowUserToDeleteRows = False
        Me.dgv_saldo1.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_saldo1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle50.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle50.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle50.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle50.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle50.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle50.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle50.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_saldo1.DefaultCellStyle = DataGridViewCellStyle50
        Me.dgv_saldo1.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_saldo1.Location = New System.Drawing.Point(848, 175)
        Me.dgv_saldo1.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_saldo1.MultiSelect = False
        Me.dgv_saldo1.Name = "dgv_saldo1"
        Me.dgv_saldo1.ReadOnly = True
        Me.dgv_saldo1.Size = New System.Drawing.Size(76, 70)
        Me.dgv_saldo1.TabIndex = 62
        '
        'dtp_akhir
        '
        Me.dtp_akhir.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtp_akhir.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtp_akhir.Location = New System.Drawing.Point(901, 146)
        Me.dtp_akhir.Margin = New System.Windows.Forms.Padding(4)
        Me.dtp_akhir.Name = "dtp_akhir"
        Me.dtp_akhir.Size = New System.Drawing.Size(115, 23)
        Me.dtp_akhir.TabIndex = 61
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.Window
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.lbl_hpp_tahun)
        Me.Panel2.Location = New System.Drawing.Point(66, 6)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(990, 62)
        Me.Panel2.TabIndex = 57
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(384, 22)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(205, 13)
        Me.Label7.TabIndex = 54
        Me.Label7.Text = "LAPORAN HARGA POKOK PENJUALAN"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(412, 4)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(153, 13)
        Me.Label6.TabIndex = 53
        Me.Label6.Text = "CV. ARTHA MEKAR LESTARI"
        '
        'lbl_hpp_tahun
        '
        Me.lbl_hpp_tahun.Location = New System.Drawing.Point(22, 37)
        Me.lbl_hpp_tahun.Name = "lbl_hpp_tahun"
        Me.lbl_hpp_tahun.Size = New System.Drawing.Size(945, 19)
        Me.lbl_hpp_tahun.TabIndex = 55
        Me.lbl_hpp_tahun.Text = "1 JANUARI - 31 DESEMBER"
        Me.lbl_hpp_tahun.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'dtp_awal
        '
        Me.dtp_awal.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtp_awal.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtp_awal.Location = New System.Drawing.Point(901, 113)
        Me.dtp_awal.Margin = New System.Windows.Forms.Padding(4)
        Me.dtp_awal.Name = "dtp_awal"
        Me.dtp_awal.Size = New System.Drawing.Size(115, 23)
        Me.dtp_awal.TabIndex = 60
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(66, 69)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(990, 20)
        Me.TextBox1.TabIndex = 56
        Me.TextBox1.Text = "(Dalam Rupiah)"
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage2.Controls.Add(Me.dgv_lapkeu_2)
        Me.TabPage2.Controls.Add(Me.Panel3)
        Me.TabPage2.Controls.Add(Me.dgv_lapkeu)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Laporan Keuangan"
        '
        'dgv_lapkeu_2
        '
        Me.dgv_lapkeu_2.AllowUserToAddRows = False
        Me.dgv_lapkeu_2.AllowUserToDeleteRows = False
        Me.dgv_lapkeu_2.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_lapkeu_2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle51.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle51.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle51.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle51.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle51.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle51.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle51.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_lapkeu_2.DefaultCellStyle = DataGridViewCellStyle51
        Me.dgv_lapkeu_2.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_lapkeu_2.Location = New System.Drawing.Point(46, 399)
        Me.dgv_lapkeu_2.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_lapkeu_2.MultiSelect = False
        Me.dgv_lapkeu_2.Name = "dgv_lapkeu_2"
        Me.dgv_lapkeu_2.ReadOnly = True
        Me.dgv_lapkeu_2.Size = New System.Drawing.Size(1030, 125)
        Me.dgv_lapkeu_2.TabIndex = 65
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.Window
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.Label8)
        Me.Panel3.Controls.Add(Me.Label9)
        Me.Panel3.Controls.Add(Me.lbl_lapkeu)
        Me.Panel3.Location = New System.Drawing.Point(46, 5)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1030, 62)
        Me.Panel3.TabIndex = 64
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(450, 22)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(118, 13)
        Me.Label8.TabIndex = 54
        Me.Label8.Text = "LAPORAN LABA RUGI"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(432, 4)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(153, 13)
        Me.Label9.TabIndex = 53
        Me.Label9.Text = "CV. ARTHA MEKAR LESTARI"
        '
        'lbl_lapkeu
        '
        Me.lbl_lapkeu.Location = New System.Drawing.Point(42, 37)
        Me.lbl_lapkeu.Name = "lbl_lapkeu"
        Me.lbl_lapkeu.Size = New System.Drawing.Size(945, 19)
        Me.lbl_lapkeu.TabIndex = 55
        Me.lbl_lapkeu.Text = "1 JANUARI - 31 DESEMBER"
        Me.lbl_lapkeu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'dgv_lapkeu
        '
        Me.dgv_lapkeu.AllowUserToAddRows = False
        Me.dgv_lapkeu.AllowUserToDeleteRows = False
        Me.dgv_lapkeu.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_lapkeu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle52.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle52.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle52.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle52.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle52.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle52.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle52.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_lapkeu.DefaultCellStyle = DataGridViewCellStyle52
        Me.dgv_lapkeu.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_lapkeu.Location = New System.Drawing.Point(46, 69)
        Me.dgv_lapkeu.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_lapkeu.MultiSelect = False
        Me.dgv_lapkeu.Name = "dgv_lapkeu"
        Me.dgv_lapkeu.ReadOnly = True
        Me.dgv_lapkeu.Size = New System.Drawing.Size(1030, 325)
        Me.dgv_lapkeu.TabIndex = 62
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage3.Controls.Add(Me.dgv_biaya)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Biaya"
        '
        'dgv_biaya
        '
        Me.dgv_biaya.AllowUserToAddRows = False
        Me.dgv_biaya.AllowUserToDeleteRows = False
        Me.dgv_biaya.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_biaya.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle53.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle53.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle53.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle53.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle53.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle53.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle53.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_biaya.DefaultCellStyle = DataGridViewCellStyle53
        Me.dgv_biaya.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_biaya.Location = New System.Drawing.Point(6, 7)
        Me.dgv_biaya.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_biaya.MultiSelect = False
        Me.dgv_biaya.Name = "dgv_biaya"
        Me.dgv_biaya.ReadOnly = True
        Me.dgv_biaya.Size = New System.Drawing.Size(1110, 514)
        Me.dgv_biaya.TabIndex = 51
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage4.Controls.Add(Me.dgv_list_masukan)
        Me.TabPage4.Controls.Add(Me.dgv_masukan)
        Me.TabPage4.Controls.Add(Me.dgv_list_lain2)
        Me.TabPage4.Controls.Add(Me.dgv_list_batubara)
        Me.TabPage4.Controls.Add(Me.dgv_list_obat)
        Me.TabPage4.Controls.Add(Me.dgv_list_kain)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Masukan"
        '
        'dgv_list_masukan
        '
        Me.dgv_list_masukan.AllowUserToAddRows = False
        Me.dgv_list_masukan.AllowUserToDeleteRows = False
        Me.dgv_list_masukan.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_masukan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_list_masukan.ColumnHeadersVisible = False
        DataGridViewCellStyle54.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle54.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle54.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle54.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle54.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle54.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle54.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_masukan.DefaultCellStyle = DataGridViewCellStyle54
        Me.dgv_list_masukan.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_masukan.Location = New System.Drawing.Point(9, 339)
        Me.dgv_list_masukan.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_masukan.MultiSelect = False
        Me.dgv_list_masukan.Name = "dgv_list_masukan"
        Me.dgv_list_masukan.ReadOnly = True
        Me.dgv_list_masukan.Size = New System.Drawing.Size(690, 180)
        Me.dgv_list_masukan.TabIndex = 52
        '
        'dgv_masukan
        '
        Me.dgv_masukan.AllowUserToAddRows = False
        Me.dgv_masukan.AllowUserToDeleteRows = False
        Me.dgv_masukan.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_masukan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle55.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle55.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle55.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle55.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle55.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle55.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle55.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_masukan.DefaultCellStyle = DataGridViewCellStyle55
        Me.dgv_masukan.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_masukan.Location = New System.Drawing.Point(9, 11)
        Me.dgv_masukan.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_masukan.MultiSelect = False
        Me.dgv_masukan.Name = "dgv_masukan"
        Me.dgv_masukan.ReadOnly = True
        Me.dgv_masukan.Size = New System.Drawing.Size(890, 320)
        Me.dgv_masukan.TabIndex = 50
        '
        'dgv_list_lain2
        '
        Me.dgv_list_lain2.AllowUserToAddRows = False
        Me.dgv_list_lain2.AllowUserToDeleteRows = False
        Me.dgv_list_lain2.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_lain2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle56.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle56.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle56.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle56.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle56.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle56.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle56.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_lain2.DefaultCellStyle = DataGridViewCellStyle56
        Me.dgv_list_lain2.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_lain2.Location = New System.Drawing.Point(622, 118)
        Me.dgv_list_lain2.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_lain2.MultiSelect = False
        Me.dgv_list_lain2.Name = "dgv_list_lain2"
        Me.dgv_list_lain2.ReadOnly = True
        Me.dgv_list_lain2.Size = New System.Drawing.Size(432, 169)
        Me.dgv_list_lain2.TabIndex = 55
        Me.dgv_list_lain2.Visible = False
        '
        'dgv_list_batubara
        '
        Me.dgv_list_batubara.AllowUserToAddRows = False
        Me.dgv_list_batubara.AllowUserToDeleteRows = False
        Me.dgv_list_batubara.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_batubara.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle57.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle57.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle57.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle57.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle57.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle57.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle57.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_batubara.DefaultCellStyle = DataGridViewCellStyle57
        Me.dgv_list_batubara.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_batubara.Location = New System.Drawing.Point(622, 194)
        Me.dgv_list_batubara.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_batubara.MultiSelect = False
        Me.dgv_list_batubara.Name = "dgv_list_batubara"
        Me.dgv_list_batubara.ReadOnly = True
        Me.dgv_list_batubara.Size = New System.Drawing.Size(432, 169)
        Me.dgv_list_batubara.TabIndex = 54
        Me.dgv_list_batubara.Visible = False
        '
        'dgv_list_obat
        '
        Me.dgv_list_obat.AllowUserToAddRows = False
        Me.dgv_list_obat.AllowUserToDeleteRows = False
        Me.dgv_list_obat.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_obat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle58.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle58.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle58.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle58.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle58.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle58.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle58.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_obat.DefaultCellStyle = DataGridViewCellStyle58
        Me.dgv_list_obat.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_obat.Location = New System.Drawing.Point(622, 278)
        Me.dgv_list_obat.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_obat.MultiSelect = False
        Me.dgv_list_obat.Name = "dgv_list_obat"
        Me.dgv_list_obat.ReadOnly = True
        Me.dgv_list_obat.Size = New System.Drawing.Size(432, 169)
        Me.dgv_list_obat.TabIndex = 53
        Me.dgv_list_obat.Visible = False
        '
        'dgv_list_kain
        '
        Me.dgv_list_kain.AllowUserToAddRows = False
        Me.dgv_list_kain.AllowUserToDeleteRows = False
        Me.dgv_list_kain.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_kain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle59.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle59.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle59.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle59.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle59.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle59.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle59.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_kain.DefaultCellStyle = DataGridViewCellStyle59
        Me.dgv_list_kain.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_kain.Location = New System.Drawing.Point(622, 352)
        Me.dgv_list_kain.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_kain.MultiSelect = False
        Me.dgv_list_kain.Name = "dgv_list_kain"
        Me.dgv_list_kain.ReadOnly = True
        Me.dgv_list_kain.Size = New System.Drawing.Size(432, 169)
        Me.dgv_list_kain.TabIndex = 51
        Me.dgv_list_kain.Visible = False
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage5.Controls.Add(Me.dgv_keluaran)
        Me.TabPage5.Controls.Add(Me.dgv_keluaran_satuan)
        Me.TabPage5.Controls.Add(Me.dgv_satuan_kg)
        Me.TabPage5.Controls.Add(Me.dgv_satuan_mtr)
        Me.TabPage5.Controls.Add(Me.dgv_list_keluaran)
        Me.TabPage5.Controls.Add(Me.dgv_satuan_yard)
        Me.TabPage5.Controls.Add(Me.dgv_list_keluaran_total)
        Me.TabPage5.Controls.Add(Me.dgv_list_keluaran_kain)
        Me.TabPage5.Controls.Add(Me.dgv_list_celup)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Keluaran"
        '
        'dgv_keluaran
        '
        Me.dgv_keluaran.AllowUserToAddRows = False
        Me.dgv_keluaran.AllowUserToDeleteRows = False
        Me.dgv_keluaran.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_keluaran.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle60.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle60.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle60.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle60.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle60.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle60.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle60.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_keluaran.DefaultCellStyle = DataGridViewCellStyle60
        Me.dgv_keluaran.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_keluaran.Location = New System.Drawing.Point(9, 9)
        Me.dgv_keluaran.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_keluaran.MultiSelect = False
        Me.dgv_keluaran.Name = "dgv_keluaran"
        Me.dgv_keluaran.ReadOnly = True
        Me.dgv_keluaran.Size = New System.Drawing.Size(1105, 320)
        Me.dgv_keluaran.TabIndex = 52
        '
        'dgv_keluaran_satuan
        '
        Me.dgv_keluaran_satuan.AllowUserToAddRows = False
        Me.dgv_keluaran_satuan.AllowUserToDeleteRows = False
        Me.dgv_keluaran_satuan.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_keluaran_satuan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_keluaran_satuan.ColumnHeadersVisible = False
        DataGridViewCellStyle61.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle61.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle61.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle61.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle61.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle61.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle61.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_keluaran_satuan.DefaultCellStyle = DataGridViewCellStyle61
        Me.dgv_keluaran_satuan.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_keluaran_satuan.Location = New System.Drawing.Point(574, 339)
        Me.dgv_keluaran_satuan.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_keluaran_satuan.MultiSelect = False
        Me.dgv_keluaran_satuan.Name = "dgv_keluaran_satuan"
        Me.dgv_keluaran_satuan.ReadOnly = True
        Me.dgv_keluaran_satuan.Size = New System.Drawing.Size(540, 180)
        Me.dgv_keluaran_satuan.TabIndex = 61
        '
        'dgv_satuan_kg
        '
        Me.dgv_satuan_kg.AllowUserToAddRows = False
        Me.dgv_satuan_kg.AllowUserToDeleteRows = False
        Me.dgv_satuan_kg.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_satuan_kg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle62.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle62.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle62.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle62.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle62.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle62.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle62.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_satuan_kg.DefaultCellStyle = DataGridViewCellStyle62
        Me.dgv_satuan_kg.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_satuan_kg.Location = New System.Drawing.Point(622, 320)
        Me.dgv_satuan_kg.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_satuan_kg.MultiSelect = False
        Me.dgv_satuan_kg.Name = "dgv_satuan_kg"
        Me.dgv_satuan_kg.ReadOnly = True
        Me.dgv_satuan_kg.Size = New System.Drawing.Size(432, 169)
        Me.dgv_satuan_kg.TabIndex = 63
        Me.dgv_satuan_kg.Visible = False
        '
        'dgv_satuan_mtr
        '
        Me.dgv_satuan_mtr.AllowUserToAddRows = False
        Me.dgv_satuan_mtr.AllowUserToDeleteRows = False
        Me.dgv_satuan_mtr.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_satuan_mtr.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle63.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle63.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle63.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle63.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle63.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle63.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle63.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_satuan_mtr.DefaultCellStyle = DataGridViewCellStyle63
        Me.dgv_satuan_mtr.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_satuan_mtr.Location = New System.Drawing.Point(622, 222)
        Me.dgv_satuan_mtr.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_satuan_mtr.MultiSelect = False
        Me.dgv_satuan_mtr.Name = "dgv_satuan_mtr"
        Me.dgv_satuan_mtr.ReadOnly = True
        Me.dgv_satuan_mtr.Size = New System.Drawing.Size(432, 169)
        Me.dgv_satuan_mtr.TabIndex = 62
        Me.dgv_satuan_mtr.Visible = False
        '
        'dgv_list_keluaran
        '
        Me.dgv_list_keluaran.AllowUserToAddRows = False
        Me.dgv_list_keluaran.AllowUserToDeleteRows = False
        Me.dgv_list_keluaran.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_keluaran.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_list_keluaran.ColumnHeadersVisible = False
        DataGridViewCellStyle64.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle64.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle64.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle64.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle64.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle64.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle64.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_keluaran.DefaultCellStyle = DataGridViewCellStyle64
        Me.dgv_list_keluaran.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_keluaran.Location = New System.Drawing.Point(9, 339)
        Me.dgv_list_keluaran.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_keluaran.MultiSelect = False
        Me.dgv_list_keluaran.Name = "dgv_list_keluaran"
        Me.dgv_list_keluaran.ReadOnly = True
        Me.dgv_list_keluaran.Size = New System.Drawing.Size(540, 180)
        Me.dgv_list_keluaran.TabIndex = 57
        '
        'dgv_satuan_yard
        '
        Me.dgv_satuan_yard.AllowUserToAddRows = False
        Me.dgv_satuan_yard.AllowUserToDeleteRows = False
        Me.dgv_satuan_yard.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_satuan_yard.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle65.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle65.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle65.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle65.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle65.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle65.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle65.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_satuan_yard.DefaultCellStyle = DataGridViewCellStyle65
        Me.dgv_satuan_yard.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_satuan_yard.Location = New System.Drawing.Point(622, 120)
        Me.dgv_satuan_yard.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_satuan_yard.MultiSelect = False
        Me.dgv_satuan_yard.Name = "dgv_satuan_yard"
        Me.dgv_satuan_yard.ReadOnly = True
        Me.dgv_satuan_yard.Size = New System.Drawing.Size(432, 169)
        Me.dgv_satuan_yard.TabIndex = 60
        Me.dgv_satuan_yard.Visible = False
        '
        'dgv_list_keluaran_total
        '
        Me.dgv_list_keluaran_total.AllowUserToAddRows = False
        Me.dgv_list_keluaran_total.AllowUserToDeleteRows = False
        Me.dgv_list_keluaran_total.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_keluaran_total.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle66.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle66.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle66.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle66.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle66.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle66.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle66.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_keluaran_total.DefaultCellStyle = DataGridViewCellStyle66
        Me.dgv_list_keluaran_total.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_keluaran_total.Location = New System.Drawing.Point(67, 162)
        Me.dgv_list_keluaran_total.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_keluaran_total.MultiSelect = False
        Me.dgv_list_keluaran_total.Name = "dgv_list_keluaran_total"
        Me.dgv_list_keluaran_total.ReadOnly = True
        Me.dgv_list_keluaran_total.Size = New System.Drawing.Size(432, 169)
        Me.dgv_list_keluaran_total.TabIndex = 59
        Me.dgv_list_keluaran_total.Visible = False
        '
        'dgv_list_keluaran_kain
        '
        Me.dgv_list_keluaran_kain.AllowUserToAddRows = False
        Me.dgv_list_keluaran_kain.AllowUserToDeleteRows = False
        Me.dgv_list_keluaran_kain.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_keluaran_kain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle67.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle67.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle67.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle67.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle67.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle67.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle67.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_keluaran_kain.DefaultCellStyle = DataGridViewCellStyle67
        Me.dgv_list_keluaran_kain.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_keluaran_kain.Location = New System.Drawing.Point(67, 246)
        Me.dgv_list_keluaran_kain.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_keluaran_kain.MultiSelect = False
        Me.dgv_list_keluaran_kain.Name = "dgv_list_keluaran_kain"
        Me.dgv_list_keluaran_kain.ReadOnly = True
        Me.dgv_list_keluaran_kain.Size = New System.Drawing.Size(432, 169)
        Me.dgv_list_keluaran_kain.TabIndex = 58
        Me.dgv_list_keluaran_kain.Visible = False
        '
        'dgv_list_celup
        '
        Me.dgv_list_celup.AllowUserToAddRows = False
        Me.dgv_list_celup.AllowUserToDeleteRows = False
        Me.dgv_list_celup.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_celup.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle68.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle68.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle68.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle68.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle68.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle68.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle68.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_celup.DefaultCellStyle = DataGridViewCellStyle68
        Me.dgv_list_celup.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_celup.Location = New System.Drawing.Point(67, 320)
        Me.dgv_list_celup.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_celup.MultiSelect = False
        Me.dgv_list_celup.Name = "dgv_list_celup"
        Me.dgv_list_celup.ReadOnly = True
        Me.dgv_list_celup.Size = New System.Drawing.Size(432, 169)
        Me.dgv_list_celup.TabIndex = 56
        Me.dgv_list_celup.Visible = False
        '
        'TabPage6
        '
        Me.TabPage6.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage6.Controls.Add(Me.dgv_spt_clone)
        Me.TabPage6.Controls.Add(Me.dgv_spt_aml)
        Me.TabPage6.Controls.Add(Me.dgv_spt_efaktur)
        Me.TabPage6.Location = New System.Drawing.Point(4, 22)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "SPT Masa PPN"
        '
        'dgv_spt_clone
        '
        Me.dgv_spt_clone.AllowUserToAddRows = False
        Me.dgv_spt_clone.AllowUserToDeleteRows = False
        Me.dgv_spt_clone.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_spt_clone.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle69.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle69.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle69.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle69.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle69.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle69.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle69.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_spt_clone.DefaultCellStyle = DataGridViewCellStyle69
        Me.dgv_spt_clone.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_spt_clone.Location = New System.Drawing.Point(9, 13)
        Me.dgv_spt_clone.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_spt_clone.MultiSelect = False
        Me.dgv_spt_clone.Name = "dgv_spt_clone"
        Me.dgv_spt_clone.ReadOnly = True
        Me.dgv_spt_clone.Size = New System.Drawing.Size(1105, 250)
        Me.dgv_spt_clone.TabIndex = 52
        '
        'dgv_spt_aml
        '
        Me.dgv_spt_aml.AllowUserToAddRows = False
        Me.dgv_spt_aml.AllowUserToDeleteRows = False
        Me.dgv_spt_aml.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_spt_aml.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle70.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle70.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle70.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle70.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle70.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle70.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle70.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_spt_aml.DefaultCellStyle = DataGridViewCellStyle70
        Me.dgv_spt_aml.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_spt_aml.Location = New System.Drawing.Point(9, 271)
        Me.dgv_spt_aml.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_spt_aml.MultiSelect = False
        Me.dgv_spt_aml.Name = "dgv_spt_aml"
        Me.dgv_spt_aml.ReadOnly = True
        Me.dgv_spt_aml.Size = New System.Drawing.Size(1105, 250)
        Me.dgv_spt_aml.TabIndex = 51
        '
        'dgv_spt_efaktur
        '
        Me.dgv_spt_efaktur.AllowUserToAddRows = False
        Me.dgv_spt_efaktur.AllowUserToDeleteRows = False
        Me.dgv_spt_efaktur.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_spt_efaktur.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle71.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle71.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle71.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle71.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle71.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle71.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle71.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_spt_efaktur.DefaultCellStyle = DataGridViewCellStyle71
        Me.dgv_spt_efaktur.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_spt_efaktur.Location = New System.Drawing.Point(9, 13)
        Me.dgv_spt_efaktur.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_spt_efaktur.MultiSelect = False
        Me.dgv_spt_efaktur.Name = "dgv_spt_efaktur"
        Me.dgv_spt_efaktur.ReadOnly = True
        Me.dgv_spt_efaktur.Size = New System.Drawing.Size(1105, 250)
        Me.dgv_spt_efaktur.TabIndex = 50
        '
        'TabPage7
        '
        Me.TabPage7.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage7.Controls.Add(Me.dgv_pln)
        Me.TabPage7.Location = New System.Drawing.Point(4, 22)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "PLN Garam Coal"
        '
        'dgv_pln
        '
        Me.dgv_pln.AllowUserToAddRows = False
        Me.dgv_pln.AllowUserToDeleteRows = False
        Me.dgv_pln.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_pln.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle72.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle72.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle72.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle72.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle72.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle72.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle72.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_pln.DefaultCellStyle = DataGridViewCellStyle72
        Me.dgv_pln.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_pln.Location = New System.Drawing.Point(9, 24)
        Me.dgv_pln.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_pln.MultiSelect = False
        Me.dgv_pln.Name = "dgv_pln"
        Me.dgv_pln.ReadOnly = True
        Me.dgv_pln.Size = New System.Drawing.Size(650, 320)
        Me.dgv_pln.TabIndex = 49
        '
        'TabPage8
        '
        Me.TabPage8.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage8.Controls.Add(Me.dgv_bukpot_lapkeu)
        Me.TabPage8.Location = New System.Drawing.Point(4, 22)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage8.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage8.TabIndex = 7
        Me.TabPage8.Text = "Bukti Potong"
        '
        'dgv_bukpot_lapkeu
        '
        Me.dgv_bukpot_lapkeu.AllowUserToAddRows = False
        Me.dgv_bukpot_lapkeu.AllowUserToDeleteRows = False
        Me.dgv_bukpot_lapkeu.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_bukpot_lapkeu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle73.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle73.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle73.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle73.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle73.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle73.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle73.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_bukpot_lapkeu.DefaultCellStyle = DataGridViewCellStyle73
        Me.dgv_bukpot_lapkeu.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_bukpot_lapkeu.Location = New System.Drawing.Point(9, 24)
        Me.dgv_bukpot_lapkeu.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_bukpot_lapkeu.MultiSelect = False
        Me.dgv_bukpot_lapkeu.Name = "dgv_bukpot_lapkeu"
        Me.dgv_bukpot_lapkeu.ReadOnly = True
        Me.dgv_bukpot_lapkeu.Size = New System.Drawing.Size(1105, 485)
        Me.dgv_bukpot_lapkeu.TabIndex = 48
        '
        'TabPage9
        '
        Me.TabPage9.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage9.Controls.Add(Me.dgv_gabungan_penyusutan_kendaraan)
        Me.TabPage9.Controls.Add(Me.dgv_penyusutan_kendaraan)
        Me.TabPage9.Controls.Add(Me.dgv_gabungan_penyusutan_bangunan)
        Me.TabPage9.Controls.Add(Me.dgv_penyusutan_bangunan)
        Me.TabPage9.Controls.Add(Me.dgv_gabungan_penyusutan_inventaris)
        Me.TabPage9.Controls.Add(Me.dgv_penyusutan_inventaris)
        Me.TabPage9.Controls.Add(Me.dgv_gabungan_penyusutan_tanki)
        Me.TabPage9.Controls.Add(Me.dgv_penyusutan_tanki)
        Me.TabPage9.Controls.Add(Me.dgv_gabungan_penyusutan_mesin)
        Me.TabPage9.Controls.Add(Me.Label5)
        Me.TabPage9.Controls.Add(Me.Label4)
        Me.TabPage9.Controls.Add(Me.Label3)
        Me.TabPage9.Controls.Add(Me.Label2)
        Me.TabPage9.Controls.Add(Me.dgv_induk_penyusutan_kendaraan)
        Me.TabPage9.Controls.Add(Me.dgv_induk_penyusutan_bangunan)
        Me.TabPage9.Controls.Add(Me.dgv_induk_penyusutan_inventaris)
        Me.TabPage9.Controls.Add(Me.dgv_induk_penyusutan_tanki)
        Me.TabPage9.Controls.Add(Me.Label10)
        Me.TabPage9.Controls.Add(Me.dgv_penyusutan_mesin)
        Me.TabPage9.Controls.Add(Me.dgv_induk_penyusutan_mesin)
        Me.TabPage9.Location = New System.Drawing.Point(4, 22)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage9.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage9.TabIndex = 8
        Me.TabPage9.Text = "Rincian Penyusutan"
        '
        'dgv_gabungan_penyusutan_kendaraan
        '
        Me.dgv_gabungan_penyusutan_kendaraan.AllowUserToAddRows = False
        Me.dgv_gabungan_penyusutan_kendaraan.AllowUserToDeleteRows = False
        Me.dgv_gabungan_penyusutan_kendaraan.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_gabungan_penyusutan_kendaraan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle74.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle74.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle74.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle74.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle74.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle74.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle74.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_gabungan_penyusutan_kendaraan.DefaultCellStyle = DataGridViewCellStyle74
        Me.dgv_gabungan_penyusutan_kendaraan.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_gabungan_penyusutan_kendaraan.Location = New System.Drawing.Point(904, 74)
        Me.dgv_gabungan_penyusutan_kendaraan.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_gabungan_penyusutan_kendaraan.MultiSelect = False
        Me.dgv_gabungan_penyusutan_kendaraan.Name = "dgv_gabungan_penyusutan_kendaraan"
        Me.dgv_gabungan_penyusutan_kendaraan.ReadOnly = True
        Me.dgv_gabungan_penyusutan_kendaraan.Size = New System.Drawing.Size(210, 356)
        Me.dgv_gabungan_penyusutan_kendaraan.TabIndex = 69
        Me.dgv_gabungan_penyusutan_kendaraan.Visible = False
        '
        'dgv_penyusutan_kendaraan
        '
        Me.dgv_penyusutan_kendaraan.AllowUserToAddRows = False
        Me.dgv_penyusutan_kendaraan.AllowUserToDeleteRows = False
        Me.dgv_penyusutan_kendaraan.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_penyusutan_kendaraan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle75.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle75.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle75.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle75.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle75.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle75.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle75.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_penyusutan_kendaraan.DefaultCellStyle = DataGridViewCellStyle75
        Me.dgv_penyusutan_kendaraan.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_penyusutan_kendaraan.Location = New System.Drawing.Point(904, 167)
        Me.dgv_penyusutan_kendaraan.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_penyusutan_kendaraan.MultiSelect = False
        Me.dgv_penyusutan_kendaraan.Name = "dgv_penyusutan_kendaraan"
        Me.dgv_penyusutan_kendaraan.ReadOnly = True
        Me.dgv_penyusutan_kendaraan.Size = New System.Drawing.Size(210, 356)
        Me.dgv_penyusutan_kendaraan.TabIndex = 68
        '
        'dgv_gabungan_penyusutan_bangunan
        '
        Me.dgv_gabungan_penyusutan_bangunan.AllowUserToAddRows = False
        Me.dgv_gabungan_penyusutan_bangunan.AllowUserToDeleteRows = False
        Me.dgv_gabungan_penyusutan_bangunan.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_gabungan_penyusutan_bangunan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle76.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle76.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle76.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle76.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle76.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle76.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle76.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_gabungan_penyusutan_bangunan.DefaultCellStyle = DataGridViewCellStyle76
        Me.dgv_gabungan_penyusutan_bangunan.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_gabungan_penyusutan_bangunan.Location = New System.Drawing.Point(680, 74)
        Me.dgv_gabungan_penyusutan_bangunan.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_gabungan_penyusutan_bangunan.MultiSelect = False
        Me.dgv_gabungan_penyusutan_bangunan.Name = "dgv_gabungan_penyusutan_bangunan"
        Me.dgv_gabungan_penyusutan_bangunan.ReadOnly = True
        Me.dgv_gabungan_penyusutan_bangunan.Size = New System.Drawing.Size(210, 356)
        Me.dgv_gabungan_penyusutan_bangunan.TabIndex = 67
        Me.dgv_gabungan_penyusutan_bangunan.Visible = False
        '
        'dgv_penyusutan_bangunan
        '
        Me.dgv_penyusutan_bangunan.AllowUserToAddRows = False
        Me.dgv_penyusutan_bangunan.AllowUserToDeleteRows = False
        Me.dgv_penyusutan_bangunan.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_penyusutan_bangunan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle77.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle77.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle77.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle77.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle77.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle77.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle77.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_penyusutan_bangunan.DefaultCellStyle = DataGridViewCellStyle77
        Me.dgv_penyusutan_bangunan.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_penyusutan_bangunan.Location = New System.Drawing.Point(680, 167)
        Me.dgv_penyusutan_bangunan.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_penyusutan_bangunan.MultiSelect = False
        Me.dgv_penyusutan_bangunan.Name = "dgv_penyusutan_bangunan"
        Me.dgv_penyusutan_bangunan.ReadOnly = True
        Me.dgv_penyusutan_bangunan.Size = New System.Drawing.Size(210, 356)
        Me.dgv_penyusutan_bangunan.TabIndex = 66
        '
        'dgv_gabungan_penyusutan_inventaris
        '
        Me.dgv_gabungan_penyusutan_inventaris.AllowUserToAddRows = False
        Me.dgv_gabungan_penyusutan_inventaris.AllowUserToDeleteRows = False
        Me.dgv_gabungan_penyusutan_inventaris.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_gabungan_penyusutan_inventaris.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle78.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle78.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle78.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle78.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle78.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle78.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle78.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_gabungan_penyusutan_inventaris.DefaultCellStyle = DataGridViewCellStyle78
        Me.dgv_gabungan_penyusutan_inventaris.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_gabungan_penyusutan_inventaris.Location = New System.Drawing.Point(456, 74)
        Me.dgv_gabungan_penyusutan_inventaris.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_gabungan_penyusutan_inventaris.MultiSelect = False
        Me.dgv_gabungan_penyusutan_inventaris.Name = "dgv_gabungan_penyusutan_inventaris"
        Me.dgv_gabungan_penyusutan_inventaris.ReadOnly = True
        Me.dgv_gabungan_penyusutan_inventaris.Size = New System.Drawing.Size(210, 356)
        Me.dgv_gabungan_penyusutan_inventaris.TabIndex = 65
        Me.dgv_gabungan_penyusutan_inventaris.Visible = False
        '
        'dgv_penyusutan_inventaris
        '
        Me.dgv_penyusutan_inventaris.AllowUserToAddRows = False
        Me.dgv_penyusutan_inventaris.AllowUserToDeleteRows = False
        Me.dgv_penyusutan_inventaris.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_penyusutan_inventaris.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle79.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle79.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle79.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle79.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle79.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle79.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle79.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_penyusutan_inventaris.DefaultCellStyle = DataGridViewCellStyle79
        Me.dgv_penyusutan_inventaris.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_penyusutan_inventaris.Location = New System.Drawing.Point(456, 167)
        Me.dgv_penyusutan_inventaris.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_penyusutan_inventaris.MultiSelect = False
        Me.dgv_penyusutan_inventaris.Name = "dgv_penyusutan_inventaris"
        Me.dgv_penyusutan_inventaris.ReadOnly = True
        Me.dgv_penyusutan_inventaris.Size = New System.Drawing.Size(210, 356)
        Me.dgv_penyusutan_inventaris.TabIndex = 64
        '
        'dgv_gabungan_penyusutan_tanki
        '
        Me.dgv_gabungan_penyusutan_tanki.AllowUserToAddRows = False
        Me.dgv_gabungan_penyusutan_tanki.AllowUserToDeleteRows = False
        Me.dgv_gabungan_penyusutan_tanki.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_gabungan_penyusutan_tanki.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle80.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle80.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle80.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle80.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle80.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle80.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle80.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_gabungan_penyusutan_tanki.DefaultCellStyle = DataGridViewCellStyle80
        Me.dgv_gabungan_penyusutan_tanki.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_gabungan_penyusutan_tanki.Location = New System.Drawing.Point(232, 74)
        Me.dgv_gabungan_penyusutan_tanki.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_gabungan_penyusutan_tanki.MultiSelect = False
        Me.dgv_gabungan_penyusutan_tanki.Name = "dgv_gabungan_penyusutan_tanki"
        Me.dgv_gabungan_penyusutan_tanki.ReadOnly = True
        Me.dgv_gabungan_penyusutan_tanki.Size = New System.Drawing.Size(210, 356)
        Me.dgv_gabungan_penyusutan_tanki.TabIndex = 63
        Me.dgv_gabungan_penyusutan_tanki.Visible = False
        '
        'dgv_penyusutan_tanki
        '
        Me.dgv_penyusutan_tanki.AllowUserToAddRows = False
        Me.dgv_penyusutan_tanki.AllowUserToDeleteRows = False
        Me.dgv_penyusutan_tanki.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_penyusutan_tanki.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle81.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle81.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle81.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle81.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle81.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle81.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle81.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_penyusutan_tanki.DefaultCellStyle = DataGridViewCellStyle81
        Me.dgv_penyusutan_tanki.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_penyusutan_tanki.Location = New System.Drawing.Point(232, 167)
        Me.dgv_penyusutan_tanki.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_penyusutan_tanki.MultiSelect = False
        Me.dgv_penyusutan_tanki.Name = "dgv_penyusutan_tanki"
        Me.dgv_penyusutan_tanki.ReadOnly = True
        Me.dgv_penyusutan_tanki.Size = New System.Drawing.Size(210, 356)
        Me.dgv_penyusutan_tanki.TabIndex = 62
        '
        'dgv_gabungan_penyusutan_mesin
        '
        Me.dgv_gabungan_penyusutan_mesin.AllowUserToAddRows = False
        Me.dgv_gabungan_penyusutan_mesin.AllowUserToDeleteRows = False
        Me.dgv_gabungan_penyusutan_mesin.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_gabungan_penyusutan_mesin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle82.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle82.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle82.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle82.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle82.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle82.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle82.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_gabungan_penyusutan_mesin.DefaultCellStyle = DataGridViewCellStyle82
        Me.dgv_gabungan_penyusutan_mesin.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_gabungan_penyusutan_mesin.Location = New System.Drawing.Point(9, 74)
        Me.dgv_gabungan_penyusutan_mesin.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_gabungan_penyusutan_mesin.MultiSelect = False
        Me.dgv_gabungan_penyusutan_mesin.Name = "dgv_gabungan_penyusutan_mesin"
        Me.dgv_gabungan_penyusutan_mesin.ReadOnly = True
        Me.dgv_gabungan_penyusutan_mesin.Size = New System.Drawing.Size(210, 356)
        Me.dgv_gabungan_penyusutan_mesin.TabIndex = 61
        Me.dgv_gabungan_penyusutan_mesin.Visible = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(966, 5)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(86, 16)
        Me.Label5.TabIndex = 60
        Me.Label5.Text = "KENDARAAN"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(746, 5)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(79, 16)
        Me.Label4.TabIndex = 59
        Me.Label4.Text = "BANGUNAN"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(518, 5)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(87, 16)
        Me.Label3.TabIndex = 58
        Me.Label3.Text = "INVENTARIS"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(250, 5)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(175, 16)
        Me.Label2.TabIndex = 57
        Me.Label2.Text = "TANKI PENGOLAH LIMBAH"
        '
        'dgv_induk_penyusutan_kendaraan
        '
        Me.dgv_induk_penyusutan_kendaraan.AllowUserToAddRows = False
        Me.dgv_induk_penyusutan_kendaraan.AllowUserToDeleteRows = False
        Me.dgv_induk_penyusutan_kendaraan.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_induk_penyusutan_kendaraan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle83.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle83.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle83.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle83.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle83.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle83.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle83.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_induk_penyusutan_kendaraan.DefaultCellStyle = DataGridViewCellStyle83
        Me.dgv_induk_penyusutan_kendaraan.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_induk_penyusutan_kendaraan.Location = New System.Drawing.Point(904, 24)
        Me.dgv_induk_penyusutan_kendaraan.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_induk_penyusutan_kendaraan.MultiSelect = False
        Me.dgv_induk_penyusutan_kendaraan.Name = "dgv_induk_penyusutan_kendaraan"
        Me.dgv_induk_penyusutan_kendaraan.ReadOnly = True
        Me.dgv_induk_penyusutan_kendaraan.Size = New System.Drawing.Size(210, 139)
        Me.dgv_induk_penyusutan_kendaraan.TabIndex = 56
        '
        'dgv_induk_penyusutan_bangunan
        '
        Me.dgv_induk_penyusutan_bangunan.AllowUserToAddRows = False
        Me.dgv_induk_penyusutan_bangunan.AllowUserToDeleteRows = False
        Me.dgv_induk_penyusutan_bangunan.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_induk_penyusutan_bangunan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle84.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle84.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle84.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle84.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle84.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle84.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle84.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_induk_penyusutan_bangunan.DefaultCellStyle = DataGridViewCellStyle84
        Me.dgv_induk_penyusutan_bangunan.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_induk_penyusutan_bangunan.Location = New System.Drawing.Point(680, 24)
        Me.dgv_induk_penyusutan_bangunan.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_induk_penyusutan_bangunan.MultiSelect = False
        Me.dgv_induk_penyusutan_bangunan.Name = "dgv_induk_penyusutan_bangunan"
        Me.dgv_induk_penyusutan_bangunan.ReadOnly = True
        Me.dgv_induk_penyusutan_bangunan.Size = New System.Drawing.Size(210, 139)
        Me.dgv_induk_penyusutan_bangunan.TabIndex = 55
        '
        'dgv_induk_penyusutan_inventaris
        '
        Me.dgv_induk_penyusutan_inventaris.AllowUserToAddRows = False
        Me.dgv_induk_penyusutan_inventaris.AllowUserToDeleteRows = False
        Me.dgv_induk_penyusutan_inventaris.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_induk_penyusutan_inventaris.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle85.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle85.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle85.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle85.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle85.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle85.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle85.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_induk_penyusutan_inventaris.DefaultCellStyle = DataGridViewCellStyle85
        Me.dgv_induk_penyusutan_inventaris.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_induk_penyusutan_inventaris.Location = New System.Drawing.Point(456, 24)
        Me.dgv_induk_penyusutan_inventaris.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_induk_penyusutan_inventaris.MultiSelect = False
        Me.dgv_induk_penyusutan_inventaris.Name = "dgv_induk_penyusutan_inventaris"
        Me.dgv_induk_penyusutan_inventaris.ReadOnly = True
        Me.dgv_induk_penyusutan_inventaris.Size = New System.Drawing.Size(210, 139)
        Me.dgv_induk_penyusutan_inventaris.TabIndex = 54
        '
        'dgv_induk_penyusutan_tanki
        '
        Me.dgv_induk_penyusutan_tanki.AllowUserToAddRows = False
        Me.dgv_induk_penyusutan_tanki.AllowUserToDeleteRows = False
        Me.dgv_induk_penyusutan_tanki.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_induk_penyusutan_tanki.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle86.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle86.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle86.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle86.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle86.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle86.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle86.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_induk_penyusutan_tanki.DefaultCellStyle = DataGridViewCellStyle86
        Me.dgv_induk_penyusutan_tanki.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_induk_penyusutan_tanki.Location = New System.Drawing.Point(232, 24)
        Me.dgv_induk_penyusutan_tanki.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_induk_penyusutan_tanki.MultiSelect = False
        Me.dgv_induk_penyusutan_tanki.Name = "dgv_induk_penyusutan_tanki"
        Me.dgv_induk_penyusutan_tanki.ReadOnly = True
        Me.dgv_induk_penyusutan_tanki.Size = New System.Drawing.Size(210, 139)
        Me.dgv_induk_penyusutan_tanki.TabIndex = 53
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(88, 5)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(50, 16)
        Me.Label10.TabIndex = 52
        Me.Label10.Text = "MESIN"
        '
        'dgv_penyusutan_mesin
        '
        Me.dgv_penyusutan_mesin.AllowUserToAddRows = False
        Me.dgv_penyusutan_mesin.AllowUserToDeleteRows = False
        Me.dgv_penyusutan_mesin.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_penyusutan_mesin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle87.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle87.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle87.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle87.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle87.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle87.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle87.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_penyusutan_mesin.DefaultCellStyle = DataGridViewCellStyle87
        Me.dgv_penyusutan_mesin.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_penyusutan_mesin.Location = New System.Drawing.Point(8, 167)
        Me.dgv_penyusutan_mesin.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_penyusutan_mesin.MultiSelect = False
        Me.dgv_penyusutan_mesin.Name = "dgv_penyusutan_mesin"
        Me.dgv_penyusutan_mesin.ReadOnly = True
        Me.dgv_penyusutan_mesin.Size = New System.Drawing.Size(210, 356)
        Me.dgv_penyusutan_mesin.TabIndex = 51
        '
        'dgv_induk_penyusutan_mesin
        '
        Me.dgv_induk_penyusutan_mesin.AllowUserToAddRows = False
        Me.dgv_induk_penyusutan_mesin.AllowUserToDeleteRows = False
        Me.dgv_induk_penyusutan_mesin.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_induk_penyusutan_mesin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle88.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle88.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle88.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle88.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle88.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle88.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle88.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_induk_penyusutan_mesin.DefaultCellStyle = DataGridViewCellStyle88
        Me.dgv_induk_penyusutan_mesin.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_induk_penyusutan_mesin.Location = New System.Drawing.Point(8, 24)
        Me.dgv_induk_penyusutan_mesin.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_induk_penyusutan_mesin.MultiSelect = False
        Me.dgv_induk_penyusutan_mesin.Name = "dgv_induk_penyusutan_mesin"
        Me.dgv_induk_penyusutan_mesin.ReadOnly = True
        Me.dgv_induk_penyusutan_mesin.Size = New System.Drawing.Size(210, 139)
        Me.dgv_induk_penyusutan_mesin.TabIndex = 50
        '
        'btn_generate
        '
        Me.btn_generate.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_generate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_generate.Location = New System.Drawing.Point(674, 8)
        Me.btn_generate.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.btn_generate.Name = "btn_generate"
        Me.btn_generate.Size = New System.Drawing.Size(93, 24)
        Me.btn_generate.TabIndex = 59
        Me.btn_generate.TabStop = False
        Me.btn_generate.Text = "GENERATE"
        Me.btn_generate.UseVisualStyleBackColor = True
        '
        'dtp_tahun
        '
        Me.dtp_tahun.CalendarFont = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtp_tahun.CustomFormat = "yyyy"
        Me.dtp_tahun.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtp_tahun.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtp_tahun.Location = New System.Drawing.Point(586, 9)
        Me.dtp_tahun.Name = "dtp_tahun"
        Me.dtp_tahun.ShowUpDown = True
        Me.dtp_tahun.Size = New System.Drawing.Size(71, 22)
        Me.dtp_tahun.TabIndex = 58
        '
        'lbl_dgv1
        '
        Me.lbl_dgv1.AutoSize = True
        Me.lbl_dgv1.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_dgv1.Location = New System.Drawing.Point(400, 13)
        Me.lbl_dgv1.Name = "lbl_dgv1"
        Me.lbl_dgv1.Size = New System.Drawing.Size(182, 14)
        Me.lbl_dgv1.TabIndex = 57
        Me.lbl_dgv1.Text = "LAPORAN KEUANGAN TAHUN"
        '
        'btn_reset
        '
        Me.btn_reset.Enabled = False
        Me.btn_reset.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_reset.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_reset.Location = New System.Drawing.Point(786, 8)
        Me.btn_reset.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.btn_reset.Name = "btn_reset"
        Me.btn_reset.Size = New System.Drawing.Size(93, 24)
        Me.btn_reset.TabIndex = 60
        Me.btn_reset.TabStop = False
        Me.btn_reset.Text = "RESET"
        Me.btn_reset.UseVisualStyleBackColor = True
        '
        'pn_nilai_laba_rugi
        '
        Me.pn_nilai_laba_rugi.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.pn_nilai_laba_rugi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_akhir_kain_warna)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.Label33)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_awal_kain_warna)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.Label34)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_akhir_kain_proses)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.Label35)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_awal_kain_proses)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.Label30)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_akhir_tahun_obat)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.Label31)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_awal_tahun_obat)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.Label32)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_pbb)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.Label29)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_sewa_kantor)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.Label28)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_sewa_pabrik)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.Label27)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_ap1)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_ap12)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_ap11)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_ap10)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_ap9)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_ap8)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_ap7)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_ap6)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_ap5)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_ap4)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_ap3)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_ap2)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.Label26)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_sp1)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_sp12)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_sp11)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_sp10)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_sp9)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_sp8)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_sp7)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_sp6)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_sp5)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_sp4)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_sp3)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_sp2)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.Label25)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_uh1)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.btn_refresh_generate)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_uh12)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.lbl_nilai_laba_rugi)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_uh11)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.lbl_laba_rugi)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_uh10)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.Label12)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_uh9)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.Label21)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_uh8)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.Label11)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_uh7)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.Label13)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_uh6)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.Label14)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_uh5)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.Label15)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_uh4)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.Label16)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_uh3)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.Label17)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.ck_uh2)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.Label18)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.Label24)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.Label19)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.Label23)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.Label20)
        Me.pn_nilai_laba_rugi.Controls.Add(Me.Label22)
        Me.pn_nilai_laba_rugi.Location = New System.Drawing.Point(13, 42)
        Me.pn_nilai_laba_rugi.Name = "pn_nilai_laba_rugi"
        Me.pn_nilai_laba_rugi.Size = New System.Drawing.Size(475, 415)
        Me.pn_nilai_laba_rugi.TabIndex = 31
        Me.pn_nilai_laba_rugi.Visible = False
        '
        'ck_akhir_kain_warna
        '
        Me.ck_akhir_kain_warna.AutoSize = True
        Me.ck_akhir_kain_warna.Location = New System.Drawing.Point(151, 388)
        Me.ck_akhir_kain_warna.Name = "ck_akhir_kain_warna"
        Me.ck_akhir_kain_warna.Size = New System.Drawing.Size(15, 14)
        Me.ck_akhir_kain_warna.TabIndex = 215
        Me.ck_akhir_kain_warna.UseVisualStyleBackColor = True
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(16, 389)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(120, 13)
        Me.Label33.TabIndex = 214
        Me.Label33.Text = "Saldo Akhir Kain Warna"
        '
        'ck_awal_kain_warna
        '
        Me.ck_awal_kain_warna.AutoSize = True
        Me.ck_awal_kain_warna.Location = New System.Drawing.Point(151, 358)
        Me.ck_awal_kain_warna.Name = "ck_awal_kain_warna"
        Me.ck_awal_kain_warna.Size = New System.Drawing.Size(15, 14)
        Me.ck_awal_kain_warna.TabIndex = 213
        Me.ck_awal_kain_warna.UseVisualStyleBackColor = True
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(16, 359)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(119, 13)
        Me.Label34.TabIndex = 212
        Me.Label34.Text = "Saldo Awal Kain Warna"
        '
        'ck_akhir_kain_proses
        '
        Me.ck_akhir_kain_proses.AutoSize = True
        Me.ck_akhir_kain_proses.Location = New System.Drawing.Point(151, 328)
        Me.ck_akhir_kain_proses.Name = "ck_akhir_kain_proses"
        Me.ck_akhir_kain_proses.Size = New System.Drawing.Size(15, 14)
        Me.ck_akhir_kain_proses.TabIndex = 211
        Me.ck_akhir_kain_proses.UseVisualStyleBackColor = True
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(16, 329)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(120, 13)
        Me.Label35.TabIndex = 210
        Me.Label35.Text = "Saldo Akhir Kain Proses"
        '
        'ck_awal_kain_proses
        '
        Me.ck_awal_kain_proses.AutoSize = True
        Me.ck_awal_kain_proses.Location = New System.Drawing.Point(151, 298)
        Me.ck_awal_kain_proses.Name = "ck_awal_kain_proses"
        Me.ck_awal_kain_proses.Size = New System.Drawing.Size(15, 14)
        Me.ck_awal_kain_proses.TabIndex = 209
        Me.ck_awal_kain_proses.UseVisualStyleBackColor = True
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(16, 299)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(119, 13)
        Me.Label30.TabIndex = 208
        Me.Label30.Text = "Saldo Awal Kain Proses"
        '
        'ck_akhir_tahun_obat
        '
        Me.ck_akhir_tahun_obat.AutoSize = True
        Me.ck_akhir_tahun_obat.Location = New System.Drawing.Point(151, 268)
        Me.ck_akhir_tahun_obat.Name = "ck_akhir_tahun_obat"
        Me.ck_akhir_tahun_obat.Size = New System.Drawing.Size(15, 14)
        Me.ck_akhir_tahun_obat.TabIndex = 207
        Me.ck_akhir_tahun_obat.UseVisualStyleBackColor = True
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(16, 269)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(127, 13)
        Me.Label31.TabIndex = 206
        Me.Label31.Text = "Saldo Akhir Tahun (Obat)"
        '
        'ck_awal_tahun_obat
        '
        Me.ck_awal_tahun_obat.AutoSize = True
        Me.ck_awal_tahun_obat.Location = New System.Drawing.Point(151, 238)
        Me.ck_awal_tahun_obat.Name = "ck_awal_tahun_obat"
        Me.ck_awal_tahun_obat.Size = New System.Drawing.Size(15, 14)
        Me.ck_awal_tahun_obat.TabIndex = 205
        Me.ck_awal_tahun_obat.UseVisualStyleBackColor = True
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(16, 239)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(126, 13)
        Me.Label32.TabIndex = 204
        Me.Label32.Text = "Saldo Awal Tahun (Obat)"
        '
        'ck_pbb
        '
        Me.ck_pbb.AutoSize = True
        Me.ck_pbb.Location = New System.Drawing.Point(290, 298)
        Me.ck_pbb.Name = "ck_pbb"
        Me.ck_pbb.Size = New System.Drawing.Size(15, 14)
        Me.ck_pbb.TabIndex = 203
        Me.ck_pbb.UseVisualStyleBackColor = True
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(208, 299)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(28, 13)
        Me.Label29.TabIndex = 202
        Me.Label29.Text = "PBB"
        '
        'ck_sewa_kantor
        '
        Me.ck_sewa_kantor.AutoSize = True
        Me.ck_sewa_kantor.Location = New System.Drawing.Point(290, 268)
        Me.ck_sewa_kantor.Name = "ck_sewa_kantor"
        Me.ck_sewa_kantor.Size = New System.Drawing.Size(15, 14)
        Me.ck_sewa_kantor.TabIndex = 201
        Me.ck_sewa_kantor.UseVisualStyleBackColor = True
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(208, 269)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(68, 13)
        Me.Label28.TabIndex = 200
        Me.Label28.Text = "Sewa Kantor"
        '
        'ck_sewa_pabrik
        '
        Me.ck_sewa_pabrik.AutoSize = True
        Me.ck_sewa_pabrik.Location = New System.Drawing.Point(290, 238)
        Me.ck_sewa_pabrik.Name = "ck_sewa_pabrik"
        Me.ck_sewa_pabrik.Size = New System.Drawing.Size(15, 14)
        Me.ck_sewa_pabrik.TabIndex = 199
        Me.ck_sewa_pabrik.UseVisualStyleBackColor = True
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(208, 239)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(67, 13)
        Me.Label27.TabIndex = 198
        Me.Label27.Text = "Sewa Pabrik"
        '
        'ck_ap1
        '
        Me.ck_ap1.AutoSize = True
        Me.ck_ap1.Location = New System.Drawing.Point(123, 208)
        Me.ck_ap1.Name = "ck_ap1"
        Me.ck_ap1.Size = New System.Drawing.Size(15, 14)
        Me.ck_ap1.TabIndex = 197
        Me.ck_ap1.UseVisualStyleBackColor = True
        '
        'ck_ap12
        '
        Me.ck_ap12.AutoSize = True
        Me.ck_ap12.Location = New System.Drawing.Point(435, 208)
        Me.ck_ap12.Name = "ck_ap12"
        Me.ck_ap12.Size = New System.Drawing.Size(15, 14)
        Me.ck_ap12.TabIndex = 196
        Me.ck_ap12.UseVisualStyleBackColor = True
        '
        'ck_ap11
        '
        Me.ck_ap11.AutoSize = True
        Me.ck_ap11.Location = New System.Drawing.Point(404, 208)
        Me.ck_ap11.Name = "ck_ap11"
        Me.ck_ap11.Size = New System.Drawing.Size(15, 14)
        Me.ck_ap11.TabIndex = 195
        Me.ck_ap11.UseVisualStyleBackColor = True
        '
        'ck_ap10
        '
        Me.ck_ap10.AutoSize = True
        Me.ck_ap10.Location = New System.Drawing.Point(375, 208)
        Me.ck_ap10.Name = "ck_ap10"
        Me.ck_ap10.Size = New System.Drawing.Size(15, 14)
        Me.ck_ap10.TabIndex = 194
        Me.ck_ap10.UseVisualStyleBackColor = True
        '
        'ck_ap9
        '
        Me.ck_ap9.AutoSize = True
        Me.ck_ap9.Location = New System.Drawing.Point(346, 208)
        Me.ck_ap9.Name = "ck_ap9"
        Me.ck_ap9.Size = New System.Drawing.Size(15, 14)
        Me.ck_ap9.TabIndex = 193
        Me.ck_ap9.UseVisualStyleBackColor = True
        '
        'ck_ap8
        '
        Me.ck_ap8.AutoSize = True
        Me.ck_ap8.Location = New System.Drawing.Point(316, 208)
        Me.ck_ap8.Name = "ck_ap8"
        Me.ck_ap8.Size = New System.Drawing.Size(15, 14)
        Me.ck_ap8.TabIndex = 192
        Me.ck_ap8.UseVisualStyleBackColor = True
        '
        'ck_ap7
        '
        Me.ck_ap7.AutoSize = True
        Me.ck_ap7.Location = New System.Drawing.Point(290, 208)
        Me.ck_ap7.Name = "ck_ap7"
        Me.ck_ap7.Size = New System.Drawing.Size(15, 14)
        Me.ck_ap7.TabIndex = 191
        Me.ck_ap7.UseVisualStyleBackColor = True
        '
        'ck_ap6
        '
        Me.ck_ap6.AutoSize = True
        Me.ck_ap6.Location = New System.Drawing.Point(264, 208)
        Me.ck_ap6.Name = "ck_ap6"
        Me.ck_ap6.Size = New System.Drawing.Size(15, 14)
        Me.ck_ap6.TabIndex = 190
        Me.ck_ap6.UseVisualStyleBackColor = True
        '
        'ck_ap5
        '
        Me.ck_ap5.AutoSize = True
        Me.ck_ap5.Location = New System.Drawing.Point(236, 208)
        Me.ck_ap5.Name = "ck_ap5"
        Me.ck_ap5.Size = New System.Drawing.Size(15, 14)
        Me.ck_ap5.TabIndex = 189
        Me.ck_ap5.UseVisualStyleBackColor = True
        '
        'ck_ap4
        '
        Me.ck_ap4.AutoSize = True
        Me.ck_ap4.Location = New System.Drawing.Point(208, 208)
        Me.ck_ap4.Name = "ck_ap4"
        Me.ck_ap4.Size = New System.Drawing.Size(15, 14)
        Me.ck_ap4.TabIndex = 188
        Me.ck_ap4.UseVisualStyleBackColor = True
        '
        'ck_ap3
        '
        Me.ck_ap3.AutoSize = True
        Me.ck_ap3.Location = New System.Drawing.Point(180, 208)
        Me.ck_ap3.Name = "ck_ap3"
        Me.ck_ap3.Size = New System.Drawing.Size(15, 14)
        Me.ck_ap3.TabIndex = 187
        Me.ck_ap3.UseVisualStyleBackColor = True
        '
        'ck_ap2
        '
        Me.ck_ap2.AutoSize = True
        Me.ck_ap2.Location = New System.Drawing.Point(151, 208)
        Me.ck_ap2.Name = "ck_ap2"
        Me.ck_ap2.Size = New System.Drawing.Size(15, 14)
        Me.ck_ap2.TabIndex = 186
        Me.ck_ap2.UseVisualStyleBackColor = True
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(16, 209)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(92, 13)
        Me.Label26.TabIndex = 185
        Me.Label26.Text = "Angsuran PPH 25"
        '
        'ck_sp1
        '
        Me.ck_sp1.AutoSize = True
        Me.ck_sp1.Location = New System.Drawing.Point(123, 178)
        Me.ck_sp1.Name = "ck_sp1"
        Me.ck_sp1.Size = New System.Drawing.Size(15, 14)
        Me.ck_sp1.TabIndex = 184
        Me.ck_sp1.UseVisualStyleBackColor = True
        '
        'ck_sp12
        '
        Me.ck_sp12.AutoSize = True
        Me.ck_sp12.Location = New System.Drawing.Point(435, 178)
        Me.ck_sp12.Name = "ck_sp12"
        Me.ck_sp12.Size = New System.Drawing.Size(15, 14)
        Me.ck_sp12.TabIndex = 183
        Me.ck_sp12.UseVisualStyleBackColor = True
        '
        'ck_sp11
        '
        Me.ck_sp11.AutoSize = True
        Me.ck_sp11.Location = New System.Drawing.Point(404, 178)
        Me.ck_sp11.Name = "ck_sp11"
        Me.ck_sp11.Size = New System.Drawing.Size(15, 14)
        Me.ck_sp11.TabIndex = 182
        Me.ck_sp11.UseVisualStyleBackColor = True
        '
        'ck_sp10
        '
        Me.ck_sp10.AutoSize = True
        Me.ck_sp10.Location = New System.Drawing.Point(375, 178)
        Me.ck_sp10.Name = "ck_sp10"
        Me.ck_sp10.Size = New System.Drawing.Size(15, 14)
        Me.ck_sp10.TabIndex = 181
        Me.ck_sp10.UseVisualStyleBackColor = True
        '
        'ck_sp9
        '
        Me.ck_sp9.AutoSize = True
        Me.ck_sp9.Location = New System.Drawing.Point(346, 178)
        Me.ck_sp9.Name = "ck_sp9"
        Me.ck_sp9.Size = New System.Drawing.Size(15, 14)
        Me.ck_sp9.TabIndex = 180
        Me.ck_sp9.UseVisualStyleBackColor = True
        '
        'ck_sp8
        '
        Me.ck_sp8.AutoSize = True
        Me.ck_sp8.Location = New System.Drawing.Point(316, 178)
        Me.ck_sp8.Name = "ck_sp8"
        Me.ck_sp8.Size = New System.Drawing.Size(15, 14)
        Me.ck_sp8.TabIndex = 179
        Me.ck_sp8.UseVisualStyleBackColor = True
        '
        'ck_sp7
        '
        Me.ck_sp7.AutoSize = True
        Me.ck_sp7.Location = New System.Drawing.Point(290, 178)
        Me.ck_sp7.Name = "ck_sp7"
        Me.ck_sp7.Size = New System.Drawing.Size(15, 14)
        Me.ck_sp7.TabIndex = 178
        Me.ck_sp7.UseVisualStyleBackColor = True
        '
        'ck_sp6
        '
        Me.ck_sp6.AutoSize = True
        Me.ck_sp6.Location = New System.Drawing.Point(264, 178)
        Me.ck_sp6.Name = "ck_sp6"
        Me.ck_sp6.Size = New System.Drawing.Size(15, 14)
        Me.ck_sp6.TabIndex = 177
        Me.ck_sp6.UseVisualStyleBackColor = True
        '
        'ck_sp5
        '
        Me.ck_sp5.AutoSize = True
        Me.ck_sp5.Location = New System.Drawing.Point(236, 178)
        Me.ck_sp5.Name = "ck_sp5"
        Me.ck_sp5.Size = New System.Drawing.Size(15, 14)
        Me.ck_sp5.TabIndex = 176
        Me.ck_sp5.UseVisualStyleBackColor = True
        '
        'ck_sp4
        '
        Me.ck_sp4.AutoSize = True
        Me.ck_sp4.Location = New System.Drawing.Point(208, 178)
        Me.ck_sp4.Name = "ck_sp4"
        Me.ck_sp4.Size = New System.Drawing.Size(15, 14)
        Me.ck_sp4.TabIndex = 175
        Me.ck_sp4.UseVisualStyleBackColor = True
        '
        'ck_sp3
        '
        Me.ck_sp3.AutoSize = True
        Me.ck_sp3.Location = New System.Drawing.Point(180, 178)
        Me.ck_sp3.Name = "ck_sp3"
        Me.ck_sp3.Size = New System.Drawing.Size(15, 14)
        Me.ck_sp3.TabIndex = 174
        Me.ck_sp3.UseVisualStyleBackColor = True
        '
        'ck_sp2
        '
        Me.ck_sp2.AutoSize = True
        Me.ck_sp2.Location = New System.Drawing.Point(151, 178)
        Me.ck_sp2.Name = "ck_sp2"
        Me.ck_sp2.Size = New System.Drawing.Size(15, 14)
        Me.ck_sp2.TabIndex = 173
        Me.ck_sp2.UseVisualStyleBackColor = True
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(16, 179)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(53, 13)
        Me.Label25.TabIndex = 172
        Me.Label25.Text = "SPT PPN"
        '
        'ck_uh1
        '
        Me.ck_uh1.AutoSize = True
        Me.ck_uh1.Location = New System.Drawing.Point(123, 148)
        Me.ck_uh1.Name = "ck_uh1"
        Me.ck_uh1.Size = New System.Drawing.Size(15, 14)
        Me.ck_uh1.TabIndex = 171
        Me.ck_uh1.UseVisualStyleBackColor = True
        '
        'btn_refresh_generate
        '
        Me.btn_refresh_generate.Location = New System.Drawing.Point(361, 44)
        Me.btn_refresh_generate.Name = "btn_refresh_generate"
        Me.btn_refresh_generate.Size = New System.Drawing.Size(95, 23)
        Me.btn_refresh_generate.TabIndex = 30
        Me.btn_refresh_generate.Text = "REFRESH"
        Me.btn_refresh_generate.UseVisualStyleBackColor = True
        '
        'ck_uh12
        '
        Me.ck_uh12.AutoSize = True
        Me.ck_uh12.Location = New System.Drawing.Point(435, 148)
        Me.ck_uh12.Name = "ck_uh12"
        Me.ck_uh12.Size = New System.Drawing.Size(15, 14)
        Me.ck_uh12.TabIndex = 169
        Me.ck_uh12.UseVisualStyleBackColor = True
        '
        'lbl_nilai_laba_rugi
        '
        Me.lbl_nilai_laba_rugi.BackColor = System.Drawing.SystemColors.Window
        Me.lbl_nilai_laba_rugi.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_nilai_laba_rugi.Location = New System.Drawing.Point(16, 43)
        Me.lbl_nilai_laba_rugi.Name = "lbl_nilai_laba_rugi"
        Me.lbl_nilai_laba_rugi.Size = New System.Drawing.Size(324, 25)
        Me.lbl_nilai_laba_rugi.TabIndex = 146
        Me.lbl_nilai_laba_rugi.Text = "Nilai Raba Rugi"
        Me.lbl_nilai_laba_rugi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ck_uh11
        '
        Me.ck_uh11.AutoSize = True
        Me.ck_uh11.Location = New System.Drawing.Point(404, 148)
        Me.ck_uh11.Name = "ck_uh11"
        Me.ck_uh11.Size = New System.Drawing.Size(15, 14)
        Me.ck_uh11.TabIndex = 168
        Me.ck_uh11.UseVisualStyleBackColor = True
        '
        'lbl_laba_rugi
        '
        Me.lbl_laba_rugi.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_laba_rugi.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_laba_rugi.ForeColor = System.Drawing.SystemColors.Window
        Me.lbl_laba_rugi.Location = New System.Drawing.Point(-1, 0)
        Me.lbl_laba_rugi.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_laba_rugi.Name = "lbl_laba_rugi"
        Me.lbl_laba_rugi.Size = New System.Drawing.Size(475, 28)
        Me.lbl_laba_rugi.TabIndex = 145
        Me.lbl_laba_rugi.Text = "LABA RUGI"
        Me.lbl_laba_rugi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ck_uh10
        '
        Me.ck_uh10.AutoSize = True
        Me.ck_uh10.Location = New System.Drawing.Point(375, 148)
        Me.ck_uh10.Name = "ck_uh10"
        Me.ck_uh10.Size = New System.Drawing.Size(15, 14)
        Me.ck_uh10.TabIndex = 167
        Me.ck_uh10.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Label12.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.SystemColors.Window
        Me.Label12.Location = New System.Drawing.Point(-1, 81)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(475, 28)
        Me.Label12.TabIndex = 145
        Me.Label12.Text = "PENGISIAN LAPORAN"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ck_uh9
        '
        Me.ck_uh9.AutoSize = True
        Me.ck_uh9.Location = New System.Drawing.Point(346, 148)
        Me.ck_uh9.Name = "ck_uh9"
        Me.ck_uh9.Size = New System.Drawing.Size(15, 14)
        Me.ck_uh9.TabIndex = 166
        Me.ck_uh9.UseVisualStyleBackColor = True
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(118, 119)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(24, 13)
        Me.Label21.TabIndex = 155
        Me.Label21.Text = "Jan"
        '
        'ck_uh8
        '
        Me.ck_uh8.AutoSize = True
        Me.ck_uh8.Location = New System.Drawing.Point(316, 148)
        Me.ck_uh8.Name = "ck_uh8"
        Me.ck_uh8.Size = New System.Drawing.Size(15, 14)
        Me.ck_uh8.TabIndex = 165
        Me.ck_uh8.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(204, 119)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(23, 13)
        Me.Label11.TabIndex = 146
        Me.Label11.Text = "Apr"
        '
        'ck_uh7
        '
        Me.ck_uh7.AutoSize = True
        Me.ck_uh7.Location = New System.Drawing.Point(290, 148)
        Me.ck_uh7.Name = "ck_uh7"
        Me.ck_uh7.Size = New System.Drawing.Size(15, 14)
        Me.ck_uh7.TabIndex = 164
        Me.ck_uh7.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(231, 119)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(24, 13)
        Me.Label13.TabIndex = 147
        Me.Label13.Text = "Mei"
        '
        'ck_uh6
        '
        Me.ck_uh6.AutoSize = True
        Me.ck_uh6.Location = New System.Drawing.Point(264, 148)
        Me.ck_uh6.Name = "ck_uh6"
        Me.ck_uh6.Size = New System.Drawing.Size(15, 14)
        Me.ck_uh6.TabIndex = 163
        Me.ck_uh6.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(259, 119)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(24, 13)
        Me.Label14.TabIndex = 148
        Me.Label14.Text = "Jun"
        '
        'ck_uh5
        '
        Me.ck_uh5.AutoSize = True
        Me.ck_uh5.Location = New System.Drawing.Point(236, 148)
        Me.ck_uh5.Name = "ck_uh5"
        Me.ck_uh5.Size = New System.Drawing.Size(15, 14)
        Me.ck_uh5.TabIndex = 162
        Me.ck_uh5.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(287, 119)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(20, 13)
        Me.Label15.TabIndex = 149
        Me.Label15.Text = "Jul"
        '
        'ck_uh4
        '
        Me.ck_uh4.AutoSize = True
        Me.ck_uh4.Location = New System.Drawing.Point(208, 148)
        Me.ck_uh4.Name = "ck_uh4"
        Me.ck_uh4.Size = New System.Drawing.Size(15, 14)
        Me.ck_uh4.TabIndex = 161
        Me.ck_uh4.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(311, 119)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(25, 13)
        Me.Label16.TabIndex = 150
        Me.Label16.Text = "Ags"
        '
        'ck_uh3
        '
        Me.ck_uh3.AutoSize = True
        Me.ck_uh3.Location = New System.Drawing.Point(180, 148)
        Me.ck_uh3.Name = "ck_uh3"
        Me.ck_uh3.Size = New System.Drawing.Size(15, 14)
        Me.ck_uh3.TabIndex = 160
        Me.ck_uh3.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(340, 119)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(26, 13)
        Me.Label17.TabIndex = 151
        Me.Label17.Text = "Sep"
        '
        'ck_uh2
        '
        Me.ck_uh2.AutoSize = True
        Me.ck_uh2.Location = New System.Drawing.Point(151, 148)
        Me.ck_uh2.Name = "ck_uh2"
        Me.ck_uh2.Size = New System.Drawing.Size(15, 14)
        Me.ck_uh2.TabIndex = 159
        Me.ck_uh2.UseVisualStyleBackColor = True
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(370, 119)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(24, 13)
        Me.Label18.TabIndex = 152
        Me.Label18.Text = "Okt"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(16, 149)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(86, 13)
        Me.Label24.TabIndex = 158
        Me.Label24.Text = "UPAH Dan GAJI"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(398, 119)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(27, 13)
        Me.Label19.TabIndex = 153
        Me.Label19.Text = "Nov"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(175, 119)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(25, 13)
        Me.Label23.TabIndex = 157
        Me.Label23.Text = "Mar"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(429, 119)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(26, 13)
        Me.Label20.TabIndex = 154
        Me.Label20.Text = "Des"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(146, 119)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(25, 13)
        Me.Label22.TabIndex = 156
        Me.Label22.Text = "Feb"
        '
        'form_menu_utama
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1244, 749)
        Me.Controls.Add(Me.pn_laba_rugi)
        Me.Controls.Add(Me.pn_nilai_laba_rugi)
        Me.Controls.Add(Me.btn_hitung_bukpot)
        Me.Controls.Add(Me.panel_bukpot)
        Me.Controls.Add(Me.dgv1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.IsMdiContainer = True
        Me.Name = "form_menu_utama"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "AML Akunting v.1.2.9"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panel_bukpot.ResumeLayout(False)
        Me.panel_bukpot.PerformLayout()
        CType(Me.dgv_bukpot, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pn_laba_rugi.ResumeLayout(False)
        Me.pn_laba_rugi.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.dgv_hpp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_saldo3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_saldo2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_saldo1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        CType(Me.dgv_lapkeu_2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.dgv_lapkeu, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        CType(Me.dgv_biaya, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        CType(Me.dgv_list_masukan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_masukan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_list_lain2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_list_batubara, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_list_obat, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_list_kain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage5.ResumeLayout(False)
        CType(Me.dgv_keluaran, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_keluaran_satuan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_satuan_kg, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_satuan_mtr, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_list_keluaran, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_satuan_yard, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_list_keluaran_total, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_list_keluaran_kain, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_list_celup, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage6.ResumeLayout(False)
        CType(Me.dgv_spt_clone, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_spt_aml, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_spt_efaktur, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage7.ResumeLayout(False)
        CType(Me.dgv_pln, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage8.ResumeLayout(False)
        CType(Me.dgv_bukpot_lapkeu, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage9.ResumeLayout(False)
        Me.TabPage9.PerformLayout()
        CType(Me.dgv_gabungan_penyusutan_kendaraan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_penyusutan_kendaraan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_gabungan_penyusutan_bangunan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_penyusutan_bangunan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_gabungan_penyusutan_inventaris, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_penyusutan_inventaris, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_gabungan_penyusutan_tanki, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_penyusutan_tanki, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_gabungan_penyusutan_mesin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_induk_penyusutan_kendaraan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_induk_penyusutan_bangunan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_induk_penyusutan_inventaris, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_induk_penyusutan_tanki, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_penyusutan_mesin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_induk_penyusutan_mesin, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pn_nilai_laba_rugi.ResumeLayout(False)
        Me.pn_nilai_laba_rugi.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents SISTEMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LOGINToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LOGOUTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PenggunaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents KELUARToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents Status1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Status2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents DatabaseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents JenisBiayaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NamaSpecsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SupplierToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PPNPPh23ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PembelianToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DataPembelianToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UploadPembelianToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExportUploadPembelianToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CariNamaBarangSpecsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CLIENTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PenjualanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DataPenjualanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InputPenjualanCelupToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GreyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DataGreyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InputNamaHargaJualGreyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatchToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatchPembelianToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatchGreyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InputPenjualanKainToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatchPenjualanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatchSupplierToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OmsetPenjualanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GenerateSuratJalanDanFakturToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NeracaGreyBaruToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatchOmsetToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExportUploadPenjualanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UploadPenjualanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents dgv1 As System.Windows.Forms.DataGridView
    Friend WithEvents PatchToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatchBukpotToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents panel_bukpot As System.Windows.Forms.Panel
    Friend WithEvents txt_jumlah_bukpot As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents dgv_bukpot As System.Windows.Forms.DataGridView
    Friend WithEvents dtp_bukpot As System.Windows.Forms.DateTimePicker
    Friend WithEvents btn_hitung_bukpot As System.Windows.Forms.Button
    Friend WithEvents btn_refresh_bukpot As System.Windows.Forms.Button
    Friend WithEvents BuktiPotongToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatchPPNPPHV121ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatchPenyusutanV121ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LaporanKeuanganToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SPTMasaPPNEfakturToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PenyusutanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatchSPTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatchBukpotV121aToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EksporExcelCoretaxToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatchBiayaTahunanV125ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BiayaTahunanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatchHPPV126ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaldoLaporanHPPToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatchAngsuranPPh25V126ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AngsuranPPh25ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripMenuItem6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripMenuItem5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ts_print_sj_bulanan As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents PrintEksporInvoiceBulananToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pn_laba_rugi As System.Windows.Forms.Panel
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents dgv_hpp As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_saldo3 As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_saldo2 As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_saldo1 As System.Windows.Forms.DataGridView
    Friend WithEvents dtp_akhir As System.Windows.Forms.DateTimePicker
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents lbl_hpp_tahun As System.Windows.Forms.Label
    Friend WithEvents dtp_awal As System.Windows.Forms.DateTimePicker
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents dgv_lapkeu_2 As System.Windows.Forms.DataGridView
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents lbl_lapkeu As System.Windows.Forms.Label
    Friend WithEvents dgv_lapkeu As System.Windows.Forms.DataGridView
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents dgv_biaya As System.Windows.Forms.DataGridView
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents dgv_list_masukan As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_masukan As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_lain2 As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_batubara As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_obat As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_kain As System.Windows.Forms.DataGridView
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents dgv_keluaran As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_keluaran_satuan As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_satuan_kg As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_satuan_mtr As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_keluaran As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_satuan_yard As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_keluaran_total As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_keluaran_kain As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_celup As System.Windows.Forms.DataGridView
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents dgv_spt_clone As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_spt_aml As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_spt_efaktur As System.Windows.Forms.DataGridView
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents dgv_pln As System.Windows.Forms.DataGridView
    Friend WithEvents TabPage8 As System.Windows.Forms.TabPage
    Friend WithEvents dgv_bukpot_lapkeu As System.Windows.Forms.DataGridView
    Friend WithEvents TabPage9 As System.Windows.Forms.TabPage
    Friend WithEvents dgv_gabungan_penyusutan_kendaraan As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_penyusutan_kendaraan As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_gabungan_penyusutan_bangunan As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_penyusutan_bangunan As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_gabungan_penyusutan_inventaris As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_penyusutan_inventaris As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_gabungan_penyusutan_tanki As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_penyusutan_tanki As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_gabungan_penyusutan_mesin As System.Windows.Forms.DataGridView
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents dgv_induk_penyusutan_kendaraan As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_induk_penyusutan_bangunan As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_induk_penyusutan_inventaris As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_induk_penyusutan_tanki As System.Windows.Forms.DataGridView
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents dgv_penyusutan_mesin As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_induk_penyusutan_mesin As System.Windows.Forms.DataGridView
    Friend WithEvents btn_generate As System.Windows.Forms.Button
    Friend WithEvents dtp_tahun As System.Windows.Forms.DateTimePicker
    Friend WithEvents lbl_dgv1 As System.Windows.Forms.Label
    Friend WithEvents btn_reset As System.Windows.Forms.Button
    Friend WithEvents pn_nilai_laba_rugi As System.Windows.Forms.Panel
    Friend WithEvents lbl_laba_rugi As System.Windows.Forms.Label
    Friend WithEvents lbl_nilai_laba_rugi As System.Windows.Forms.Label
    Friend WithEvents btn_refresh_generate As System.Windows.Forms.Button
    Friend WithEvents PatchUpahDanGajiV129ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UPAHDanGAJIToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ck_uh2 As System.Windows.Forms.CheckBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents ck_uh1 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_uh12 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_uh11 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_uh10 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_uh9 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_uh8 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_uh7 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_uh6 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_uh5 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_uh4 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_uh3 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_sp1 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_sp12 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_sp11 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_sp10 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_sp9 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_sp8 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_sp7 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_sp6 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_sp5 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_sp4 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_sp3 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_sp2 As System.Windows.Forms.CheckBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents ck_ap1 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_ap12 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_ap11 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_ap10 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_ap9 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_ap8 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_ap7 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_ap6 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_ap5 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_ap4 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_ap3 As System.Windows.Forms.CheckBox
    Friend WithEvents ck_ap2 As System.Windows.Forms.CheckBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents ck_pbb As System.Windows.Forms.CheckBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents ck_sewa_kantor As System.Windows.Forms.CheckBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents ck_sewa_pabrik As System.Windows.Forms.CheckBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents ck_akhir_kain_warna As System.Windows.Forms.CheckBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents ck_awal_kain_warna As System.Windows.Forms.CheckBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents ck_akhir_kain_proses As System.Windows.Forms.CheckBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents ck_awal_kain_proses As System.Windows.Forms.CheckBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents ck_akhir_tahun_obat As System.Windows.Forms.CheckBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents ck_awal_tahun_obat As System.Windows.Forms.CheckBox
    Friend WithEvents Label32 As System.Windows.Forms.Label

End Class
