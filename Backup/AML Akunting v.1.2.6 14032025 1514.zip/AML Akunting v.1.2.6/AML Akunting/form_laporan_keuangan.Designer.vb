﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class form_laporan_keuangan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle43 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle44 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle45 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle46 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle42 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle47 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle48 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle49 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle50 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle51 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle52 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle53 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle54 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle55 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle56 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle57 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle58 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle59 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle60 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle61 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle62 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle63 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle64 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle65 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle66 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle67 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle68 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle69 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle70 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle71 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle72 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle73 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle74 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle75 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle76 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle77 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle78 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle79 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle80 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle81 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle82 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.dgv_hpp = New System.Windows.Forms.DataGridView()
        Me.dgv_saldo3 = New System.Windows.Forms.DataGridView()
        Me.dgv_saldo2 = New System.Windows.Forms.DataGridView()
        Me.dgv_saldo1 = New System.Windows.Forms.DataGridView()
        Me.dtp_akhir = New System.Windows.Forms.DateTimePicker()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lbl_hpp_tahun = New System.Windows.Forms.Label()
        Me.dtp_awal = New System.Windows.Forms.DateTimePicker()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.dgv_lapkeu = New System.Windows.Forms.DataGridView()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lbl_lapkeu = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.dgv_biaya = New System.Windows.Forms.DataGridView()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.dgv_list_masukan = New System.Windows.Forms.DataGridView()
        Me.dgv_masukan = New System.Windows.Forms.DataGridView()
        Me.dgv_list_lain2 = New System.Windows.Forms.DataGridView()
        Me.dgv_list_batubara = New System.Windows.Forms.DataGridView()
        Me.dgv_list_obat = New System.Windows.Forms.DataGridView()
        Me.dgv_list_kain = New System.Windows.Forms.DataGridView()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.dgv_keluaran = New System.Windows.Forms.DataGridView()
        Me.dgv_keluaran_satuan = New System.Windows.Forms.DataGridView()
        Me.dgv_satuan_kg = New System.Windows.Forms.DataGridView()
        Me.dgv_satuan_mtr = New System.Windows.Forms.DataGridView()
        Me.dgv_list_keluaran = New System.Windows.Forms.DataGridView()
        Me.dgv_satuan_yard = New System.Windows.Forms.DataGridView()
        Me.dgv_list_keluaran_total = New System.Windows.Forms.DataGridView()
        Me.dgv_list_keluaran_kain = New System.Windows.Forms.DataGridView()
        Me.dgv_list_celup = New System.Windows.Forms.DataGridView()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.dgv_spt_clone = New System.Windows.Forms.DataGridView()
        Me.dgv_spt_aml = New System.Windows.Forms.DataGridView()
        Me.dgv_spt_efaktur = New System.Windows.Forms.DataGridView()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.dgv_pln = New System.Windows.Forms.DataGridView()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.dgv_bukpot = New System.Windows.Forms.DataGridView()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.dgv_gabungan_penyusutan_kendaraan = New System.Windows.Forms.DataGridView()
        Me.dgv_penyusutan_kendaraan = New System.Windows.Forms.DataGridView()
        Me.dgv_gabungan_penyusutan_bangunan = New System.Windows.Forms.DataGridView()
        Me.dgv_penyusutan_bangunan = New System.Windows.Forms.DataGridView()
        Me.dgv_gabungan_penyusutan_inventaris = New System.Windows.Forms.DataGridView()
        Me.dgv_penyusutan_inventaris = New System.Windows.Forms.DataGridView()
        Me.dgv_gabungan_penyusutan_tanki = New System.Windows.Forms.DataGridView()
        Me.dgv_penyusutan_tanki = New System.Windows.Forms.DataGridView()
        Me.dgv_gabungan_penyusutan_mesin = New System.Windows.Forms.DataGridView()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.dgv_induk_penyusutan_kendaraan = New System.Windows.Forms.DataGridView()
        Me.dgv_induk_penyusutan_bangunan = New System.Windows.Forms.DataGridView()
        Me.dgv_induk_penyusutan_inventaris = New System.Windows.Forms.DataGridView()
        Me.dgv_induk_penyusutan_tanki = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dgv_penyusutan_mesin = New System.Windows.Forms.DataGridView()
        Me.dgv_induk_penyusutan_mesin = New System.Windows.Forms.DataGridView()
        Me.btn_generate = New System.Windows.Forms.Button()
        Me.dtp_tahun = New System.Windows.Forms.DateTimePicker()
        Me.lbl_dgv1 = New System.Windows.Forms.Label()
        Me.btn_reset = New System.Windows.Forms.Button()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.dgv_hpp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_saldo3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_saldo2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_saldo1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.dgv_lapkeu, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        CType(Me.dgv_biaya, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        CType(Me.dgv_list_masukan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_masukan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_list_lain2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_list_batubara, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_list_obat, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_list_kain, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage5.SuspendLayout()
        CType(Me.dgv_keluaran, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_keluaran_satuan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_satuan_kg, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_satuan_mtr, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_list_keluaran, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_satuan_yard, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_list_keluaran_total, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_list_keluaran_kain, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_list_celup, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage6.SuspendLayout()
        CType(Me.dgv_spt_clone, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_spt_aml, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_spt_efaktur, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage7.SuspendLayout()
        CType(Me.dgv_pln, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage8.SuspendLayout()
        CType(Me.dgv_bukpot, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage9.SuspendLayout()
        CType(Me.dgv_gabungan_penyusutan_kendaraan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_penyusutan_kendaraan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_gabungan_penyusutan_bangunan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_penyusutan_bangunan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_gabungan_penyusutan_inventaris, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_penyusutan_inventaris, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_gabungan_penyusutan_tanki, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_penyusutan_tanki, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_gabungan_penyusutan_mesin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_induk_penyusutan_kendaraan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_induk_penyusutan_bangunan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_induk_penyusutan_inventaris, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_induk_penyusutan_tanki, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_penyusutan_mesin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_induk_penyusutan_mesin, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Controls.Add(Me.TabPage8)
        Me.TabControl1.Controls.Add(Me.TabPage9)
        Me.TabControl1.Location = New System.Drawing.Point(0, 29)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1130, 554)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage1.Controls.Add(Me.dgv_hpp)
        Me.TabPage1.Controls.Add(Me.dgv_saldo3)
        Me.TabPage1.Controls.Add(Me.dgv_saldo2)
        Me.TabPage1.Controls.Add(Me.dgv_saldo1)
        Me.TabPage1.Controls.Add(Me.dtp_akhir)
        Me.TabPage1.Controls.Add(Me.Panel1)
        Me.TabPage1.Controls.Add(Me.dtp_awal)
        Me.TabPage1.Controls.Add(Me.TextBox1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "HPP"
        '
        'dgv_hpp
        '
        Me.dgv_hpp.AllowUserToAddRows = False
        Me.dgv_hpp.AllowUserToDeleteRows = False
        Me.dgv_hpp.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_hpp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle43.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle43.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle43.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle43.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle43.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle43.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_hpp.DefaultCellStyle = DataGridViewCellStyle43
        Me.dgv_hpp.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_hpp.Location = New System.Drawing.Point(66, 91)
        Me.dgv_hpp.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_hpp.MultiSelect = False
        Me.dgv_hpp.Name = "dgv_hpp"
        Me.dgv_hpp.ReadOnly = True
        Me.dgv_hpp.Size = New System.Drawing.Size(990, 428)
        Me.dgv_hpp.TabIndex = 52
        '
        'dgv_saldo3
        '
        Me.dgv_saldo3.AllowUserToAddRows = False
        Me.dgv_saldo3.AllowUserToDeleteRows = False
        Me.dgv_saldo3.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_saldo3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle44.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle44.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle44.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle44.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle44.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle44.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle44.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_saldo3.DefaultCellStyle = DataGridViewCellStyle44
        Me.dgv_saldo3.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_saldo3.Location = New System.Drawing.Point(848, 352)
        Me.dgv_saldo3.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_saldo3.MultiSelect = False
        Me.dgv_saldo3.Name = "dgv_saldo3"
        Me.dgv_saldo3.ReadOnly = True
        Me.dgv_saldo3.Size = New System.Drawing.Size(86, 68)
        Me.dgv_saldo3.TabIndex = 64
        '
        'dgv_saldo2
        '
        Me.dgv_saldo2.AllowUserToAddRows = False
        Me.dgv_saldo2.AllowUserToDeleteRows = False
        Me.dgv_saldo2.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_saldo2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle45.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle45.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle45.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle45.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle45.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle45.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle45.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_saldo2.DefaultCellStyle = DataGridViewCellStyle45
        Me.dgv_saldo2.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_saldo2.Location = New System.Drawing.Point(848, 273)
        Me.dgv_saldo2.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_saldo2.MultiSelect = False
        Me.dgv_saldo2.Name = "dgv_saldo2"
        Me.dgv_saldo2.ReadOnly = True
        Me.dgv_saldo2.Size = New System.Drawing.Size(94, 70)
        Me.dgv_saldo2.TabIndex = 63
        '
        'dgv_saldo1
        '
        Me.dgv_saldo1.AllowUserToAddRows = False
        Me.dgv_saldo1.AllowUserToDeleteRows = False
        Me.dgv_saldo1.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_saldo1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle46.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle46.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle46.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle46.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle46.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle46.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_saldo1.DefaultCellStyle = DataGridViewCellStyle46
        Me.dgv_saldo1.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_saldo1.Location = New System.Drawing.Point(848, 175)
        Me.dgv_saldo1.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_saldo1.MultiSelect = False
        Me.dgv_saldo1.Name = "dgv_saldo1"
        Me.dgv_saldo1.ReadOnly = True
        Me.dgv_saldo1.Size = New System.Drawing.Size(76, 70)
        Me.dgv_saldo1.TabIndex = 62
        '
        'dtp_akhir
        '
        Me.dtp_akhir.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtp_akhir.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtp_akhir.Location = New System.Drawing.Point(901, 146)
        Me.dtp_akhir.Margin = New System.Windows.Forms.Padding(4)
        Me.dtp_akhir.Name = "dtp_akhir"
        Me.dtp_akhir.Size = New System.Drawing.Size(115, 23)
        Me.dtp_akhir.TabIndex = 61
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.Window
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.lbl_hpp_tahun)
        Me.Panel1.Location = New System.Drawing.Point(66, 6)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(990, 62)
        Me.Panel1.TabIndex = 57
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(384, 22)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(220, 13)
        Me.Label7.TabIndex = 54
        Me.Label7.Text = "LAPORAN HARGA POKOK PENJUALAN"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(412, 4)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(165, 13)
        Me.Label6.TabIndex = 53
        Me.Label6.Text = "CV. ARTHA MEKAR LESTARI"
        '
        'lbl_hpp_tahun
        '
        Me.lbl_hpp_tahun.Location = New System.Drawing.Point(22, 37)
        Me.lbl_hpp_tahun.Name = "lbl_hpp_tahun"
        Me.lbl_hpp_tahun.Size = New System.Drawing.Size(945, 19)
        Me.lbl_hpp_tahun.TabIndex = 55
        Me.lbl_hpp_tahun.Text = "1 JANUARI - 31 DESEMBER"
        Me.lbl_hpp_tahun.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'dtp_awal
        '
        Me.dtp_awal.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtp_awal.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtp_awal.Location = New System.Drawing.Point(901, 113)
        Me.dtp_awal.Margin = New System.Windows.Forms.Padding(4)
        Me.dtp_awal.Name = "dtp_awal"
        Me.dtp_awal.Size = New System.Drawing.Size(115, 23)
        Me.dtp_awal.TabIndex = 60
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(66, 69)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(990, 21)
        Me.TextBox1.TabIndex = 56
        Me.TextBox1.Text = "(Dalam Rupiah)"
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage2.Controls.Add(Me.Panel2)
        Me.TabPage2.Controls.Add(Me.dgv_lapkeu)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Laporan Keuangan"
        '
        'dgv_lapkeu
        '
        Me.dgv_lapkeu.AllowUserToAddRows = False
        Me.dgv_lapkeu.AllowUserToDeleteRows = False
        Me.dgv_lapkeu.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_lapkeu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle42.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle42.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle42.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle42.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle42.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle42.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_lapkeu.DefaultCellStyle = DataGridViewCellStyle42
        Me.dgv_lapkeu.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_lapkeu.Location = New System.Drawing.Point(11, 74)
        Me.dgv_lapkeu.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_lapkeu.MultiSelect = False
        Me.dgv_lapkeu.Name = "dgv_lapkeu"
        Me.dgv_lapkeu.ReadOnly = True
        Me.dgv_lapkeu.Size = New System.Drawing.Size(1100, 447)
        Me.dgv_lapkeu.TabIndex = 62
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.Window
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.lbl_lapkeu)
        Me.Panel2.Location = New System.Drawing.Point(11, 8)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1100, 62)
        Me.Panel2.TabIndex = 64
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(430, 22)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(129, 13)
        Me.Label8.TabIndex = 54
        Me.Label8.Text = "LAPORAN LABA RUGI"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(412, 4)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(165, 13)
        Me.Label9.TabIndex = 53
        Me.Label9.Text = "CV. ARTHA MEKAR LESTARI"
        '
        'lbl_lapkeu
        '
        Me.lbl_lapkeu.Location = New System.Drawing.Point(22, 37)
        Me.lbl_lapkeu.Name = "lbl_lapkeu"
        Me.lbl_lapkeu.Size = New System.Drawing.Size(945, 19)
        Me.lbl_lapkeu.TabIndex = 55
        Me.lbl_lapkeu.Text = "1 JANUARI - 31 DESEMBER"
        Me.lbl_lapkeu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage3.Controls.Add(Me.dgv_biaya)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Biaya"
        '
        'dgv_biaya
        '
        Me.dgv_biaya.AllowUserToAddRows = False
        Me.dgv_biaya.AllowUserToDeleteRows = False
        Me.dgv_biaya.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_biaya.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle47.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle47.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle47.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle47.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle47.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle47.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_biaya.DefaultCellStyle = DataGridViewCellStyle47
        Me.dgv_biaya.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_biaya.Location = New System.Drawing.Point(6, 7)
        Me.dgv_biaya.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_biaya.MultiSelect = False
        Me.dgv_biaya.Name = "dgv_biaya"
        Me.dgv_biaya.ReadOnly = True
        Me.dgv_biaya.Size = New System.Drawing.Size(1110, 514)
        Me.dgv_biaya.TabIndex = 51
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage4.Controls.Add(Me.dgv_list_masukan)
        Me.TabPage4.Controls.Add(Me.dgv_masukan)
        Me.TabPage4.Controls.Add(Me.dgv_list_lain2)
        Me.TabPage4.Controls.Add(Me.dgv_list_batubara)
        Me.TabPage4.Controls.Add(Me.dgv_list_obat)
        Me.TabPage4.Controls.Add(Me.dgv_list_kain)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Masukan"
        '
        'dgv_list_masukan
        '
        Me.dgv_list_masukan.AllowUserToAddRows = False
        Me.dgv_list_masukan.AllowUserToDeleteRows = False
        Me.dgv_list_masukan.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_masukan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_list_masukan.ColumnHeadersVisible = False
        DataGridViewCellStyle48.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle48.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle48.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle48.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle48.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle48.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle48.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_masukan.DefaultCellStyle = DataGridViewCellStyle48
        Me.dgv_list_masukan.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_masukan.Location = New System.Drawing.Point(9, 339)
        Me.dgv_list_masukan.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_masukan.MultiSelect = False
        Me.dgv_list_masukan.Name = "dgv_list_masukan"
        Me.dgv_list_masukan.ReadOnly = True
        Me.dgv_list_masukan.Size = New System.Drawing.Size(690, 180)
        Me.dgv_list_masukan.TabIndex = 52
        '
        'dgv_masukan
        '
        Me.dgv_masukan.AllowUserToAddRows = False
        Me.dgv_masukan.AllowUserToDeleteRows = False
        Me.dgv_masukan.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_masukan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle49.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle49.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle49.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle49.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle49.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle49.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle49.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_masukan.DefaultCellStyle = DataGridViewCellStyle49
        Me.dgv_masukan.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_masukan.Location = New System.Drawing.Point(9, 11)
        Me.dgv_masukan.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_masukan.MultiSelect = False
        Me.dgv_masukan.Name = "dgv_masukan"
        Me.dgv_masukan.ReadOnly = True
        Me.dgv_masukan.Size = New System.Drawing.Size(890, 320)
        Me.dgv_masukan.TabIndex = 50
        '
        'dgv_list_lain2
        '
        Me.dgv_list_lain2.AllowUserToAddRows = False
        Me.dgv_list_lain2.AllowUserToDeleteRows = False
        Me.dgv_list_lain2.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_lain2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle50.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle50.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle50.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle50.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle50.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle50.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle50.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_lain2.DefaultCellStyle = DataGridViewCellStyle50
        Me.dgv_list_lain2.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_lain2.Location = New System.Drawing.Point(622, 118)
        Me.dgv_list_lain2.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_lain2.MultiSelect = False
        Me.dgv_list_lain2.Name = "dgv_list_lain2"
        Me.dgv_list_lain2.ReadOnly = True
        Me.dgv_list_lain2.Size = New System.Drawing.Size(432, 169)
        Me.dgv_list_lain2.TabIndex = 55
        Me.dgv_list_lain2.Visible = False
        '
        'dgv_list_batubara
        '
        Me.dgv_list_batubara.AllowUserToAddRows = False
        Me.dgv_list_batubara.AllowUserToDeleteRows = False
        Me.dgv_list_batubara.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_batubara.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle51.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle51.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle51.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle51.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle51.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle51.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle51.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_batubara.DefaultCellStyle = DataGridViewCellStyle51
        Me.dgv_list_batubara.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_batubara.Location = New System.Drawing.Point(622, 194)
        Me.dgv_list_batubara.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_batubara.MultiSelect = False
        Me.dgv_list_batubara.Name = "dgv_list_batubara"
        Me.dgv_list_batubara.ReadOnly = True
        Me.dgv_list_batubara.Size = New System.Drawing.Size(432, 169)
        Me.dgv_list_batubara.TabIndex = 54
        Me.dgv_list_batubara.Visible = False
        '
        'dgv_list_obat
        '
        Me.dgv_list_obat.AllowUserToAddRows = False
        Me.dgv_list_obat.AllowUserToDeleteRows = False
        Me.dgv_list_obat.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_obat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle52.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle52.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle52.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle52.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle52.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle52.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle52.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_obat.DefaultCellStyle = DataGridViewCellStyle52
        Me.dgv_list_obat.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_obat.Location = New System.Drawing.Point(622, 278)
        Me.dgv_list_obat.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_obat.MultiSelect = False
        Me.dgv_list_obat.Name = "dgv_list_obat"
        Me.dgv_list_obat.ReadOnly = True
        Me.dgv_list_obat.Size = New System.Drawing.Size(432, 169)
        Me.dgv_list_obat.TabIndex = 53
        Me.dgv_list_obat.Visible = False
        '
        'dgv_list_kain
        '
        Me.dgv_list_kain.AllowUserToAddRows = False
        Me.dgv_list_kain.AllowUserToDeleteRows = False
        Me.dgv_list_kain.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_kain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle53.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle53.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle53.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle53.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle53.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle53.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle53.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_kain.DefaultCellStyle = DataGridViewCellStyle53
        Me.dgv_list_kain.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_kain.Location = New System.Drawing.Point(622, 352)
        Me.dgv_list_kain.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_kain.MultiSelect = False
        Me.dgv_list_kain.Name = "dgv_list_kain"
        Me.dgv_list_kain.ReadOnly = True
        Me.dgv_list_kain.Size = New System.Drawing.Size(432, 169)
        Me.dgv_list_kain.TabIndex = 51
        Me.dgv_list_kain.Visible = False
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage5.Controls.Add(Me.dgv_keluaran)
        Me.TabPage5.Controls.Add(Me.dgv_keluaran_satuan)
        Me.TabPage5.Controls.Add(Me.dgv_satuan_kg)
        Me.TabPage5.Controls.Add(Me.dgv_satuan_mtr)
        Me.TabPage5.Controls.Add(Me.dgv_list_keluaran)
        Me.TabPage5.Controls.Add(Me.dgv_satuan_yard)
        Me.TabPage5.Controls.Add(Me.dgv_list_keluaran_total)
        Me.TabPage5.Controls.Add(Me.dgv_list_keluaran_kain)
        Me.TabPage5.Controls.Add(Me.dgv_list_celup)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Keluaran"
        '
        'dgv_keluaran
        '
        Me.dgv_keluaran.AllowUserToAddRows = False
        Me.dgv_keluaran.AllowUserToDeleteRows = False
        Me.dgv_keluaran.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_keluaran.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle54.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle54.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle54.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle54.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle54.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle54.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle54.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_keluaran.DefaultCellStyle = DataGridViewCellStyle54
        Me.dgv_keluaran.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_keluaran.Location = New System.Drawing.Point(9, 9)
        Me.dgv_keluaran.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_keluaran.MultiSelect = False
        Me.dgv_keluaran.Name = "dgv_keluaran"
        Me.dgv_keluaran.ReadOnly = True
        Me.dgv_keluaran.Size = New System.Drawing.Size(1105, 320)
        Me.dgv_keluaran.TabIndex = 52
        '
        'dgv_keluaran_satuan
        '
        Me.dgv_keluaran_satuan.AllowUserToAddRows = False
        Me.dgv_keluaran_satuan.AllowUserToDeleteRows = False
        Me.dgv_keluaran_satuan.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_keluaran_satuan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_keluaran_satuan.ColumnHeadersVisible = False
        DataGridViewCellStyle55.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle55.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle55.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle55.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle55.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle55.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle55.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_keluaran_satuan.DefaultCellStyle = DataGridViewCellStyle55
        Me.dgv_keluaran_satuan.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_keluaran_satuan.Location = New System.Drawing.Point(574, 339)
        Me.dgv_keluaran_satuan.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_keluaran_satuan.MultiSelect = False
        Me.dgv_keluaran_satuan.Name = "dgv_keluaran_satuan"
        Me.dgv_keluaran_satuan.ReadOnly = True
        Me.dgv_keluaran_satuan.Size = New System.Drawing.Size(540, 180)
        Me.dgv_keluaran_satuan.TabIndex = 61
        '
        'dgv_satuan_kg
        '
        Me.dgv_satuan_kg.AllowUserToAddRows = False
        Me.dgv_satuan_kg.AllowUserToDeleteRows = False
        Me.dgv_satuan_kg.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_satuan_kg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle56.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle56.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle56.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle56.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle56.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle56.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle56.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_satuan_kg.DefaultCellStyle = DataGridViewCellStyle56
        Me.dgv_satuan_kg.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_satuan_kg.Location = New System.Drawing.Point(622, 320)
        Me.dgv_satuan_kg.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_satuan_kg.MultiSelect = False
        Me.dgv_satuan_kg.Name = "dgv_satuan_kg"
        Me.dgv_satuan_kg.ReadOnly = True
        Me.dgv_satuan_kg.Size = New System.Drawing.Size(432, 169)
        Me.dgv_satuan_kg.TabIndex = 63
        Me.dgv_satuan_kg.Visible = False
        '
        'dgv_satuan_mtr
        '
        Me.dgv_satuan_mtr.AllowUserToAddRows = False
        Me.dgv_satuan_mtr.AllowUserToDeleteRows = False
        Me.dgv_satuan_mtr.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_satuan_mtr.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle57.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle57.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle57.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle57.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle57.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle57.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle57.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_satuan_mtr.DefaultCellStyle = DataGridViewCellStyle57
        Me.dgv_satuan_mtr.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_satuan_mtr.Location = New System.Drawing.Point(622, 222)
        Me.dgv_satuan_mtr.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_satuan_mtr.MultiSelect = False
        Me.dgv_satuan_mtr.Name = "dgv_satuan_mtr"
        Me.dgv_satuan_mtr.ReadOnly = True
        Me.dgv_satuan_mtr.Size = New System.Drawing.Size(432, 169)
        Me.dgv_satuan_mtr.TabIndex = 62
        Me.dgv_satuan_mtr.Visible = False
        '
        'dgv_list_keluaran
        '
        Me.dgv_list_keluaran.AllowUserToAddRows = False
        Me.dgv_list_keluaran.AllowUserToDeleteRows = False
        Me.dgv_list_keluaran.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_keluaran.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_list_keluaran.ColumnHeadersVisible = False
        DataGridViewCellStyle58.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle58.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle58.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle58.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle58.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle58.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle58.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_keluaran.DefaultCellStyle = DataGridViewCellStyle58
        Me.dgv_list_keluaran.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_keluaran.Location = New System.Drawing.Point(9, 339)
        Me.dgv_list_keluaran.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_keluaran.MultiSelect = False
        Me.dgv_list_keluaran.Name = "dgv_list_keluaran"
        Me.dgv_list_keluaran.ReadOnly = True
        Me.dgv_list_keluaran.Size = New System.Drawing.Size(540, 180)
        Me.dgv_list_keluaran.TabIndex = 57
        '
        'dgv_satuan_yard
        '
        Me.dgv_satuan_yard.AllowUserToAddRows = False
        Me.dgv_satuan_yard.AllowUserToDeleteRows = False
        Me.dgv_satuan_yard.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_satuan_yard.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle59.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle59.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle59.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle59.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle59.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle59.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle59.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_satuan_yard.DefaultCellStyle = DataGridViewCellStyle59
        Me.dgv_satuan_yard.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_satuan_yard.Location = New System.Drawing.Point(622, 120)
        Me.dgv_satuan_yard.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_satuan_yard.MultiSelect = False
        Me.dgv_satuan_yard.Name = "dgv_satuan_yard"
        Me.dgv_satuan_yard.ReadOnly = True
        Me.dgv_satuan_yard.Size = New System.Drawing.Size(432, 169)
        Me.dgv_satuan_yard.TabIndex = 60
        Me.dgv_satuan_yard.Visible = False
        '
        'dgv_list_keluaran_total
        '
        Me.dgv_list_keluaran_total.AllowUserToAddRows = False
        Me.dgv_list_keluaran_total.AllowUserToDeleteRows = False
        Me.dgv_list_keluaran_total.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_keluaran_total.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle60.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle60.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle60.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle60.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle60.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle60.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle60.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_keluaran_total.DefaultCellStyle = DataGridViewCellStyle60
        Me.dgv_list_keluaran_total.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_keluaran_total.Location = New System.Drawing.Point(67, 162)
        Me.dgv_list_keluaran_total.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_keluaran_total.MultiSelect = False
        Me.dgv_list_keluaran_total.Name = "dgv_list_keluaran_total"
        Me.dgv_list_keluaran_total.ReadOnly = True
        Me.dgv_list_keluaran_total.Size = New System.Drawing.Size(432, 169)
        Me.dgv_list_keluaran_total.TabIndex = 59
        Me.dgv_list_keluaran_total.Visible = False
        '
        'dgv_list_keluaran_kain
        '
        Me.dgv_list_keluaran_kain.AllowUserToAddRows = False
        Me.dgv_list_keluaran_kain.AllowUserToDeleteRows = False
        Me.dgv_list_keluaran_kain.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_keluaran_kain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle61.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle61.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle61.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle61.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle61.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle61.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle61.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_keluaran_kain.DefaultCellStyle = DataGridViewCellStyle61
        Me.dgv_list_keluaran_kain.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_keluaran_kain.Location = New System.Drawing.Point(67, 246)
        Me.dgv_list_keluaran_kain.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_keluaran_kain.MultiSelect = False
        Me.dgv_list_keluaran_kain.Name = "dgv_list_keluaran_kain"
        Me.dgv_list_keluaran_kain.ReadOnly = True
        Me.dgv_list_keluaran_kain.Size = New System.Drawing.Size(432, 169)
        Me.dgv_list_keluaran_kain.TabIndex = 58
        Me.dgv_list_keluaran_kain.Visible = False
        '
        'dgv_list_celup
        '
        Me.dgv_list_celup.AllowUserToAddRows = False
        Me.dgv_list_celup.AllowUserToDeleteRows = False
        Me.dgv_list_celup.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_celup.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle62.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle62.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle62.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle62.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle62.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle62.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle62.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_celup.DefaultCellStyle = DataGridViewCellStyle62
        Me.dgv_list_celup.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_celup.Location = New System.Drawing.Point(67, 320)
        Me.dgv_list_celup.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_celup.MultiSelect = False
        Me.dgv_list_celup.Name = "dgv_list_celup"
        Me.dgv_list_celup.ReadOnly = True
        Me.dgv_list_celup.Size = New System.Drawing.Size(432, 169)
        Me.dgv_list_celup.TabIndex = 56
        Me.dgv_list_celup.Visible = False
        '
        'TabPage6
        '
        Me.TabPage6.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage6.Controls.Add(Me.dgv_spt_clone)
        Me.TabPage6.Controls.Add(Me.dgv_spt_aml)
        Me.TabPage6.Controls.Add(Me.dgv_spt_efaktur)
        Me.TabPage6.Location = New System.Drawing.Point(4, 22)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "SPT Masa PPN"
        '
        'dgv_spt_clone
        '
        Me.dgv_spt_clone.AllowUserToAddRows = False
        Me.dgv_spt_clone.AllowUserToDeleteRows = False
        Me.dgv_spt_clone.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_spt_clone.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle63.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle63.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle63.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle63.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle63.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle63.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle63.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_spt_clone.DefaultCellStyle = DataGridViewCellStyle63
        Me.dgv_spt_clone.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_spt_clone.Location = New System.Drawing.Point(9, 13)
        Me.dgv_spt_clone.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_spt_clone.MultiSelect = False
        Me.dgv_spt_clone.Name = "dgv_spt_clone"
        Me.dgv_spt_clone.ReadOnly = True
        Me.dgv_spt_clone.Size = New System.Drawing.Size(1105, 250)
        Me.dgv_spt_clone.TabIndex = 52
        '
        'dgv_spt_aml
        '
        Me.dgv_spt_aml.AllowUserToAddRows = False
        Me.dgv_spt_aml.AllowUserToDeleteRows = False
        Me.dgv_spt_aml.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_spt_aml.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle64.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle64.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle64.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle64.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle64.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle64.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle64.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_spt_aml.DefaultCellStyle = DataGridViewCellStyle64
        Me.dgv_spt_aml.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_spt_aml.Location = New System.Drawing.Point(9, 271)
        Me.dgv_spt_aml.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_spt_aml.MultiSelect = False
        Me.dgv_spt_aml.Name = "dgv_spt_aml"
        Me.dgv_spt_aml.ReadOnly = True
        Me.dgv_spt_aml.Size = New System.Drawing.Size(1105, 250)
        Me.dgv_spt_aml.TabIndex = 51
        '
        'dgv_spt_efaktur
        '
        Me.dgv_spt_efaktur.AllowUserToAddRows = False
        Me.dgv_spt_efaktur.AllowUserToDeleteRows = False
        Me.dgv_spt_efaktur.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_spt_efaktur.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle65.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle65.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle65.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle65.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle65.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle65.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle65.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_spt_efaktur.DefaultCellStyle = DataGridViewCellStyle65
        Me.dgv_spt_efaktur.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_spt_efaktur.Location = New System.Drawing.Point(9, 13)
        Me.dgv_spt_efaktur.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_spt_efaktur.MultiSelect = False
        Me.dgv_spt_efaktur.Name = "dgv_spt_efaktur"
        Me.dgv_spt_efaktur.ReadOnly = True
        Me.dgv_spt_efaktur.Size = New System.Drawing.Size(1105, 250)
        Me.dgv_spt_efaktur.TabIndex = 50
        '
        'TabPage7
        '
        Me.TabPage7.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage7.Controls.Add(Me.dgv_pln)
        Me.TabPage7.Location = New System.Drawing.Point(4, 22)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "PLN Garam Coal"
        '
        'dgv_pln
        '
        Me.dgv_pln.AllowUserToAddRows = False
        Me.dgv_pln.AllowUserToDeleteRows = False
        Me.dgv_pln.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_pln.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle66.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle66.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle66.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle66.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle66.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle66.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle66.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_pln.DefaultCellStyle = DataGridViewCellStyle66
        Me.dgv_pln.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_pln.Location = New System.Drawing.Point(9, 24)
        Me.dgv_pln.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_pln.MultiSelect = False
        Me.dgv_pln.Name = "dgv_pln"
        Me.dgv_pln.ReadOnly = True
        Me.dgv_pln.Size = New System.Drawing.Size(650, 320)
        Me.dgv_pln.TabIndex = 49
        '
        'TabPage8
        '
        Me.TabPage8.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage8.Controls.Add(Me.dgv_bukpot)
        Me.TabPage8.Location = New System.Drawing.Point(4, 22)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage8.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage8.TabIndex = 7
        Me.TabPage8.Text = "Bukti Potong"
        '
        'dgv_bukpot
        '
        Me.dgv_bukpot.AllowUserToAddRows = False
        Me.dgv_bukpot.AllowUserToDeleteRows = False
        Me.dgv_bukpot.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_bukpot.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle67.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle67.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle67.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle67.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle67.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle67.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle67.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_bukpot.DefaultCellStyle = DataGridViewCellStyle67
        Me.dgv_bukpot.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_bukpot.Location = New System.Drawing.Point(9, 24)
        Me.dgv_bukpot.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_bukpot.MultiSelect = False
        Me.dgv_bukpot.Name = "dgv_bukpot"
        Me.dgv_bukpot.ReadOnly = True
        Me.dgv_bukpot.Size = New System.Drawing.Size(1105, 485)
        Me.dgv_bukpot.TabIndex = 48
        '
        'TabPage9
        '
        Me.TabPage9.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage9.Controls.Add(Me.dgv_gabungan_penyusutan_kendaraan)
        Me.TabPage9.Controls.Add(Me.dgv_penyusutan_kendaraan)
        Me.TabPage9.Controls.Add(Me.dgv_gabungan_penyusutan_bangunan)
        Me.TabPage9.Controls.Add(Me.dgv_penyusutan_bangunan)
        Me.TabPage9.Controls.Add(Me.dgv_gabungan_penyusutan_inventaris)
        Me.TabPage9.Controls.Add(Me.dgv_penyusutan_inventaris)
        Me.TabPage9.Controls.Add(Me.dgv_gabungan_penyusutan_tanki)
        Me.TabPage9.Controls.Add(Me.dgv_penyusutan_tanki)
        Me.TabPage9.Controls.Add(Me.dgv_gabungan_penyusutan_mesin)
        Me.TabPage9.Controls.Add(Me.Label5)
        Me.TabPage9.Controls.Add(Me.Label4)
        Me.TabPage9.Controls.Add(Me.Label3)
        Me.TabPage9.Controls.Add(Me.Label2)
        Me.TabPage9.Controls.Add(Me.dgv_induk_penyusutan_kendaraan)
        Me.TabPage9.Controls.Add(Me.dgv_induk_penyusutan_bangunan)
        Me.TabPage9.Controls.Add(Me.dgv_induk_penyusutan_inventaris)
        Me.TabPage9.Controls.Add(Me.dgv_induk_penyusutan_tanki)
        Me.TabPage9.Controls.Add(Me.Label1)
        Me.TabPage9.Controls.Add(Me.dgv_penyusutan_mesin)
        Me.TabPage9.Controls.Add(Me.dgv_induk_penyusutan_mesin)
        Me.TabPage9.Location = New System.Drawing.Point(4, 22)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage9.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage9.TabIndex = 8
        Me.TabPage9.Text = "Rincian Penyusutan"
        '
        'dgv_gabungan_penyusutan_kendaraan
        '
        Me.dgv_gabungan_penyusutan_kendaraan.AllowUserToAddRows = False
        Me.dgv_gabungan_penyusutan_kendaraan.AllowUserToDeleteRows = False
        Me.dgv_gabungan_penyusutan_kendaraan.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_gabungan_penyusutan_kendaraan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle68.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle68.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle68.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle68.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle68.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle68.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle68.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_gabungan_penyusutan_kendaraan.DefaultCellStyle = DataGridViewCellStyle68
        Me.dgv_gabungan_penyusutan_kendaraan.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_gabungan_penyusutan_kendaraan.Location = New System.Drawing.Point(904, 74)
        Me.dgv_gabungan_penyusutan_kendaraan.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_gabungan_penyusutan_kendaraan.MultiSelect = False
        Me.dgv_gabungan_penyusutan_kendaraan.Name = "dgv_gabungan_penyusutan_kendaraan"
        Me.dgv_gabungan_penyusutan_kendaraan.ReadOnly = True
        Me.dgv_gabungan_penyusutan_kendaraan.Size = New System.Drawing.Size(210, 356)
        Me.dgv_gabungan_penyusutan_kendaraan.TabIndex = 69
        Me.dgv_gabungan_penyusutan_kendaraan.Visible = False
        '
        'dgv_penyusutan_kendaraan
        '
        Me.dgv_penyusutan_kendaraan.AllowUserToAddRows = False
        Me.dgv_penyusutan_kendaraan.AllowUserToDeleteRows = False
        Me.dgv_penyusutan_kendaraan.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_penyusutan_kendaraan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle69.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle69.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle69.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle69.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle69.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle69.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle69.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_penyusutan_kendaraan.DefaultCellStyle = DataGridViewCellStyle69
        Me.dgv_penyusutan_kendaraan.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_penyusutan_kendaraan.Location = New System.Drawing.Point(904, 167)
        Me.dgv_penyusutan_kendaraan.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_penyusutan_kendaraan.MultiSelect = False
        Me.dgv_penyusutan_kendaraan.Name = "dgv_penyusutan_kendaraan"
        Me.dgv_penyusutan_kendaraan.ReadOnly = True
        Me.dgv_penyusutan_kendaraan.Size = New System.Drawing.Size(210, 356)
        Me.dgv_penyusutan_kendaraan.TabIndex = 68
        '
        'dgv_gabungan_penyusutan_bangunan
        '
        Me.dgv_gabungan_penyusutan_bangunan.AllowUserToAddRows = False
        Me.dgv_gabungan_penyusutan_bangunan.AllowUserToDeleteRows = False
        Me.dgv_gabungan_penyusutan_bangunan.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_gabungan_penyusutan_bangunan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle70.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle70.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle70.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle70.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle70.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle70.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle70.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_gabungan_penyusutan_bangunan.DefaultCellStyle = DataGridViewCellStyle70
        Me.dgv_gabungan_penyusutan_bangunan.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_gabungan_penyusutan_bangunan.Location = New System.Drawing.Point(680, 74)
        Me.dgv_gabungan_penyusutan_bangunan.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_gabungan_penyusutan_bangunan.MultiSelect = False
        Me.dgv_gabungan_penyusutan_bangunan.Name = "dgv_gabungan_penyusutan_bangunan"
        Me.dgv_gabungan_penyusutan_bangunan.ReadOnly = True
        Me.dgv_gabungan_penyusutan_bangunan.Size = New System.Drawing.Size(210, 356)
        Me.dgv_gabungan_penyusutan_bangunan.TabIndex = 67
        Me.dgv_gabungan_penyusutan_bangunan.Visible = False
        '
        'dgv_penyusutan_bangunan
        '
        Me.dgv_penyusutan_bangunan.AllowUserToAddRows = False
        Me.dgv_penyusutan_bangunan.AllowUserToDeleteRows = False
        Me.dgv_penyusutan_bangunan.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_penyusutan_bangunan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle71.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle71.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle71.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle71.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle71.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle71.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle71.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_penyusutan_bangunan.DefaultCellStyle = DataGridViewCellStyle71
        Me.dgv_penyusutan_bangunan.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_penyusutan_bangunan.Location = New System.Drawing.Point(680, 167)
        Me.dgv_penyusutan_bangunan.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_penyusutan_bangunan.MultiSelect = False
        Me.dgv_penyusutan_bangunan.Name = "dgv_penyusutan_bangunan"
        Me.dgv_penyusutan_bangunan.ReadOnly = True
        Me.dgv_penyusutan_bangunan.Size = New System.Drawing.Size(210, 356)
        Me.dgv_penyusutan_bangunan.TabIndex = 66
        '
        'dgv_gabungan_penyusutan_inventaris
        '
        Me.dgv_gabungan_penyusutan_inventaris.AllowUserToAddRows = False
        Me.dgv_gabungan_penyusutan_inventaris.AllowUserToDeleteRows = False
        Me.dgv_gabungan_penyusutan_inventaris.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_gabungan_penyusutan_inventaris.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle72.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle72.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle72.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle72.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle72.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle72.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle72.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_gabungan_penyusutan_inventaris.DefaultCellStyle = DataGridViewCellStyle72
        Me.dgv_gabungan_penyusutan_inventaris.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_gabungan_penyusutan_inventaris.Location = New System.Drawing.Point(456, 74)
        Me.dgv_gabungan_penyusutan_inventaris.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_gabungan_penyusutan_inventaris.MultiSelect = False
        Me.dgv_gabungan_penyusutan_inventaris.Name = "dgv_gabungan_penyusutan_inventaris"
        Me.dgv_gabungan_penyusutan_inventaris.ReadOnly = True
        Me.dgv_gabungan_penyusutan_inventaris.Size = New System.Drawing.Size(210, 356)
        Me.dgv_gabungan_penyusutan_inventaris.TabIndex = 65
        Me.dgv_gabungan_penyusutan_inventaris.Visible = False
        '
        'dgv_penyusutan_inventaris
        '
        Me.dgv_penyusutan_inventaris.AllowUserToAddRows = False
        Me.dgv_penyusutan_inventaris.AllowUserToDeleteRows = False
        Me.dgv_penyusutan_inventaris.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_penyusutan_inventaris.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle73.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle73.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle73.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle73.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle73.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle73.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle73.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_penyusutan_inventaris.DefaultCellStyle = DataGridViewCellStyle73
        Me.dgv_penyusutan_inventaris.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_penyusutan_inventaris.Location = New System.Drawing.Point(456, 167)
        Me.dgv_penyusutan_inventaris.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_penyusutan_inventaris.MultiSelect = False
        Me.dgv_penyusutan_inventaris.Name = "dgv_penyusutan_inventaris"
        Me.dgv_penyusutan_inventaris.ReadOnly = True
        Me.dgv_penyusutan_inventaris.Size = New System.Drawing.Size(210, 356)
        Me.dgv_penyusutan_inventaris.TabIndex = 64
        '
        'dgv_gabungan_penyusutan_tanki
        '
        Me.dgv_gabungan_penyusutan_tanki.AllowUserToAddRows = False
        Me.dgv_gabungan_penyusutan_tanki.AllowUserToDeleteRows = False
        Me.dgv_gabungan_penyusutan_tanki.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_gabungan_penyusutan_tanki.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle74.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle74.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle74.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle74.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle74.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle74.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle74.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_gabungan_penyusutan_tanki.DefaultCellStyle = DataGridViewCellStyle74
        Me.dgv_gabungan_penyusutan_tanki.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_gabungan_penyusutan_tanki.Location = New System.Drawing.Point(232, 74)
        Me.dgv_gabungan_penyusutan_tanki.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_gabungan_penyusutan_tanki.MultiSelect = False
        Me.dgv_gabungan_penyusutan_tanki.Name = "dgv_gabungan_penyusutan_tanki"
        Me.dgv_gabungan_penyusutan_tanki.ReadOnly = True
        Me.dgv_gabungan_penyusutan_tanki.Size = New System.Drawing.Size(210, 356)
        Me.dgv_gabungan_penyusutan_tanki.TabIndex = 63
        Me.dgv_gabungan_penyusutan_tanki.Visible = False
        '
        'dgv_penyusutan_tanki
        '
        Me.dgv_penyusutan_tanki.AllowUserToAddRows = False
        Me.dgv_penyusutan_tanki.AllowUserToDeleteRows = False
        Me.dgv_penyusutan_tanki.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_penyusutan_tanki.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle75.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle75.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle75.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle75.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle75.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle75.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle75.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_penyusutan_tanki.DefaultCellStyle = DataGridViewCellStyle75
        Me.dgv_penyusutan_tanki.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_penyusutan_tanki.Location = New System.Drawing.Point(232, 167)
        Me.dgv_penyusutan_tanki.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_penyusutan_tanki.MultiSelect = False
        Me.dgv_penyusutan_tanki.Name = "dgv_penyusutan_tanki"
        Me.dgv_penyusutan_tanki.ReadOnly = True
        Me.dgv_penyusutan_tanki.Size = New System.Drawing.Size(210, 356)
        Me.dgv_penyusutan_tanki.TabIndex = 62
        '
        'dgv_gabungan_penyusutan_mesin
        '
        Me.dgv_gabungan_penyusutan_mesin.AllowUserToAddRows = False
        Me.dgv_gabungan_penyusutan_mesin.AllowUserToDeleteRows = False
        Me.dgv_gabungan_penyusutan_mesin.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_gabungan_penyusutan_mesin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle76.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle76.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle76.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle76.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle76.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle76.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle76.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_gabungan_penyusutan_mesin.DefaultCellStyle = DataGridViewCellStyle76
        Me.dgv_gabungan_penyusutan_mesin.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_gabungan_penyusutan_mesin.Location = New System.Drawing.Point(9, 74)
        Me.dgv_gabungan_penyusutan_mesin.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_gabungan_penyusutan_mesin.MultiSelect = False
        Me.dgv_gabungan_penyusutan_mesin.Name = "dgv_gabungan_penyusutan_mesin"
        Me.dgv_gabungan_penyusutan_mesin.ReadOnly = True
        Me.dgv_gabungan_penyusutan_mesin.Size = New System.Drawing.Size(210, 356)
        Me.dgv_gabungan_penyusutan_mesin.TabIndex = 61
        Me.dgv_gabungan_penyusutan_mesin.Visible = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(966, 5)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(86, 16)
        Me.Label5.TabIndex = 60
        Me.Label5.Text = "KENDARAAN"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(746, 5)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(79, 16)
        Me.Label4.TabIndex = 59
        Me.Label4.Text = "BANGUNAN"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(518, 5)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(87, 16)
        Me.Label3.TabIndex = 58
        Me.Label3.Text = "INVENTARIS"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(250, 5)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(175, 16)
        Me.Label2.TabIndex = 57
        Me.Label2.Text = "TANKI PENGOLAH LIMBAH"
        '
        'dgv_induk_penyusutan_kendaraan
        '
        Me.dgv_induk_penyusutan_kendaraan.AllowUserToAddRows = False
        Me.dgv_induk_penyusutan_kendaraan.AllowUserToDeleteRows = False
        Me.dgv_induk_penyusutan_kendaraan.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_induk_penyusutan_kendaraan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle77.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle77.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle77.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle77.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle77.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle77.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle77.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_induk_penyusutan_kendaraan.DefaultCellStyle = DataGridViewCellStyle77
        Me.dgv_induk_penyusutan_kendaraan.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_induk_penyusutan_kendaraan.Location = New System.Drawing.Point(904, 24)
        Me.dgv_induk_penyusutan_kendaraan.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_induk_penyusutan_kendaraan.MultiSelect = False
        Me.dgv_induk_penyusutan_kendaraan.Name = "dgv_induk_penyusutan_kendaraan"
        Me.dgv_induk_penyusutan_kendaraan.ReadOnly = True
        Me.dgv_induk_penyusutan_kendaraan.Size = New System.Drawing.Size(210, 139)
        Me.dgv_induk_penyusutan_kendaraan.TabIndex = 56
        '
        'dgv_induk_penyusutan_bangunan
        '
        Me.dgv_induk_penyusutan_bangunan.AllowUserToAddRows = False
        Me.dgv_induk_penyusutan_bangunan.AllowUserToDeleteRows = False
        Me.dgv_induk_penyusutan_bangunan.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_induk_penyusutan_bangunan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle78.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle78.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle78.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle78.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle78.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle78.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle78.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_induk_penyusutan_bangunan.DefaultCellStyle = DataGridViewCellStyle78
        Me.dgv_induk_penyusutan_bangunan.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_induk_penyusutan_bangunan.Location = New System.Drawing.Point(680, 24)
        Me.dgv_induk_penyusutan_bangunan.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_induk_penyusutan_bangunan.MultiSelect = False
        Me.dgv_induk_penyusutan_bangunan.Name = "dgv_induk_penyusutan_bangunan"
        Me.dgv_induk_penyusutan_bangunan.ReadOnly = True
        Me.dgv_induk_penyusutan_bangunan.Size = New System.Drawing.Size(210, 139)
        Me.dgv_induk_penyusutan_bangunan.TabIndex = 55
        '
        'dgv_induk_penyusutan_inventaris
        '
        Me.dgv_induk_penyusutan_inventaris.AllowUserToAddRows = False
        Me.dgv_induk_penyusutan_inventaris.AllowUserToDeleteRows = False
        Me.dgv_induk_penyusutan_inventaris.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_induk_penyusutan_inventaris.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle79.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle79.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle79.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle79.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle79.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle79.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle79.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_induk_penyusutan_inventaris.DefaultCellStyle = DataGridViewCellStyle79
        Me.dgv_induk_penyusutan_inventaris.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_induk_penyusutan_inventaris.Location = New System.Drawing.Point(456, 24)
        Me.dgv_induk_penyusutan_inventaris.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_induk_penyusutan_inventaris.MultiSelect = False
        Me.dgv_induk_penyusutan_inventaris.Name = "dgv_induk_penyusutan_inventaris"
        Me.dgv_induk_penyusutan_inventaris.ReadOnly = True
        Me.dgv_induk_penyusutan_inventaris.Size = New System.Drawing.Size(210, 139)
        Me.dgv_induk_penyusutan_inventaris.TabIndex = 54
        '
        'dgv_induk_penyusutan_tanki
        '
        Me.dgv_induk_penyusutan_tanki.AllowUserToAddRows = False
        Me.dgv_induk_penyusutan_tanki.AllowUserToDeleteRows = False
        Me.dgv_induk_penyusutan_tanki.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_induk_penyusutan_tanki.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle80.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle80.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle80.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle80.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle80.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle80.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle80.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_induk_penyusutan_tanki.DefaultCellStyle = DataGridViewCellStyle80
        Me.dgv_induk_penyusutan_tanki.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_induk_penyusutan_tanki.Location = New System.Drawing.Point(232, 24)
        Me.dgv_induk_penyusutan_tanki.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_induk_penyusutan_tanki.MultiSelect = False
        Me.dgv_induk_penyusutan_tanki.Name = "dgv_induk_penyusutan_tanki"
        Me.dgv_induk_penyusutan_tanki.ReadOnly = True
        Me.dgv_induk_penyusutan_tanki.Size = New System.Drawing.Size(210, 139)
        Me.dgv_induk_penyusutan_tanki.TabIndex = 53
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(88, 5)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(50, 16)
        Me.Label1.TabIndex = 52
        Me.Label1.Text = "MESIN"
        '
        'dgv_penyusutan_mesin
        '
        Me.dgv_penyusutan_mesin.AllowUserToAddRows = False
        Me.dgv_penyusutan_mesin.AllowUserToDeleteRows = False
        Me.dgv_penyusutan_mesin.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_penyusutan_mesin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle81.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle81.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle81.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle81.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle81.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle81.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle81.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_penyusutan_mesin.DefaultCellStyle = DataGridViewCellStyle81
        Me.dgv_penyusutan_mesin.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_penyusutan_mesin.Location = New System.Drawing.Point(8, 167)
        Me.dgv_penyusutan_mesin.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_penyusutan_mesin.MultiSelect = False
        Me.dgv_penyusutan_mesin.Name = "dgv_penyusutan_mesin"
        Me.dgv_penyusutan_mesin.ReadOnly = True
        Me.dgv_penyusutan_mesin.Size = New System.Drawing.Size(210, 356)
        Me.dgv_penyusutan_mesin.TabIndex = 51
        '
        'dgv_induk_penyusutan_mesin
        '
        Me.dgv_induk_penyusutan_mesin.AllowUserToAddRows = False
        Me.dgv_induk_penyusutan_mesin.AllowUserToDeleteRows = False
        Me.dgv_induk_penyusutan_mesin.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_induk_penyusutan_mesin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle82.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle82.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle82.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle82.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle82.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle82.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle82.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_induk_penyusutan_mesin.DefaultCellStyle = DataGridViewCellStyle82
        Me.dgv_induk_penyusutan_mesin.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_induk_penyusutan_mesin.Location = New System.Drawing.Point(8, 24)
        Me.dgv_induk_penyusutan_mesin.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_induk_penyusutan_mesin.MultiSelect = False
        Me.dgv_induk_penyusutan_mesin.Name = "dgv_induk_penyusutan_mesin"
        Me.dgv_induk_penyusutan_mesin.ReadOnly = True
        Me.dgv_induk_penyusutan_mesin.Size = New System.Drawing.Size(210, 139)
        Me.dgv_induk_penyusutan_mesin.TabIndex = 50
        '
        'btn_generate
        '
        Me.btn_generate.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_generate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_generate.Location = New System.Drawing.Point(656, 4)
        Me.btn_generate.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.btn_generate.Name = "btn_generate"
        Me.btn_generate.Size = New System.Drawing.Size(93, 24)
        Me.btn_generate.TabIndex = 54
        Me.btn_generate.TabStop = False
        Me.btn_generate.Text = "GENERATE"
        Me.btn_generate.UseVisualStyleBackColor = True
        '
        'dtp_tahun
        '
        Me.dtp_tahun.CalendarFont = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtp_tahun.CustomFormat = "yyyy"
        Me.dtp_tahun.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtp_tahun.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtp_tahun.Location = New System.Drawing.Point(568, 5)
        Me.dtp_tahun.Name = "dtp_tahun"
        Me.dtp_tahun.ShowUpDown = True
        Me.dtp_tahun.Size = New System.Drawing.Size(71, 22)
        Me.dtp_tahun.TabIndex = 53
        '
        'lbl_dgv1
        '
        Me.lbl_dgv1.AutoSize = True
        Me.lbl_dgv1.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_dgv1.Location = New System.Drawing.Point(382, 9)
        Me.lbl_dgv1.Name = "lbl_dgv1"
        Me.lbl_dgv1.Size = New System.Drawing.Size(182, 14)
        Me.lbl_dgv1.TabIndex = 52
        Me.lbl_dgv1.Text = "LAPORAN KEUANGAN TAHUN"
        '
        'btn_reset
        '
        Me.btn_reset.Enabled = False
        Me.btn_reset.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_reset.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_reset.Location = New System.Drawing.Point(768, 4)
        Me.btn_reset.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.btn_reset.Name = "btn_reset"
        Me.btn_reset.Size = New System.Drawing.Size(93, 24)
        Me.btn_reset.TabIndex = 55
        Me.btn_reset.TabStop = False
        Me.btn_reset.Text = "RESET"
        Me.btn_reset.UseVisualStyleBackColor = True
        '
        'form_laporan_keuangan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1131, 587)
        Me.Controls.Add(Me.btn_reset)
        Me.Controls.Add(Me.btn_generate)
        Me.Controls.Add(Me.dtp_tahun)
        Me.Controls.Add(Me.lbl_dgv1)
        Me.Controls.Add(Me.TabControl1)
        Me.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "form_laporan_keuangan"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.dgv_hpp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_saldo3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_saldo2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_saldo1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        CType(Me.dgv_lapkeu, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        CType(Me.dgv_biaya, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        CType(Me.dgv_list_masukan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_masukan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_list_lain2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_list_batubara, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_list_obat, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_list_kain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage5.ResumeLayout(False)
        CType(Me.dgv_keluaran, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_keluaran_satuan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_satuan_kg, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_satuan_mtr, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_list_keluaran, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_satuan_yard, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_list_keluaran_total, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_list_keluaran_kain, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_list_celup, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage6.ResumeLayout(False)
        CType(Me.dgv_spt_clone, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_spt_aml, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_spt_efaktur, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage7.ResumeLayout(False)
        CType(Me.dgv_pln, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage8.ResumeLayout(False)
        CType(Me.dgv_bukpot, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage9.ResumeLayout(False)
        Me.TabPage9.PerformLayout()
        CType(Me.dgv_gabungan_penyusutan_kendaraan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_penyusutan_kendaraan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_gabungan_penyusutan_bangunan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_penyusutan_bangunan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_gabungan_penyusutan_inventaris, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_penyusutan_inventaris, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_gabungan_penyusutan_tanki, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_penyusutan_tanki, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_gabungan_penyusutan_mesin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_induk_penyusutan_kendaraan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_induk_penyusutan_bangunan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_induk_penyusutan_inventaris, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_induk_penyusutan_tanki, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_penyusutan_mesin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_induk_penyusutan_mesin, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage8 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage9 As System.Windows.Forms.TabPage
    Friend WithEvents btn_generate As System.Windows.Forms.Button
    Friend WithEvents dtp_tahun As System.Windows.Forms.DateTimePicker
    Friend WithEvents lbl_dgv1 As System.Windows.Forms.Label
    Friend WithEvents dgv_bukpot As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_pln As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_spt_aml As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_spt_efaktur As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_spt_clone As System.Windows.Forms.DataGridView
    Friend WithEvents btn_reset As System.Windows.Forms.Button
    Friend WithEvents dgv_masukan As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_kain As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_masukan As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_obat As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_batubara As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_lain2 As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_keluaran As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_keluaran As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_satuan_yard As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_keluaran_total As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_keluaran_kain As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_list_celup As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_satuan_kg As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_satuan_mtr As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_keluaran_satuan As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_penyusutan_mesin As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_induk_penyusutan_mesin As System.Windows.Forms.DataGridView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents dgv_induk_penyusutan_kendaraan As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_induk_penyusutan_bangunan As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_induk_penyusutan_inventaris As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_induk_penyusutan_tanki As System.Windows.Forms.DataGridView
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents dgv_gabungan_penyusutan_mesin As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_gabungan_penyusutan_tanki As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_penyusutan_tanki As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_gabungan_penyusutan_inventaris As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_penyusutan_inventaris As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_gabungan_penyusutan_bangunan As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_penyusutan_bangunan As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_gabungan_penyusutan_kendaraan As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_penyusutan_kendaraan As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_biaya As System.Windows.Forms.DataGridView
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents lbl_hpp_tahun As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents dgv_hpp As System.Windows.Forms.DataGridView
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents dtp_akhir As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtp_awal As System.Windows.Forms.DateTimePicker
    Friend WithEvents dgv_saldo1 As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_saldo2 As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_saldo3 As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_lapkeu As System.Windows.Forms.DataGridView
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents lbl_lapkeu As System.Windows.Forms.Label
End Class
