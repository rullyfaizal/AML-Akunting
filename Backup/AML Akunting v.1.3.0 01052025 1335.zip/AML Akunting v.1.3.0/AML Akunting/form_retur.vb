﻿Imports MySql.Data.MySqlClient

Public Class form_retur

    Dim ppn As Double
    Private Sub isi_ppn()
        Try
            Using conx As New MySqlConnection(sLocalConn)
                conx.Open()
                Dim sqlx = "SELECT ppn from tbppn WHERE id ='ppn'"
                Using cmdx As New MySqlCommand(sqlx, conx)
                    Using drx As MySqlDataReader = cmdx.ExecuteReader
                        drx.Read()
                        ppn = drx(0)
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
    End Sub

    Private Sub form_retur_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call isi_ppn()
    End Sub

    Private Sub btn_batal_retur_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_batal_retur.Click
        Me.Close()
    End Sub

    Private Sub isidgvpembelian()
        Try
            dgv1.Columns.Clear()
            Using conx As New MySqlConnection(sLocalConn)
                conx.Open()
                Dim sqlx As String = "SELECT * FROM tbpembelian WHERE kode = '" & txt_kode_induk.Text & "' ORDER BY baris ASC"
                Using cmdx As New MySqlCommand(sqlx, conx)
                    Using dax As New MySqlDataAdapter
                        dax.SelectCommand = cmdx
                        Using dsx As New DataSet
                            dax.Fill(dsx, "tbpembelian")
                            dgv1.DataSource = dsx.Tables("tbpembelian")
                            Call atur_dgv1()
                        End Using
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub atur_dgv1()
        dgv1.Columns(1).HeaderText = "TGL BELI"
        dgv1.Columns(2).HeaderText = "NO FAKTUR"
        dgv1.Columns(3).HeaderText = "SUPPLIER"
        dgv1.Columns(5).HeaderText = "NAMA GREY"
        dgv1.Columns(6).HeaderText = "QUANTITY"
        dgv1.Columns(7).HeaderText = "DPP GREY"
        For Each column As DataGridViewColumn In dgv1.Columns
            column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        Next
        dgv1.Columns(1).Width = 90
        dgv1.Columns(2).Width = 150
        dgv1.Columns(3).Width = 150
        dgv1.Columns(5).Width = 110
        dgv1.Columns(6).Width = 100
        dgv1.Columns(7).Width = 100
        dgv1.Columns(0).Visible = False
        dgv1.Columns(4).Visible = False
        dgv1.Columns(8).Visible = False
        For i As Integer = 9 To 16
            dgv1.Columns(i).Visible = False
        Next
        dgv1.Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv1.Columns(7).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv1.Columns(6).DefaultCellStyle.Format = "#,##0.00"
        dgv1.Columns(7).DefaultCellStyle.Format = "#,##0.00"
    End Sub
    Private Sub isidgvgrey()
        Try
            dgv2.Columns.Clear()
            Using conx As New MySqlConnection(sLocalConn)
                conx.Open()
                Dim sqlx As String = "SELECT * FROM tbgrey WHERE kode = '" & txt_kode_induk.Text & "'"
                Using cmdx As New MySqlCommand(sqlx, conx)
                    Using dax As New MySqlDataAdapter
                        dax.SelectCommand = cmdx
                        Using dsx As New DataSet
                            dax.Fill(dsx, "tbpembelian")
                            dgv2.DataSource = dsx.Tables("tbpembelian")
                        End Using
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub txt_kode_induk_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_kode_induk.TextChanged
        Call isidgvpembelian()
        Call isidgvgrey()
        If dgv2.RowCount = 0 Then
            MsgBox("Silahkah Input Harga Greynya terlebih dahulu agar Grey masuk ke Stok")
            Me.Close()
        Else
            Dim total As Decimal = 0
            For Each row As DataGridViewRow In dgv2.Rows
                ' Pastikan baris bukan baris baru (new row)
                If Not row.IsNewRow Then
                    ' Cek apakah nilai di kolom ke-10 tidak kosong dan valid
                    If Not IsDBNull(row.Cells(9).Value) AndAlso row.Cells(9).Value IsNot Nothing Then
                        Dim nilai As Decimal
                        If Decimal.TryParse(row.Cells(9).Value.ToString(), nilai) Then
                            total += nilai
                        End If
                    End If
                End If
            Next
            If total <= 0 Then
                MsgBox("Grey yang dipilih sudah terpakai semua")
                Me.Close()
            End If
        End If
    End Sub

    Private Sub dgv2_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgv2.CellMouseClick
        Try
            If dgv1.RowCount = 0 Then
                MsgBox("Tidak Terdapat data untuk Di tampilkan")
            Else
                txt_id_grey_retur.Text = dgv2.CurrentRow.Cells(0).Value.ToString()
                txt_nama_grey_retur.Text = dgv2.CurrentRow.Cells(5).Value.ToString()
                txt_jumlah_asal.Text = dgv2.CurrentRow.Cells(9).Value.ToString()
                txt_dpp_asal.Text = dgv2.CurrentRow.Cells(10).Value.ToString()
                txt_jumlah_retur.Text = ""
                txt_dpp_retur.Text = ""
                txt_ppn_retur.Text = ""
                txt_total_retur.Text = ""
                btn_simpan_retur.Enabled = False
                txt_jumlah_retur.ReadOnly = False
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btn_hitung_retur_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_hitung_retur.Click
        Dim angka1 As Decimal
        Dim angka2 As Decimal
        If txt_nama_grey_retur.Text = "" Then
            MsgBox("Pilih terlebih dahulu GREY yang akan di RETUR")
            txt_jumlah_retur.Focus()
        ElseIf txt_jumlah_retur.Text = "" Or txt_jumlah_retur.Text = "0" Then
            MsgBox("Jumlah GREY yang akan di RETUR belum diinput")
            txt_jumlah_retur.Focus()
        ElseIf Decimal.TryParse(txt_jumlah_retur.Text, Globalization.NumberStyles.Any, Globalization.CultureInfo.CurrentCulture, angka1) _
            AndAlso Decimal.TryParse(txt_jumlah_asal.Text, Globalization.NumberStyles.Any, Globalization.CultureInfo.CurrentCulture, angka2) Then
            If angka1 > angka2 Then
                MessageBox.Show("Jumlah RETUR GREY tidak boleh melebihi stok yang ada")
                txt_jumlah_retur.Focus()
            Else
                Dim jumlah, harga, total_dpp, total_ppn, grand_total As Double
                jumlah = txt_jumlah_retur.Text.Replace(".", "")
                harga = txt_dpp_asal.Text.Replace(".", "")
                total_dpp = jumlah * harga
                txt_dpp_retur.Text = total_dpp.ToString("#,##0.00########")
                total_ppn = total_dpp * (ppn / 100)
                txt_ppn_retur.Text = total_ppn.ToString("#,##0.00########")
                grand_total = total_dpp + total_ppn
                txt_total_retur.Text = grand_total.ToString("#,##0.00########")
                btn_simpan_retur.Enabled = True
                txt_jumlah_retur.ReadOnly = True

            End If
        End If

    End Sub

    Private Sub txt_jumlah_retur_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_jumlah_retur.LostFocus
        If txt_jumlah_retur.Text <> "" Then
            Dim input As String = txt_jumlah_retur.Text
            Dim number As Decimal
            If Decimal.TryParse(input, number) Then
                txt_jumlah_retur.Text = number.ToString("#,##0.##")
            Else
                MessageBox.Show("Jumlah GREY harus berupa angka dengan format yang benar", "Kesalahan", MessageBoxButtons.OK, MessageBoxIcon.Error)
                txt_jumlah_retur.SelectAll()
                txt_jumlah_retur.Focus()
            End If
        End If
    End Sub
End Class