﻿Imports MySql.Data.MySqlClient
Imports OfficeOpenXml
Imports OfficeOpenXml.Style
Imports System.IO

Public Class form_laporan_keuangan

    Private Sub form_laporan_keuangan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call isi_ppn()
    End Sub

    Dim ppn, pph23, pph22 As Double
    Private Sub isi_ppn()
        Try
            Using conx As New MySqlConnection(sLocalConn)
                conx.Open()
                Dim sqlx = "SELECT ppn,pph23,pph22 from tbppn WHERE id ='ppn'"
                Using cmdx As New MySqlCommand(sqlx, conx)
                    Using drx As MySqlDataReader = cmdx.ExecuteReader
                        drx.Read()
                        ppn = drx(0)
                        pph23 = drx(1)
                        pph22 = drx(2)
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
    End Sub

    Private Sub btn_generate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_generate.Click
        If btn_generate.Text = "GENERATE" Then
            btn_generate.Text = "EKSPOR"
            Call tampil_data_bukpot()
            Call LoadDataPLN()

        Else
            btn_generate.Text = "GENERATE"
            Dim txtdate, txttahun As New TextBox
            Dim dtptoday As New DateTimePicker
            dtptoday.Value = DateTime.Now
            txtdate.Text = dtptoday.Value.ToString("dd-MM-yyyy HH:mm:ss")
            txttahun.Text = dtp_tahun.Value.ToString("yyyy")
            Ekspor(dgv_pln, dgv_bukpot, "D:\Ekspor\Laporan Keuangan Tahun " & txttahun.Text & " " & txtdate.Text.Replace("-", "").Replace(":", "") & ".xlsx")
        End If
    End Sub

    Private Sub tampil_data_bukpot()
        dgv_bukpot.Columns.Clear()
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Dim selectedYear As Integer = dtp_tahun.Value.Year
            Dim sqlx As String = "SELECT id_jual, supplier, npwp, tanggal, no_faktur, dpp, ppn, pph23, pph23_actual, no_bukpot, tgl_bukpot, masa_bukpot, gabung_bukpot " &
                                 "FROM tbpenjualan " &
                                 "WHERE no_bukpot <> '' " &
                                 "AND jenis_biaya = 'Jasa' " &
                                 "AND no_faktur <> '' " &
                                 "AND YEAR(masa_bukpot) = " & selectedYear & " " &
                                 "ORDER BY tgl_bukpot ASC, no_bukpot ASC, supplier ASC, pph23_actual DESC"

            Using cmdx As New MySqlCommand(sqlx, conx)
                Using dax As New MySqlDataAdapter
                    dax.SelectCommand = cmdx
                    Using dsx As New DataSet
                        dax.Fill(dsx, "tbpenjualan")
                        dgv_bukpot.DataSource = dsx.Tables("tbpenjualan")
                    End Using
                End Using
            End Using
        End Using

        dgv_bukpot.Columns(1).HeaderText = "CUSTOMER"
        dgv_bukpot.Columns(2).HeaderText = "NPWP"
        dgv_bukpot.Columns(3).HeaderText = "TANGGAL"
        dgv_bukpot.Columns(4).HeaderText = "NO FAKTUR"
        dgv_bukpot.Columns(5).HeaderText = "DPP"
        dgv_bukpot.Columns(6).HeaderText = "PPN"
        dgv_bukpot.Columns(7).HeaderText = "PPH 23"
        dgv_bukpot.Columns(8).HeaderText = "PPH23 ACTUAL"
        dgv_bukpot.Columns(9).HeaderText = "NO BUKPOT"
        dgv_bukpot.Columns(10).HeaderText = "TGL BUKPOT"
        dgv_bukpot.Columns(11).HeaderText = "MASA BUKPOT"
        For Each column As DataGridViewColumn In dgv_bukpot.Columns
            column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        Next
        dgv_bukpot.RowHeadersWidth = 60
        dgv_bukpot.Columns(0).Visible = False
        dgv_bukpot.Columns(12).Visible = False
        dgv_bukpot.Columns(1).Width = 220
        dgv_bukpot.Columns(2).Width = 160
        dgv_bukpot.Columns(3).Width = 85
        dgv_bukpot.Columns(4).Width = 160
        dgv_bukpot.Columns(5).Width = 120
        dgv_bukpot.Columns(6).Width = 120
        dgv_bukpot.Columns(7).Width = 120
        dgv_bukpot.Columns(8).Width = 140
        dgv_bukpot.Columns(9).Width = 120
        dgv_bukpot.Columns(10).Width = 120
        dgv_bukpot.Columns(11).Width = 120
        dgv_bukpot.Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_bukpot.Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_bukpot.Columns(7).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_bukpot.Columns(8).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_bukpot.Columns(9).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_bukpot.Columns(10).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_bukpot.Columns(11).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_bukpot.Columns(12).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_bukpot.Columns(5).DefaultCellStyle.Format = "#,##0.00"
        dgv_bukpot.Columns(6).DefaultCellStyle.Format = "#,##0.00"
        dgv_bukpot.Columns(7).DefaultCellStyle.Format = "#,##0.00"
        dgv_bukpot.Columns(8).DefaultCellStyle.Format = "#,##0.00"
        dgv_bukpot.Columns(10).DefaultCellStyle.Format = "dd-MMM-yy"
        dgv_bukpot.Columns(11).DefaultCellStyle.Format = "MMMM-yy"
    End Sub
    Private Sub dgv_bukpot_CellFormatting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles dgv_bukpot.CellFormatting
        dgv_bukpot.Rows(e.RowIndex).HeaderCell.Value = (e.RowIndex + 1).ToString()
    End Sub

    Private Sub LoadDataPLN()
        dgv_pln.Columns.Clear()
        Call setup_dgv_pln()

        Dim tahun As Integer = dtp_tahun.Value.Year ' Ambil tahun dari DateTimePicker

        ' Query untuk PLN
        Dim queryPLN As String =
            "SELECT MONTH(tanggal) AS bulan, SUM(total) AS total_pln " &
            "FROM tbpembelian " &
            "WHERE jenis_biaya = 'BIAYA LISTRIK PABRIK' AND YEAR(tanggal) = @tahun " &
            "GROUP BY MONTH(tanggal) ORDER BY MONTH(tanggal);"

        ' Query untuk GARAM
        Dim queryGARAM As String =
            "SELECT MONTH(tanggal) AS bulan, SUM(total) AS total_garam " &
            "FROM tbpembelian " &
            "WHERE jenis_biaya = 'BIAYA GARAM' AND YEAR(tanggal) = @tahun " &
            "GROUP BY MONTH(tanggal) ORDER BY MONTH(tanggal);"

        ' Query untuk COAL
        Dim queryCOAL As String =
            "SELECT MONTH(tanggal) AS bulan, SUM(dpp) AS total_coal " &
            "FROM tbpembelian " &
            "WHERE jenis_biaya = 'BATUBARA' AND YEAR(tanggal) = @tahun " &
            "GROUP BY MONTH(tanggal) ORDER BY MONTH(tanggal);"

        ' Kosongkan semua kolom sebelum diisi ulang
        For Each row As DataGridViewRow In dgv_pln.Rows
            row.Cells("PLN").Value = 0
            row.Cells("GARAM").Value = 0
            row.Cells("COAL").Value = 0
            row.Cells("PPH 22 COAL").Value = 0
        Next

        ' Proses PLN
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Using cmd As New MySqlCommand(queryPLN, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim bulan As Integer = reader.GetInt32("bulan")
                        Dim total_pln As Decimal = reader.GetDecimal("total_pln")
                        If bulan >= 1 And bulan <= 12 Then
                            dgv_pln.Rows(bulan - 1).Cells("PLN").Value = total_pln
                        End If
                    End While
                End Using
            End Using

            ' Proses GARAM
            Using cmd As New MySqlCommand(queryGARAM, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim bulan As Integer = reader.GetInt32("bulan")
                        Dim total_garam As Decimal = reader.GetDecimal("total_garam")
                        If bulan >= 1 And bulan <= 12 Then
                            dgv_pln.Rows(bulan - 1).Cells("GARAM").Value = total_garam
                        End If
                    End While
                End Using
            End Using

            ' Proses COAL
            Using cmd As New MySqlCommand(queryCOAL, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim bulan As Integer = reader.GetInt32("bulan")
                        Dim total_coal As Decimal = reader.GetDecimal("total_coal")
                        If bulan >= 1 And bulan <= 12 Then
                            dgv_pln.Rows(bulan - 1).Cells("COAL").Value = total_coal
                            ' Hitung PPH 22 COAL (COAL * PPN 22 dari variabel global)
                            dgv_pln.Rows(bulan - 1).Cells("PPH 22 COAL").Value = total_coal * (pph22 / 100)
                        End If
                    End While
                End Using
            End Using
        End Using
    End Sub
    Private Sub setup_dgv_pln()
        dgv_pln.ColumnCount = 5
        dgv_pln.Columns(0).Name = ""
        dgv_pln.Columns(1).Name = "PLN"
        dgv_pln.Columns(2).Name = "GARAM"
        dgv_pln.Columns(3).Name = "COAL"
        dgv_pln.Columns(4).Name = "PPH 22 COAL"

        Dim bulanArray As String() = {"JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"}
        For Each bulan As String In bulanArray
            dgv_pln.Rows.Add(bulan, 0, 0, 0, 0)
        Next
        dgv_pln.Columns(1).Width = 120
        dgv_pln.Columns(2).Width = 120
        dgv_pln.Columns(3).Width = 120
        dgv_pln.Columns(4).Width = 120
        dgv_pln.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_pln.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_pln.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_pln.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_pln.Columns(1).DefaultCellStyle.Format = "#,##0.00"
        dgv_pln.Columns(2).DefaultCellStyle.Format = "#,##0.00"
        dgv_pln.Columns(3).DefaultCellStyle.Format = "#,##0.00"
        dgv_pln.Columns(4).DefaultCellStyle.Format = "#,##0.00"
    End Sub

    Private Sub Ekspor(ByVal dgv_pln As DataGridView, ByVal dgv_bukpot As DataGridView, ByVal filePath As String)
        Try
            Dim txttahun As New TextBox
            txttahun.Text = dtp_tahun.Value.ToString("yyyy")

            Using package As New ExcelPackage()

                ' Sheet 7: PLN GARAM COAL
                Dim ws1 As ExcelWorksheet = package.Workbook.Worksheets.Add("PLN GARAM COAL")
                ws1.Cells(1, 1).Value = "DATA PLN GARAM COAL TAHUN " & txttahun.Text
                ws1.Cells(1, 1, 1, dgv_pln.Columns.Count).Merge = True
                'ws1.Cells(1, 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                'ws1.Cells(1, 1).Style.Font.Bold = True
                ' Header PLN GARAM COAL
                For col As Integer = 0 To dgv_pln.Columns.Count - 1
                    ws1.Cells(3, col + 1).Value = dgv_pln.Columns(col).HeaderText
                    'ws1.Cells(3, col + 1).Style.Font.Bold = True
                    ws1.Cells(3, col + 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws1.Cells(3, col + 1).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                Next
                ' Data PLN GARAM COAL
                For row As Integer = 0 To dgv_pln.Rows.Count - 1
                    For col As Integer = 0 To dgv_pln.Columns.Count - 1
                        ws1.Cells(row + 4, col + 1).Value = dgv_pln.Rows(row).Cells(col).Value
                        ws1.Cells(row + 4, col + 1).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                        Dim cell = ws1.Cells(row + 4, col + 1)
                        Dim value = dgv_pln.Rows(row).Cells(col).Value
                        If IsNumeric(value) Then
                            cell.Value = value
                            cell.Style.Numberformat.Format = "#,##0.00" ' Format angka
                        Else
                            cell.Value = value
                        End If
                    Next
                Next
                'ws1.Cells(ws1.Dimension.Address).AutoFitColumns()
                For col As Integer = 1 To dgv_pln.Columns.Count + 1
                    ws1.Column(col).Width = 135 / 7.5 ' Mengonversi px ke Excel units
                Next
                ' Akhir Sheet 7

                ' Sheet 8: DAFTAR BUKTI POTONG
                Dim ws2 As ExcelWorksheet = package.Workbook.Worksheets.Add("DAFTAR BUKTI POTONG")
                ws2.Cells(1, 1, 1, dgv_bukpot.Columns.Count).Merge = True
                ws2.Cells(1, 1).Value = "DAFTAR BUKTI POTONG TAHUN PAJAK " & txttahun.Text
                'ws2.Cells(1, 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                'ws2.Cells(1, 1).Style.Font.Bold = True
                ' Header DAFTAR BUKTI POTONG
                Dim headers = {"NO", "NAMA CUSTOMER PEMOTONG", "NPWP CUSTOMER", "TANGGAL FP", "NO FAKTUR PAJAK", "NILAI DPP", "PPN", "PPH23", "PPH23 ACTUAL", "NO BUKPOT", "TGL BUKPOT", "MASA BUKPOT"}
                For col As Integer = 0 To headers.Length - 1
                    ws2.Cells(3, col + 1).Value = headers(col)
                    'ws2.Cells(3, col + 1).Style.Font.Bold = True
                    ws2.Cells(3, col + 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws2.Cells(3, col + 1).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                    'ws2.Cells(3, col + 1).Style.Fill.PatternType = ExcelFillStyle.Solid
                    'ws2.Cells(3, col + 1).Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightGray)
                Next
                ' Mengelompokkan data berdasarkan nilai gabung_bukpot
                Dim groupedData As New List(Of Dictionary(Of String, Object))
                Dim tempGroup As Dictionary(Of String, Object) = Nothing
                For row As Integer = 0 To dgv_bukpot.Rows.Count - 1
                    Dim gabung_bukpot = dgv_bukpot.Rows(row).Cells("gabung_bukpot").Value.ToString()
                    If tempGroup IsNot Nothing AndAlso tempGroup("gabung_bukpot").ToString() = gabung_bukpot Then
                        ' Gabungkan nilai pph23_actual
                        tempGroup("pph23_actual") = CDbl(tempGroup("pph23_actual")) + CDbl(dgv_bukpot.Rows(row).Cells("pph23_actual").Value)
                        tempGroup("Rows").Add(row)
                    Else
                        ' Tambahkan grup baru
                        If tempGroup IsNot Nothing Then groupedData.Add(tempGroup)
                        tempGroup = New Dictionary(Of String, Object) From {
                            {"gabung_bukpot", gabung_bukpot},
                            {"pph23_actual", dgv_bukpot.Rows(row).Cells("pph23_actual").Value},
                            {"Rows", New List(Of Integer) From {row}}
                        }
                    End If
                Next
                If tempGroup IsNot Nothing Then groupedData.Add(tempGroup)

                ' Mengisi data ke Excel
                Dim rowIndex As Integer = 4
                For Each group In groupedData
                    Dim Rows = group("Rows")
                    Dim startRow = rowIndex
                    Dim endRow = rowIndex + Rows.Count - 1

                    For Each rowIndexInGroup In Rows
                        ' Menulis nomor urut
                        ws2.Cells(rowIndex, 1).Value = rowIndex - 3
                        ws2.Cells(rowIndex, 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                        ws2.Cells(rowIndex, 1).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                        ' Menulis data ke kolom lain
                        Dim colIndexData As Integer = 1
                        For col As Integer = 0 To dgv_bukpot.Columns.Count - 1
                            If dgv_bukpot.Columns(col).Name <> "id_jual" AndAlso dgv_bukpot.Columns(col).Name <> "gabung_bukpot" Then
                                colIndexData += 1
                                Dim cell = ws2.Cells(rowIndex, colIndexData)
                                Dim value = dgv_bukpot.Rows(rowIndexInGroup).Cells(col).Value

                                ' Format khusus untuk kolom tertentu
                                Select Case dgv_bukpot.Columns(col).Name
                                    Case "tanggal", "tgl_bukpot"
                                        ' Format tanggal menjadi 19-Jan-2024
                                        If value IsNot Nothing AndAlso IsDate(value) Then
                                            cell.Value = CDate(value)
                                            cell.Style.Numberformat.Format = "dd-MMM-yyyy"
                                        End If
                                    Case "masa_bukpot"
                                        ' Format masa_bukpot menjadi Januari-24
                                        If value IsNot Nothing AndAlso IsDate(value) Then
                                            cell.Value = CDate(value).ToString("MMMM-yy")
                                        End If
                                        cell.Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                                    Case "no_bukpot"
                                        ' Rata kanan untuk no_bukpot
                                        cell.Value = value.ToString()
                                        cell.Style.Numberformat.Format = "@"
                                        cell.Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                                    Case "pph23_actual"
                                        If rowIndex = startRow Then
                                            ' Tuliskan nilai hasil penjumlahan pada baris pertama
                                            cell.Value = CDbl(group("pph23_actual"))
                                            cell.Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                                            cell.Style.Numberformat.Format = "#,##0.00"
                                            cell.Style.VerticalAlignment = ExcelVerticalAlignment.Center
                                            ' Merge cell pph23_actual
                                            ws2.Cells(startRow, colIndexData, endRow, colIndexData).Merge = True
                                        End If
                                    Case Else
                                        ' Default untuk kolom lainnya
                                        If TypeOf value Is Double Or TypeOf value Is Decimal Then
                                            cell.Value = value
                                            cell.Style.Numberformat.Format = "#,##0.00"
                                        Else
                                            cell.Value = value.ToString()
                                        End If
                                End Select
                                cell.Style.Border.BorderAround(ExcelBorderStyle.Thin)
                            End If
                        Next
                        rowIndex += 1
                    Next
                Next
                'Akhir sheet 8

                ' Menyesuaikan lebar kolom
                ws2.Cells(ws2.Dimension.Address).AutoFitColumns()

                ' Simpan file Excel
                Dim fi As New FileInfo(filePath)
                package.SaveAs(fi)
                MessageBox.Show("Ekspor Data ke Excel Berhasil!")
            End Using
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub

    'Private Sub Ekspor(ByVal dgv1 As DataGridView, ByVal filePath As String)
    '    Try
    '        Dim txttahun As New TextBox
    '        txttahun.Text = dtp_tahun.Value.ToString("yyyy")
    '        Using package As New ExcelPackage()
    '            ' Membuat worksheet dengan nama tahun
    '            Dim ws As ExcelWorksheet = package.Workbook.Worksheets.Add("DAFTAR BUKTI POTONG")

    '            ' Menambahkan judul
    '            ws.Cells(1, 1, 1, 12).Merge = True
    '            ws.Cells(1, 1).Value = "DAFTAR BUKTI POTONG TAHUN PAJAK " & txttahun.Text

    '            ' Menambahkan header
    '            ws.Cells(3, 1).Value = "NO"
    '            ws.Cells(3, 2).Value = "NAMA CUSTOMER PEMOTONG"
    '            ws.Cells(3, 3).Value = "NPWP CUSTOMER"
    '            ws.Cells(3, 4).Value = "TANGGAL FP"
    '            ws.Cells(3, 5).Value = "NO FAKTUR PAJAK"
    '            ws.Cells(3, 6).Value = "NILAI DPP"
    '            ws.Cells(3, 7).Value = "PPN"
    '            ws.Cells(3, 8).Value = "PPH23"
    '            ws.Cells(3, 9).Value = "PPH23 ACTUAL"
    '            ws.Cells(3, 10).Value = "NO BUKPOT"
    '            ws.Cells(3, 11).Value = "TGL BUKPOT"
    '            ws.Cells(3, 12).Value = "MASA BUKPOT"

    '            ' Set style header
    '            For col As Integer = 1 To 12
    '                ws.Cells(3, col).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
    '                ws.Cells(3, col).Style.Fill.PatternType = ExcelFillStyle.Solid
    '                ws.Cells(3, col).Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightGray)
    '                ws.Cells(3, col).Style.Border.BorderAround(ExcelBorderStyle.Thin)
    '            Next

    '            ' Mengelompokkan data berdasarkan nilai gabung_bukpot
    '            Dim groupedData As New List(Of Dictionary(Of String, Object))
    '            Dim tempGroup As Dictionary(Of String, Object) = Nothing
    '            For row As Integer = 0 To dgv1.Rows.Count - 1
    '                Dim gabung_bukpot = dgv1.Rows(row).Cells("gabung_bukpot").Value.ToString()
    '                If tempGroup IsNot Nothing AndAlso tempGroup("gabung_bukpot").ToString() = gabung_bukpot Then
    '                    ' Gabungkan nilai pph23_actual
    '                    tempGroup("pph23_actual") = CDbl(tempGroup("pph23_actual")) + CDbl(dgv1.Rows(row).Cells("pph23_actual").Value)
    '                    tempGroup("rows").Add(row)
    '                Else
    '                    ' Tambahkan grup baru
    '                    If tempGroup IsNot Nothing Then groupedData.Add(tempGroup)
    '                    tempGroup = New Dictionary(Of String, Object) From {
    '                        {"gabung_bukpot", gabung_bukpot},
    '                        {"pph23_actual", dgv1.Rows(row).Cells("pph23_actual").Value},
    '                        {"rows", New List(Of Integer) From {row}}
    '                    }
    '                End If
    '            Next
    '            If tempGroup IsNot Nothing Then groupedData.Add(tempGroup)

    '            ' Mengisi data ke Excel
    '            Dim rowIndex As Integer = 4
    '            For Each group In groupedData
    '                Dim rows = group("rows")
    '                Dim startRow = rowIndex
    '                Dim endRow = rowIndex + rows.Count - 1

    '                For Each rowIndexInGroup In rows
    '                    ' Menulis nomor urut
    '                    ws.Cells(rowIndex, 1).Value = rowIndex - 3
    '                    ws.Cells(rowIndex, 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
    '                    ws.Cells(rowIndex, 1).Style.Border.BorderAround(ExcelBorderStyle.Thin)

    '                    ' Menulis data ke kolom lain
    '                    Dim colIndexData As Integer = 1
    '                    For col As Integer = 0 To dgv1.Columns.Count - 1
    '                        If dgv1.Columns(col).Name <> "id_jual" AndAlso dgv1.Columns(col).Name <> "gabung_bukpot" Then
    '                            colIndexData += 1
    '                            Dim cell = ws.Cells(rowIndex, colIndexData)
    '                            Dim value = dgv1.Rows(rowIndexInGroup).Cells(col).Value

    '                            ' Format khusus untuk kolom tertentu
    '                            Select Case dgv1.Columns(col).Name
    '                                Case "tanggal", "tgl_bukpot"
    '                                    ' Format tanggal menjadi 19-Jan-2024
    '                                    If value IsNot Nothing AndAlso IsDate(value) Then
    '                                        cell.Value = CDate(value)
    '                                        cell.Style.Numberformat.Format = "dd-MMM-yyyy"
    '                                    End If
    '                                Case "masa_bukpot"
    '                                    ' Format masa_bukpot menjadi Januari-24
    '                                    If value IsNot Nothing AndAlso IsDate(value) Then
    '                                        cell.Value = CDate(value).ToString("MMMM-yy")
    '                                    End If
    '                                    cell.Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
    '                                Case "no_bukpot"
    '                                    ' Rata kanan untuk no_bukpot
    '                                    cell.Value = value.ToString()
    '                                    cell.Style.Numberformat.Format = "@"
    '                                    cell.Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
    '                                Case "pph23_actual"
    '                                    If rowIndex = startRow Then
    '                                        ' Tuliskan nilai hasil penjumlahan pada baris pertama
    '                                        cell.Value = CDbl(group("pph23_actual"))
    '                                        cell.Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
    '                                        cell.Style.Numberformat.Format = "#,##0.00"
    '                                        cell.Style.VerticalAlignment = ExcelVerticalAlignment.Center
    '                                        ' Merge cell pph23_actual
    '                                        ws.Cells(startRow, colIndexData, endRow, colIndexData).Merge = True
    '                                    End If
    '                                Case Else
    '                                    ' Default untuk kolom lainnya
    '                                    If TypeOf value Is Double Or TypeOf value Is Decimal Then
    '                                        cell.Value = value
    '                                        cell.Style.Numberformat.Format = "#,##0.00"
    '                                    Else
    '                                        cell.Value = value.ToString()
    '                                    End If
    '                            End Select
    '                            cell.Style.Border.BorderAround(ExcelBorderStyle.Thin)
    '                        End If
    '                    Next
    '                    rowIndex += 1
    '                Next
    '            Next

    '            ' Menyesuaikan lebar kolom
    '            ws.Cells(ws.Dimension.Address).AutoFitColumns()

    '            ' Menyimpan file Excel
    '            Dim fi As New FileInfo(filePath)
    '            package.SaveAs(fi)

    '            MessageBox.Show("Ekspor Data ke Format Excel Berhasil")
    '        End Using
    '    Catch ex As Exception
    '        MessageBox.Show("Error: " & ex.Message)
    '    End Try
    'End Sub
End Class