﻿Imports MySql.Data.MySqlClient

Public Class form_menu_utama

    Private Sub Form_Menu_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        form_koneksi_database.MdiParent = Me
        form_koneksi_database.Show()
        form_koneksi_database.Focus()
        MenuStrip1.Visible = False
        StatusStrip1.Visible = False
        Call otomastis_bs()
    End Sub
    Private Sub KELUARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KELUARToolStripMenuItem.Click
        Me.Close()
    End Sub
    Private Sub JenisBiayaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles JenisBiayaToolStripMenuItem.Click
        form_jenis_biaya.Show()
        form_jenis_biaya.Focus()
    End Sub
    Private Sub NamaSpecsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NamaSpecsToolStripMenuItem.Click
        form_nama_specs.Show()
        form_nama_specs.Focus()
    End Sub
    Private Sub SupplierToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SupplierToolStripMenuItem1.Click
        form_supplier.Show()
        form_supplier.Focus()
    End Sub
    Private Sub PPNPPh23ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PPNPPh23ToolStripMenuItem.Click
        'form_parameter_ppn.MdiParent = Me
        form_parameter_ppn.Show()
        form_parameter_ppn.Focus()
    End Sub
    Private Sub DataPembelianToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DataPembelianToolStripMenuItem.Click
        form_pembelian.Show()
        form_pembelian.Focus()
    End Sub
    Private Sub ToolStripMenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem3.Click
        form_input_pembelian_baru.Show()
        form_input_pembelian_baru.Focus()
    End Sub
    Private Sub UploadPembelianToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UploadPembelianToolStripMenuItem.Click
        form_upload_pembelian.Show()
        form_upload_pembelian.Focus()
    End Sub
    Private Sub ExportUploadPembelianToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExportUploadPembelianToolStripMenuItem.Click
        form_export_pembelian.Show()
        form_export_pembelian.Focus()
    End Sub
    Private Sub CariNamaBarangSpecsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CariNamaBarangSpecsToolStripMenuItem.Click
        form_cari_specs_pembelian.Show()
        form_cari_specs_pembelian.Focus()
    End Sub

    Private Sub CLIENTToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CLIENTToolStripMenuItem.Click
        form_client.Show()
        form_client.Focus()
    End Sub

    Private Sub DataPenjualanToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DataPenjualanToolStripMenuItem.Click
        form_penjualan.Show()
        form_penjualan.Focus()
    End Sub

    Private Sub InputPenjualanCelupToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InputPenjualanCelupToolStripMenuItem.Click
        form_input_penjualan_celup.Show()
        form_input_penjualan_celup.Focus()
    End Sub

    Private Sub InputNamaHargaJualGreyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InputNamaHargaJualGreyToolStripMenuItem.Click
        form_input_harga_jual_grey.Show()
        form_input_harga_jual_grey.Focus()
    End Sub

    Private Sub PatchPembelianToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PatchPembelianToolStripMenuItem.Click
        Try
            Using cony As New MySqlConnection(sLocalConn)
                cony.Open()
                Dim sqly = "SELECT status2 FROM tbpembelian"
                Using cmdy As New MySqlCommand(sqly, cony)
                    Using dry As MySqlDataReader = cmdy.ExecuteReader
                        dry.Read()
                        If dry.HasRows Then
                            MsgBox("Tabel Pembelian Sudah di PATCH")
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            Using conz As New MySqlConnection(sLocalConn)
                conz.Open()
                Dim sqlz = "ALTER TABLE tbpembelian ADD COLUMN status2 VARCHAR(255) COLLATE latin1_swedish_ci NOT NULL DEFAULT '';"
                Using cmdz As New MySqlCommand(sqlz, conz)
                    cmdz.ExecuteNonQuery()
                End Using
            End Using
            MsgBox("PATCH Tabel Pembelian BERHASIL")
        End Try
    End Sub

    Private Sub DataGreyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DataGreyToolStripMenuItem.Click
        form_data_grey.Show()
        form_data_grey.Focus()
    End Sub

    Private Sub PatchGreyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PatchGreyToolStripMenuItem.Click
        Try
            Using cony As New MySqlConnection(sLocalConn)
                cony.Open()
                Dim sqly = "DROP TABLE tbindukgrey;"
                Using cmdy As New MySqlCommand(sqly, cony)
                    cmdy.ExecuteNonQuery()
                End Using
            End Using
            Using conz As New MySqlConnection(sLocalConn)
                conz.Open()
                Dim sqlz = "UPDATE tbpembelian SET status2 = '' WHERE status2 = 'GREY';"
                Using cmdz As New MySqlCommand(sqlz, conz)
                    cmdz.ExecuteNonQuery()
                End Using
            End Using
            MsgBox("PATCH Tabel Grey BERHASIL")
        Catch ex As Exception
            MsgBox("Tabel Grey Sudah di PATCH")
        End Try
    End Sub

    Private Sub InputPenjualanKainToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InputPenjualanKainToolStripMenuItem.Click
        form_input_penjualan_kain.Show()
        form_input_penjualan_kain.Focus()
    End Sub

    Private Sub PatchPenjualanToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PatchPenjualanToolStripMenuItem.Click
        Try
            Using cony As New MySqlConnection(sLocalConn)
                cony.Open()
                Dim sqly = "SELECT gabung_faktur FROM tbpenjualan"
                Using cmdy As New MySqlCommand(sqly, cony)
                    Using dry As MySqlDataReader = cmdy.ExecuteReader
                        dry.Read()
                        If dry.HasRows Then
                            MsgBox("Tabel Penjualan Sudah di PATCH")
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            Using conz As New MySqlConnection(sLocalConn)
                conz.Open()
                Dim sqlz = "ALTER TABLE tbpenjualan ADD COLUMN gabung_faktur VARCHAR(255) COLLATE latin1_swedish_ci NOT NULL DEFAULT '';"
                Using cmdz As New MySqlCommand(sqlz, conz)
                    cmdz.ExecuteNonQuery()
                End Using
            End Using
            MsgBox("PATCH Tabel Penjualan BERHASIL")
        End Try

        'Try
        '    Using cony As New MySqlConnection(sLocalConn)
        '        cony.Open()
        '        Dim sqly = "SELECT upload FROM tbpenjualan"
        '        Using cmdy As New MySqlCommand(sqly, cony)
        '            Using dry As MySqlDataReader = cmdy.ExecuteReader
        '                dry.Read()
        '                If dry.HasRows Then
        '                    MsgBox("Tabel Penjualan Sudah di PATCH")
        '                End If
        '            End Using
        '        End Using
        '    End Using
        'Catch ex As Exception
        '    Using conz As New MySqlConnection(sLocalConn)
        '        conz.Open()
        '        Dim sqlz = "ALTER TABLE tbpenjualan ADD COLUMN upload DATE NULL COLLATE latin1_swedish_ci;"
        '        Using cmdz As New MySqlCommand(sqlz, conz)
        '            cmdz.ExecuteNonQuery()
        '        End Using
        '    End Using
        '    MsgBox("PATCH Tabel Penjualan BERHASIL")
        'End Try
        'Try
        '    Using cony As New MySqlConnection(sLocalConn)
        '        cony.Open()
        '        Dim sqly = "SELECT id_grey1 FROM tbpenjualan"
        '        Using cmdy As New MySqlCommand(sqly, cony)
        '            Using dry As MySqlDataReader = cmdy.ExecuteReader
        '                dry.Read()
        '                If dry.HasRows Then
        '                    MsgBox("Tabel Penjualan Sudah di PATCH")
        '                End If
        '            End Using
        '        End Using
        '    End Using
        'Catch ex As Exception
        '    Using conz As New MySqlConnection(sLocalConn)
        '        conz.Open()
        '        Dim sqlz = "ALTER TABLE tbpenjualan ADD COLUMN id_grey1 int(11) NOT NULL DEFAULT 0, " &
        '            "ADD COLUMN id_grey2 int(11) NOT NULL DEFAULT 0, " &
        '            "ADD COLUMN id_grey3 int(11) NOT NULL DEFAULT 0, " &
        '            "ADD COLUMN kode_omset VARCHAR(50) COLLATE latin1_swedish_ci NOT NULL DEFAULT '';"
        '        Using cmdz As New MySqlCommand(sqlz, conz)
        '            cmdz.ExecuteNonQuery()
        '        End Using
        '    End Using
        '    MsgBox("PATCH Tabel Penjualan BERHASIL")
        'End Try

        'Using conx As New MySqlConnection(sLocalConn)
        '    conx.Open()
        '    Dim sqlx = "SELECT id_jual FROM tbpenjualan WHERE id_jual = 21"
        '    Using cmdx As New MySqlCommand(sqlx, conx)
        '        Using drx As MySqlDataReader = cmdx.ExecuteReader
        '            drx.Read()
        '            If drx.HasRows Then
        '                Using cony As New MySqlConnection(sLocalConn)
        '                    cony.Open()
        '                    Dim sqly = "DELETE FROM tbhistorygrey WHERE id_grey = 14"
        '                    Using cmdy As New MySqlCommand(sqly, cony)
        '                        cmdy.ExecuteNonQuery()
        '                    End Using
        '                End Using
        '                Using cony As New MySqlConnection(sLocalConn)
        '                    cony.Open()
        '                    Dim sqly = "DELETE FROM tbpenjualan WHERE id_jual = 21"
        '                    Using cmdy As New MySqlCommand(sqly, cony)
        '                        cmdy.ExecuteNonQuery()
        '                    End Using
        '                End Using
        '                Using cony As New MySqlConnection(sLocalConn)
        '                    cony.Open()
        '                    Dim sqly = "UPDATE tbneracagrey SET stok_keluar=@1, stok_akhir=@2, dpp_jual=@3 WHERE id_neraca = 3"
        '                    Using cmdy As New MySqlCommand(sqly, cony)
        '                        With cmdy
        '                            .Parameters.Clear()
        '                            .Parameters.AddWithValue("@1", 0)
        '                            .Parameters.AddWithValue("@2", 42748.98)
        '                            .Parameters.AddWithValue("@3", 379349056.75675786)
        '                            .ExecuteNonQuery()
        '                        End With
        '                    End Using
        '                End Using
        '                Using cony As New MySqlConnection(sLocalConn)
        '                    cony.Open()
        '                    Dim sqly = "UPDATE tbgrey SET stok_keluar=@1,stok_akhir=@2,dpp_jual=@3 WHERE id_grey = 8"
        '                    Using cmdy As New MySqlCommand(sqly, cony)
        '                        With cmdy
        '                            .Parameters.Clear()
        '                            .Parameters.AddWithValue("@1", 0)
        '                            .Parameters.AddWithValue("@2", 29790.98)
        '                            .Parameters.AddWithValue("@3", 264361399.09909987)
        '                            .ExecuteNonQuery()
        '                        End With
        '                    End Using
        '                End Using
        '                MsgBox("PATCH PENJUALAN BERHASIL")
        '            Else
        '                MsgBox("PENJUALAN Sudah di PATCH")
        '            End If
        '        End Using
        '    End Using
        'End Using
    End Sub

    Private Sub PatchSupplierToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PatchSupplierToolStripMenuItem.Click
        Try
            Using cony As New MySqlConnection(sLocalConn)
                cony.Open()
                Dim sqly = "SELECT satuan FROM tbsupplier"
                Using cmdy As New MySqlCommand(sqly, cony)
                    Using dry As MySqlDataReader = cmdy.ExecuteReader
                        dry.Read()
                        If dry.HasRows Then
                            MsgBox("Tabel Supplier Sudah di PATCH")
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            Using conz As New MySqlConnection(sLocalConn)
                conz.Open()
                Dim sqlz = "ALTER TABLE tbsupplier ADD COLUMN satuan VARCHAR(50) COLLATE latin1_swedish_ci NOT NULL DEFAULT '';"
                Using cmdz As New MySqlCommand(sqlz, conz)
                    cmdz.ExecuteNonQuery()
                End Using
            End Using
            MsgBox("PATCH Tabel Supplier BERHASIL")
        End Try
    End Sub

    Private Sub OmsetPenjualanToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OmsetPenjualanToolStripMenuItem.Click
        form_omset_penjualan.Show()
        form_omset_penjualan.Focus()
    End Sub

    Private Sub GenerateSuratJalanDanFakturToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GenerateSuratJalanDanFakturToolStripMenuItem.Click
        'form_generate_sj_penjualan.Show()
        'form_generate_sj_penjualan.Focus()
        form_generate_sj_penjualan_baru.Show()
        form_generate_sj_penjualan_baru.Focus()
    End Sub

    Private Sub NeracaGreyBaruToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NeracaGreyBaruToolStripMenuItem.Click
        form_neraca_grey_baru.Show()
        form_neraca_grey_baru.Focus()
    End Sub

    Private Sub PatchOmsetToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PatchOmsetToolStripMenuItem.Click
        Try
            Using cony As New MySqlConnection(sLocalConn)
                cony.Open()
                Dim sqly = "SELECT sisa_omset FROM tbomset"
                Using cmdy As New MySqlCommand(sqly, cony)
                    Using dry As MySqlDataReader = cmdy.ExecuteReader
                        dry.Read()
                        If dry.HasRows Then
                            MsgBox("Tabel Omset Sudah di PATCH")
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            Using conz As New MySqlConnection(sLocalConn)
                conz.Open()
                Dim sqlz = "ALTER TABLE tbomset ADD COLUMN sisa_omset DECIMAL(65,10) DEFAULT 0;"
                Using cmdz As New MySqlCommand(sqlz, conz)
                    cmdz.ExecuteNonQuery()
                End Using
            End Using
            MsgBox("PATCH Tabel Omset BERHASIL")
        End Try
    End Sub

    Private Sub ExportUploadPenjualanToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExportUploadPenjualanToolStripMenuItem.Click
        form_export_penjualan.Show()
        form_export_penjualan.Focus()
    End Sub

    Private Sub UploadPenjualanToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UploadPenjualanToolStripMenuItem.Click
        form_upload_penjualan_baru.Show()
        form_upload_penjualan_baru.Focus()
    End Sub

    Private Sub otomastis_bs()
        '---FITUR HAPUS BS OTOMATIS
        Try
            dgv1.Columns.Clear()
            Using conx As New MySqlConnection(sLocalConn)
                conx.Open()
                Dim sqlx As String = "SELECT * FROM tbgrey WHERE stok_akhir <= 5 AND stok_akhir <> 0"
                Using cmdx As New MySqlCommand(sqlx, conx)
                    Using dax As New MySqlDataAdapter
                        dax.SelectCommand = cmdx
                        Using dsx As New DataSet
                            dax.Fill(dsx, "tbpenjualan")
                            dgv1.DataSource = dsx.Tables("tbpenjualan")
                        End Using
                    End Using
                End Using
            End Using
            Using cony As New MySqlConnection(sLocalConn)
                cony.Open()
                ' Loop melalui setiap baris di dgv1
                For Each row As DataGridViewRow In dgv1.Rows
                    If Not row.IsNewRow Then
                        ' Ambil data dari DataGridView
                        Dim id_grey As String = row.Cells(0).Value.ToString() ' Index 0: id_grey
                        Dim stok_keluar As Decimal = Convert.ToDecimal(row.Cells(8).Value) ' Index 8: stok_keluar
                        Dim stok_akhir As Decimal = Convert.ToDecimal(row.Cells(9).Value) ' Index 9: stok_akhir
                        Dim updated_stok_keluar As Decimal = stok_keluar + stok_akhir
                        ' Query untuk update data
                        Dim sqly As String = "UPDATE tbgrey SET stok_keluar=@1, stok_akhir=@2, dpp_jual=@4 WHERE id_grey=@3"
                        Using cmdy As New MySqlCommand(sqly, cony)
                            With cmdy
                                .Parameters.Clear()
                                .Parameters.AddWithValue("@1", updated_stok_keluar)
                                .Parameters.AddWithValue("@2", 0) ' Reset stok_akhir menjadi 0
                                .Parameters.AddWithValue("@3", id_grey)
                                .Parameters.AddWithValue("@4", 0)
                                .ExecuteNonQuery()
                            End With
                        End Using
                    End If
                Next
            End Using
            Using cony As New MySqlConnection(sLocalConn)
                cony.Open()
                For Each row As DataGridViewRow In dgv1.Rows
                    If Not row.IsNewRow Then
                        Dim stok_keluar As Decimal = Convert.ToDecimal(row.Cells(9).Value)
                        Dim sqly = "INSERT INTO tbhistorygrey (id_beli,tanggal,no_faktur,supplier,nama_specs,stok_awal,stok_masuk,stok_keluar,stok_akhir,harga," &
                            "Harga_jual,harga_jual_ppn,dpp_jual,nama_jual,kode,kode_grey,kode_neraca,kode_jual) " &
                            "VALUES (@1,@2,@3,@4,@5,@6,@7,@8,@9,@10,@11,@12,@13,@14,@15,@16,@17,@18)"
                        Using cmdy As New MySqlCommand(sqly, cony)
                            With cmdy
                                .Parameters.Clear()
                                .Parameters.AddWithValue("@1", row.Cells(1).Value)
                                .Parameters.AddWithValue("@2", row.Cells(2).Value)
                                .Parameters.AddWithValue("@3", row.Cells(3).Value)
                                .Parameters.AddWithValue("@4", row.Cells(4).Value)
                                .Parameters.AddWithValue("@5", row.Cells(5).Value)
                                .Parameters.AddWithValue("@6", 0)
                                .Parameters.AddWithValue("@7", 0)
                                .Parameters.AddWithValue("@8", stok_keluar)
                                .Parameters.AddWithValue("@9", 0)
                                .Parameters.AddWithValue("@10", row.Cells(10).Value)
                                .Parameters.AddWithValue("@11", row.Cells(11).Value)
                                .Parameters.AddWithValue("@12", row.Cells(12).Value)
                                .Parameters.AddWithValue("@13", row.Cells(13).Value)
                                .Parameters.AddWithValue("@14", row.Cells(14).Value)
                                .Parameters.AddWithValue("@15", row.Cells(15).Value)
                                .Parameters.AddWithValue("@16", row.Cells(16).Value)
                                .Parameters.AddWithValue("@17", row.Cells(17).Value)
                                .Parameters.AddWithValue("@18", "BS")
                                .ExecuteNonQuery()
                            End With
                        End Using
                    End If
                Next
            End Using
            dgv1.Columns.Clear()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
   
    Private Sub PatchToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PatchToolStripMenuItem1.Click
        'patch Revisi 10 Jan 2024 (Generate SJ)
        Try
            If MsgBox("Yakin SJ bulan September 2024 akan dihapus ?", vbYesNo + vbQuestion, "Hapus Data") = vbYes Then
                Using conz As New MySqlConnection(sLocalConn)
                    conz.Open()
                    Dim sqlz = "UPDATE tbpenjualan SET surat_jalan = '', no_faktur = '' WHERE MONTH(tanggal) = 9 AND YEAR(tanggal) = 2024;"
                    Using cmdz As New MySqlCommand(sqlz, conz)
                        cmdz.ExecuteNonQuery()
                    End Using
                End Using
                Call hitung_belum_bukpot()
                MsgBox("SJ bulan September 2024 berhasil di hapus")
            End If
        Catch ex As Exception
            MsgBox("Tidak terdapat data di bulan September 2024")
        End Try
    End Sub

    Private Sub PatchBukpotToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PatchBukpotToolStripMenuItem.Click
        'patch bukpot v.1.2.0
        'Try
        '    Using cony As New MySqlConnection(sLocalConn)
        '        cony.Open()
        '        Dim sqly = "SELECT pph23_actual FROM tbpenjualan"
        '        Using cmdy As New MySqlCommand(sqly, cony)
        '            Using dry As MySqlDataReader = cmdy.ExecuteReader
        '                dry.Read()
        '                If dry.HasRows Then
        '                    MsgBox("Tabel Penjualan untuk Bukpot Sudah di PATCH")
        '                End If
        '            End Using
        '        End Using
        '    End Using
        'Catch ex As Exception
        '    Using conz As New MySqlConnection(sLocalConn)
        '        conz.Open()
        '        Dim sqlz As String = "ALTER TABLE tbpenjualan " &
        '             "ADD COLUMN pph23_actual DECIMAL(65,10) NOT NULL DEFAULT 0, " &
        '             "ADD COLUMN no_bukpot VARCHAR(50) COLLATE latin1_swedish_ci NOT NULL DEFAULT '', " &
        '             "ADD COLUMN tgl_bukpot DATETIME DEFAULT NULL, " &
        '             "ADD COLUMN masa_bukpot DATETIME DEFAULT NULL, " &
        '             "ADD COLUMN gabung_bukpot VARCHAR(50) COLLATE latin1_swedish_ci NOT NULL DEFAULT '';"
        '        Using cmdz As New MySqlCommand(sqlz, conz)
        '            cmdz.ExecuteNonQuery()
        '        End Using
        '    End Using
        '    Call hitung_belum_bukpot()
        '    MsgBox("PATCH Tabel Penjualan untuk Bukpot BERHASIL")
        'End Try

        'patch bukpot v.1.2.0a
        Try
            Using cony As New MySqlConnection(sLocalConn)
                cony.Open()
                Dim sqly As String = "ALTER TABLE tbpenjualan MODIFY COLUMN tgl_bukpot DATE, MODIFY COLUMN masa_bukpot DATE"
                Using cmdy As New MySqlCommand(sqly, cony)
                    cmdy.ExecuteNonQuery()
                End Using
            End Using
            Using cony As New MySqlConnection(sLocalConn)
                cony.Open()
                Dim sqly = "SELECT npwp FROM tbpenjualan"
                Using cmdy As New MySqlCommand(sqly, cony)
                    Using dry As MySqlDataReader = cmdy.ExecuteReader
                        dry.Read()
                        If dry.HasRows Then
                            MsgBox("Tabel Penjualan untuk Bukpot Sudah di PATCH")
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            Using conz As New MySqlConnection(sLocalConn)
                conz.Open()
                Dim sqlz As String = "ALTER TABLE tbpenjualan " &
                    "ADD COLUMN npwp VARCHAR(50) COLLATE latin1_swedish_ci NOT NULL DEFAULT '';"
                Using cmdz As New MySqlCommand(sqlz, conz)
                    cmdz.ExecuteNonQuery()
                End Using
            End Using
            Call hitung_belum_bukpot()
            MsgBox("PATCH Tabel Penjualan untuk Bukpot BERHASIL")
        End Try
    End Sub

    '---fitur Bukti Potong
    Private Sub hitung_belum_bukpot()
        Try
            dgv_bukpot.Columns.Clear()
            Dim currentYear As Integer = dtp_bukpot.Value.Year - 1 ' Ambil tahun dari DateTimePicker, lalu kurangi 1 tahun

            Using conx As New MySqlConnection(sLocalConn)
                conx.Open()
                ' Tambahkan kondisi untuk mengambil data dari tahun sebelumnya
                'Dim sqlx As String = "SELECT id_jual, tanggal, supplier, no_faktur, pph23 " &
                '                     "FROM tbpenjualan " &
                '                     "WHERE no_bukpot = '' " &
                '                     "AND jenis_biaya = 'Jasa' " &
                '                     "AND no_faktur <> '' " &
                '                     "AND YEAR(tanggal) = @prevYear ORDER BY tanggal ASC"
                Dim sqlx As String = "SELECT id_jual, tanggal, supplier, no_faktur, pph23 " &
                                    "FROM tbpenjualan " &
                                    "WHERE no_bukpot = '' " &
                                    "AND jenis_biaya = 'Jasa' " &
                                    "AND no_faktur <> '' " &
                                    "ORDER BY tanggal ASC"
                Using cmdx As New MySqlCommand(sqlx, conx)
                    ' Tambahkan parameter untuk tahun sebelumnya
                    cmdx.Parameters.AddWithValue("@prevYear", currentYear)

                    Using dax As New MySqlDataAdapter
                        dax.SelectCommand = cmdx
                        Using dsx As New DataSet
                            dax.Fill(dsx, "tbpenjualan")
                            dgv_bukpot.DataSource = dsx.Tables("tbpenjualan")
                        End Using
                    End Using
                End Using
            End Using


            'Using conx As New MySqlConnection(sLocalConn)
            '    conx.Open()
            '    Dim sqlx As String = "SELECT id_jual, tanggal, supplier, no_faktur, pph23 FROM tbpenjualan WHERE no_bukpot = '' AND jenis_biaya = 'Jasa' AND no_faktur <> ''"
            '    Using cmdx As New MySqlCommand(sqlx, conx)
            '        Using dax As New MySqlDataAdapter
            '            dax.SelectCommand = cmdx
            '            Using dsx As New DataSet
            '                dax.Fill(dsx, "tbpenjualan")
            '                dgv_bukpot.DataSource = dsx.Tables("tbpenjualan")
            '            End Using
            '        End Using
            '    End Using
            'End Using

            dgv_bukpot.Columns(1).HeaderText = "TANGGAL"
            dgv_bukpot.Columns(2).HeaderText = "CLIENT"
            dgv_bukpot.Columns(3).HeaderText = "NO FAKTUR"
            dgv_bukpot.Columns(4).HeaderText = "PPH 23"
            For Each column As DataGridViewColumn In dgv_bukpot.Columns
                column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            Next
            dgv_bukpot.RowHeadersWidth = 60
            dgv_bukpot.Columns(0).Visible = False
            dgv_bukpot.Columns(1).Width = 100
            dgv_bukpot.Columns(2).Width = 220
            dgv_bukpot.Columns(3).Width = 170
            dgv_bukpot.Columns(4).Width = 120
            dgv_bukpot.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            dgv_bukpot.Columns(4).DefaultCellStyle.Format = "#,##0.00"

            txt_jumlah_bukpot.Text = dgv_bukpot.RowCount
            btn_hitung_bukpot.Visible = False
        Catch ex As Exception
            btn_hitung_bukpot.Visible = False
            MessageBox.Show("Silahkan Patch terlebih dahulu 'Patch Bukpot v.1.2.0'")
        End Try
    End Sub

    Private Sub btn_hitung_bukpot_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_hitung_bukpot.Click
        panel_bukpot.Visible = True
        Call hitung_belum_bukpot()
    End Sub

    Private Sub dgv_bukpot_CellFormatting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles dgv_bukpot.CellFormatting
        dgv_bukpot.Rows(e.RowIndex).HeaderCell.Value = (e.RowIndex + 1).ToString()
    End Sub

    Private Sub btn_refresh_bukpot_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_refresh_bukpot.Click
        Call hitung_belum_bukpot()
    End Sub

    Private Sub BuktiPotongToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BuktiPotongToolStripMenuItem.Click
        form_input_bukpot.Show()
        form_input_bukpot.Focus()
    End Sub

    Private Sub PatchPPNPPHV121ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PatchPPNPPHV121ToolStripMenuItem.Click
        'patch ppn/pph v.1.2.1
        Try
            Using cony As New MySqlConnection(sLocalConn)
                cony.Open()
                Dim sqly = "SELECT pph22 FROM tbppn"
                Using cmdy As New MySqlCommand(sqly, cony)
                    Using dry As MySqlDataReader = cmdy.ExecuteReader
                        dry.Read()
                        If dry.HasRows Then
                            MsgBox("Tabel PPN/PPH sudah di PATCH")
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            Using conz As New MySqlConnection(sLocalConn)
                conz.Open()
                Dim sqlz As String = "ALTER TABLE tbppn " &
                    "ADD COLUMN pph22 VARCHAR(50) COLLATE latin1_swedish_ci NOT NULL DEFAULT '';"
                Using cmdz As New MySqlCommand(sqlz, conz)
                    cmdz.ExecuteNonQuery()
                End Using
            End Using
            Using cony As New MySqlConnection(sLocalConn)
                cony.Open()
                Dim sqly As String = "ALTER TABLE tbppn " &
                                     "MODIFY COLUMN ppn DECIMAL(10,2), " &
                                     "MODIFY COLUMN pph23 DECIMAL(10,2), " &
                                     "MODIFY COLUMN pph22 DECIMAL(10,2)"
                Using cmdy As New MySqlCommand(sqly, cony)
                    cmdy.ExecuteNonQuery()
                End Using
            End Using
            Using cony As New MySqlConnection(sLocalConn)
                cony.Open()
                Dim sqly = "UPDATE tbppn SET pph22=@1 WHERE id='ppn'"
                Using cmdy As New MySqlCommand(sqly, cony)
                    With cmdy
                        .Parameters.Clear()
                        .Parameters.AddWithValue("@1", 1.5)
                        .ExecuteNonQuery()
                    End With
                   
                End Using
            End Using
            MsgBox("PATCH Tabel PPN/PPH BERHASIL")
        End Try
    End Sub

    Private Sub PatchPenyusutanV121ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PatchPenyusutanV121ToolStripMenuItem.Click
        'patch penyusutan v 1.2.5
        Try
            Using con As New MySqlConnection(sLocalConn)
                con.Open()
                ' Cek apakah kolom kategori_aset sudah ada di tbdatapenyusutan
                Dim sqlCheck As String = "SELECT kategori_aset FROM tbdatapenyusutan LIMIT 1"
                Using cmdCheck As New MySqlCommand(sqlCheck, con)
                    Try
                        Using dr As MySqlDataReader = cmdCheck.ExecuteReader()
                            dr.Read()
                            If dr.HasRows Then
                                MsgBox("Data Penyusutan sudah di PATCH")
                            End If
                        End Using
                    Catch ex As Exception
                        ' Jika error berarti kolom belum ada, maka kita tambahkan
                        Dim sqlAlter As String = "ALTER TABLE tbdatapenyusutan " &
                                                 "ADD COLUMN kategori_aset VARCHAR(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL;"
                        Using cmdAlter As New MySqlCommand(sqlAlter, con)
                            cmdAlter.ExecuteNonQuery()
                        End Using
                        ' Update kolom kategori_aset dari tbindukpenyusutan
                        Dim sqlUpdate As String = "UPDATE tbdatapenyusutan dp " &
                                                  "JOIN tbindukpenyusutan ip ON dp.kode = ip.kode " &
                                                  "SET dp.kategori_aset = ip.kategori_aset;"
                        Using cmdUpdate As New MySqlCommand(sqlUpdate, con)
                            cmdUpdate.ExecuteNonQuery()
                            'Dim rowsAffected As Integer = cmdUpdate.ExecuteNonQuery()
                            'MsgBox("PATCH: " & rowsAffected.ToString() & " baris berhasil diperbarui di tbdatapenyusutan.")
                        End Using
                        MsgBox("Data Penyusutan Berhasil di PATCH")
                    End Try
                End Using
            End Using
        Catch ex As Exception
            MsgBox("Terjadi kesalahan: " & ex.Message)
        End Try

        'patch penyusutan v 1.2.3
        'Try
        '    Using conz As New MySqlConnection(sLocalConn)
        '        conz.Open()
        '        Dim sqlz As String = "CREATE TABLE tbindukpenyusutan (" &
        '                                       "kode VARCHAR(100) COLLATE latin1_swedish_ci NOT NULL PRIMARY KEY," &
        '                                       "kategori_aset VARCHAR(100) COLLATE latin1_swedish_ci NOT NULL," &
        '                                       "nama_aset VARCHAR(100) COLLATE latin1_swedish_ci NOT NULL," &
        '                                       "tahun INT," &
        '                                       "nilai_buku DECIMAL(65, 10))"
        '        Using cmdz As New MySqlCommand(sqlz, conz)
        '            cmdz.ExecuteNonQuery()
        '        End Using
        '    End Using
        '    Using conz As New MySqlConnection(sLocalConn)
        '        conz.Open()
        '        Dim sqlz As String = "CREATE TABLE tbdatapenyusutan (" &
        '                                       "id INT NOT NULL PRIMARY KEY AUTO_INCREMENT," &
        '                                       "tahun INT," &
        '                                       "persentase VARCHAR(10) COLLATE latin1_swedish_ci NOT NULL," &
        '                                       "nilai_penyusutan DECIMAL(65, 10)," &
        '                                       "nilai_buku DECIMAL(65, 10)," &
        '                                       "kode VARCHAR(100) COLLATE latin1_swedish_ci NOT NULL)"
        '        Using cmdz As New MySqlCommand(sqlz, conz)
        '            cmdz.ExecuteNonQuery()
        '        End Using
        '    End Using
        '    MessageBox.Show("Patch Tabel Penyusutan Berhasil")
        'Catch ex As Exception
        '    MessageBox.Show("Table Penyusutan Sudah di Patch")
        'End Try
    End Sub

    Private Sub LaporanKeuanganToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LaporanKeuanganToolStripMenuItem.Click
        form_laporan_keuangan.Show()
        form_laporan_keuangan.Focus()
    End Sub

    Private Sub PatchSPTToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PatchSPTToolStripMenuItem.Click
        'patch SPT v.1.2.1
        Try
            Using conx As New MySqlConnection(sLocalConn)
                conx.Open()
                Dim sqlCreateTable As String = "CREATE TABLE tbsptppn (" &
                    "id INT AUTO_INCREMENT PRIMARY KEY, " &
                    "bulan ENUM('JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER') NOT NULL, " & _
                    "tahun YEAR NOT NULL, " &
                    "nilai_masukan DECIMAL(65,10) DEFAULT 0, " &
                    "nilai_keluaran DECIMAL(65,10) DEFAULT 0, " &
                    "ppn_masukan DECIMAL(65,10) DEFAULT 0, " &
                    "ppn_keluaran DECIMAL(65,10) DEFAULT 0, " &
                    "ppn_disetor DECIMAL(65,10) DEFAULT 0, " &
                    "UNIQUE(bulan, tahun)" &
                ");"
                Using cmd As New MySqlCommand(sqlCreateTable, conx)
                    cmd.ExecuteNonQuery()
                    MessageBox.Show("Patch Tabel SPT Berhasil")
                End Using
            End Using
        Catch ex As MySqlException
            MessageBox.Show("Tabel SPT sudah di Patch")
        End Try
    End Sub

    Private Sub SPTMasaPPNEfakturToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SPTMasaPPNEfakturToolStripMenuItem.Click
        form_spt_efaktur.Show()
        form_spt_efaktur.Focus()
    End Sub

    Private Sub PatchBukpotV121aToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PatchBukpotV121aToolStripMenuItem.Click
        'patch Bukpot v.1.2.2a
        Try
            Using cony As New MySqlConnection(sLocalConn)
                cony.Open()
                Dim sqly As String = "UPDATE tbpenjualan p " &
                                     "JOIN tbclient c ON p.supplier = c.nama " &
                                     "SET p.npwp = c.npwp"
                Using cmdy As New MySqlCommand(sqly, cony)
                    cmdy.ExecuteNonQuery()
                    MessageBox.Show("Patch Tabel Bukpot Berhasil")
                End Using
            End Using
        Catch ex As MySqlException
            MessageBox.Show("Tabel SPT sudah di Patch")
        End Try
    End Sub

    Private Sub PenyusutanToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PenyusutanToolStripMenuItem.Click
        form_biaya_penyusutan.Show()
        form_biaya_penyusutan.Focus()
    End Sub

    Private Sub EksporExcelCoretaxToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EksporExcelCoretaxToolStripMenuItem.Click
        form_export_excel_coretax.Show()
        form_export_excel_coretax.Focus()
    End Sub

    Private Sub PatchBiayaTahunanV125ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PatchBiayaTahunanV125ToolStripMenuItem.Click
        Try
            'patch Biaya v.1.2.5
            Using conx As New MySqlConnection(sLocalConn)
                conx.Open()
                Dim sqlCreateTable As String = "CREATE TABLE tbbiayatahunan (" &
                    "id INT AUTO_INCREMENT PRIMARY KEY, " &
                    "tahun YEAR NOT NULL, " &
                    "upah_harian DECIMAL(65,10) DEFAULT 0, " &
                    "gaji_pegawai DECIMAL(65,10) DEFAULT 0, " &
                    "sewa_pabrik DECIMAL(65,10) DEFAULT 0, " &
                    "sewa_kantor DECIMAL(65,10) DEFAULT 0, " &
                    "pbb DECIMAL(65,10) DEFAULT 0, " &
                    "UNIQUE(tahun)" &
                ");"
                Using cmd As New MySqlCommand(sqlCreateTable, conx)
                    cmd.ExecuteNonQuery()
                    For tahun As Integer = 2010 To 2040
                        Dim sqlInsert As String = "INSERT IGNORE INTO tbbiayatahunan (tahun, upah_harian, gaji_pegawai, sewa_pabrik, sewa_kantor, pbb) " &
                                                  "VALUES (@tahun, 0.00, 0.00, 0.00, 0.00, 0.00);"

                        Using cmdInsert As New MySqlCommand(sqlInsert, conx)
                            cmdInsert.Parameters.AddWithValue("@tahun", tahun)
                            cmdInsert.ExecuteNonQuery()
                        End Using
                    Next
                    MessageBox.Show("Patch Biaya Tahunan Berhasil")
                End Using
            End Using
        Catch ex As MySqlException
            MessageBox.Show("Biaya Tahunan Sudah di Patch")
        End Try
    End Sub

    Private Sub BiayaTahunanToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BiayaTahunanToolStripMenuItem.Click
        Form_biaya_tahunan.Show()
        Form_biaya_tahunan.Focus()
    End Sub

    Private Sub PatchHPPV126ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PatchHPPV126ToolStripMenuItem.Click
        Try
            'patch hpp v.1.2.6
            Using conx As New MySqlConnection(sLocalConn)
                conx.Open()
                Dim sqlCreateTable As String = "CREATE TABLE tblaphpp (" &
                    "id INT AUTO_INCREMENT PRIMARY KEY, " &
                    "tahun YEAR NOT NULL, " &
                    "awal_tahun_obat DECIMAL(65,10) DEFAULT 0, " &
                    "akhir_tahun_obat DECIMAL(65,10) DEFAULT 0, " &
                    "awal_kain_proses DECIMAL(65,10) DEFAULT 0, " &
                    "akhir_kain_proses DECIMAL(65,10) DEFAULT 0, " &
                    "awal_kain_warna DECIMAL(65,10) DEFAULT 0, " &
                    "akhir_kain_warna DECIMAL(65,10) DEFAULT 0, " &
                    "UNIQUE(tahun)" &
                ");"
                Using cmd As New MySqlCommand(sqlCreateTable, conx)
                    cmd.ExecuteNonQuery()
                    For tahun As Integer = 2010 To 2040
                        Dim sqlInsert As String = "INSERT IGNORE INTO tblaphpp (tahun, awal_tahun_obat, akhir_tahun_obat, awal_kain_proses, akhir_kain_proses, awal_kain_warna, akhir_kain_warna) " &
                                                  "VALUES (@tahun, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00);"

                        Using cmdInsert As New MySqlCommand(sqlInsert, conx)
                            cmdInsert.Parameters.AddWithValue("@tahun", tahun)
                            cmdInsert.ExecuteNonQuery()
                        End Using
                    Next
                    MessageBox.Show("Patch Laporan HPP Berhasil")
                End Using
            End Using
        Catch ex As MySqlException
            MessageBox.Show("Laporan HPP Sudah di Patch")
        End Try
    End Sub

    Private Sub SaldoLaporanHPPToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaldoLaporanHPPToolStripMenuItem.Click
        form_saldo_laporan_hpp.Show()
        form_saldo_laporan_hpp.Focus()
    End Sub

    Private Sub PatchAngsuranPPh25V126ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PatchAngsuranPPh25V126ToolStripMenuItem.Click
        Try
            'patch angsuran pph 25 v.1.2.6
            Using conx As New MySqlConnection(sLocalConn)
                conx.Open()
                Dim sqlCreateTable As String = "CREATE TABLE tbangsuranpph25 (" &
                    "id INT AUTO_INCREMENT PRIMARY KEY, " &
                    "tahun YEAR NOT NULL, " &
                    "januari DECIMAL(65,10) DEFAULT 0, " &
                    "februari DECIMAL(65,10) DEFAULT 0, " &
                    "maret DECIMAL(65,10) DEFAULT 0, " &
                    "april DECIMAL(65,10) DEFAULT 0, " &
                    "mei DECIMAL(65,10) DEFAULT 0, " &
                    "juni DECIMAL(65,10) DEFAULT 0, " &
                    "juli DECIMAL(65,10) DEFAULT 0, " &
                    "agustus DECIMAL(65,10) DEFAULT 0, " &
                    "september DECIMAL(65,10) DEFAULT 0, " &
                    "oktober DECIMAL(65,10) DEFAULT 0, " &
                    "november DECIMAL(65,10) DEFAULT 0, " &
                    "desember DECIMAL(65,10) DEFAULT 0, " &
                    "total DECIMAL(65,10) DEFAULT 0, " &
                    "UNIQUE(tahun)" &
                ");"
                Using cmd As New MySqlCommand(sqlCreateTable, conx)
                    cmd.ExecuteNonQuery()
                    For tahun As Integer = 2010 To 2040
                        Dim sqlInsert As String = "INSERT IGNORE INTO tbangsuranpph25 (tahun, januari, februari, maret, april, mei, juni, juli, agustus, september, oktober, november, desember, total) " &
                                                  "VALUES (@tahun, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00);"

                        Using cmdInsert As New MySqlCommand(sqlInsert, conx)
                            cmdInsert.Parameters.AddWithValue("@tahun", tahun)
                            cmdInsert.ExecuteNonQuery()
                        End Using
                    Next
                    MessageBox.Show("Patch Angsuran PPh 25 Berhasil")
                End Using
            End Using
        Catch ex As MySqlException
            MessageBox.Show("Angsuran PPh 25 Sudah di Patch")
        End Try
    End Sub

    Private Sub AngsuranPPh25ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AngsuranPPh25ToolStripMenuItem.Click
        form_angsuran_pph25.Show()
        form_angsuran_pph25.Focus()
    End Sub

End Class
