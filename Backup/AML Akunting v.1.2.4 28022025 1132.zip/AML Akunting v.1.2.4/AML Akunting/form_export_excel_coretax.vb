﻿Imports MySql.Data.MySqlClient
Imports System.Globalization

Public Class form_export_excel_coretax

    Dim bulan, tahun As Integer

    Private Sub txt_tanggal_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_tanggal.TextChanged
        btn_generate.Text = "GENERATE"
        dgv1.Columns.Clear()
    End Sub

    Private Sub dtp_tanggal_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtp_tanggal.ValueChanged
        Dim selectedDate As DateTime = dtp_tanggal.Value
        Dim cultureInfo As New CultureInfo("id-ID")
        Dim formattedDate As String = selectedDate.ToString("MMMM yyyy", cultureInfo)
        txt_tanggal.Text = formattedDate
        bulan = Month(dtp_tanggal.Value)
        tahun = Year(dtp_tanggal.Value)
        txtbulan.Text = bulan
        txttahun.Text = tahun
    End Sub

    Private Sub btn_kosong_tanggal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_kosong_tanggal.Click
        If Not txt_tanggal.Text = "" Then
            txt_tanggal.Text = ""
            txtbulan.Text = ""
            txttahun.Text = ""
        End If
    End Sub

    Private Sub setup_dgv1()
        dgv1.ColumnCount = 17
        dgv1.Columns(0).Name = "Baris"
        dgv1.Columns(1).Name = "Tanggal Faktur"
        dgv1.Columns(2).Name = "Jenis Faktur"
        dgv1.Columns(3).Name = "Kode Transaksi"
        dgv1.Columns(4).Name = "Keterangan Tambahan"
        dgv1.Columns(5).Name = "Dokumen Pendukung"
        dgv1.Columns(6).Name = "Referensi"
        dgv1.Columns(7).Name = "Cap Fasilitas"
        dgv1.Columns(8).Name = "ID TKU Penjual"
        dgv1.Columns(9).Name = "NPWP/NIK Pembeli"
        dgv1.Columns(10).Name = "Jenis ID Pembeli"
        dgv1.Columns(11).Name = "Negara Pembeli"
        dgv1.Columns(12).Name = "Nomor Dokumen Pembeli"
        dgv1.Columns(13).Name = "Nama Pembeli"
        dgv1.Columns(14).Name = "Alamat Pembeli"
        dgv1.Columns(15).Name = "Email Pembeli"
        dgv1.Columns(16).Name = "ID TKU Pembeli"
    End Sub

    Private Sub form_export_excel_coretax_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


    End Sub
End Class