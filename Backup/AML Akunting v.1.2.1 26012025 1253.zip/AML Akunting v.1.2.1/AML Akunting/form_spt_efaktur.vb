﻿Imports MySql.Data.MySqlClient


Public Class form_spt_efaktur
    Dim ppn As Double
    Private Sub isi_ppn()
        Try
            Using conx As New MySqlConnection(sLocalConn)
                conx.Open()
                Dim sqlx = "SELECT ppn from tbppn WHERE id ='ppn'"
                Using cmdx As New MySqlCommand(sqlx, conx)
                    Using drx As MySqlDataReader = cmdx.ExecuteReader
                        drx.Read()
                        ppn = drx(0)
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
    End Sub
    Private Sub form_spt_efaktur_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call tampil_spt()
        Call isi_ppn()
    End Sub
    Private Sub tampil_spt()
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Dim selectedYear As Integer = dtp_tahun.Value.Year
            Dim sqlx As String = "SELECT id,bulan, tahun, nilai_masukan, nilai_keluaran, ppn_masukan, ppn_keluaran, ppn_disetor " &
                                 "FROM tbsptppn " &
                                 "WHERE tahun = @selectedYear " &
                                 "ORDER BY FIELD(bulan, 'January', 'February', 'March', 'April', 'May', 'June', " &
                                 "'July', 'August', 'September', 'October', 'November', 'December')"
            Using cmdx As New MySqlCommand(sqlx, conx)
                cmdx.Parameters.AddWithValue("@selectedYear", selectedYear)
                Using dax As New MySqlDataAdapter
                    dax.SelectCommand = cmdx
                    Using dsx As New DataSet
                        dax.Fill(dsx, "spt_ppn")
                        dgv1.DataSource = dsx.Tables("spt_ppn")
                    End Using
                End Using
            End Using
        End Using
    End Sub

    Private Sub txt_nilai_keluaran_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_nilai_keluaran.LostFocus
        Dim input As String = txt_nilai_keluaran.Text
        Dim number As Decimal
        If Not txt_nilai_keluaran.Text = "" Then
            If Decimal.TryParse(input, number) Then
                Call hitung_ppn_keluaran()
            Else
                MessageBox.Show("Input harus berupa angka dengan format yang benar", "Kesalahan", MessageBoxButtons.OK, MessageBoxIcon.Error)
                txt_nilai_keluaran.Focus()
            End If
        End If
    End Sub
    Private Sub txt_nilai_masukan_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_nilai_masukan.LostFocus
        Dim input As String = txt_nilai_masukan.Text
        Dim number As Decimal
        If Not txt_nilai_masukan.Text = "" Then
            If Decimal.TryParse(input, number) Then
                Call hitung_ppn_masukan()
            Else
                MessageBox.Show("Input harus berupa angka dengan format yang benar", "Kesalahan", MessageBoxButtons.OK, MessageBoxIcon.Error)
                txt_nilai_masukan.Focus()
            End If
        End If
    End Sub
    Private Sub hitung_ppn_keluaran()
        Dim keluaran, ppnkeluar, ppnmasuk, ppndisetor As Decimal
        Decimal.TryParse(txt_nilai_keluaran.Text, keluaran)
        Decimal.TryParse(txt_ppn_masukan.Text, ppnmasuk)
        ppnkeluar = keluaran * (ppn / 100)
        ppndisetor = ppnkeluar - ppnmasuk
        txt_nilai_keluaran.Text = keluaran.ToString("#,##0.00########")
        txt_ppn_keluaran.Text = ppnkeluar.ToString("#,##0.00########")
        txt_ppn_disetor.Text = ppndisetor.ToString("#,##0.00########")
    End Sub
    Private Sub hitung_ppn_masukan()
        Dim masukan, ppnkeluar, ppnmasuk, ppndisetor As Decimal
        Decimal.TryParse(txt_nilai_masukan.Text, masukan)
        Decimal.TryParse(txt_ppn_keluaran.Text, ppnkeluar)
        ppnmasuk = masukan * (ppn / 100)
        ppndisetor = ppnkeluar - ppnmasuk
        txt_nilai_masukan.Text = masukan.ToString("#,##0.00########")
        txt_ppn_masukan.Text = ppnmasuk.ToString("#,##0.00########")
        txt_ppn_disetor.Text = ppndisetor.ToString("#,##0.00########")
    End Sub

    Private Sub btn_refresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_refresh.Click
        cbo_bulan.Text = "-- Pilih Bulan --"
        cbo_bulan.Enabled = True
        txt_nilai_keluaran.Text = ""
        txt_nilai_masukan.Text = ""
        txt_ppn_disetor.Text = ""
        txt_ppn_keluaran.Text = ""
        txt_ppn_masukan.Text = ""
        txt_id.Text = ""
        Call tampil_spt()
        btn_simpan.Text = "SIMPAN"
        btn_hapus.Enabled = False
    End Sub

    Private Sub cbo_bulan_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbo_bulan.SelectedIndexChanged
        If cbo_bulan.Text <> "-- Pilih Bulan -- " Then
            Using cony As New MySqlConnection(sLocalConn)
                cony.Open()
                Dim selectedYear As Integer = dtp_tahun.Value.Year
                Dim selectedMonth As String = cbo_bulan.Text
                Dim sqly As String = "SELECT id, bulan, tahun, nilai_masukan, nilai_keluaran, ppn_masukan, ppn_keluaran, ppn_disetor " &
                                 "FROM tbsptppn " &
                                 "WHERE tahun = @selectedYear AND bulan = @selectedMonth "
                Using cmdy As New MySqlCommand(sqly, cony)
                    cmdy.Parameters.AddWithValue("@selectedYear", selectedYear)
                    cmdy.Parameters.AddWithValue("@selectedMonth", selectedMonth)
                    Using dry As MySqlDataReader = cmdy.ExecuteReader
                        dry.Read()
                        If dry.HasRows Then
                            txt_id.Text = dry(0).ToString
                            txt_nilai_masukan.Text = Convert.ToDecimal(dry(3)).ToString("#,##0.00########")
                            txt_nilai_keluaran.Text = Convert.ToDecimal(dry(4)).ToString("#,##0.00########")
                            txt_ppn_masukan.Text = Convert.ToDecimal(dry(5)).ToString("#,##0.00########")
                            txt_ppn_keluaran.Text = Convert.ToDecimal(dry(6)).ToString("#,##0.00########")
                            txt_ppn_disetor.Text = Convert.ToDecimal(dry(7)).ToString("#,##0.00########")
                            btn_simpan.Text = "UPDATE"
                            btn_hapus.Enabled = True
                        Else
                            txt_nilai_keluaran.Text = ""
                            txt_nilai_masukan.Text = ""
                            txt_ppn_disetor.Text = ""
                            txt_ppn_keluaran.Text = ""
                            txt_ppn_masukan.Text = ""
                            txt_id.Text = ""
                            btn_simpan.Text = "SIMPAN"
                            btn_hapus.Enabled = False
                        End If
                    End Using
                End Using
            End Using
        End If
    End Sub

    Private Sub btn_simpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_simpan.Click
        Try
            If cbo_bulan.Text = "-- Pilih Bulan --" Then
                MsgBox("Silahkan Pilih Dahulu Bulan")
            Else
                If btn_simpan.Text = "SIMPAN" Then
                    If txt_nilai_masukan.Text = "" Then
                        MsgBox("Silakan input nilai masukan terlebih dulu")
                        txt_nilai_masukan.Focus()
                    ElseIf txt_nilai_keluaran.Text = "" Then
                        MsgBox("Silakan input nilai keluaran terlebih dulu")
                        txt_nilai_keluaran.Focus()
                    Else
                        Using cony As New MySqlConnection(sLocalConn)
                            cony.Open()
                            Dim selectedYear As Integer = dtp_tahun.Value.Year
                            Dim selectedMonth As String = cbo_bulan.Text
                            Dim sqly = "INSERT INTO tbsptppn (bulan, tahun, nilai_masukan, nilai_keluaran, ppn_masukan, ppn_keluaran, ppn_disetor) VALUES (@1,@2,@3,@4,@5,@6,@7)"
                            Using cmdy As New MySqlCommand(sqly, cony)
                                With cmdy
                                    .Parameters.Clear()
                                    .Parameters.AddWithValue("@1", selectedMonth)
                                    .Parameters.AddWithValue("@2", selectedYear)
                                    .Parameters.AddWithValue("@3", txt_nilai_masukan.Text.Replace(".", "").Replace(",", "."))
                                    .Parameters.AddWithValue("@4", txt_nilai_keluaran.Text.Replace(".", "").Replace(",", "."))
                                    .Parameters.AddWithValue("@5", txt_ppn_masukan.Text.Replace(".", "").Replace(",", "."))
                                    .Parameters.AddWithValue("@6", txt_ppn_keluaran.Text.Replace(".", "").Replace(",", "."))
                                    .Parameters.AddWithValue("@7", txt_ppn_disetor.Text.Replace(".", "").Replace(",", "."))
                                    .ExecuteNonQuery()
                                End With
                            End Using
                        End Using
                        MsgBox("Data SPT berhasil Di Simpan")
                        btn_refresh.PerformClick()
                    End If
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub dtp_tahun_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtp_tahun.ValueChanged
        btn_refresh.PerformClick()
    End Sub
End Class