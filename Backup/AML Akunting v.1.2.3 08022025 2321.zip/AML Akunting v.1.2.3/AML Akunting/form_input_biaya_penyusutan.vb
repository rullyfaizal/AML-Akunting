﻿Public Class form_input_biaya_penyusutan

    Private Sub form_biaya_penyusutan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call buat_kode()

    End Sub
    Private Sub buat_kode()
        Dim dtptoday As New DateTimePicker
        txt_kode.Text = dtptoday.Value.ToString("dd-MM-yyyyHH:mm:ss")
        txt_kode.Text = txt_kode.Text.Replace("-", "").Replace(":", "")
    End Sub

    Private Sub txt_nilai_buku_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txt_nilai_buku.KeyPress
        If Not Char.IsDigit(e.KeyChar) AndAlso e.KeyChar <> ","c AndAlso e.KeyChar <> ControlChars.Back Then
            e.Handled = True
            Exit Sub
        End If
    End Sub
    Private Sub txt_nilai_buku_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_nilai_buku.LostFocus
        Dim input As String = txt_nilai_buku.Text
        Dim number As Decimal
        If Decimal.TryParse(input, number) Then
            txt_nilai_buku.Text = number.ToString("#,##0")
        Else
            MessageBox.Show("Input harus berupa angka dengan format yang benar", "Kesalahan", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txt_nilai_buku.Focus()
        End If
    End Sub

    Private Sub btn_simpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_simpan.Click
        If btn_simpan.Text = "GENERATE" Then
            If cbo_aset.Text = "-- Pilih Aset --" Then
                MsgBox("Pilih terlebih dahulu kategori Asetnya")
                cbo_aset.Focus()
            ElseIf txt_nama_aset.Text = "" Then
                MsgBox("Nama Aset belum diinput")
                txt_nama_aset.Focus()
            ElseIf txt_nilai_buku.Text = "" Then
                MsgBox("Nilai Buku belum diinput")
                txt_nilai_buku.Focus()
            Else
                Call buat_kolom_dgv1()
                If cbo_aset.Text = "MESIN" Then
                    Call hitung_penyusutan_mesin()
                End If

                btn_simpan.Text = "SIMPAN"

            End If
        Else

            btn_simpan.Text = "GENERATE"

        End If
    End Sub
    Private Sub buat_kolom_dgv1()
        ' Hapus kolom yang ada (jika ada)
        dgv1.Columns.Clear()

        ' Tambahkan kolom ke dgv1
        dgv1.Columns.Add("Tahun", "Tahun")
        dgv1.Columns.Add("PersentasePenyusutan", "%")
        dgv1.Columns.Add("NilaiPenyusutan", "Nilai Penyusutan")
        dgv1.Columns.Add("NilaiBuku", "Nilai Buku")

        ' Atur format angka ke dua desimal tanpa pemisah ribuan
        dgv1.Columns("NilaiPenyusutan").DefaultCellStyle.Format = "#,##0"
        dgv1.Columns("NilaiBuku").DefaultCellStyle.Format = "#,##0"
    End Sub
    Private Sub hitung_penyusutan_mesin()
        ' Bersihkan dgv1 sebelum memasukkan data baru
        dgv1.Rows.Clear()
        ' Pastikan txt_nilai_buku memiliki angka yang valid
        Dim nilaiBukuAwal As Decimal
        If Not Decimal.TryParse(txt_nilai_buku.Text, nilaiBukuAwal) Then
            MessageBox.Show("Masukkan nilai buku yang valid!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If
        ' Tahun awal penyusutan (diambil dari tahun sekarang atau bisa dari input)
        Dim tahunAwal As Integer = dtp_tahun.Text
        Dim tarifPenyusutan As Decimal = 0.125 ' 12.5%
        Dim nilaiBuku As Decimal = nilaiBukuAwal
        ' Iterasi penyusutan maksimal 16 kali
        Dim tahun As Integer = tahunAwal
        For i As Integer = 1 To 16
            Dim nilaiPenyusutan As Decimal
            ' Jika sudah di baris ke-16, nilai penyusutan harus sama dengan nilai buku agar nilai buku menjadi 0
            If i = 16 Then
                nilaiPenyusutan = nilaiBuku
            Else
                nilaiPenyusutan = nilaiBuku * tarifPenyusutan ' Dibulatkan ke satuan terdekat
            End If
            ' Kurangi nilai buku
            nilaiBuku -= nilaiPenyusutan
            ' Tambahkan hasil ke dalam DataGridView (dgv1)
            dgv1.Rows.Add(tahun, (tarifPenyusutan * 100).ToString("0.##") & "%", nilaiPenyusutan, nilaiBuku)
            ' Hentikan jika nilai buku sudah 0
            If nilaiBuku = 0 Then Exit For
            ' Naikkan tahun
            tahun += 1
        Next
    End Sub
    Private Sub btn_refresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_refresh.Click
        dgv1.Columns.Clear()
        cbo_aset.Text = "-- Pilih Aset --"
        txt_nama_aset.Text = ""
        txt_nilai_buku.Text = ""
        btn_simpan.Text = "GENERATE"
        Call buat_kode()
        txt_id.Text = ""
    End Sub
End Class