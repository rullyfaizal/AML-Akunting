﻿Imports MySql.Data.MySqlClient

Public Class form_sj_bulanan

    'Fungsi potong nama client
    Private Function AmbilDuaKata(ByVal txt As TextBox) As String
        Dim kata() As String = txt.Text.Trim().Split(" "c)
        If kata.Length >= 2 Then
            Return kata(0) & " " & kata(1)
        ElseIf kata.Length = 1 Then
            Return kata(0)
        Else
            Return ""
        End If
    End Function
    'Fungsi potong alamat client
    Private Function AmbilDelapanKata(ByVal txt As TextBox) As String
        Dim kata() As String = txt.Text.Trim().Split(" "c)
        Dim hasil As String = ""
        Dim jumlahKata As Integer = Math.Min(8, kata.Length)
        For i As Integer = 0 To jumlahKata - 1
            hasil &= kata(i) & " "
        Next
        Return hasil.Trim()
    End Function
    ' Fungsi untuk mendapatkan nilai Decimal dari sel DGV
    Private Function GetDecimalValue(ByVal cellValue As Object, Optional ByVal defaultValue As Decimal = 0) As Decimal
        Dim result As Decimal
        If cellValue IsNot Nothing AndAlso Not IsDBNull(cellValue) AndAlso Decimal.TryParse(cellValue.ToString(), result) Then
            Return result
        End If
        Return defaultValue
    End Function
    ' Fungsi untuk mendapatkan nilai String dari sel DGV
    Private Function GetStringValue(ByVal cellValue As Object, Optional ByVal defaultValue As String = "") As String
        If cellValue IsNot Nothing AndAlso Not IsDBNull(cellValue) Then
            Return cellValue.ToString().Trim()
        End If
        Return defaultValue
    End Function

    Private Sub btn_batal_print_sj_bulanan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_batal_print_sj_bulanan.Click
        Me.Close()
    End Sub

    Private Sub btn_print_sj_bulanan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_print_sj_bulanan.Click
        If dgv_list_sj.Rows.Count = 0 Then
            MsgBox("Tidak ada Surat Jalan dalam bulan yang dipilih.")
            Exit Sub
        End If

        ' DataTable untuk menyimpan semua Surat Jalan
        Dim tbsuratjalan As New DataTable
        With tbsuratjalan
            .Columns.Add("client")
            .Columns.Add("alamat_client")
            .Columns.Add("kota_client")
            .Columns.Add("no_surat_jalan")
            .Columns.Add("tanggal")
            .Columns.Add("ket_bawah")
        End With

        ' DataTable untuk menyimpan semua barang dari semua Surat Jalan
        Dim tbdata As New DataTable
        With tbdata
            .Columns.Add("no")
            .Columns.Add("no_surat_jalan") ' Tambahkan No Surat Jalan agar bisa dipisahkan di laporan
            .Columns.Add("nama_barang")
            .Columns.Add("kuantitas")
            .Columns.Add("satuan")
            .Columns.Add("keterangan")
        End With

        ' Loop semua Surat Jalan
        For Each row As DataGridViewRow In dgv_list_sj.Rows
            If Not row.IsNewRow Then
                txt_no_sj_print_bulanan.Text = row.Cells(0).Value.ToString()
                txt_client_bulanan.Text = row.Cells(1).Value.ToString()

                ' Ambil data client
                Using conx As New MySqlConnection(sLocalConn)
                    conx.Open()
                    Dim sqlx As String = "SELECT alamat, kota FROM tbclient WHERE nama = @nama"
                    Using cmdx As New MySqlCommand(sqlx, conx)
                        cmdx.Parameters.AddWithValue("@nama", txt_client_bulanan.Text)
                        Using reader As MySqlDataReader = cmdx.ExecuteReader()
                            If reader.Read() Then
                                txt_alamat_client_bulanan.Text = reader("alamat").ToString()
                                txt_kota_client_bulanan.Text = reader("kota").ToString()
                            End If
                        End Using
                    End Using
                End Using

                ' Tambahkan data Surat Jalan ke DataTable
                tbsuratjalan.Rows.Add(txt_client_bulanan.Text, AmbilDelapanKata(txt_alamat_client_bulanan), txt_kota_client_bulanan.Text, txt_no_sj_print_bulanan.Text,
                                      txt_tanggal_print_sj_bulanan.Text, "")

                ' Ambil data barang dalam Surat Jalan
                Using conx As New MySqlConnection(sLocalConn)
                    conx.Open()
                    Dim sqlx As String
                    If dgv_list_sj.CurrentRow.Cells(3).Value = "Celup" Then
                        sqlx = "SELECT nama_kain, jumlah, satuan FROM tbpenjualan WHERE surat_jalan = @surat_jalan AND jenis_biaya = 'Obat'"
                    Else
                        sqlx = "SELECT nama_kain, jumlah, satuan FROM tbpenjualan WHERE surat_jalan = @surat_jalan AND jenis_biaya = 'Kain'"
                    End If
                    Using cmdx As New MySqlCommand(sqlx, conx)
                        cmdx.Parameters.AddWithValue("@surat_jalan", txt_no_sj_print_bulanan.Text)
                        Using reader As MySqlDataReader = cmdx.ExecuteReader()
                            Dim noUrut As Integer = 1
                            While reader.Read()
                                tbdata.Rows.Add(noUrut, txt_no_sj_print_bulanan.Text,
                                                "Kain " & reader("nama_kain").ToString(),
                                                Format(reader("jumlah"), "#,##0.00"),
                                                reader("satuan").ToString(), "")
                                noUrut += 1
                            End While
                        End Using
                    End Using
                End Using
            End If
        Next

        'Set DataSource hanya sekali untuk semua Surat Jalan
        form_print_surat_jalan.ReportViewer1.LocalReport.DataSources.Clear()
        form_print_surat_jalan.ReportViewer1.LocalReport.DataSources.Add(New Microsoft.Reporting.WinForms.ReportDataSource("DataSet1", tbsuratjalan))
        form_print_surat_jalan.ReportViewer1.LocalReport.DataSources.Add(New Microsoft.Reporting.WinForms.ReportDataSource("DataSet2", tbdata))

        ' Tampilkan form cetak hanya sekali
        form_print_surat_jalan.ReportViewer1.RefreshReport()
        form_print_surat_jalan.ShowDialog()
        form_print_surat_jalan.Dispose()
    End Sub

    Private Sub dtp_tanggal_print_sj_bulanan_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtp_tanggal_print_sj_bulanan.ValueChanged
        dgv_list_sj.Columns.Clear()
        Dim namaBulan As String = dtp_tanggal_print_sj_bulanan.Value.ToString("MMMM", New Globalization.CultureInfo("id-ID")).ToUpper()
        Dim namaTahun As String = dtp_tanggal_print_sj_bulanan.Value.ToString("yyyy")
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Dim sqlx As String = "SELECT DISTINCT surat_jalan, supplier, tanggal, status FROM tbpenjualan " &
                                 "WHERE MONTH(tanggal) = @bulan AND YEAR(tanggal) = @tahun " &
                                 "ORDER BY surat_jalan ASC"
            Using cmdx As New MySqlCommand(sqlx, conx)
                cmdx.Parameters.AddWithValue("@bulan", dtp_tanggal_print_sj_bulanan.Value.Month)
                cmdx.Parameters.AddWithValue("@tahun", dtp_tanggal_print_sj_bulanan.Value.Year)
                Using dax As New MySqlDataAdapter
                    dax.SelectCommand = cmdx
                    Using dsx As New DataSet
                        dax.Fill(dsx, "surat_jalan")
                        dgv_list_sj.DataSource = dsx.Tables("surat_jalan")
                        dgv_list_sj.Columns(0).Width = 170
                        dgv_list_sj.RowHeadersWidth = 60
                        dgv_list_sj.Columns(0).HeaderText = "SURAT JALAN"
                        dgv_list_sj.Columns(1).Width = 250
                        dgv_list_sj.Columns(1).HeaderText = "CLIENT"
                        lbl_print_sj_bulanan.Text = "PRINT SURAT JALAN BULAN " & namaBulan & " " & namaTahun
                        panelPrintSuratJalanBulanan.Visible = True
                    End Using
                End Using
            End Using
        End Using
    End Sub

    Private Sub dgv_list_sj_CellFormatting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles dgv_list_sj.CellFormatting
        dgv_list_sj.Rows(e.RowIndex).HeaderCell.Value = (e.RowIndex + 1).ToString()
    End Sub

    Private Sub btn_ekspor_sj_bulanan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_ekspor_sj_bulanan.Click
        Try
            If dgv_list_sj.RowCount = 0 Then
                MsgBox("Tidak Terdapat data untuk Print Surat Jalan")
            Else

                'dtp_tanggal_print_sj.Value = dgv1.CurrentRow.Cells(2).Value

                'txt_client.Text = dgv1.CurrentRow.Cells(1).Value
                'txt_no_sj.Text = dgv1.CurrentRow.Cells(3).Value
                'Call cariclient()
                'Call carisj()
                'Call atur_print_sj()
                'panelPrintSuratJalan.Visible = True
            End If
        Catch ex As Exception
            MsgBox("Silahkan Pilih Terlebih dahulu Data PENJUALAN yang akan Print Surat Jalan")
        End Try
    End Sub
End Class