﻿Imports MySql.Data.MySqlClient


Public Class _00form_coba_print

    Private Sub _00form_coba_print_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
       
    End Sub

    Private Sub btn_batal_print_sj_bulanan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_batal_print_sj_bulanan.Click
        dgv_list_sj.Columns.Clear()
        Dim namaBulan As String = dtp_awal.Value.ToString("MMMM", New Globalization.CultureInfo("id-ID")).ToUpper()
        Dim namaTahun As String = dtp_awal.Value.ToString("yyyy")
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Dim sqlx As String = "SELECT DISTINCT surat_jalan, supplier, status FROM tbpenjualan " &
                                 "WHERE MONTH(tanggal) = @bulan AND YEAR(tanggal) = @tahun " &
                                 "ORDER BY surat_jalan ASC"
            Using cmdx As New MySqlCommand(sqlx, conx)
                cmdx.Parameters.AddWithValue("@bulan", dtp_awal.Value.Month)
                cmdx.Parameters.AddWithValue("@tahun", dtp_awal.Value.Year)
                Using dax As New MySqlDataAdapter
                    dax.SelectCommand = cmdx
                    Using dsx As New DataSet
                        dax.Fill(dsx, "surat_jalan")
                        ' Cek apakah ada data
                        If dsx.Tables("surat_jalan").Rows.Count = 0 Then
                            MessageBox.Show("Data tidak ditemukan untuk bulan dan tahun yang dipilih.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        Else
                            dgv_list_sj.DataSource = dsx.Tables("surat_jalan")
                            dgv_list_sj.Columns(0).Width = 170
                            dgv_list_sj.RowHeadersWidth = 60
                            dgv_list_sj.Columns(0).HeaderText = "SURAT JALAN"
                            dgv_list_sj.Columns(1).Width = 250
                            dgv_list_sj.Columns(1).HeaderText = "CLIENT"
                            lbl_print_sj_bulanan.Text = "PRINT SURAT JALAN BULAN " & namaBulan & " " & namaTahun
                            panelPrintSuratJalanBulanan.Visible = True
                        End If
                    End Using
                End Using
            End Using
        End Using
    End Sub

    Private Sub btn_print_sj_bulanan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_print_sj_bulanan.Click
        'Dim tbsuratjalan As New DataTable
        '    With tbsuratjalan
        '    .Columns.Add("DataColumn1")
        '    .Columns.Add("DataColumn2")
        'End With
        'tbsuratjalan.Rows.Add(dgv_list_sj.Rows(1).Cells(0).Value, dgv_list_sj.Rows(1).Cells(1).Value)

        '_00formprint.ReportViewer1.LocalReport.DataSources.Item(0).Value = tbsuratjalan
        '_00formprint.ShowDialog()
        '_00formprint.Dispose()

        Dim ds As New DataSet()
        Dim tbsuratjalan As New DataTable("SuratJalan")

        With tbsuratjalan
            .Columns.Add("ID", GetType(Integer)) ' Kolom ID untuk pemisahan halaman
            .Columns.Add("DataColumn1")
            .Columns.Add("DataColumn2")
        End With

        Dim rowIndex As Integer = 1
        For Each row As DataGridViewRow In dgv_list_sj.Rows
            If Not row.IsNewRow Then
                tbsuratjalan.Rows.Add(rowIndex, row.Cells(0).Value, row.Cells(1).Value)
                rowIndex += 1
            End If
        Next

        ds.Tables.Add(tbsuratjalan)

        ' Set data source untuk ReportViewer
        _00formprint.ReportViewer1.LocalReport.DataSources.Clear()
        _00formprint.ReportViewer1.LocalReport.DataSources.Add(New Microsoft.Reporting.WinForms.ReportDataSource("DataSet1", ds.Tables("SuratJalan")))

        ' Refresh laporan
        _00formprint.ReportViewer1.RefreshReport()

        _00formprint.ShowDialog()
        _00formprint.Dispose()


    End Sub
End Class