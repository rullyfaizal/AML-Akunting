﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class form_penjualan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(form_penjualan))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.ts_celup_baru = New System.Windows.Forms.ToolStripButton()
        Me.ts_perbarui = New System.Windows.Forms.ToolStripButton()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.ts_kain_baru = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ts_edit = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ts_hapus = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.ts_gabung_sj = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.ts_generate_sj = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSplitButton1 = New System.Windows.Forms.ToolStripSplitButton()
        Me.SatuanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BulananToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.ts_print_invoice = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.btn_supplier = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.txt_total_ppn_kain = New System.Windows.Forms.TextBox()
        Me.txt_total_dpp_kain = New System.Windows.Forms.TextBox()
        Me.txt_gran_total_kain = New System.Windows.Forms.TextBox()
        Me.txt_transfer_kain = New System.Windows.Forms.TextBox()
        Me.txt_total_ppn = New System.Windows.Forms.TextBox()
        Me.txt_total_dpp = New System.Windows.Forms.TextBox()
        Me.txt_gran_total = New System.Windows.Forms.TextBox()
        Me.txt_transfer = New System.Windows.Forms.TextBox()
        Me.dgv1 = New System.Windows.Forms.DataGridView()
        Me.dtp_hari_ini = New System.Windows.Forms.DateTimePicker()
        Me.Cbo_Supplier = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.dgv_supplier = New System.Windows.Forms.DataGridView()
        Me.btn_reset = New System.Windows.Forms.Button()
        Me.btn_cari = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.dtp_akhir = New System.Windows.Forms.DateTimePicker()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.dtp_awal = New System.Windows.Forms.DateTimePicker()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.txt_total_ppn_celup = New System.Windows.Forms.TextBox()
        Me.txt_total_dpp_celup = New System.Windows.Forms.TextBox()
        Me.txt_gran_total_celup = New System.Windows.Forms.TextBox()
        Me.txt_transfer_celup = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.panelGabung = New System.Windows.Forms.Panel()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.btnGabung = New System.Windows.Forms.Button()
        Me.btnHapus = New System.Windows.Forms.Button()
        Me.btnBatal = New System.Windows.Forms.Button()
        Me.dgv2 = New System.Windows.Forms.DataGridView()
        Me.Txt_kode = New System.Windows.Forms.TextBox()
        Me.panelPrintSuratJalan = New System.Windows.Forms.Panel()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.btn_kosong_tanggal_print_sj = New System.Windows.Forms.Button()
        Me.txt_tanggal_print_sj = New System.Windows.Forms.TextBox()
        Me.dtp_tanggal_print_sj = New System.Windows.Forms.DateTimePicker()
        Me.txt_no_sj = New System.Windows.Forms.TextBox()
        Me.txt_kota_client = New System.Windows.Forms.TextBox()
        Me.txt_alamat_client = New System.Windows.Forms.TextBox()
        Me.txt_client = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.btnPrintSj = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.dgv_print_sj = New System.Windows.Forms.DataGridView()
        Me.txt_ket_sj = New System.Windows.Forms.TextBox()
        Me.panelPrintInvoice = New System.Windows.Forms.Panel()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txt_total_inv = New System.Windows.Forms.TextBox()
        Me.lblPPN = New System.Windows.Forms.Label()
        Me.txt_ppn_inv = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txt_dpp_inv = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txt_no_faktur = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.btn_tanggal_inv = New System.Windows.Forms.Button()
        Me.txt_tanggal_inv = New System.Windows.Forms.TextBox()
        Me.dtp_tanggal_inv = New System.Windows.Forms.DateTimePicker()
        Me.txt_no_sj_inv = New System.Windows.Forms.TextBox()
        Me.txt_kota_client_inv = New System.Windows.Forms.TextBox()
        Me.txt_alamat_client_inv = New System.Windows.Forms.TextBox()
        Me.txt_client_inv = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.btn_print_inv = New System.Windows.Forms.Button()
        Me.btn_batal_inv = New System.Windows.Forms.Button()
        Me.dgv_inv = New System.Windows.Forms.DataGridView()
        Me.txt_ket_inv = New System.Windows.Forms.TextBox()
        Me.panelPrintSuratJalanBulanan = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.dgv_list_sj = New System.Windows.Forms.DataGridView()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txt_kosong_tanggal_print_sj_bulanan = New System.Windows.Forms.Button()
        Me.txt_tanggal_print_sj_bulanan = New System.Windows.Forms.TextBox()
        Me.dtp_tanggal_print_sj_bulanan = New System.Windows.Forms.DateTimePicker()
        Me.txt_no_sj_print_bulanan = New System.Windows.Forms.TextBox()
        Me.txt_kota_client_bulanan = New System.Windows.Forms.TextBox()
        Me.txt_alamat_client_bulanan = New System.Windows.Forms.TextBox()
        Me.txt_client_bulanan = New System.Windows.Forms.TextBox()
        Me.lbl_print_sj_bulanan = New System.Windows.Forms.Label()
        Me.btn_print_sj_bulanan = New System.Windows.Forms.Button()
        Me.btn_batal_print_sj_bulanan = New System.Windows.Forms.Button()
        Me.dgv_print_sj_bulanan = New System.Windows.Forms.DataGridView()
        Me.txt_ketrangan_sj_bulanan = New System.Windows.Forms.TextBox()
        Me.ToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStrip1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.dgv_supplier, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.panelGabung.SuspendLayout()
        CType(Me.dgv2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelPrintSuratJalan.SuspendLayout()
        CType(Me.dgv_print_sj, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelPrintInvoice.SuspendLayout()
        CType(Me.dgv_inv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelPrintSuratJalanBulanan.SuspendLayout()
        CType(Me.dgv_list_sj, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_print_sj_bulanan, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Label6.Font = New System.Drawing.Font("Verdana", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.Window
        Me.Label6.Location = New System.Drawing.Point(2, 27)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(1127, 28)
        Me.Label6.TabIndex = 26
        Me.Label6.Text = "DATA PENJUALAN"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ts_celup_baru
        '
        Me.ts_celup_baru.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_celup_baru.Name = "ts_celup_baru"
        Me.ts_celup_baru.Size = New System.Drawing.Size(101, 22)
        Me.ts_celup_baru.Text = "Celup Baru"
        '
        'ts_perbarui
        '
        Me.ts_perbarui.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_perbarui.Name = "ts_perbarui"
        Me.ts_perbarui.Size = New System.Drawing.Size(85, 22)
        Me.ts_perbarui.Text = "Perbarui "
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ts_celup_baru, Me.ToolStripSeparator7, Me.ts_kain_baru, Me.ToolStripSeparator1, Me.ts_edit, Me.ToolStripSeparator2, Me.ts_hapus, Me.ToolStripSeparator3, Me.ts_gabung_sj, Me.ToolStripSeparator4, Me.ts_generate_sj, Me.ToolStripSeparator6, Me.ToolStripButton1, Me.ToolStripSeparator9, Me.ToolStripButton2, Me.ToolStripSeparator5, Me.ts_print_invoice, Me.ToolStripSeparator8, Me.ts_perbarui, Me.ToolStripSplitButton1})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(1131, 25)
        Me.ToolStrip1.TabIndex = 22
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(6, 25)
        '
        'ts_kain_baru
        '
        Me.ts_kain_baru.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_kain_baru.Name = "ts_kain_baru"
        Me.ts_kain_baru.Size = New System.Drawing.Size(91, 22)
        Me.ts_kain_baru.Text = "Kain Baru"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'ts_edit
        '
        Me.ts_edit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_edit.Name = "ts_edit"
        Me.ts_edit.Size = New System.Drawing.Size(54, 22)
        Me.ts_edit.Text = "Ubah"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'ts_hapus
        '
        Me.ts_hapus.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_hapus.Name = "ts_hapus"
        Me.ts_hapus.Size = New System.Drawing.Size(63, 22)
        Me.ts_hapus.Text = "Hapus"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 25)
        '
        'ts_gabung_sj
        '
        Me.ts_gabung_sj.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_gabung_sj.Name = "ts_gabung_sj"
        Me.ts_gabung_sj.Size = New System.Drawing.Size(97, 22)
        Me.ts_gabung_sj.Text = "Gabung SJ"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 25)
        '
        'ts_generate_sj
        '
        Me.ts_generate_sj.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_generate_sj.Name = "ts_generate_sj"
        Me.ts_generate_sj.Size = New System.Drawing.Size(110, 22)
        Me.ts_generate_sj.Text = "Generate SJ"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(54, 22)
        Me.ToolStripButton1.Text = "Excel"
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripSplitButton1
        '
        Me.ToolStripSplitButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripSplitButton1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SatuanToolStripMenuItem, Me.BulananToolStripMenuItem})
        Me.ToolStripSplitButton1.Image = CType(resources.GetObject("ToolStripSplitButton1.Image"), System.Drawing.Image)
        Me.ToolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripSplitButton1.Name = "ToolStripSplitButton1"
        Me.ToolStripSplitButton1.Size = New System.Drawing.Size(85, 22)
        Me.ToolStripSplitButton1.Text = "Print SJ"
        Me.ToolStripSplitButton1.Visible = False
        '
        'SatuanToolStripMenuItem
        '
        Me.SatuanToolStripMenuItem.Name = "SatuanToolStripMenuItem"
        Me.SatuanToolStripMenuItem.Size = New System.Drawing.Size(183, 22)
        Me.SatuanToolStripMenuItem.Text = "1 Surat Jalan"
        '
        'BulananToolStripMenuItem
        '
        Me.BulananToolStripMenuItem.Name = "BulananToolStripMenuItem"
        Me.BulananToolStripMenuItem.Size = New System.Drawing.Size(183, 22)
        Me.BulananToolStripMenuItem.Text = "1 Bulan"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(6, 25)
        '
        'ts_print_invoice
        '
        Me.ts_print_invoice.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_print_invoice.Name = "ts_print_invoice"
        Me.ts_print_invoice.Size = New System.Drawing.Size(71, 22)
        Me.ts_print_invoice.Text = "Invoice"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(6, 25)
        '
        'btn_supplier
        '
        Me.btn_supplier.BackColor = System.Drawing.SystemColors.Control
        Me.btn_supplier.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_supplier.Location = New System.Drawing.Point(214, 147)
        Me.btn_supplier.Margin = New System.Windows.Forms.Padding(4)
        Me.btn_supplier.Name = "btn_supplier"
        Me.btn_supplier.Size = New System.Drawing.Size(24, 24)
        Me.btn_supplier.TabIndex = 52
        Me.btn_supplier.Text = "X"
        Me.btn_supplier.UseVisualStyleBackColor = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Khaki
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.txt_total_ppn_kain)
        Me.Panel2.Controls.Add(Me.txt_total_dpp_kain)
        Me.Panel2.Controls.Add(Me.txt_gran_total_kain)
        Me.Panel2.Controls.Add(Me.txt_transfer_kain)
        Me.Panel2.Location = New System.Drawing.Point(255, 550)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(874, 35)
        Me.Panel2.TabIndex = 27
        '
        'txt_total_ppn_kain
        '
        Me.txt_total_ppn_kain.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_total_ppn_kain.Location = New System.Drawing.Point(229, 5)
        Me.txt_total_ppn_kain.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.txt_total_ppn_kain.Name = "txt_total_ppn_kain"
        Me.txt_total_ppn_kain.ReadOnly = True
        Me.txt_total_ppn_kain.Size = New System.Drawing.Size(200, 23)
        Me.txt_total_ppn_kain.TabIndex = 227
        Me.txt_total_ppn_kain.TabStop = False
        Me.txt_total_ppn_kain.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txt_total_dpp_kain
        '
        Me.txt_total_dpp_kain.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_total_dpp_kain.Location = New System.Drawing.Point(15, 5)
        Me.txt_total_dpp_kain.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.txt_total_dpp_kain.Name = "txt_total_dpp_kain"
        Me.txt_total_dpp_kain.ReadOnly = True
        Me.txt_total_dpp_kain.Size = New System.Drawing.Size(200, 23)
        Me.txt_total_dpp_kain.TabIndex = 226
        Me.txt_total_dpp_kain.TabStop = False
        Me.txt_total_dpp_kain.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txt_gran_total_kain
        '
        Me.txt_gran_total_kain.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_gran_total_kain.Location = New System.Drawing.Point(443, 5)
        Me.txt_gran_total_kain.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.txt_gran_total_kain.Name = "txt_gran_total_kain"
        Me.txt_gran_total_kain.ReadOnly = True
        Me.txt_gran_total_kain.Size = New System.Drawing.Size(200, 23)
        Me.txt_gran_total_kain.TabIndex = 225
        Me.txt_gran_total_kain.TabStop = False
        Me.txt_gran_total_kain.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txt_transfer_kain
        '
        Me.txt_transfer_kain.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_transfer_kain.Location = New System.Drawing.Point(657, 5)
        Me.txt_transfer_kain.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.txt_transfer_kain.Name = "txt_transfer_kain"
        Me.txt_transfer_kain.ReadOnly = True
        Me.txt_transfer_kain.Size = New System.Drawing.Size(200, 23)
        Me.txt_transfer_kain.TabIndex = 228
        Me.txt_transfer_kain.TabStop = False
        Me.txt_transfer_kain.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txt_total_ppn
        '
        Me.txt_total_ppn.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_total_ppn.Location = New System.Drawing.Point(485, 384)
        Me.txt_total_ppn.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.txt_total_ppn.Name = "txt_total_ppn"
        Me.txt_total_ppn.ReadOnly = True
        Me.txt_total_ppn.Size = New System.Drawing.Size(200, 23)
        Me.txt_total_ppn.TabIndex = 223
        Me.txt_total_ppn.TabStop = False
        Me.txt_total_ppn.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txt_total_dpp
        '
        Me.txt_total_dpp.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_total_dpp.Location = New System.Drawing.Point(271, 384)
        Me.txt_total_dpp.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.txt_total_dpp.Name = "txt_total_dpp"
        Me.txt_total_dpp.ReadOnly = True
        Me.txt_total_dpp.Size = New System.Drawing.Size(200, 23)
        Me.txt_total_dpp.TabIndex = 222
        Me.txt_total_dpp.TabStop = False
        Me.txt_total_dpp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txt_gran_total
        '
        Me.txt_gran_total.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_gran_total.Location = New System.Drawing.Point(699, 384)
        Me.txt_gran_total.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.txt_gran_total.Name = "txt_gran_total"
        Me.txt_gran_total.ReadOnly = True
        Me.txt_gran_total.Size = New System.Drawing.Size(200, 23)
        Me.txt_gran_total.TabIndex = 221
        Me.txt_gran_total.TabStop = False
        Me.txt_gran_total.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txt_transfer
        '
        Me.txt_transfer.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_transfer.Location = New System.Drawing.Point(913, 384)
        Me.txt_transfer.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.txt_transfer.Name = "txt_transfer"
        Me.txt_transfer.ReadOnly = True
        Me.txt_transfer.Size = New System.Drawing.Size(200, 23)
        Me.txt_transfer.TabIndex = 224
        Me.txt_transfer.TabStop = False
        Me.txt_transfer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'dgv1
        '
        Me.dgv1.AllowUserToAddRows = False
        Me.dgv1.AllowUserToDeleteRows = False
        Me.dgv1.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv1.DefaultCellStyle = DataGridViewCellStyle1
        Me.dgv1.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv1.Location = New System.Drawing.Point(255, 58)
        Me.dgv1.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv1.MultiSelect = False
        Me.dgv1.Name = "dgv1"
        Me.dgv1.ReadOnly = True
        Me.dgv1.Size = New System.Drawing.Size(874, 423)
        Me.dgv1.TabIndex = 23
        '
        'dtp_hari_ini
        '
        Me.dtp_hari_ini.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtp_hari_ini.Location = New System.Drawing.Point(952, 29)
        Me.dtp_hari_ini.Margin = New System.Windows.Forms.Padding(4)
        Me.dtp_hari_ini.Name = "dtp_hari_ini"
        Me.dtp_hari_ini.Size = New System.Drawing.Size(150, 22)
        Me.dtp_hari_ini.TabIndex = 25
        '
        'Cbo_Supplier
        '
        Me.Cbo_Supplier.Location = New System.Drawing.Point(11, 148)
        Me.Cbo_Supplier.Name = "Cbo_Supplier"
        Me.Cbo_Supplier.Size = New System.Drawing.Size(202, 22)
        Me.Cbo_Supplier.TabIndex = 17
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.dgv_supplier)
        Me.Panel1.Controls.Add(Me.btn_supplier)
        Me.Panel1.Controls.Add(Me.btn_reset)
        Me.Panel1.Controls.Add(Me.Cbo_Supplier)
        Me.Panel1.Controls.Add(Me.btn_cari)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.dtp_akhir)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.dtp_awal)
        Me.Panel1.Location = New System.Drawing.Point(2, 58)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(250, 527)
        Me.Panel1.TabIndex = 24
        '
        'dgv_supplier
        '
        Me.dgv_supplier.AllowUserToAddRows = False
        Me.dgv_supplier.AllowUserToDeleteRows = False
        Me.dgv_supplier.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_supplier.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgv_supplier.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_supplier.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgv_supplier.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_supplier.Location = New System.Drawing.Point(11, 173)
        Me.dgv_supplier.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.dgv_supplier.MultiSelect = False
        Me.dgv_supplier.Name = "dgv_supplier"
        Me.dgv_supplier.ReadOnly = True
        Me.dgv_supplier.Size = New System.Drawing.Size(227, 318)
        Me.dgv_supplier.TabIndex = 51
        Me.dgv_supplier.Visible = False
        '
        'btn_reset
        '
        Me.btn_reset.BackColor = System.Drawing.SystemColors.Control
        Me.btn_reset.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_reset.Location = New System.Drawing.Point(142, 223)
        Me.btn_reset.Margin = New System.Windows.Forms.Padding(4)
        Me.btn_reset.Name = "btn_reset"
        Me.btn_reset.Size = New System.Drawing.Size(75, 30)
        Me.btn_reset.TabIndex = 53
        Me.btn_reset.Text = "RESET"
        Me.btn_reset.UseVisualStyleBackColor = False
        '
        'btn_cari
        '
        Me.btn_cari.BackColor = System.Drawing.SystemColors.Control
        Me.btn_cari.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_cari.Location = New System.Drawing.Point(31, 223)
        Me.btn_cari.Margin = New System.Windows.Forms.Padding(4)
        Me.btn_cari.Name = "btn_cari"
        Me.btn_cari.Size = New System.Drawing.Size(75, 30)
        Me.btn_cari.TabIndex = 14
        Me.btn_cari.Text = "CARI"
        Me.btn_cari.UseVisualStyleBackColor = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(11, 81)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(29, 16)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "s/d"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(11, 49)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(33, 16)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Dari"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(11, 20)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(126, 16)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Tanggal Penjualan"
        '
        'dtp_akhir
        '
        Me.dtp_akhir.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtp_akhir.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtp_akhir.Location = New System.Drawing.Point(51, 77)
        Me.dtp_akhir.Margin = New System.Windows.Forms.Padding(4)
        Me.dtp_akhir.Name = "dtp_akhir"
        Me.dtp_akhir.Size = New System.Drawing.Size(115, 23)
        Me.dtp_akhir.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(11, 130)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(45, 16)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Client"
        '
        'dtp_awal
        '
        Me.dtp_awal.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtp_awal.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtp_awal.Location = New System.Drawing.Point(51, 44)
        Me.dtp_awal.Margin = New System.Windows.Forms.Padding(4)
        Me.dtp_awal.Name = "dtp_awal"
        Me.dtp_awal.Size = New System.Drawing.Size(115, 23)
        Me.dtp_awal.TabIndex = 4
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.LightGreen
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.txt_total_ppn_celup)
        Me.Panel3.Controls.Add(Me.txt_total_dpp_celup)
        Me.Panel3.Controls.Add(Me.txt_gran_total_celup)
        Me.Panel3.Controls.Add(Me.txt_transfer_celup)
        Me.Panel3.Location = New System.Drawing.Point(255, 512)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(874, 35)
        Me.Panel3.TabIndex = 229
        '
        'txt_total_ppn_celup
        '
        Me.txt_total_ppn_celup.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_total_ppn_celup.Location = New System.Drawing.Point(229, 5)
        Me.txt_total_ppn_celup.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.txt_total_ppn_celup.Name = "txt_total_ppn_celup"
        Me.txt_total_ppn_celup.ReadOnly = True
        Me.txt_total_ppn_celup.Size = New System.Drawing.Size(200, 23)
        Me.txt_total_ppn_celup.TabIndex = 227
        Me.txt_total_ppn_celup.TabStop = False
        Me.txt_total_ppn_celup.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txt_total_dpp_celup
        '
        Me.txt_total_dpp_celup.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_total_dpp_celup.Location = New System.Drawing.Point(15, 5)
        Me.txt_total_dpp_celup.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.txt_total_dpp_celup.Name = "txt_total_dpp_celup"
        Me.txt_total_dpp_celup.ReadOnly = True
        Me.txt_total_dpp_celup.Size = New System.Drawing.Size(200, 23)
        Me.txt_total_dpp_celup.TabIndex = 226
        Me.txt_total_dpp_celup.TabStop = False
        Me.txt_total_dpp_celup.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txt_gran_total_celup
        '
        Me.txt_gran_total_celup.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_gran_total_celup.Location = New System.Drawing.Point(443, 5)
        Me.txt_gran_total_celup.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.txt_gran_total_celup.Name = "txt_gran_total_celup"
        Me.txt_gran_total_celup.ReadOnly = True
        Me.txt_gran_total_celup.Size = New System.Drawing.Size(200, 23)
        Me.txt_gran_total_celup.TabIndex = 225
        Me.txt_gran_total_celup.TabStop = False
        Me.txt_gran_total_celup.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txt_transfer_celup
        '
        Me.txt_transfer_celup.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_transfer_celup.Location = New System.Drawing.Point(657, 5)
        Me.txt_transfer_celup.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.txt_transfer_celup.Name = "txt_transfer_celup"
        Me.txt_transfer_celup.ReadOnly = True
        Me.txt_transfer_celup.Size = New System.Drawing.Size(200, 23)
        Me.txt_transfer_celup.TabIndex = 228
        Me.txt_transfer_celup.TabStop = False
        Me.txt_transfer_celup.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(270, 3)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(104, 16)
        Me.Label1.TabIndex = 227
        Me.Label1.Text = "Total PPN (Rp)"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(684, 3)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(133, 16)
        Me.Label7.TabIndex = 225
        Me.Label7.Text = "Total Transfer (Rp)"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(478, 3)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(117, 16)
        Me.Label8.TabIndex = 228
        Me.Label8.Text = "Grand Total (Rp)"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(56, 3)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(104, 16)
        Me.Label9.TabIndex = 226
        Me.Label9.Text = "Total DPP (Rp)"
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.Label8)
        Me.Panel4.Controls.Add(Me.Label9)
        Me.Panel4.Controls.Add(Me.Label1)
        Me.Panel4.Controls.Add(Me.Label7)
        Me.Panel4.Location = New System.Drawing.Point(255, 484)
        Me.Panel4.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(874, 25)
        Me.Panel4.TabIndex = 230
        '
        'panelGabung
        '
        Me.panelGabung.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.panelGabung.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panelGabung.Controls.Add(Me.Label10)
        Me.panelGabung.Controls.Add(Me.btnGabung)
        Me.panelGabung.Controls.Add(Me.btnHapus)
        Me.panelGabung.Controls.Add(Me.btnBatal)
        Me.panelGabung.Controls.Add(Me.dgv2)
        Me.panelGabung.Controls.Add(Me.Txt_kode)
        Me.panelGabung.Location = New System.Drawing.Point(118, 141)
        Me.panelGabung.Name = "panelGabung"
        Me.panelGabung.Size = New System.Drawing.Size(894, 304)
        Me.panelGabung.TabIndex = 231
        Me.panelGabung.Visible = False
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Label10.Font = New System.Drawing.Font("Verdana", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.Window
        Me.Label10.Location = New System.Drawing.Point(22, 18)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(849, 28)
        Me.Label10.TabIndex = 144
        Me.Label10.Text = "GABUNG SURAT JALAN"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnGabung
        '
        Me.btnGabung.BackColor = System.Drawing.SystemColors.Control
        Me.btnGabung.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnGabung.Location = New System.Drawing.Point(147, 255)
        Me.btnGabung.Margin = New System.Windows.Forms.Padding(4)
        Me.btnGabung.Name = "btnGabung"
        Me.btnGabung.Size = New System.Drawing.Size(117, 30)
        Me.btnGabung.TabIndex = 27
        Me.btnGabung.Text = "GABUNG"
        Me.btnGabung.UseVisualStyleBackColor = False
        '
        'btnHapus
        '
        Me.btnHapus.BackColor = System.Drawing.SystemColors.Control
        Me.btnHapus.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnHapus.Location = New System.Drawing.Point(388, 255)
        Me.btnHapus.Margin = New System.Windows.Forms.Padding(4)
        Me.btnHapus.Name = "btnHapus"
        Me.btnHapus.Size = New System.Drawing.Size(117, 30)
        Me.btnHapus.TabIndex = 26
        Me.btnHapus.Text = "HAPUS"
        Me.btnHapus.UseVisualStyleBackColor = False
        '
        'btnBatal
        '
        Me.btnBatal.BackColor = System.Drawing.SystemColors.Control
        Me.btnBatal.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnBatal.Location = New System.Drawing.Point(629, 255)
        Me.btnBatal.Margin = New System.Windows.Forms.Padding(4)
        Me.btnBatal.Name = "btnBatal"
        Me.btnBatal.Size = New System.Drawing.Size(117, 30)
        Me.btnBatal.TabIndex = 25
        Me.btnBatal.Text = "BATAL"
        Me.btnBatal.UseVisualStyleBackColor = False
        '
        'dgv2
        '
        Me.dgv2.AllowUserToAddRows = False
        Me.dgv2.AllowUserToDeleteRows = False
        Me.dgv2.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv2.DefaultCellStyle = DataGridViewCellStyle3
        Me.dgv2.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv2.Location = New System.Drawing.Point(22, 46)
        Me.dgv2.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv2.MultiSelect = False
        Me.dgv2.Name = "dgv2"
        Me.dgv2.ReadOnly = True
        Me.dgv2.Size = New System.Drawing.Size(849, 186)
        Me.dgv2.TabIndex = 24
        '
        'Txt_kode
        '
        Me.Txt_kode.Location = New System.Drawing.Point(3, 238)
        Me.Txt_kode.Name = "Txt_kode"
        Me.Txt_kode.ReadOnly = True
        Me.Txt_kode.Size = New System.Drawing.Size(174, 22)
        Me.Txt_kode.TabIndex = 143
        Me.Txt_kode.TabStop = False
        Me.Txt_kode.Visible = False
        '
        'panelPrintSuratJalan
        '
        Me.panelPrintSuratJalan.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.panelPrintSuratJalan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panelPrintSuratJalan.Controls.Add(Me.Label14)
        Me.panelPrintSuratJalan.Controls.Add(Me.Label13)
        Me.panelPrintSuratJalan.Controls.Add(Me.Label12)
        Me.panelPrintSuratJalan.Controls.Add(Me.btn_kosong_tanggal_print_sj)
        Me.panelPrintSuratJalan.Controls.Add(Me.txt_tanggal_print_sj)
        Me.panelPrintSuratJalan.Controls.Add(Me.dtp_tanggal_print_sj)
        Me.panelPrintSuratJalan.Controls.Add(Me.txt_no_sj)
        Me.panelPrintSuratJalan.Controls.Add(Me.txt_kota_client)
        Me.panelPrintSuratJalan.Controls.Add(Me.txt_alamat_client)
        Me.panelPrintSuratJalan.Controls.Add(Me.txt_client)
        Me.panelPrintSuratJalan.Controls.Add(Me.Label11)
        Me.panelPrintSuratJalan.Controls.Add(Me.btnPrintSj)
        Me.panelPrintSuratJalan.Controls.Add(Me.Button3)
        Me.panelPrintSuratJalan.Controls.Add(Me.dgv_print_sj)
        Me.panelPrintSuratJalan.Controls.Add(Me.txt_ket_sj)
        Me.panelPrintSuratJalan.Location = New System.Drawing.Point(118, 100)
        Me.panelPrintSuratJalan.Name = "panelPrintSuratJalan"
        Me.panelPrintSuratJalan.Size = New System.Drawing.Size(894, 386)
        Me.panelPrintSuratJalan.TabIndex = 232
        Me.panelPrintSuratJalan.Visible = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(521, 67)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(45, 16)
        Me.Label14.TabIndex = 153
        Me.Label14.Text = "No SJ"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(22, 284)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(83, 16)
        Me.Label13.TabIndex = 152
        Me.Label13.Text = "Keterangan"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(521, 44)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(58, 16)
        Me.Label12.TabIndex = 54
        Me.Label12.Text = "Tanggal"
        '
        'btn_kosong_tanggal_print_sj
        '
        Me.btn_kosong_tanggal_print_sj.BackColor = System.Drawing.SystemColors.Window
        Me.btn_kosong_tanggal_print_sj.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_kosong_tanggal_print_sj.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_kosong_tanggal_print_sj.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_kosong_tanggal_print_sj.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_kosong_tanggal_print_sj.Location = New System.Drawing.Point(753, 41)
        Me.btn_kosong_tanggal_print_sj.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.btn_kosong_tanggal_print_sj.Name = "btn_kosong_tanggal_print_sj"
        Me.btn_kosong_tanggal_print_sj.Size = New System.Drawing.Size(27, 22)
        Me.btn_kosong_tanggal_print_sj.TabIndex = 151
        Me.btn_kosong_tanggal_print_sj.TabStop = False
        Me.btn_kosong_tanggal_print_sj.Text = "X"
        Me.btn_kosong_tanggal_print_sj.UseMnemonic = False
        Me.btn_kosong_tanggal_print_sj.UseVisualStyleBackColor = False
        Me.btn_kosong_tanggal_print_sj.Visible = False
        '
        'txt_tanggal_print_sj
        '
        Me.txt_tanggal_print_sj.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_tanggal_print_sj.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_tanggal_print_sj.Location = New System.Drawing.Point(602, 41)
        Me.txt_tanggal_print_sj.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.txt_tanggal_print_sj.Name = "txt_tanggal_print_sj"
        Me.txt_tanggal_print_sj.ReadOnly = True
        Me.txt_tanggal_print_sj.Size = New System.Drawing.Size(130, 22)
        Me.txt_tanggal_print_sj.TabIndex = 150
        Me.txt_tanggal_print_sj.TabStop = False
        '
        'dtp_tanggal_print_sj
        '
        Me.dtp_tanggal_print_sj.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtp_tanggal_print_sj.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtp_tanggal_print_sj.Location = New System.Drawing.Point(735, 41)
        Me.dtp_tanggal_print_sj.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.dtp_tanggal_print_sj.Name = "dtp_tanggal_print_sj"
        Me.dtp_tanggal_print_sj.Size = New System.Drawing.Size(15, 22)
        Me.dtp_tanggal_print_sj.TabIndex = 149
        Me.dtp_tanggal_print_sj.TabStop = False
        Me.dtp_tanggal_print_sj.Visible = False
        '
        'txt_no_sj
        '
        Me.txt_no_sj.Location = New System.Drawing.Point(602, 64)
        Me.txt_no_sj.Name = "txt_no_sj"
        Me.txt_no_sj.ReadOnly = True
        Me.txt_no_sj.Size = New System.Drawing.Size(269, 22)
        Me.txt_no_sj.TabIndex = 148
        Me.txt_no_sj.TabStop = False
        '
        'txt_kota_client
        '
        Me.txt_kota_client.Location = New System.Drawing.Point(22, 87)
        Me.txt_kota_client.Name = "txt_kota_client"
        Me.txt_kota_client.ReadOnly = True
        Me.txt_kota_client.Size = New System.Drawing.Size(361, 22)
        Me.txt_kota_client.TabIndex = 147
        Me.txt_kota_client.TabStop = False
        '
        'txt_alamat_client
        '
        Me.txt_alamat_client.Location = New System.Drawing.Point(22, 64)
        Me.txt_alamat_client.Name = "txt_alamat_client"
        Me.txt_alamat_client.ReadOnly = True
        Me.txt_alamat_client.Size = New System.Drawing.Size(361, 22)
        Me.txt_alamat_client.TabIndex = 146
        Me.txt_alamat_client.TabStop = False
        '
        'txt_client
        '
        Me.txt_client.Location = New System.Drawing.Point(22, 41)
        Me.txt_client.Name = "txt_client"
        Me.txt_client.ReadOnly = True
        Me.txt_client.Size = New System.Drawing.Size(361, 22)
        Me.txt_client.TabIndex = 145
        Me.txt_client.TabStop = False
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Label11.Font = New System.Drawing.Font("Verdana", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.SystemColors.Window
        Me.Label11.Location = New System.Drawing.Point(22, 7)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(849, 28)
        Me.Label11.TabIndex = 144
        Me.Label11.Text = "PRINT SURAT JALAN"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnPrintSj
        '
        Me.btnPrintSj.BackColor = System.Drawing.SystemColors.Control
        Me.btnPrintSj.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnPrintSj.Location = New System.Drawing.Point(286, 331)
        Me.btnPrintSj.Margin = New System.Windows.Forms.Padding(4)
        Me.btnPrintSj.Name = "btnPrintSj"
        Me.btnPrintSj.Size = New System.Drawing.Size(117, 30)
        Me.btnPrintSj.TabIndex = 27
        Me.btnPrintSj.Text = "PRINT"
        Me.btnPrintSj.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.SystemColors.Control
        Me.Button3.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button3.Location = New System.Drawing.Point(490, 331)
        Me.Button3.Margin = New System.Windows.Forms.Padding(4)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(117, 30)
        Me.Button3.TabIndex = 25
        Me.Button3.Text = "BATAL"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'dgv_print_sj
        '
        Me.dgv_print_sj.AllowUserToAddRows = False
        Me.dgv_print_sj.AllowUserToDeleteRows = False
        Me.dgv_print_sj.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_print_sj.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_print_sj.DefaultCellStyle = DataGridViewCellStyle4
        Me.dgv_print_sj.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_print_sj.Location = New System.Drawing.Point(22, 115)
        Me.dgv_print_sj.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_print_sj.MultiSelect = False
        Me.dgv_print_sj.Name = "dgv_print_sj"
        Me.dgv_print_sj.Size = New System.Drawing.Size(849, 156)
        Me.dgv_print_sj.TabIndex = 24
        '
        'txt_ket_sj
        '
        Me.txt_ket_sj.Location = New System.Drawing.Point(114, 281)
        Me.txt_ket_sj.MaxLength = 70
        Me.txt_ket_sj.Name = "txt_ket_sj"
        Me.txt_ket_sj.Size = New System.Drawing.Size(618, 22)
        Me.txt_ket_sj.TabIndex = 143
        Me.txt_ket_sj.TabStop = False
        '
        'panelPrintInvoice
        '
        Me.panelPrintInvoice.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.panelPrintInvoice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panelPrintInvoice.Controls.Add(Me.Label22)
        Me.panelPrintInvoice.Controls.Add(Me.txt_total_inv)
        Me.panelPrintInvoice.Controls.Add(Me.lblPPN)
        Me.panelPrintInvoice.Controls.Add(Me.txt_ppn_inv)
        Me.panelPrintInvoice.Controls.Add(Me.Label20)
        Me.panelPrintInvoice.Controls.Add(Me.txt_dpp_inv)
        Me.panelPrintInvoice.Controls.Add(Me.Label19)
        Me.panelPrintInvoice.Controls.Add(Me.txt_no_faktur)
        Me.panelPrintInvoice.Controls.Add(Me.Label15)
        Me.panelPrintInvoice.Controls.Add(Me.Label16)
        Me.panelPrintInvoice.Controls.Add(Me.Label17)
        Me.panelPrintInvoice.Controls.Add(Me.btn_tanggal_inv)
        Me.panelPrintInvoice.Controls.Add(Me.txt_tanggal_inv)
        Me.panelPrintInvoice.Controls.Add(Me.dtp_tanggal_inv)
        Me.panelPrintInvoice.Controls.Add(Me.txt_no_sj_inv)
        Me.panelPrintInvoice.Controls.Add(Me.txt_kota_client_inv)
        Me.panelPrintInvoice.Controls.Add(Me.txt_alamat_client_inv)
        Me.panelPrintInvoice.Controls.Add(Me.txt_client_inv)
        Me.panelPrintInvoice.Controls.Add(Me.Label18)
        Me.panelPrintInvoice.Controls.Add(Me.btn_print_inv)
        Me.panelPrintInvoice.Controls.Add(Me.btn_batal_inv)
        Me.panelPrintInvoice.Controls.Add(Me.dgv_inv)
        Me.panelPrintInvoice.Controls.Add(Me.txt_ket_inv)
        Me.panelPrintInvoice.Location = New System.Drawing.Point(118, 75)
        Me.panelPrintInvoice.Name = "panelPrintInvoice"
        Me.panelPrintInvoice.Size = New System.Drawing.Size(894, 437)
        Me.panelPrintInvoice.TabIndex = 233
        Me.panelPrintInvoice.Visible = False
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(597, 329)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(51, 16)
        Me.Label22.TabIndex = 161
        Me.Label22.Text = "TOTAL"
        '
        'txt_total_inv
        '
        Me.txt_total_inv.Location = New System.Drawing.Point(672, 326)
        Me.txt_total_inv.Name = "txt_total_inv"
        Me.txt_total_inv.ReadOnly = True
        Me.txt_total_inv.Size = New System.Drawing.Size(199, 22)
        Me.txt_total_inv.TabIndex = 160
        Me.txt_total_inv.TabStop = False
        Me.txt_total_inv.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblPPN
        '
        Me.lblPPN.AutoSize = True
        Me.lblPPN.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPPN.Location = New System.Drawing.Point(597, 305)
        Me.lblPPN.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblPPN.Name = "lblPPN"
        Me.lblPPN.Size = New System.Drawing.Size(33, 16)
        Me.lblPPN.TabIndex = 159
        Me.lblPPN.Text = "PPN"
        '
        'txt_ppn_inv
        '
        Me.txt_ppn_inv.Location = New System.Drawing.Point(672, 302)
        Me.txt_ppn_inv.Name = "txt_ppn_inv"
        Me.txt_ppn_inv.ReadOnly = True
        Me.txt_ppn_inv.Size = New System.Drawing.Size(199, 22)
        Me.txt_ppn_inv.TabIndex = 158
        Me.txt_ppn_inv.TabStop = False
        Me.txt_ppn_inv.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(597, 281)
        Me.Label20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(33, 16)
        Me.Label20.TabIndex = 157
        Me.Label20.Text = "DPP"
        '
        'txt_dpp_inv
        '
        Me.txt_dpp_inv.Location = New System.Drawing.Point(672, 278)
        Me.txt_dpp_inv.Name = "txt_dpp_inv"
        Me.txt_dpp_inv.ReadOnly = True
        Me.txt_dpp_inv.Size = New System.Drawing.Size(199, 22)
        Me.txt_dpp_inv.TabIndex = 156
        Me.txt_dpp_inv.TabStop = False
        Me.txt_dpp_inv.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(458, 90)
        Me.Label19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(71, 16)
        Me.Label19.TabIndex = 155
        Me.Label19.Text = "No Faktur"
        '
        'txt_no_faktur
        '
        Me.txt_no_faktur.Location = New System.Drawing.Point(539, 87)
        Me.txt_no_faktur.Name = "txt_no_faktur"
        Me.txt_no_faktur.ReadOnly = True
        Me.txt_no_faktur.Size = New System.Drawing.Size(332, 22)
        Me.txt_no_faktur.TabIndex = 154
        Me.txt_no_faktur.TabStop = False
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(458, 66)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(45, 16)
        Me.Label15.TabIndex = 153
        Me.Label15.Text = "No SJ"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(22, 281)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(83, 16)
        Me.Label16.TabIndex = 152
        Me.Label16.Text = "Keterangan"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(458, 43)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(58, 16)
        Me.Label17.TabIndex = 54
        Me.Label17.Text = "Tanggal"
        '
        'btn_tanggal_inv
        '
        Me.btn_tanggal_inv.BackColor = System.Drawing.SystemColors.Window
        Me.btn_tanggal_inv.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_tanggal_inv.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_tanggal_inv.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_tanggal_inv.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_tanggal_inv.Location = New System.Drawing.Point(690, 40)
        Me.btn_tanggal_inv.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.btn_tanggal_inv.Name = "btn_tanggal_inv"
        Me.btn_tanggal_inv.Size = New System.Drawing.Size(27, 22)
        Me.btn_tanggal_inv.TabIndex = 151
        Me.btn_tanggal_inv.TabStop = False
        Me.btn_tanggal_inv.Text = "X"
        Me.btn_tanggal_inv.UseMnemonic = False
        Me.btn_tanggal_inv.UseVisualStyleBackColor = False
        Me.btn_tanggal_inv.Visible = False
        '
        'txt_tanggal_inv
        '
        Me.txt_tanggal_inv.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_tanggal_inv.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_tanggal_inv.Location = New System.Drawing.Point(539, 40)
        Me.txt_tanggal_inv.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.txt_tanggal_inv.Name = "txt_tanggal_inv"
        Me.txt_tanggal_inv.ReadOnly = True
        Me.txt_tanggal_inv.Size = New System.Drawing.Size(130, 22)
        Me.txt_tanggal_inv.TabIndex = 150
        Me.txt_tanggal_inv.TabStop = False
        '
        'dtp_tanggal_inv
        '
        Me.dtp_tanggal_inv.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtp_tanggal_inv.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtp_tanggal_inv.Location = New System.Drawing.Point(672, 40)
        Me.dtp_tanggal_inv.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.dtp_tanggal_inv.Name = "dtp_tanggal_inv"
        Me.dtp_tanggal_inv.Size = New System.Drawing.Size(15, 22)
        Me.dtp_tanggal_inv.TabIndex = 149
        Me.dtp_tanggal_inv.TabStop = False
        Me.dtp_tanggal_inv.Visible = False
        '
        'txt_no_sj_inv
        '
        Me.txt_no_sj_inv.Location = New System.Drawing.Point(539, 63)
        Me.txt_no_sj_inv.Name = "txt_no_sj_inv"
        Me.txt_no_sj_inv.ReadOnly = True
        Me.txt_no_sj_inv.Size = New System.Drawing.Size(332, 22)
        Me.txt_no_sj_inv.TabIndex = 148
        Me.txt_no_sj_inv.TabStop = False
        '
        'txt_kota_client_inv
        '
        Me.txt_kota_client_inv.Location = New System.Drawing.Point(22, 87)
        Me.txt_kota_client_inv.Name = "txt_kota_client_inv"
        Me.txt_kota_client_inv.ReadOnly = True
        Me.txt_kota_client_inv.Size = New System.Drawing.Size(361, 22)
        Me.txt_kota_client_inv.TabIndex = 147
        Me.txt_kota_client_inv.TabStop = False
        '
        'txt_alamat_client_inv
        '
        Me.txt_alamat_client_inv.Location = New System.Drawing.Point(22, 64)
        Me.txt_alamat_client_inv.Name = "txt_alamat_client_inv"
        Me.txt_alamat_client_inv.ReadOnly = True
        Me.txt_alamat_client_inv.Size = New System.Drawing.Size(361, 22)
        Me.txt_alamat_client_inv.TabIndex = 146
        Me.txt_alamat_client_inv.TabStop = False
        '
        'txt_client_inv
        '
        Me.txt_client_inv.Location = New System.Drawing.Point(22, 41)
        Me.txt_client_inv.Name = "txt_client_inv"
        Me.txt_client_inv.ReadOnly = True
        Me.txt_client_inv.Size = New System.Drawing.Size(361, 22)
        Me.txt_client_inv.TabIndex = 145
        Me.txt_client_inv.TabStop = False
        '
        'Label18
        '
        Me.Label18.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Label18.Font = New System.Drawing.Font("Verdana", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.SystemColors.Window
        Me.Label18.Location = New System.Drawing.Point(22, 7)
        Me.Label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(849, 28)
        Me.Label18.TabIndex = 144
        Me.Label18.Text = "PRINT INVOICE"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn_print_inv
        '
        Me.btn_print_inv.BackColor = System.Drawing.SystemColors.Control
        Me.btn_print_inv.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_print_inv.Location = New System.Drawing.Point(286, 377)
        Me.btn_print_inv.Margin = New System.Windows.Forms.Padding(4)
        Me.btn_print_inv.Name = "btn_print_inv"
        Me.btn_print_inv.Size = New System.Drawing.Size(117, 30)
        Me.btn_print_inv.TabIndex = 27
        Me.btn_print_inv.Text = "PRINT"
        Me.btn_print_inv.UseVisualStyleBackColor = False
        '
        'btn_batal_inv
        '
        Me.btn_batal_inv.BackColor = System.Drawing.SystemColors.Control
        Me.btn_batal_inv.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_batal_inv.Location = New System.Drawing.Point(490, 377)
        Me.btn_batal_inv.Margin = New System.Windows.Forms.Padding(4)
        Me.btn_batal_inv.Name = "btn_batal_inv"
        Me.btn_batal_inv.Size = New System.Drawing.Size(117, 30)
        Me.btn_batal_inv.TabIndex = 25
        Me.btn_batal_inv.Text = "BATAL"
        Me.btn_batal_inv.UseVisualStyleBackColor = False
        '
        'dgv_inv
        '
        Me.dgv_inv.AllowUserToAddRows = False
        Me.dgv_inv.AllowUserToDeleteRows = False
        Me.dgv_inv.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_inv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_inv.DefaultCellStyle = DataGridViewCellStyle5
        Me.dgv_inv.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_inv.Location = New System.Drawing.Point(22, 115)
        Me.dgv_inv.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_inv.MultiSelect = False
        Me.dgv_inv.Name = "dgv_inv"
        Me.dgv_inv.ReadOnly = True
        Me.dgv_inv.Size = New System.Drawing.Size(849, 156)
        Me.dgv_inv.TabIndex = 24
        '
        'txt_ket_inv
        '
        Me.txt_ket_inv.Location = New System.Drawing.Point(107, 278)
        Me.txt_ket_inv.MaxLength = 70
        Me.txt_ket_inv.Name = "txt_ket_inv"
        Me.txt_ket_inv.Size = New System.Drawing.Size(443, 22)
        Me.txt_ket_inv.TabIndex = 143
        Me.txt_ket_inv.TabStop = False
        '
        'panelPrintSuratJalanBulanan
        '
        Me.panelPrintSuratJalanBulanan.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.panelPrintSuratJalanBulanan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.Button1)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.dgv_list_sj)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.Label21)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.Label23)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.Label24)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.txt_kosong_tanggal_print_sj_bulanan)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.txt_tanggal_print_sj_bulanan)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.dtp_tanggal_print_sj_bulanan)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.txt_no_sj_print_bulanan)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.txt_kota_client_bulanan)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.txt_alamat_client_bulanan)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.txt_client_bulanan)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.lbl_print_sj_bulanan)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.btn_print_sj_bulanan)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.btn_batal_print_sj_bulanan)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.dgv_print_sj_bulanan)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.txt_ketrangan_sj_bulanan)
        Me.panelPrintSuratJalanBulanan.Location = New System.Drawing.Point(87, 38)
        Me.panelPrintSuratJalanBulanan.Name = "panelPrintSuratJalanBulanan"
        Me.panelPrintSuratJalanBulanan.Size = New System.Drawing.Size(894, 386)
        Me.panelPrintSuratJalanBulanan.TabIndex = 233
        Me.panelPrintSuratJalanBulanan.Visible = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.Control
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button1.Location = New System.Drawing.Point(91, 341)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(117, 30)
        Me.Button1.TabIndex = 156
        Me.Button1.Text = "BATAL"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'dgv_list_sj
        '
        Me.dgv_list_sj.AllowUserToAddRows = False
        Me.dgv_list_sj.AllowUserToDeleteRows = False
        Me.dgv_list_sj.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_sj.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_sj.DefaultCellStyle = DataGridViewCellStyle6
        Me.dgv_list_sj.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_sj.Location = New System.Drawing.Point(270, 144)
        Me.dgv_list_sj.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_sj.MultiSelect = False
        Me.dgv_list_sj.Name = "dgv_list_sj"
        Me.dgv_list_sj.Size = New System.Drawing.Size(538, 156)
        Me.dgv_list_sj.TabIndex = 155
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(521, 67)
        Me.Label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(45, 16)
        Me.Label21.TabIndex = 153
        Me.Label21.Text = "No SJ"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(22, 284)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(83, 16)
        Me.Label23.TabIndex = 152
        Me.Label23.Text = "Keterangan"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(521, 44)
        Me.Label24.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(58, 16)
        Me.Label24.TabIndex = 54
        Me.Label24.Text = "Tanggal"
        '
        'txt_kosong_tanggal_print_sj_bulanan
        '
        Me.txt_kosong_tanggal_print_sj_bulanan.BackColor = System.Drawing.SystemColors.Window
        Me.txt_kosong_tanggal_print_sj_bulanan.Cursor = System.Windows.Forms.Cursors.Hand
        Me.txt_kosong_tanggal_print_sj_bulanan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.txt_kosong_tanggal_print_sj_bulanan.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_kosong_tanggal_print_sj_bulanan.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.txt_kosong_tanggal_print_sj_bulanan.Location = New System.Drawing.Point(753, 41)
        Me.txt_kosong_tanggal_print_sj_bulanan.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.txt_kosong_tanggal_print_sj_bulanan.Name = "txt_kosong_tanggal_print_sj_bulanan"
        Me.txt_kosong_tanggal_print_sj_bulanan.Size = New System.Drawing.Size(27, 22)
        Me.txt_kosong_tanggal_print_sj_bulanan.TabIndex = 151
        Me.txt_kosong_tanggal_print_sj_bulanan.TabStop = False
        Me.txt_kosong_tanggal_print_sj_bulanan.Text = "X"
        Me.txt_kosong_tanggal_print_sj_bulanan.UseMnemonic = False
        Me.txt_kosong_tanggal_print_sj_bulanan.UseVisualStyleBackColor = False
        Me.txt_kosong_tanggal_print_sj_bulanan.Visible = False
        '
        'txt_tanggal_print_sj_bulanan
        '
        Me.txt_tanggal_print_sj_bulanan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_tanggal_print_sj_bulanan.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_tanggal_print_sj_bulanan.Location = New System.Drawing.Point(602, 41)
        Me.txt_tanggal_print_sj_bulanan.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.txt_tanggal_print_sj_bulanan.Name = "txt_tanggal_print_sj_bulanan"
        Me.txt_tanggal_print_sj_bulanan.ReadOnly = True
        Me.txt_tanggal_print_sj_bulanan.Size = New System.Drawing.Size(130, 22)
        Me.txt_tanggal_print_sj_bulanan.TabIndex = 150
        Me.txt_tanggal_print_sj_bulanan.TabStop = False
        '
        'dtp_tanggal_print_sj_bulanan
        '
        Me.dtp_tanggal_print_sj_bulanan.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtp_tanggal_print_sj_bulanan.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtp_tanggal_print_sj_bulanan.Location = New System.Drawing.Point(735, 41)
        Me.dtp_tanggal_print_sj_bulanan.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.dtp_tanggal_print_sj_bulanan.Name = "dtp_tanggal_print_sj_bulanan"
        Me.dtp_tanggal_print_sj_bulanan.Size = New System.Drawing.Size(15, 22)
        Me.dtp_tanggal_print_sj_bulanan.TabIndex = 149
        Me.dtp_tanggal_print_sj_bulanan.TabStop = False
        '
        'txt_no_sj_print_bulanan
        '
        Me.txt_no_sj_print_bulanan.Location = New System.Drawing.Point(602, 64)
        Me.txt_no_sj_print_bulanan.Name = "txt_no_sj_print_bulanan"
        Me.txt_no_sj_print_bulanan.ReadOnly = True
        Me.txt_no_sj_print_bulanan.Size = New System.Drawing.Size(269, 22)
        Me.txt_no_sj_print_bulanan.TabIndex = 148
        Me.txt_no_sj_print_bulanan.TabStop = False
        '
        'txt_kota_client_bulanan
        '
        Me.txt_kota_client_bulanan.Location = New System.Drawing.Point(22, 87)
        Me.txt_kota_client_bulanan.Name = "txt_kota_client_bulanan"
        Me.txt_kota_client_bulanan.ReadOnly = True
        Me.txt_kota_client_bulanan.Size = New System.Drawing.Size(361, 22)
        Me.txt_kota_client_bulanan.TabIndex = 147
        Me.txt_kota_client_bulanan.TabStop = False
        '
        'txt_alamat_client_bulanan
        '
        Me.txt_alamat_client_bulanan.Location = New System.Drawing.Point(22, 64)
        Me.txt_alamat_client_bulanan.Name = "txt_alamat_client_bulanan"
        Me.txt_alamat_client_bulanan.ReadOnly = True
        Me.txt_alamat_client_bulanan.Size = New System.Drawing.Size(361, 22)
        Me.txt_alamat_client_bulanan.TabIndex = 146
        Me.txt_alamat_client_bulanan.TabStop = False
        '
        'txt_client_bulanan
        '
        Me.txt_client_bulanan.Location = New System.Drawing.Point(22, 41)
        Me.txt_client_bulanan.Name = "txt_client_bulanan"
        Me.txt_client_bulanan.ReadOnly = True
        Me.txt_client_bulanan.Size = New System.Drawing.Size(361, 22)
        Me.txt_client_bulanan.TabIndex = 145
        Me.txt_client_bulanan.TabStop = False
        '
        'lbl_print_sj_bulanan
        '
        Me.lbl_print_sj_bulanan.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_print_sj_bulanan.Font = New System.Drawing.Font("Verdana", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_print_sj_bulanan.ForeColor = System.Drawing.SystemColors.Window
        Me.lbl_print_sj_bulanan.Location = New System.Drawing.Point(22, 7)
        Me.lbl_print_sj_bulanan.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_print_sj_bulanan.Name = "lbl_print_sj_bulanan"
        Me.lbl_print_sj_bulanan.Size = New System.Drawing.Size(849, 28)
        Me.lbl_print_sj_bulanan.TabIndex = 144
        Me.lbl_print_sj_bulanan.Text = "PRINT SURAT JALAN SATU BULAN"
        Me.lbl_print_sj_bulanan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn_print_sj_bulanan
        '
        Me.btn_print_sj_bulanan.BackColor = System.Drawing.SystemColors.Control
        Me.btn_print_sj_bulanan.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_print_sj_bulanan.Location = New System.Drawing.Point(286, 331)
        Me.btn_print_sj_bulanan.Margin = New System.Windows.Forms.Padding(4)
        Me.btn_print_sj_bulanan.Name = "btn_print_sj_bulanan"
        Me.btn_print_sj_bulanan.Size = New System.Drawing.Size(117, 30)
        Me.btn_print_sj_bulanan.TabIndex = 27
        Me.btn_print_sj_bulanan.Text = "PRINT"
        Me.btn_print_sj_bulanan.UseVisualStyleBackColor = False
        '
        'btn_batal_print_sj_bulanan
        '
        Me.btn_batal_print_sj_bulanan.BackColor = System.Drawing.SystemColors.Control
        Me.btn_batal_print_sj_bulanan.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_batal_print_sj_bulanan.Location = New System.Drawing.Point(490, 331)
        Me.btn_batal_print_sj_bulanan.Margin = New System.Windows.Forms.Padding(4)
        Me.btn_batal_print_sj_bulanan.Name = "btn_batal_print_sj_bulanan"
        Me.btn_batal_print_sj_bulanan.Size = New System.Drawing.Size(117, 30)
        Me.btn_batal_print_sj_bulanan.TabIndex = 25
        Me.btn_batal_print_sj_bulanan.Text = "BATAL"
        Me.btn_batal_print_sj_bulanan.UseVisualStyleBackColor = False
        '
        'dgv_print_sj_bulanan
        '
        Me.dgv_print_sj_bulanan.AllowUserToAddRows = False
        Me.dgv_print_sj_bulanan.AllowUserToDeleteRows = False
        Me.dgv_print_sj_bulanan.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_print_sj_bulanan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_print_sj_bulanan.DefaultCellStyle = DataGridViewCellStyle7
        Me.dgv_print_sj_bulanan.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_print_sj_bulanan.Location = New System.Drawing.Point(22, 115)
        Me.dgv_print_sj_bulanan.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_print_sj_bulanan.MultiSelect = False
        Me.dgv_print_sj_bulanan.Name = "dgv_print_sj_bulanan"
        Me.dgv_print_sj_bulanan.Size = New System.Drawing.Size(849, 156)
        Me.dgv_print_sj_bulanan.TabIndex = 24
        '
        'txt_ketrangan_sj_bulanan
        '
        Me.txt_ketrangan_sj_bulanan.Location = New System.Drawing.Point(114, 281)
        Me.txt_ketrangan_sj_bulanan.MaxLength = 70
        Me.txt_ketrangan_sj_bulanan.Name = "txt_ketrangan_sj_bulanan"
        Me.txt_ketrangan_sj_bulanan.Size = New System.Drawing.Size(618, 22)
        Me.txt_ketrangan_sj_bulanan.TabIndex = 143
        Me.txt_ketrangan_sj_bulanan.TabStop = False
        '
        'ToolStripButton2
        '
        Me.ToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton2.Name = "ToolStripButton2"
        Me.ToolStripButton2.Size = New System.Drawing.Size(73, 22)
        Me.ToolStripButton2.Text = "Print SJ"
        '
        'form_penjualan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1131, 587)
        Me.Controls.Add(Me.panelPrintSuratJalanBulanan)
        Me.Controls.Add(Me.panelPrintSuratJalan)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.dtp_hari_ini)
        Me.Controls.Add(Me.panelGabung)
        Me.Controls.Add(Me.panelPrintInvoice)
        Me.Controls.Add(Me.dgv1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.txt_total_ppn)
        Me.Controls.Add(Me.txt_total_dpp)
        Me.Controls.Add(Me.txt_gran_total)
        Me.Controls.Add(Me.txt_transfer)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "form_penjualan"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.dgv_supplier, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.panelGabung.ResumeLayout(False)
        Me.panelGabung.PerformLayout()
        CType(Me.dgv2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelPrintSuratJalan.ResumeLayout(False)
        Me.panelPrintSuratJalan.PerformLayout()
        CType(Me.dgv_print_sj, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelPrintInvoice.ResumeLayout(False)
        Me.panelPrintInvoice.PerformLayout()
        CType(Me.dgv_inv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelPrintSuratJalanBulanan.ResumeLayout(False)
        Me.panelPrintSuratJalanBulanan.PerformLayout()
        CType(Me.dgv_list_sj, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_print_sj_bulanan, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents ts_celup_baru As System.Windows.Forms.ToolStripButton
    Friend WithEvents ts_perbarui As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents btn_supplier As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents txt_transfer As System.Windows.Forms.TextBox
    Friend WithEvents txt_total_ppn As System.Windows.Forms.TextBox
    Friend WithEvents txt_total_dpp As System.Windows.Forms.TextBox
    Friend WithEvents txt_gran_total As System.Windows.Forms.TextBox
    Friend WithEvents dgv1 As System.Windows.Forms.DataGridView
    Friend WithEvents dtp_hari_ini As System.Windows.Forms.DateTimePicker
    Friend WithEvents Cbo_Supplier As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents dgv_supplier As System.Windows.Forms.DataGridView
    Friend WithEvents btn_reset As System.Windows.Forms.Button
    Friend WithEvents btn_cari As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents dtp_akhir As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtp_awal As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ts_hapus As System.Windows.Forms.ToolStripButton
    Friend WithEvents ts_edit As System.Windows.Forms.ToolStripButton
    Friend WithEvents ts_kain_baru As System.Windows.Forms.ToolStripButton
    Friend WithEvents ts_generate_sj As System.Windows.Forms.ToolStripButton
    Friend WithEvents txt_total_ppn_kain As System.Windows.Forms.TextBox
    Friend WithEvents txt_total_dpp_kain As System.Windows.Forms.TextBox
    Friend WithEvents txt_gran_total_kain As System.Windows.Forms.TextBox
    Friend WithEvents txt_transfer_kain As System.Windows.Forms.TextBox
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents txt_total_ppn_celup As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txt_total_dpp_celup As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txt_gran_total_celup As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txt_transfer_celup As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents ToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ts_gabung_sj As System.Windows.Forms.ToolStripButton
    Friend WithEvents panelGabung As System.Windows.Forms.Panel
    Friend WithEvents dgv2 As System.Windows.Forms.DataGridView
    Friend WithEvents btnGabung As System.Windows.Forms.Button
    Friend WithEvents btnHapus As System.Windows.Forms.Button
    Friend WithEvents btnBatal As System.Windows.Forms.Button
    Friend WithEvents Txt_kode As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents panelPrintSuratJalan As System.Windows.Forms.Panel
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents btnPrintSj As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents dgv_print_sj As System.Windows.Forms.DataGridView
    Friend WithEvents txt_ket_sj As System.Windows.Forms.TextBox
    Friend WithEvents txt_kota_client As System.Windows.Forms.TextBox
    Friend WithEvents txt_alamat_client As System.Windows.Forms.TextBox
    Friend WithEvents txt_client As System.Windows.Forms.TextBox
    Friend WithEvents txt_no_sj As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents btn_kosong_tanggal_print_sj As System.Windows.Forms.Button
    Friend WithEvents txt_tanggal_print_sj As System.Windows.Forms.TextBox
    Friend WithEvents dtp_tanggal_print_sj As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents panelPrintInvoice As System.Windows.Forms.Panel
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents btn_tanggal_inv As System.Windows.Forms.Button
    Friend WithEvents txt_tanggal_inv As System.Windows.Forms.TextBox
    Friend WithEvents dtp_tanggal_inv As System.Windows.Forms.DateTimePicker
    Friend WithEvents txt_no_sj_inv As System.Windows.Forms.TextBox
    Friend WithEvents txt_kota_client_inv As System.Windows.Forms.TextBox
    Friend WithEvents txt_alamat_client_inv As System.Windows.Forms.TextBox
    Friend WithEvents txt_client_inv As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents btn_print_inv As System.Windows.Forms.Button
    Friend WithEvents btn_batal_inv As System.Windows.Forms.Button
    Friend WithEvents dgv_inv As System.Windows.Forms.DataGridView
    Friend WithEvents txt_ket_inv As System.Windows.Forms.TextBox
    Friend WithEvents ts_print_invoice As System.Windows.Forms.ToolStripButton
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents txt_no_faktur As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txt_total_inv As System.Windows.Forms.TextBox
    Friend WithEvents lblPPN As System.Windows.Forms.Label
    Friend WithEvents txt_ppn_inv As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents txt_dpp_inv As System.Windows.Forms.TextBox
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSplitButton1 As System.Windows.Forms.ToolStripSplitButton
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator9 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SatuanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BulananToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents panelPrintSuratJalanBulanan As System.Windows.Forms.Panel
    Friend WithEvents dgv_list_sj As System.Windows.Forms.DataGridView
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents txt_kosong_tanggal_print_sj_bulanan As System.Windows.Forms.Button
    Friend WithEvents txt_tanggal_print_sj_bulanan As System.Windows.Forms.TextBox
    Friend WithEvents dtp_tanggal_print_sj_bulanan As System.Windows.Forms.DateTimePicker
    Friend WithEvents txt_no_sj_print_bulanan As System.Windows.Forms.TextBox
    Friend WithEvents txt_kota_client_bulanan As System.Windows.Forms.TextBox
    Friend WithEvents txt_alamat_client_bulanan As System.Windows.Forms.TextBox
    Friend WithEvents txt_client_bulanan As System.Windows.Forms.TextBox
    Friend WithEvents lbl_print_sj_bulanan As System.Windows.Forms.Label
    Friend WithEvents btn_print_sj_bulanan As System.Windows.Forms.Button
    Friend WithEvents btn_batal_print_sj_bulanan As System.Windows.Forms.Button
    Friend WithEvents dgv_print_sj_bulanan As System.Windows.Forms.DataGridView
    Friend WithEvents txt_ketrangan_sj_bulanan As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ToolStripButton2 As System.Windows.Forms.ToolStripButton
End Class
