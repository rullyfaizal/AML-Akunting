﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class _00form_coba_print
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panelPrintSuratJalanBulanan = New System.Windows.Forms.Panel()
        Me.dgv_list_sj = New System.Windows.Forms.DataGridView()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txt_kosong_tanggal_print_sj_bulanan = New System.Windows.Forms.Button()
        Me.txt_tanggal_print_sj_bulanan = New System.Windows.Forms.TextBox()
        Me.dtp_tanggal_print_sj_bulanan = New System.Windows.Forms.DateTimePicker()
        Me.txt_no_sj_print_bulanan = New System.Windows.Forms.TextBox()
        Me.txt_kota_client_bulanan = New System.Windows.Forms.TextBox()
        Me.txt_alamat_client_bulanan = New System.Windows.Forms.TextBox()
        Me.txt_client_bulanan = New System.Windows.Forms.TextBox()
        Me.lbl_print_sj_bulanan = New System.Windows.Forms.Label()
        Me.btn_print_sj_bulanan = New System.Windows.Forms.Button()
        Me.btn_batal_print_sj_bulanan = New System.Windows.Forms.Button()
        Me.dgv_print_sj_bulanan = New System.Windows.Forms.DataGridView()
        Me.txt_ketrangan_sj_bulanan = New System.Windows.Forms.TextBox()
        Me.dtp_awal = New System.Windows.Forms.DateTimePicker()
        Me.panelPrintSuratJalanBulanan.SuspendLayout()
        CType(Me.dgv_list_sj, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_print_sj_bulanan, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'panelPrintSuratJalanBulanan
        '
        Me.panelPrintSuratJalanBulanan.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.panelPrintSuratJalanBulanan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.dgv_list_sj)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.Label21)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.Label23)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.Label24)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.txt_kosong_tanggal_print_sj_bulanan)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.txt_tanggal_print_sj_bulanan)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.dtp_tanggal_print_sj_bulanan)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.txt_no_sj_print_bulanan)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.txt_kota_client_bulanan)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.txt_alamat_client_bulanan)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.txt_client_bulanan)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.lbl_print_sj_bulanan)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.btn_print_sj_bulanan)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.btn_batal_print_sj_bulanan)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.dgv_print_sj_bulanan)
        Me.panelPrintSuratJalanBulanan.Controls.Add(Me.txt_ketrangan_sj_bulanan)
        Me.panelPrintSuratJalanBulanan.Location = New System.Drawing.Point(59, 44)
        Me.panelPrintSuratJalanBulanan.Name = "panelPrintSuratJalanBulanan"
        Me.panelPrintSuratJalanBulanan.Size = New System.Drawing.Size(894, 386)
        Me.panelPrintSuratJalanBulanan.TabIndex = 234
        '
        'dgv_list_sj
        '
        Me.dgv_list_sj.AllowUserToAddRows = False
        Me.dgv_list_sj.AllowUserToDeleteRows = False
        Me.dgv_list_sj.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_list_sj.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_list_sj.DefaultCellStyle = DataGridViewCellStyle11
        Me.dgv_list_sj.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_list_sj.Location = New System.Drawing.Point(270, 144)
        Me.dgv_list_sj.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_list_sj.MultiSelect = False
        Me.dgv_list_sj.Name = "dgv_list_sj"
        Me.dgv_list_sj.Size = New System.Drawing.Size(538, 156)
        Me.dgv_list_sj.TabIndex = 155
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(521, 67)
        Me.Label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(45, 16)
        Me.Label21.TabIndex = 153
        Me.Label21.Text = "No SJ"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(22, 284)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(83, 16)
        Me.Label23.TabIndex = 152
        Me.Label23.Text = "Keterangan"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(521, 44)
        Me.Label24.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(58, 16)
        Me.Label24.TabIndex = 54
        Me.Label24.Text = "Tanggal"
        '
        'txt_kosong_tanggal_print_sj_bulanan
        '
        Me.txt_kosong_tanggal_print_sj_bulanan.BackColor = System.Drawing.SystemColors.Window
        Me.txt_kosong_tanggal_print_sj_bulanan.Cursor = System.Windows.Forms.Cursors.Hand
        Me.txt_kosong_tanggal_print_sj_bulanan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.txt_kosong_tanggal_print_sj_bulanan.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_kosong_tanggal_print_sj_bulanan.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.txt_kosong_tanggal_print_sj_bulanan.Location = New System.Drawing.Point(753, 41)
        Me.txt_kosong_tanggal_print_sj_bulanan.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.txt_kosong_tanggal_print_sj_bulanan.Name = "txt_kosong_tanggal_print_sj_bulanan"
        Me.txt_kosong_tanggal_print_sj_bulanan.Size = New System.Drawing.Size(27, 22)
        Me.txt_kosong_tanggal_print_sj_bulanan.TabIndex = 151
        Me.txt_kosong_tanggal_print_sj_bulanan.TabStop = False
        Me.txt_kosong_tanggal_print_sj_bulanan.Text = "X"
        Me.txt_kosong_tanggal_print_sj_bulanan.UseMnemonic = False
        Me.txt_kosong_tanggal_print_sj_bulanan.UseVisualStyleBackColor = False
        Me.txt_kosong_tanggal_print_sj_bulanan.Visible = False
        '
        'txt_tanggal_print_sj_bulanan
        '
        Me.txt_tanggal_print_sj_bulanan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_tanggal_print_sj_bulanan.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_tanggal_print_sj_bulanan.Location = New System.Drawing.Point(602, 41)
        Me.txt_tanggal_print_sj_bulanan.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.txt_tanggal_print_sj_bulanan.Name = "txt_tanggal_print_sj_bulanan"
        Me.txt_tanggal_print_sj_bulanan.ReadOnly = True
        Me.txt_tanggal_print_sj_bulanan.Size = New System.Drawing.Size(130, 22)
        Me.txt_tanggal_print_sj_bulanan.TabIndex = 150
        Me.txt_tanggal_print_sj_bulanan.TabStop = False
        '
        'dtp_tanggal_print_sj_bulanan
        '
        Me.dtp_tanggal_print_sj_bulanan.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtp_tanggal_print_sj_bulanan.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtp_tanggal_print_sj_bulanan.Location = New System.Drawing.Point(735, 41)
        Me.dtp_tanggal_print_sj_bulanan.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.dtp_tanggal_print_sj_bulanan.Name = "dtp_tanggal_print_sj_bulanan"
        Me.dtp_tanggal_print_sj_bulanan.Size = New System.Drawing.Size(15, 22)
        Me.dtp_tanggal_print_sj_bulanan.TabIndex = 149
        Me.dtp_tanggal_print_sj_bulanan.TabStop = False
        '
        'txt_no_sj_print_bulanan
        '
        Me.txt_no_sj_print_bulanan.Location = New System.Drawing.Point(602, 64)
        Me.txt_no_sj_print_bulanan.Name = "txt_no_sj_print_bulanan"
        Me.txt_no_sj_print_bulanan.ReadOnly = True
        Me.txt_no_sj_print_bulanan.Size = New System.Drawing.Size(269, 20)
        Me.txt_no_sj_print_bulanan.TabIndex = 148
        Me.txt_no_sj_print_bulanan.TabStop = False
        '
        'txt_kota_client_bulanan
        '
        Me.txt_kota_client_bulanan.Location = New System.Drawing.Point(22, 87)
        Me.txt_kota_client_bulanan.Name = "txt_kota_client_bulanan"
        Me.txt_kota_client_bulanan.ReadOnly = True
        Me.txt_kota_client_bulanan.Size = New System.Drawing.Size(361, 20)
        Me.txt_kota_client_bulanan.TabIndex = 147
        Me.txt_kota_client_bulanan.TabStop = False
        '
        'txt_alamat_client_bulanan
        '
        Me.txt_alamat_client_bulanan.Location = New System.Drawing.Point(22, 64)
        Me.txt_alamat_client_bulanan.Name = "txt_alamat_client_bulanan"
        Me.txt_alamat_client_bulanan.ReadOnly = True
        Me.txt_alamat_client_bulanan.Size = New System.Drawing.Size(361, 20)
        Me.txt_alamat_client_bulanan.TabIndex = 146
        Me.txt_alamat_client_bulanan.TabStop = False
        '
        'txt_client_bulanan
        '
        Me.txt_client_bulanan.Location = New System.Drawing.Point(22, 41)
        Me.txt_client_bulanan.Name = "txt_client_bulanan"
        Me.txt_client_bulanan.ReadOnly = True
        Me.txt_client_bulanan.Size = New System.Drawing.Size(361, 20)
        Me.txt_client_bulanan.TabIndex = 145
        Me.txt_client_bulanan.TabStop = False
        '
        'lbl_print_sj_bulanan
        '
        Me.lbl_print_sj_bulanan.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.lbl_print_sj_bulanan.Font = New System.Drawing.Font("Verdana", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_print_sj_bulanan.ForeColor = System.Drawing.SystemColors.Window
        Me.lbl_print_sj_bulanan.Location = New System.Drawing.Point(22, 7)
        Me.lbl_print_sj_bulanan.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_print_sj_bulanan.Name = "lbl_print_sj_bulanan"
        Me.lbl_print_sj_bulanan.Size = New System.Drawing.Size(849, 28)
        Me.lbl_print_sj_bulanan.TabIndex = 144
        Me.lbl_print_sj_bulanan.Text = "PRINT SURAT JALAN SATU BULAN"
        Me.lbl_print_sj_bulanan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn_print_sj_bulanan
        '
        Me.btn_print_sj_bulanan.BackColor = System.Drawing.SystemColors.Control
        Me.btn_print_sj_bulanan.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_print_sj_bulanan.Location = New System.Drawing.Point(286, 331)
        Me.btn_print_sj_bulanan.Margin = New System.Windows.Forms.Padding(4)
        Me.btn_print_sj_bulanan.Name = "btn_print_sj_bulanan"
        Me.btn_print_sj_bulanan.Size = New System.Drawing.Size(117, 30)
        Me.btn_print_sj_bulanan.TabIndex = 27
        Me.btn_print_sj_bulanan.Text = "PRINT"
        Me.btn_print_sj_bulanan.UseVisualStyleBackColor = False
        '
        'btn_batal_print_sj_bulanan
        '
        Me.btn_batal_print_sj_bulanan.BackColor = System.Drawing.SystemColors.Control
        Me.btn_batal_print_sj_bulanan.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_batal_print_sj_bulanan.Location = New System.Drawing.Point(490, 331)
        Me.btn_batal_print_sj_bulanan.Margin = New System.Windows.Forms.Padding(4)
        Me.btn_batal_print_sj_bulanan.Name = "btn_batal_print_sj_bulanan"
        Me.btn_batal_print_sj_bulanan.Size = New System.Drawing.Size(117, 30)
        Me.btn_batal_print_sj_bulanan.TabIndex = 25
        Me.btn_batal_print_sj_bulanan.Text = "BATAL"
        Me.btn_batal_print_sj_bulanan.UseVisualStyleBackColor = False
        '
        'dgv_print_sj_bulanan
        '
        Me.dgv_print_sj_bulanan.AllowUserToAddRows = False
        Me.dgv_print_sj_bulanan.AllowUserToDeleteRows = False
        Me.dgv_print_sj_bulanan.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_print_sj_bulanan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_print_sj_bulanan.DefaultCellStyle = DataGridViewCellStyle12
        Me.dgv_print_sj_bulanan.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_print_sj_bulanan.Location = New System.Drawing.Point(22, 115)
        Me.dgv_print_sj_bulanan.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_print_sj_bulanan.MultiSelect = False
        Me.dgv_print_sj_bulanan.Name = "dgv_print_sj_bulanan"
        Me.dgv_print_sj_bulanan.Size = New System.Drawing.Size(849, 156)
        Me.dgv_print_sj_bulanan.TabIndex = 24
        '
        'txt_ketrangan_sj_bulanan
        '
        Me.txt_ketrangan_sj_bulanan.Location = New System.Drawing.Point(114, 281)
        Me.txt_ketrangan_sj_bulanan.MaxLength = 70
        Me.txt_ketrangan_sj_bulanan.Name = "txt_ketrangan_sj_bulanan"
        Me.txt_ketrangan_sj_bulanan.Size = New System.Drawing.Size(618, 20)
        Me.txt_ketrangan_sj_bulanan.TabIndex = 143
        Me.txt_ketrangan_sj_bulanan.TabStop = False
        '
        'dtp_awal
        '
        Me.dtp_awal.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtp_awal.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtp_awal.Location = New System.Drawing.Point(250, 14)
        Me.dtp_awal.Margin = New System.Windows.Forms.Padding(4)
        Me.dtp_awal.Name = "dtp_awal"
        Me.dtp_awal.Size = New System.Drawing.Size(115, 23)
        Me.dtp_awal.TabIndex = 235
        '
        '_00form_coba_print
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1013, 475)
        Me.Controls.Add(Me.dtp_awal)
        Me.Controls.Add(Me.panelPrintSuratJalanBulanan)
        Me.Name = "_00form_coba_print"
        Me.Text = "_00form_coba_print"
        Me.panelPrintSuratJalanBulanan.ResumeLayout(False)
        Me.panelPrintSuratJalanBulanan.PerformLayout()
        CType(Me.dgv_list_sj, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_print_sj_bulanan, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents panelPrintSuratJalanBulanan As System.Windows.Forms.Panel
    Friend WithEvents dgv_list_sj As System.Windows.Forms.DataGridView
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents txt_kosong_tanggal_print_sj_bulanan As System.Windows.Forms.Button
    Friend WithEvents txt_tanggal_print_sj_bulanan As System.Windows.Forms.TextBox
    Friend WithEvents dtp_tanggal_print_sj_bulanan As System.Windows.Forms.DateTimePicker
    Friend WithEvents txt_no_sj_print_bulanan As System.Windows.Forms.TextBox
    Friend WithEvents txt_kota_client_bulanan As System.Windows.Forms.TextBox
    Friend WithEvents txt_alamat_client_bulanan As System.Windows.Forms.TextBox
    Friend WithEvents txt_client_bulanan As System.Windows.Forms.TextBox
    Friend WithEvents lbl_print_sj_bulanan As System.Windows.Forms.Label
    Friend WithEvents btn_print_sj_bulanan As System.Windows.Forms.Button
    Friend WithEvents btn_batal_print_sj_bulanan As System.Windows.Forms.Button
    Friend WithEvents dgv_print_sj_bulanan As System.Windows.Forms.DataGridView
    Friend WithEvents txt_ketrangan_sj_bulanan As System.Windows.Forms.TextBox
    Friend WithEvents dtp_awal As System.Windows.Forms.DateTimePicker
End Class
