﻿Imports MySql.Data.MySqlClient

Public Class form_retur

    Dim ppn As Double
    Private Sub isi_ppn()
        Try
            Using conx As New MySqlConnection(sLocalConn)
                conx.Open()
                Dim sqlx = "SELECT ppn from tbppn WHERE id ='ppn'"
                Using cmdx As New MySqlCommand(sqlx, conx)
                    Using drx As MySqlDataReader = cmdx.ExecuteReader
                        drx.Read()
                        ppn = drx(0)
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
    End Sub

    Private Sub form_retur_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call isi_ppn()
    End Sub

    Private Sub btn_batal_retur_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_batal_retur.Click
        Me.Close()
    End Sub

    Private Sub isidgvpembelian()
        Try
            dgv1.Columns.Clear()
            Using conx As New MySqlConnection(sLocalConn)
                conx.Open()
                Dim sqlx As String = "SELECT * FROM tbpembelian WHERE kode = '" & txt_kode_induk.Text & "' ORDER BY baris ASC"
                Using cmdx As New MySqlCommand(sqlx, conx)
                    Using dax As New MySqlDataAdapter
                        dax.SelectCommand = cmdx
                        Using dsx As New DataSet
                            dax.Fill(dsx, "tbpembelian")
                            dgv1.DataSource = dsx.Tables("tbpembelian")
                        End Using
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub isidgvgrey()
        Try
            dgv2.Columns.Clear()
            Using conx As New MySqlConnection(sLocalConn)
                conx.Open()
                Dim sqlx As String = "SELECT * FROM tbgrey WHERE kode = '" & txt_kode_induk.Text & "'"
                Using cmdx As New MySqlCommand(sqlx, conx)
                    Using dax As New MySqlDataAdapter
                        dax.SelectCommand = cmdx
                        Using dsx As New DataSet
                            dax.Fill(dsx, "tbpembelian")
                            dgv2.DataSource = dsx.Tables("tbpembelian")
                        End Using
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub txt_kode_induk_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_kode_induk.TextChanged
        Call isidgvpembelian()
        Call isidgvgrey()
        If dgv2.RowCount = 0 Then
            MsgBox("Silahkah Input Harga Greynya terlebih dahulu agar Grey masuk ke Stok")
            Me.Close()
        Else
            Dim total As Decimal = 0
            For Each row As DataGridViewRow In dgv2.Rows
                ' Pastikan baris bukan baris baru (new row)
                If Not row.IsNewRow Then
                    ' Cek apakah nilai di kolom ke-10 tidak kosong dan valid
                    If Not IsDBNull(row.Cells(9).Value) AndAlso row.Cells(9).Value IsNot Nothing Then
                        Dim nilai As Decimal
                        If Decimal.TryParse(row.Cells(9).Value.ToString(), nilai) Then
                            total += nilai
                        End If
                    End If
                End If
            Next
            If total <= 0 Then
                MsgBox("Grey yang dipilih sudah terpakai semua")
                Me.Close()
            End If
        End If
    End Sub

    Private Sub dgv2_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgv2.CellMouseClick
        Try
            If dgv1.RowCount = 0 Then
                MsgBox("Tidak Terdapat data untuk Di tampilkan")
            Else
                txt_id_grey_retur.Text = dgv2.CurrentRow.Cells(0).Value.ToString()
                txt_nama_grey_retur.Text = dgv2.CurrentRow.Cells(5).Value.ToString()
                txt_jumlah_asal.Text = dgv2.CurrentRow.Cells(9).Value.ToString()
                txt_dpp_asal.Text = dgv2.CurrentRow.Cells(10).Value.ToString()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btn_hitung_retur_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_hitung_retur.Click
        Dim angka1 As Decimal
        Dim angka2 As Decimal
        If txt_jumlah_retur.Text = "" Then
            MsgBox("Jumlah GREY yang akan di RETUR belum diinput")
            txt_jumlah_retur.Focus()
        ElseIf Decimal.TryParse(txt_jumlah_retur.Text, Globalization.NumberStyles.Any, Globalization.CultureInfo.CurrentCulture, angka1) _
            AndAlso Decimal.TryParse(txt_jumlah_asal.Text, Globalization.NumberStyles.Any, Globalization.CultureInfo.CurrentCulture, angka2) Then
            If angka1 > angka2 Then
                MessageBox.Show("Jumlah RETUR GREY tidak boleh melebihi stok yang ada")
                txt_jumlah_retur.Focus()
            Else
                MessageBox.Show("SIP")
            End If
        End If

    End Sub
End Class