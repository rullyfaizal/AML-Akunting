﻿Imports MySql.Data.MySqlClient
Imports System.Globalization
Imports OfficeOpenXml
Imports OfficeOpenXml.Style
Imports System.IO

Public Class form_invoice_bulanan
    Dim FormatID As New CultureInfo("id-ID")
    'Fungsi potong nama client
    Private Function AmbilDuaKata(ByVal txt As TextBox) As String
        Dim kata() As String = txt.Text.Trim().Split(" "c)
        If kata.Length >= 2 Then
            Return kata(0) & " " & kata(1)
        ElseIf kata.Length = 1 Then
            Return kata(0)
        Else
            Return ""
        End If
    End Function
    'Fungsi potong alamat client
    Private Function AmbilDelapanKata(ByVal txt As TextBox) As String
        Dim kata() As String = txt.Text.Trim().Split(" "c)
        Dim hasil As String = ""
        Dim jumlahKata As Integer = Math.Min(8, kata.Length)
        For i As Integer = 0 To jumlahKata - 1
            hasil &= kata(i) & " "
        Next
        Return hasil.Trim()
    End Function
    ' Fungsi untuk mendapatkan nilai Decimal dari sel DGV
    Private Function GetDecimalValue(ByVal cellValue As Object, Optional ByVal defaultValue As Decimal = 0) As Decimal
        Dim result As Decimal
        If cellValue IsNot Nothing AndAlso Not IsDBNull(cellValue) AndAlso Decimal.TryParse(cellValue.ToString(), result) Then
            Return result
        End If
        Return defaultValue
    End Function
    ' Fungsi untuk mendapatkan nilai String dari sel DGV
    Private Function GetStringValue(ByVal cellValue As Object, Optional ByVal defaultValue As String = "") As String
        If cellValue IsNot Nothing AndAlso Not IsDBNull(cellValue) Then
            Return cellValue.ToString().Trim()
        End If
        Return defaultValue
    End Function

    Private Sub btn_batal_print_sj_bulanan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_batal_print_sj_bulanan.Click
        Me.Close()
    End Sub

    Private Sub dtp_tanggal_print_sj_bulanan_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtp_tanggal_print_sj_bulanan.ValueChanged
        dgv_list_sj.Columns.Clear()
        Dim namaBulan As String = dtp_tanggal_print_sj_bulanan.Value.ToString("MMMM", New Globalization.CultureInfo("id-ID")).ToUpper()
        Dim namaTahun As String = dtp_tanggal_print_sj_bulanan.Value.ToString("yyyy")
        Dim selectedDate As DateTime = dtp_tanggal_print_sj_bulanan.Value
        txt_bulan.Text = selectedDate.ToString("MMMM yyyy", FormatID)
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Dim sqlx As String = "SELECT DISTINCT surat_jalan, supplier, tanggal, status FROM tbpenjualan " &
                                 "WHERE MONTH(tanggal) = @bulan AND YEAR(tanggal) = @tahun " &
                                 "ORDER BY surat_jalan ASC"
            Using cmdx As New MySqlCommand(sqlx, conx)
                cmdx.Parameters.AddWithValue("@bulan", dtp_tanggal_print_sj_bulanan.Value.Month)
                cmdx.Parameters.AddWithValue("@tahun", dtp_tanggal_print_sj_bulanan.Value.Year)
                Using dax As New MySqlDataAdapter
                    dax.SelectCommand = cmdx
                    Using dsx As New DataSet
                        dax.Fill(dsx, "surat_jalan")
                        dgv_list_sj.DataSource = dsx.Tables("surat_jalan")
                        dgv_list_sj.RowHeadersWidth = 60
                        dgv_list_sj.Columns(0).Width = 170
                        dgv_list_sj.Columns(0).HeaderText = "SURAT JALAN"
                        dgv_list_sj.Columns(1).Width = 250
                        dgv_list_sj.Columns(1).HeaderText = "CLIENT"
                        dgv_list_sj.Columns(2).Width = 100
                        dgv_list_sj.Columns(2).HeaderText = "TANGGAL"
                        dgv_list_sj.Columns(3).Visible = False
                    End Using
                End Using
            End Using
        End Using
    End Sub
End Class