﻿Imports MySql.Data.MySqlClient
Imports OfficeOpenXml
Imports OfficeOpenXml.Style
Imports System.IO

Public Class form_laporan_keuangan

    Private Sub form_laporan_keuangan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call isi_ppn()
        TabControl1.TabPages.Remove(TabPage1)
        TabControl1.TabPages.Remove(TabPage2)
        TabControl1.TabPages.Remove(TabPage3)
        TabControl1.TabPages.Remove(TabPage4)
        TabControl1.TabPages.Remove(TabPage5)
        TabControl1.TabPages.Remove(TabPage9)
    End Sub

    Dim ppn, pph23, pph22 As Double
    Private Sub isi_ppn()
        Try
            Using conx As New MySqlConnection(sLocalConn)
                conx.Open()
                Dim sqlx = "SELECT ppn,pph23,pph22 from tbppn WHERE id ='ppn'"
                Using cmdx As New MySqlCommand(sqlx, conx)
                    Using drx As MySqlDataReader = cmdx.ExecuteReader
                        drx.Read()
                        ppn = drx(0)
                        pph23 = drx(1)
                        pph22 = drx(2)
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            Exit Sub
        End Try
    End Sub

    Private Sub btn_generate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_generate.Click
        Try
            If btn_generate.Text = "GENERATE" Then
                btn_generate.Text = "EKSPOR"
                btn_reset.Enabled = True

                Call tampil_spt()

                Call tampil_data_bukpot()
                Call LoadDataPLN()

            Else
                Dim txtdate, txttahun As New TextBox
                Dim dtptoday As New DateTimePicker
                dtptoday.Value = DateTime.Now
                txtdate.Text = dtptoday.Value.ToString("dd-MM-yyyy HH:mm:ss")
                txttahun.Text = dtp_tahun.Value.ToString("yyyy")
                Export("D:\Ekspor\Laporan Keuangan Tahun " & txttahun.Text & " " & txtdate.Text.Replace("-", "").Replace(":", "") & ".xlsx")
                btn_reset.PerformClick()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub tampil_data_bukpot()
        dgv_bukpot.Columns.Clear()
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Dim selectedYear As Integer = dtp_tahun.Value.Year
            Dim sqlx As String = "SELECT id_jual, supplier, npwp, tanggal, no_faktur, dpp, ppn, pph23, pph23_actual, no_bukpot, tgl_bukpot, masa_bukpot, gabung_bukpot " &
                                 "FROM tbpenjualan " &
                                 "WHERE no_bukpot <> '' " &
                                 "AND jenis_biaya = 'Jasa' " &
                                 "AND no_faktur <> '' " &
                                 "AND YEAR(masa_bukpot) = " & selectedYear & " " &
                                 "ORDER BY tgl_bukpot ASC, no_bukpot ASC, supplier ASC, pph23_actual DESC"

            Using cmdx As New MySqlCommand(sqlx, conx)
                Using dax As New MySqlDataAdapter
                    dax.SelectCommand = cmdx
                    Using dsx As New DataSet
                        dax.Fill(dsx, "tbpenjualan")
                        dgv_bukpot.DataSource = dsx.Tables("tbpenjualan")
                    End Using
                End Using
            End Using
        End Using

        dgv_bukpot.Columns(1).HeaderText = "CUSTOMER"
        dgv_bukpot.Columns(2).HeaderText = "NPWP"
        dgv_bukpot.Columns(3).HeaderText = "TANGGAL"
        dgv_bukpot.Columns(4).HeaderText = "NO FAKTUR"
        dgv_bukpot.Columns(5).HeaderText = "DPP"
        dgv_bukpot.Columns(6).HeaderText = "PPN"
        dgv_bukpot.Columns(7).HeaderText = "PPH 23"
        dgv_bukpot.Columns(8).HeaderText = "PPH23 ACTUAL"
        dgv_bukpot.Columns(9).HeaderText = "NO BUKPOT"
        dgv_bukpot.Columns(10).HeaderText = "TGL BUKPOT"
        dgv_bukpot.Columns(11).HeaderText = "MASA BUKPOT"
        For Each column As DataGridViewColumn In dgv_bukpot.Columns
            column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        Next
        dgv_bukpot.RowHeadersWidth = 60
        dgv_bukpot.Columns(0).Visible = False
        dgv_bukpot.Columns(12).Visible = False
        dgv_bukpot.Columns(1).Width = 220
        dgv_bukpot.Columns(2).Width = 160
        dgv_bukpot.Columns(3).Width = 85
        dgv_bukpot.Columns(4).Width = 160
        dgv_bukpot.Columns(5).Width = 120
        dgv_bukpot.Columns(6).Width = 120
        dgv_bukpot.Columns(7).Width = 120
        dgv_bukpot.Columns(8).Width = 140
        dgv_bukpot.Columns(9).Width = 120
        dgv_bukpot.Columns(10).Width = 120
        dgv_bukpot.Columns(11).Width = 120
        dgv_bukpot.Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_bukpot.Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_bukpot.Columns(7).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_bukpot.Columns(8).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_bukpot.Columns(9).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_bukpot.Columns(10).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_bukpot.Columns(11).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_bukpot.Columns(12).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_bukpot.Columns(5).DefaultCellStyle.Format = "#,##0.00"
        dgv_bukpot.Columns(6).DefaultCellStyle.Format = "#,##0.00"
        dgv_bukpot.Columns(7).DefaultCellStyle.Format = "#,##0.00"
        dgv_bukpot.Columns(8).DefaultCellStyle.Format = "#,##0.00"
        dgv_bukpot.Columns(10).DefaultCellStyle.Format = "dd-MMM-yy"
        dgv_bukpot.Columns(11).DefaultCellStyle.Format = "MMMM-yy"

        For Each col As DataGridViewColumn In dgv_bukpot.Columns
            col.SortMode = DataGridViewColumnSortMode.NotSortable
        Next
    End Sub
    Private Sub dgv_bukpot_CellFormatting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles dgv_bukpot.CellFormatting
        dgv_bukpot.Rows(e.RowIndex).HeaderCell.Value = (e.RowIndex + 1).ToString()
    End Sub

    Private Sub LoadDataPLN()
        dgv_pln.Columns.Clear()
        Call setup_dgv_pln()

        Dim tahun As Integer = dtp_tahun.Value.Year ' Ambil tahun dari DateTimePicker

        ' Query untuk PLN
        Dim queryPLN As String =
            "SELECT MONTH(tanggal) AS bulan, SUM(total) AS total_pln " &
            "FROM tbpembelian " &
            "WHERE jenis_biaya = 'BIAYA LISTRIK PABRIK' AND YEAR(tanggal) = @tahun " &
            "GROUP BY MONTH(tanggal) ORDER BY MONTH(tanggal);"

        ' Query untuk GARAM
        Dim queryGARAM As String =
            "SELECT MONTH(tanggal) AS bulan, SUM(total) AS total_garam " &
            "FROM tbpembelian " &
            "WHERE jenis_biaya = 'BIAYA GARAM' AND YEAR(tanggal) = @tahun " &
            "GROUP BY MONTH(tanggal) ORDER BY MONTH(tanggal);"

        ' Query untuk COAL
        Dim queryCOAL As String =
            "SELECT MONTH(tanggal) AS bulan, SUM(dpp) AS total_coal " &
            "FROM tbpembelian " &
            "WHERE jenis_biaya = 'BATUBARA' AND YEAR(tanggal) = @tahun " &
            "GROUP BY MONTH(tanggal) ORDER BY MONTH(tanggal);"

        ' Kosongkan semua kolom sebelum diisi ulang
        For Each row As DataGridViewRow In dgv_pln.Rows
            row.Cells("PLN").Value = 0
            row.Cells("GARAM").Value = 0
            row.Cells("COAL").Value = 0
            row.Cells("PPH 22 COAL").Value = 0
        Next

        ' Proses PLN
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Using cmd As New MySqlCommand(queryPLN, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim bulan As Integer = reader.GetInt32("bulan")
                        Dim total_pln As Decimal = reader.GetDecimal("total_pln")
                        If bulan >= 1 And bulan <= 12 Then
                            dgv_pln.Rows(bulan - 1).Cells("PLN").Value = total_pln
                        End If
                    End While
                End Using
            End Using

            ' Proses GARAM
            Using cmd As New MySqlCommand(queryGARAM, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim bulan As Integer = reader.GetInt32("bulan")
                        Dim total_garam As Decimal = reader.GetDecimal("total_garam")
                        If bulan >= 1 And bulan <= 12 Then
                            dgv_pln.Rows(bulan - 1).Cells("GARAM").Value = total_garam
                        End If
                    End While
                End Using
            End Using

            ' Proses COAL
            Using cmd As New MySqlCommand(queryCOAL, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim bulan As Integer = reader.GetInt32("bulan")
                        Dim total_coal As Decimal = reader.GetDecimal("total_coal")
                        If bulan >= 1 And bulan <= 12 Then
                            dgv_pln.Rows(bulan - 1).Cells("COAL").Value = total_coal
                            ' Hitung PPH 22 COAL (COAL * PPN 22 dari variabel global)
                            dgv_pln.Rows(bulan - 1).Cells("PPH 22 COAL").Value = total_coal * (pph22 / 100)
                        End If
                    End While
                End Using
            End Using
        End Using

        For Each col As DataGridViewColumn In dgv_pln.Columns
            col.SortMode = DataGridViewColumnSortMode.NotSortable
        Next
    End Sub
    Private Sub setup_dgv_pln()
        dgv_pln.ColumnCount = 5
        dgv_pln.Columns(0).Name = ""
        dgv_pln.Columns(1).Name = "PLN"
        dgv_pln.Columns(2).Name = "GARAM"
        dgv_pln.Columns(3).Name = "COAL"
        dgv_pln.Columns(4).Name = "PPH 22 COAL"

        Dim bulanArray As String() = {"JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"}
        For Each bulan As String In bulanArray
            dgv_pln.Rows.Add(bulan, 0, 0, 0, 0)
        Next
        dgv_pln.Columns(1).Width = 120
        dgv_pln.Columns(2).Width = 120
        dgv_pln.Columns(3).Width = 120
        dgv_pln.Columns(4).Width = 120
        dgv_pln.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_pln.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_pln.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_pln.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_pln.Columns(1).DefaultCellStyle.Format = "#,##0.00"
        dgv_pln.Columns(2).DefaultCellStyle.Format = "#,##0.00"
        dgv_pln.Columns(3).DefaultCellStyle.Format = "#,##0.00"
        dgv_pln.Columns(4).DefaultCellStyle.Format = "#,##0.00"
    End Sub

    Private Sub tampil_spt()
        dgv_spt_aml.Columns.Clear()
        Call headertablesptaml()
        Dim tahun As Integer = dtp_tahun.Value.Year ' Ambil tahun dari DateTimePicker
        ' Query untuk Pembelian
        Dim querypembelian As String =
            "SELECT MONTH(tanggal_upload) AS bulan, SUM(total_dpp) AS total_beli, SUM(total_ppn) AS total_ppn_beli " &
            "FROM tbindukpembelian " &
            "WHERE YEAR(tanggal_upload) = @tahun " &
            "GROUP BY MONTH(tanggal_upload) ORDER BY MONTH(tanggal_upload);"
        ' Query untuk Penjualan
        Dim querypenjualan As String =
            "SELECT MONTH(tanggal) AS bulan, SUM(dpp) AS total_jual, SUM(ppn) AS total_ppn_jual " &
            "FROM tbpenjualan " &
            "WHERE YEAR(tanggal) = @tahun " &
            "GROUP BY MONTH(tanggal) ORDER BY MONTH(tanggal);"
        ' Kosongkan semua kolom sebelum diisi ulang
        For Each row As DataGridViewRow In dgv_spt_aml.Rows
            row.Cells("NILAI MASUKAN").Value = 0
            row.Cells("NILAI KELUARAN").Value = 0
            row.Cells("PPN MASUKAN").Value = 0
            row.Cells("PPN KELUARAN").Value = 0
            row.Cells("PPN DISETOR").Value = 0
        Next
        ' Proses Pembelian
        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Using cmd As New MySqlCommand(querypembelian, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim bulan As Integer = reader.GetInt32("bulan")
                        Dim total_beli As Decimal = reader.GetDecimal("total_beli")
                        Dim total_ppn_beli As Decimal = reader.GetDecimal("total_ppn_beli")
                        If bulan >= 1 And bulan <= 12 Then
                            dgv_spt_aml.Rows(bulan - 1).Cells("NILAI MASUKAN").Value = total_beli
                            dgv_spt_aml.Rows(bulan - 1).Cells("PPN MASUKAN").Value = total_ppn_beli
                        End If
                    End While
                End Using
            End Using
            ' Proses Penjualan
            Using cmd As New MySqlCommand(querypenjualan, conx)
                cmd.Parameters.AddWithValue("@tahun", tahun)
                Using reader As MySqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim bulan As Integer = reader.GetInt32("bulan")
                        Dim total_jual As Decimal = reader.GetDecimal("total_jual")
                        Dim total_ppn_jual As Decimal = reader.GetDecimal("total_ppn_jual")
                        If bulan >= 1 And bulan <= 12 Then
                            dgv_spt_aml.Rows(bulan - 1).Cells("NILAI KELUARAN").Value = total_jual
                            dgv_spt_aml.Rows(bulan - 1).Cells("PPN KELUARAN").Value = total_ppn_jual
                        End If
                    End While
                End Using
            End Using
            ' Hitung PPN DISETOR
            For Each row As DataGridViewRow In dgv_spt_aml.Rows
                ' Pastikan baris bukan baris kosong baru
                If Not row.IsNewRow Then
                    ' Ambil nilai PPN Keluaran dan PPN Masukan
                    Dim ppnKeluaran As Decimal = 0
                    Dim ppnMasukan As Decimal = 0

                    ' Pastikan nilai tidak kosong sebelum parsing
                    If Not IsDBNull(row.Cells("PPN KELUARAN").Value) AndAlso IsNumeric(row.Cells("PPN KELUARAN").Value) Then
                        ppnKeluaran = Convert.ToDecimal(row.Cells("PPN KELUARAN").Value)
                    End If
                    If Not IsDBNull(row.Cells("PPN MASUKAN").Value) AndAlso IsNumeric(row.Cells("PPN MASUKAN").Value) Then
                        ppnMasukan = Convert.ToDecimal(row.Cells("PPN MASUKAN").Value)
                    End If

                    ' Hitung selisih
                    Dim selisihPPN As Decimal = ppnKeluaran - ppnMasukan

                    ' Masukkan selisih ke kolom baru
                    row.Cells("PPN DISETOR").Value = selisihPPN
                End If
            Next
        End Using

        Using conx As New MySqlConnection(sLocalConn)
            conx.Open()
            Dim selectedYear As Integer = dtp_tahun.Value.Year
            Dim sqlx As String = "SELECT bulan, nilai_masukan, nilai_keluaran, ppn_masukan, ppn_keluaran, ppn_disetor " &
                                 "FROM tbsptppn " &
                                 "WHERE tahun = @selectedYear " &
                                 "ORDER BY FIELD(bulan, 'January', 'February', 'March', 'April', 'May', 'June', " &
                                 "'July', 'August', 'September', 'October', 'November', 'December')"
            Using cmdx As New MySqlCommand(sqlx, conx)
                cmdx.Parameters.AddWithValue("@selectedYear", selectedYear)
                Using dax As New MySqlDataAdapter
                    dax.SelectCommand = cmdx
                    Using dsx As New DataSet
                        dax.Fill(dsx, "spt_ppn")
                        dgv_spt_efaktur.DataSource = dsx.Tables("spt_ppn")
                    End Using
                End Using
            End Using
        End Using

        ' Clear dgv_spt_clone before populating
        dgv_spt_clone.Columns.Clear()
        dgv_spt_clone.Rows.Clear()

        ' Copy columns from dgv_spt_efaktur to dgv_spt_clone
        For Each col As DataGridViewColumn In dgv_spt_efaktur.Columns
            Dim newCol As New DataGridViewColumn(col.CellTemplate)
            newCol.HeaderText = col.HeaderText
            newCol.Name = col.Name
            newCol.Width = col.Width
            dgv_spt_clone.Columns.Add(newCol)
        Next

        ' Add new column "SELISIH PPN" at the end
        Dim selisihPpnCol As New DataGridViewTextBoxColumn()
        selisihPpnCol.HeaderText = "SELISIH PPN"
        selisihPpnCol.Name = "SELISIH PPN"
        dgv_spt_clone.Columns.Add(selisihPpnCol)

        ' Copy rows from dgv_spt_efaktur to dgv_spt_clone
        For Each row As DataGridViewRow In dgv_spt_efaktur.Rows
            If Not row.IsNewRow Then
                Dim newRow As DataGridViewRow = CType(row.Clone(), DataGridViewRow)
                For i As Integer = 0 To row.Cells.Count - 1
                    newRow.Cells(i).Value = row.Cells(i).Value
                Next
                dgv_spt_clone.Rows.Add(newRow)
            End If
        Next

        For i As Integer = 0 To dgv_spt_clone.Rows.Count - 1
            ' Pastikan kolom pada kedua DataGridView memiliki data numerik
            Dim value1 As Decimal = 0
            Dim value2 As Decimal = 0
            Dim hasil As Decimal = 0
            ' Cek apakah data di dgv_spt_aml valid dan numerik
            If Not IsDBNull(dgv_spt_aml.Rows(i).Cells(5).Value) AndAlso IsNumeric(dgv_spt_aml.Rows(i).Cells(5).Value) Then
                value1 = Convert.ToDecimal(dgv_spt_aml.Rows(i).Cells(5).Value)
            End If
            ' Cek apakah data di dgv_spt_efaktur valid dan numerik
            If Not IsDBNull(dgv_spt_efaktur.Rows(i).Cells(5).Value) AndAlso IsNumeric(dgv_spt_efaktur.Rows(i).Cells(5).Value) Then
                value2 = Convert.ToDecimal(dgv_spt_efaktur.Rows(i).Cells(5).Value)
            End If
            ' Jumlahkan kedua nilai dan masukkan hasilnya ke dgv_spt_aml
            hasil = value1 - value2
            dgv_spt_clone.Rows(i).Cells("SELISIH PPN").Value = hasil
        Next

        ' Tambahkan kolom "TDK DIGUNGGUNG" setelah "NILAI KELUARAN"
        Dim kolomTdkDigunggung As New DataGridViewTextBoxColumn()
        kolomTdkDigunggung.Name = "TDK DIGUNGGUNG"
        kolomTdkDigunggung.HeaderText = "TDK DIGUNGGUNG"
        dgv_spt_clone.Columns.Insert(2 + 1, kolomTdkDigunggung)

        ' Tambahkan kolom "DIGUNGGUNG" setelah "TDK DIGUNGGUNG"
        Dim kolomDigunggung As New DataGridViewTextBoxColumn()
        kolomDigunggung.Name = "DIGUNGGUNG"
        kolomDigunggung.HeaderText = "DIGUNGGUNG"
        dgv_spt_clone.Columns.Insert(2 + 2, kolomDigunggung)

        ' Tambahkan kolom "TDK DIGUNGGUNG" setelah "NILAI KELUARAN"
        Dim kolomTdkDigunggungamal As New DataGridViewTextBoxColumn()
        kolomTdkDigunggungamal.Name = "TDK DIGUNGGUNG"
        kolomTdkDigunggungamal.HeaderText = "TDK DIGUNGGUNG"
        dgv_spt_aml.Columns.Insert(2 + 1, kolomTdkDigunggungamal)

        ' Tambahkan kolom "Digunggungamal" setelah "TDK Digunggungamal"
        Dim kolomDigunggungamal As New DataGridViewTextBoxColumn()
        kolomDigunggungamal.Name = "DIGUNGGUNG"
        kolomDigunggungamal.HeaderText = "DIGUNGGUNG"
        dgv_spt_aml.Columns.Insert(2 + 2, kolomDigunggungamal)

        ' Pastikan nilai awal pada kolom-kolom baru adalah kosong
        For Each row As DataGridViewRow In dgv_spt_clone.Rows
            row.Cells("TDK DIGUNGGUNG").Value = ""
            row.Cells("DIGUNGGUNG").Value = ""
        Next
        For Each row As DataGridViewRow In dgv_spt_aml.Rows
            row.Cells("TDK DIGUNGGUNG").Value = ""
            row.Cells("DIGUNGGUNG").Value = ""
        Next

        Call headertablesptclone()
        Call headertablesptamltambah()

        For Each col As DataGridViewColumn In dgv_spt_clone.Columns
            col.SortMode = DataGridViewColumnSortMode.NotSortable
        Next
        For Each col As DataGridViewColumn In dgv_spt_aml.Columns
            col.SortMode = DataGridViewColumnSortMode.NotSortable
        Next
    End Sub
    Private Sub headertablesptclone()
        dgv_spt_clone.Columns(0).HeaderText = "SPT EFAKTUR"
        dgv_spt_clone.Columns(1).HeaderText = "NILAI MASUKAN"
        dgv_spt_clone.Columns(2).HeaderText = "NILAI KELUARAN"
        dgv_spt_clone.Columns(3).HeaderText = "TDK DIGUNGGUNG"
        dgv_spt_clone.Columns(4).HeaderText = "DIGUNGGUNG"
        dgv_spt_clone.Columns(5).HeaderText = "PPN MASUKAN"
        dgv_spt_clone.Columns(6).HeaderText = "PPN KELUARAN"
        dgv_spt_clone.Columns(7).HeaderText = "PPN DISETOR"
        For Each column As DataGridViewColumn In dgv_spt_clone.Columns
            column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        Next
        dgv_spt_clone.Columns(0).Width = 100
        dgv_spt_clone.Columns(1).Width = 130
        dgv_spt_clone.Columns(2).Width = 130
        dgv_spt_clone.Columns(3).Width = 100
        dgv_spt_clone.Columns(4).Width = 100
        dgv_spt_clone.Columns(5).Width = 120
        dgv_spt_clone.Columns(6).Width = 120
        dgv_spt_clone.Columns(7).Width = 110
        dgv_spt_clone.Columns(8).Width = 110
        dgv_spt_clone.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_clone.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_clone.Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_clone.Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_clone.Columns(7).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_clone.Columns(8).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_clone.Columns(1).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_clone.Columns(2).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_clone.Columns(4).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_clone.Columns(5).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_clone.Columns(6).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_clone.Columns(7).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_clone.Columns(8).DefaultCellStyle.Format = "#,##0.00"
    End Sub
    Private Sub headertablesptaml()
        dgv_spt_aml.ColumnCount = 6
        dgv_spt_aml.Columns(0).Name = "SPT AML"
        dgv_spt_aml.Columns(1).Name = "NILAI MASUKAN"
        dgv_spt_aml.Columns(2).Name = "NILAI KELUARAN"
        dgv_spt_aml.Columns(3).Name = "PPN MASUKAN"
        dgv_spt_aml.Columns(4).Name = "PPN KELUARAN"
        dgv_spt_aml.Columns(5).Name = "PPN DISETOR"

        Dim bulanArray As String() = {"JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"}
        For Each bulan As String In bulanArray
            dgv_spt_aml.Rows.Add(bulan, 0, 0, 0, 0, 0)
        Next

        For Each column As DataGridViewColumn In dgv_spt_aml.Columns
            column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        Next
        dgv_spt_aml.Columns(0).Width = 120
        dgv_spt_aml.Columns(1).Width = 150
        dgv_spt_aml.Columns(2).Width = 150
        dgv_spt_aml.Columns(3).Width = 140
        dgv_spt_aml.Columns(4).Width = 140
        dgv_spt_aml.Columns(5).Width = 130
        dgv_spt_aml.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_aml.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_aml.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_aml.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_aml.Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_aml.Columns(1).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_aml.Columns(2).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_aml.Columns(3).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_aml.Columns(4).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_aml.Columns(5).DefaultCellStyle.Format = "#,##0.00"
    End Sub
    Private Sub headertablesptamltambah()
        dgv_spt_aml.Columns(0).HeaderText = "SPT AML"
        dgv_spt_aml.Columns(1).HeaderText = "NILAI MASUKAN"
        dgv_spt_aml.Columns(2).HeaderText = "NILAI KELUARAN"
        dgv_spt_aml.Columns(3).HeaderText = "TDK DIGUNGGUNG"
        dgv_spt_aml.Columns(4).HeaderText = "DIGUNGGUNG"
        dgv_spt_aml.Columns(5).HeaderText = "PPN MASUKAN"
        dgv_spt_aml.Columns(6).HeaderText = "PPN KELUARAN"
        dgv_spt_aml.Columns(7).HeaderText = "PPN DISETOR"
        For Each column As DataGridViewColumn In dgv_spt_aml.Columns
            column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        Next
        dgv_spt_aml.Columns(0).Width = 100
        dgv_spt_aml.Columns(1).Width = 130
        dgv_spt_aml.Columns(2).Width = 130
        dgv_spt_aml.Columns(3).Width = 100
        dgv_spt_aml.Columns(4).Width = 100
        dgv_spt_aml.Columns(5).Width = 120
        dgv_spt_aml.Columns(6).Width = 120
        dgv_spt_aml.Columns(7).Width = 110
        dgv_spt_aml.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_aml.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_aml.Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_aml.Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_aml.Columns(7).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgv_spt_aml.Columns(1).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_aml.Columns(2).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_aml.Columns(4).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_aml.Columns(5).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_aml.Columns(6).DefaultCellStyle.Format = "#,##0.00"
        dgv_spt_aml.Columns(7).DefaultCellStyle.Format = "#,##0.00"
    End Sub
    Private Sub dgv_spt_aml_CellFormatting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles dgv_spt_aml.CellFormatting
        ' Periksa apakah nilai di sel adalah numerik
        If e.Value IsNot Nothing AndAlso IsNumeric(e.Value) Then
            Dim nilai As Decimal = Convert.ToDecimal(e.Value)
            If nilai < 0 Then
                ' Format nilai negatif dengan tanda kurung
                e.Value = "(" & Format(Math.Abs(nilai), "#,##0.00") & ")"
                e.FormattingApplied = True
            Else
                ' Format nilai positif atau nol tanpa tanda kurung
                e.Value = Format(nilai, "#,##0.00")
                e.FormattingApplied = True
            End If
        End If
    End Sub
    Private Sub dgv_spt_clone_CellFormatting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles dgv_spt_clone.CellFormatting
        ' Periksa apakah nilai di sel adalah numerik
        If e.Value IsNot Nothing AndAlso IsNumeric(e.Value) Then
            Dim nilai As Decimal = Convert.ToDecimal(e.Value)
            If nilai < 0 Then
                ' Format nilai negatif dengan tanda kurung
                e.Value = "(" & Format(Math.Abs(nilai), "#,##0.00") & ")"
                e.FormattingApplied = True
            Else
                ' Format nilai positif atau nol tanpa tanda kurung
                e.Value = Format(nilai, "#,##0.00")
                e.FormattingApplied = True
            End If
        End If
        If dgv_spt_clone.Columns(e.ColumnIndex).Name = "SELISIH PPN" Then
            ' Pastikan nilai tidak kosong dan merupakan angka
            If e.Value IsNot Nothing AndAlso IsNumeric(e.Value.ToString()) Then
                Dim nilai As Decimal
                ' Gunakan TryParse untuk menghindari error konversi
                If Decimal.TryParse(e.Value.ToString(), nilai) Then
                    ' Cek jika nilai lebih dari 100
                    If nilai > 100 Then
                        dgv_spt_clone.Rows(e.RowIndex).Cells(e.ColumnIndex).Style.ForeColor = Color.Red
                    Else
                        dgv_spt_clone.Rows(e.RowIndex).Cells(e.ColumnIndex).Style.ForeColor = Color.Black
                    End If
                End If
            Else
                ' Jika nilai tidak valid, pastikan warna tetap default (opsional)
                dgv_spt_clone.Rows(e.RowIndex).Cells(e.ColumnIndex).Style.ForeColor = Color.Black
            End If
        End If
    End Sub

    Private Sub Export(ByVal filePath As String)
        Try
            Dim txttahun As New TextBox
            txttahun.Text = dtp_tahun.Value.ToString("yyyy")

            Using package As New ExcelPackage()

                ' Sheet 6: SPT Masa PPN
                Dim ws6 As ExcelWorksheet = package.Workbook.Worksheets.Add("SPT Masa PPN")
                ws6.Cells(1, 1).Value = "SPT MASA PPN EFAKTUR TAHUN " & txttahun.Text
                ws6.Cells(1, 1, 1, dgv_spt_clone.Columns.Count).Merge = True
                For col As Integer = 0 To dgv_spt_clone.Columns.Count - 1
                    ws6.Cells(3, col + 1).Value = dgv_spt_clone.Columns(col).HeaderText
                    ws6.Cells(3, col + 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws6.Cells(3, col + 1).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                Next
                For row As Integer = 0 To dgv_spt_clone.Rows.Count - 1
                    For col As Integer = 0 To dgv_spt_clone.Columns.Count - 1
                        Dim cell = ws6.Cells(row + 4, col + 1)
                        Dim value = dgv_spt_clone(col, row).Value
                        If IsNumeric(value) Then
                            cell.Value = value
                            cell.Style.Numberformat.Format = "#,##0.00" ' Format angka
                        Else
                            cell.Value = value
                        End If
                        cell.Style.Border.BorderAround(ExcelBorderStyle.Thin)
                    Next
                Next
                For col As Integer = 1 To dgv_spt_clone.Columns.Count + 1
                    ws6.Column(col).Width = 145 / 7.5 ' Mengonversi px ke Excel units
                Next

                ' Tambahkan baris total
                Dim totalRow As Integer = dgv_spt_clone.Rows.Count + 4
                For col As Integer = 1 To dgv_spt_clone.Columns.Count - 1
                    ws6.Cells(totalRow, col + 1).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                Next
                Dim nilaimasukan As Decimal = 0
                Dim nilaikeluaran As Decimal = 0
                Dim ppnmasukan As Decimal = 0
                Dim ppnkeluaran As Decimal = 0
                Dim ppndisetor As Decimal = 0
                For row As Integer = 0 To dgv_spt_clone.Rows.Count - 1
                    nilaimasukan += dgv_spt_clone(1, row).Value
                    nilaikeluaran += dgv_spt_clone(2, row).Value
                    ppnmasukan += dgv_spt_clone(5, row).Value
                    ppnkeluaran += dgv_spt_clone(6, row).Value
                    ppndisetor += dgv_spt_clone(7, row).Value
                Next
                ws6.Cells(totalRow, 2).Value = nilaimasukan
                ws6.Cells(totalRow, 3).Value = nilaikeluaran
                ws6.Cells(totalRow, 6).Value = ppnmasukan
                ws6.Cells(totalRow, 7).Value = ppnkeluaran
                ws6.Cells(totalRow, 8).Value = ppndisetor
                For i As Integer = 2 To 8
                    ws6.Cells(totalRow, i).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                    ws6.Cells(totalRow, i).Style.Numberformat.Format = "#,##0.00"
                Next

                ws6.Cells(totalRow + 2, 1).Value = "SPT MASA PPN AML TAHUN " & txttahun.Text
                ws6.Cells(totalRow + 2, 1, totalRow + 2, dgv_spt_aml.Columns.Count).Merge = True
                For col As Integer = 0 To dgv_spt_aml.Columns.Count - 1
                    ws6.Cells(totalRow + 4, col + 1).Value = dgv_spt_aml.Columns(col).HeaderText
                    ws6.Cells(totalRow + 4, col + 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws6.Cells(totalRow + 4, col + 1).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                Next
                For row As Integer = 0 To dgv_spt_aml.Rows.Count - 1
                    For col As Integer = 0 To dgv_spt_aml.Columns.Count - 1
                        Dim cell = ws6.Cells(row + totalRow + 5, col + 1)
                        Dim value = dgv_spt_aml(col, row).Value
                        If IsNumeric(value) Then
                            cell.Value = value
                            cell.Style.Numberformat.Format = "#,##0.00" ' Format angka
                        Else
                            cell.Value = value
                        End If
                        cell.Style.Border.BorderAround(ExcelBorderStyle.Thin)
                    Next
                Next

                ' Tambahkan baris total
                Dim akhirbaris As Integer = dgv_spt_aml.Rows.Count + totalRow + 5
                For col As Integer = 1 To dgv_spt_aml.Columns.Count - 1
                    ws6.Cells(akhirbaris, col + 1).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                Next
                Dim nilaimasukanaml As Decimal = 0
                Dim nilaikeluaranaml As Decimal = 0
                Dim ppnmasukanaml As Decimal = 0
                Dim ppnkeluaranaml As Decimal = 0
                Dim ppndisetoraml As Decimal = 0
                For row As Integer = 0 To dgv_spt_aml.Rows.Count - 1
                    nilaimasukanaml += dgv_spt_aml(1, row).Value
                    nilaikeluaranaml += dgv_spt_aml(2, row).Value
                    ppnmasukanaml += dgv_spt_aml(5, row).Value
                    ppnkeluaranaml += dgv_spt_aml(6, row).Value
                    ppndisetoraml += dgv_spt_aml(7, row).Value
                Next
                ws6.Cells(akhirbaris, 2).Value = nilaimasukanaml
                ws6.Cells(akhirbaris, 3).Value = nilaikeluaranaml
                ws6.Cells(akhirbaris, 6).Value = ppnmasukanaml
                ws6.Cells(akhirbaris, 7).Value = ppnkeluaranaml
                ws6.Cells(akhirbaris, 8).Value = ppndisetoraml
                For i As Integer = 2 To 8
                    ws6.Cells(akhirbaris, i).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                    ws6.Cells(akhirbaris, i).Style.Numberformat.Format = "#,##0.00"
                Next
                ' Akhir sheet 6

                ' Sheet 7: PLN GARAM COAL
                Dim ws7 As ExcelWorksheet = package.Workbook.Worksheets.Add("PLN GARAM COAL")
                ws7.Cells(1, 1).Value = "DATA PLN GARAM COAL TAHUN " & txttahun.Text
                ws7.Cells(1, 1, 1, dgv_pln.Columns.Count).Merge = True
                'ws7.Cells(1, 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                'ws7.Cells(1, 1).Style.Font.Bold = True
                'Header PLN GARAM COAL
                For col As Integer = 0 To dgv_pln.Columns.Count - 1
                    ws7.Cells(3, col + 1).Value = dgv_pln.Columns(col).HeaderText
                    'ws7.Cells(3, col + 1).Style.Font.Bold = True
                    ws7.Cells(3, col + 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws7.Cells(3, col + 1).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                Next
                ' Data PLN GARAM COAL
                For row As Integer = 0 To dgv_pln.Rows.Count - 1
                    For col As Integer = 0 To dgv_pln.Columns.Count - 1
                        ws7.Cells(row + 4, col + 1).Value = dgv_pln.Rows(row).Cells(col).Value
                        ws7.Cells(row + 4, col + 1).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                        Dim cell = ws7.Cells(row + 4, col + 1)
                        Dim value = dgv_pln.Rows(row).Cells(col).Value
                        If IsNumeric(value) Then
                            cell.Value = value
                            cell.Style.Numberformat.Format = "#,##0.00" ' Format angka
                        Else
                            cell.Value = value
                        End If
                    Next
                Next
                'ws7.Cells(ws7.Dimension.Address).AutoFitColumns()
                For col As Integer = 1 To dgv_pln.Columns.Count + 1
                    ws7.Column(col).Width = 135 / 7.5 ' Mengonversi px ke Excel units
                Next
                ws7.Cells(3, 2).Value = "PLN"
                ws7.Cells(3, 3).Value = "GARAM"
                ws7.Cells(3, 4).Value = "COAL"
                ws7.Cells(3, 5).Value = "PPH 22 COAL"

                ' Akhir Sheet 7

                ' Sheet 8: DAFTAR BUKTI POTONG
                Dim ws8 As ExcelWorksheet = package.Workbook.Worksheets.Add("DAFTAR BUKTI POTONG")
                ws8.Cells(1, 1, 1, dgv_bukpot.Columns.Count - 1).Merge = True
                ws8.Cells(1, 1).Value = "DAFTAR BUKTI POTONG TAHUN PAJAK " & txttahun.Text
                'ws8.Cells(1, 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                'ws8.Cells(1, 1).Style.Font.Bold = True
                ' Header DAFTAR BUKTI POTONG
                Dim headers = {"NO", "NAMA CUSTOMER PEMOTONG", "NPWP CUSTOMER", "TANGGAL FP", "NO FAKTUR PAJAK", "NILAI DPP", "PPN", "PPH23", "PPH23 ACTUAL", "NO BUKPOT", "TGL BUKPOT", "MASA BUKPOT"}
                For col As Integer = 0 To headers.Length - 1
                    ws8.Cells(3, col + 1).Value = headers(col)
                    'ws8.Cells(3, col + 1).Style.Font.Bold = True
                    ws8.Cells(3, col + 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws8.Cells(3, col + 1).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                    'ws8.Cells(3, col + 1).Style.Fill.PatternType = ExcelFillStyle.Solid
                    'ws8.Cells(3, col + 1).Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightGray)
                Next
                ' Mengelompokkan data berdasarkan nilai gabung_bukpot
                Dim groupedData As New List(Of Dictionary(Of String, Object))
                Dim tempGroup As Dictionary(Of String, Object) = Nothing
                For row As Integer = 0 To dgv_bukpot.Rows.Count - 1
                    Dim gabung_bukpot = dgv_bukpot.Rows(row).Cells("gabung_bukpot").Value.ToString()
                    If tempGroup IsNot Nothing AndAlso tempGroup("gabung_bukpot").ToString() = gabung_bukpot Then
                        ' Gabungkan nilai pph23_actual
                        tempGroup("pph23_actual") = CDbl(tempGroup("pph23_actual")) + CDbl(dgv_bukpot.Rows(row).Cells("pph23_actual").Value)
                        tempGroup("Rows").Add(row)
                    Else
                        ' Tambahkan grup baru
                        If tempGroup IsNot Nothing Then groupedData.Add(tempGroup)
                        tempGroup = New Dictionary(Of String, Object) From {
                            {"gabung_bukpot", gabung_bukpot},
                            {"pph23_actual", dgv_bukpot.Rows(row).Cells("pph23_actual").Value},
                            {"Rows", New List(Of Integer) From {row}}
                        }
                    End If
                Next
                If tempGroup IsNot Nothing Then groupedData.Add(tempGroup)

                ' Mengisi data ke Excel
                Dim rowIndex As Integer = 4
                For Each group In groupedData
                    Dim Rows = group("Rows")
                    Dim startRow = rowIndex
                    Dim endRow = rowIndex + Rows.Count - 1

                    For Each rowIndexInGroup In Rows
                        ' Menulis nomor urut
                        ws8.Cells(rowIndex, 1).Value = rowIndex - 3
                        ws8.Cells(rowIndex, 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                        ws8.Cells(rowIndex, 1).Style.Border.BorderAround(ExcelBorderStyle.Thin)
                        ' Menulis data ke kolom lain
                        Dim colIndexData As Integer = 1
                        For col As Integer = 0 To dgv_bukpot.Columns.Count - 1
                            If dgv_bukpot.Columns(col).Name <> "id_jual" AndAlso dgv_bukpot.Columns(col).Name <> "gabung_bukpot" Then
                                colIndexData += 1
                                Dim cell = ws8.Cells(rowIndex, colIndexData)
                                Dim value = dgv_bukpot.Rows(rowIndexInGroup).Cells(col).Value

                                ' Format khusus untuk kolom tertentu
                                Select Case dgv_bukpot.Columns(col).Name
                                    Case "tanggal", "tgl_bukpot"
                                        ' Format tanggal menjadi 19-Jan-2024
                                        If value IsNot Nothing AndAlso IsDate(value) Then
                                            cell.Value = CDate(value)
                                            cell.Style.Numberformat.Format = "dd-MMM-yyyy"
                                        End If
                                    Case "masa_bukpot"
                                        ' Format masa_bukpot menjadi Januari-24
                                        If value IsNot Nothing AndAlso IsDate(value) Then
                                            cell.Value = CDate(value).ToString("MMMM-yy")
                                        End If
                                        cell.Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                                    Case "no_bukpot"
                                        ' Rata kanan untuk no_bukpot
                                        cell.Value = value.ToString()
                                        cell.Style.Numberformat.Format = "@"
                                        cell.Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                                    Case "pph23_actual"
                                        If rowIndex = startRow Then
                                            ' Tuliskan nilai hasil penjumlahan pada baris pertama
                                            cell.Value = CDbl(group("pph23_actual"))
                                            cell.Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                                            cell.Style.Numberformat.Format = "#,##0.00"
                                            cell.Style.VerticalAlignment = ExcelVerticalAlignment.Center
                                            ' Merge cell pph23_actual
                                            ws8.Cells(startRow, colIndexData, endRow, colIndexData).Merge = True
                                        End If
                                    Case Else
                                        ' Default untuk kolom lainnya
                                        If TypeOf value Is Double Or TypeOf value Is Decimal Then
                                            cell.Value = value
                                            cell.Style.Numberformat.Format = "#,##0.00"
                                        Else
                                            cell.Value = value.ToString()
                                        End If
                                End Select
                                cell.Style.Border.BorderAround(ExcelBorderStyle.Thin)
                            End If
                        Next
                        rowIndex += 1
                    Next
                Next
                ' Menyesuaikan lebar kolom
                ws8.Cells(ws8.Dimension.Address).AutoFitColumns()
                'Akhir sheet 8

                ' Simpan file Excel
                Dim fi As New FileInfo(filePath)
                package.SaveAs(fi)
                MessageBox.Show("Ekspor Data ke Excel Berhasil!")
            End Using
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub

    Private Sub btn_reset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_reset.Click
        btn_generate.Text = "GENERATE"
        btn_reset.Enabled = False
        dgv_spt_aml.Columns.Clear()
        dgv_spt_efaktur.Columns.Clear()
        dgv_spt_clone.Columns.Clear()
        dgv_pln.Columns.Clear()
        dgv_bukpot.Columns.Clear()
    End Sub
End Class