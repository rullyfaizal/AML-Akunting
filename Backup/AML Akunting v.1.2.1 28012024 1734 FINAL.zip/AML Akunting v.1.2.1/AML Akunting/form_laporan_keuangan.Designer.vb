﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class form_laporan_keuangan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.dgv_spt_clone = New System.Windows.Forms.DataGridView()
        Me.dgv_spt_aml = New System.Windows.Forms.DataGridView()
        Me.dgv_spt_efaktur = New System.Windows.Forms.DataGridView()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.dgv_pln = New System.Windows.Forms.DataGridView()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.dgv_bukpot = New System.Windows.Forms.DataGridView()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.btn_generate = New System.Windows.Forms.Button()
        Me.dtp_tahun = New System.Windows.Forms.DateTimePicker()
        Me.lbl_dgv1 = New System.Windows.Forms.Label()
        Me.btn_reset = New System.Windows.Forms.Button()
        Me.TabControl1.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        CType(Me.dgv_spt_clone, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_spt_aml, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_spt_efaktur, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage7.SuspendLayout()
        CType(Me.dgv_pln, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage8.SuspendLayout()
        CType(Me.dgv_bukpot, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Controls.Add(Me.TabPage8)
        Me.TabControl1.Controls.Add(Me.TabPage9)
        Me.TabControl1.Location = New System.Drawing.Point(0, 29)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1130, 554)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "HPP"
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Laporan Keuangan"
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Biaya"
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Masukan"
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Keluaran"
        '
        'TabPage6
        '
        Me.TabPage6.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage6.Controls.Add(Me.dgv_spt_clone)
        Me.TabPage6.Controls.Add(Me.dgv_spt_aml)
        Me.TabPage6.Controls.Add(Me.dgv_spt_efaktur)
        Me.TabPage6.Location = New System.Drawing.Point(4, 22)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "SPT Masa PPN"
        '
        'dgv_spt_clone
        '
        Me.dgv_spt_clone.AllowUserToAddRows = False
        Me.dgv_spt_clone.AllowUserToDeleteRows = False
        Me.dgv_spt_clone.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_spt_clone.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_spt_clone.DefaultCellStyle = DataGridViewCellStyle6
        Me.dgv_spt_clone.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_spt_clone.Location = New System.Drawing.Point(9, 13)
        Me.dgv_spt_clone.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_spt_clone.MultiSelect = False
        Me.dgv_spt_clone.Name = "dgv_spt_clone"
        Me.dgv_spt_clone.ReadOnly = True
        Me.dgv_spt_clone.Size = New System.Drawing.Size(1105, 250)
        Me.dgv_spt_clone.TabIndex = 52
        '
        'dgv_spt_aml
        '
        Me.dgv_spt_aml.AllowUserToAddRows = False
        Me.dgv_spt_aml.AllowUserToDeleteRows = False
        Me.dgv_spt_aml.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_spt_aml.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_spt_aml.DefaultCellStyle = DataGridViewCellStyle7
        Me.dgv_spt_aml.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_spt_aml.Location = New System.Drawing.Point(9, 271)
        Me.dgv_spt_aml.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_spt_aml.MultiSelect = False
        Me.dgv_spt_aml.Name = "dgv_spt_aml"
        Me.dgv_spt_aml.ReadOnly = True
        Me.dgv_spt_aml.Size = New System.Drawing.Size(1105, 250)
        Me.dgv_spt_aml.TabIndex = 51
        '
        'dgv_spt_efaktur
        '
        Me.dgv_spt_efaktur.AllowUserToAddRows = False
        Me.dgv_spt_efaktur.AllowUserToDeleteRows = False
        Me.dgv_spt_efaktur.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_spt_efaktur.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_spt_efaktur.DefaultCellStyle = DataGridViewCellStyle8
        Me.dgv_spt_efaktur.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_spt_efaktur.Location = New System.Drawing.Point(9, 13)
        Me.dgv_spt_efaktur.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_spt_efaktur.MultiSelect = False
        Me.dgv_spt_efaktur.Name = "dgv_spt_efaktur"
        Me.dgv_spt_efaktur.ReadOnly = True
        Me.dgv_spt_efaktur.Size = New System.Drawing.Size(1105, 250)
        Me.dgv_spt_efaktur.TabIndex = 50
        '
        'TabPage7
        '
        Me.TabPage7.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage7.Controls.Add(Me.dgv_pln)
        Me.TabPage7.Location = New System.Drawing.Point(4, 22)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "PLN Garam Coal"
        '
        'dgv_pln
        '
        Me.dgv_pln.AllowUserToAddRows = False
        Me.dgv_pln.AllowUserToDeleteRows = False
        Me.dgv_pln.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_pln.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_pln.DefaultCellStyle = DataGridViewCellStyle9
        Me.dgv_pln.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_pln.Location = New System.Drawing.Point(9, 24)
        Me.dgv_pln.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_pln.MultiSelect = False
        Me.dgv_pln.Name = "dgv_pln"
        Me.dgv_pln.ReadOnly = True
        Me.dgv_pln.Size = New System.Drawing.Size(634, 295)
        Me.dgv_pln.TabIndex = 49
        '
        'TabPage8
        '
        Me.TabPage8.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage8.Controls.Add(Me.dgv_bukpot)
        Me.TabPage8.Location = New System.Drawing.Point(4, 22)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage8.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage8.TabIndex = 7
        Me.TabPage8.Text = "Bukti Potong"
        '
        'dgv_bukpot
        '
        Me.dgv_bukpot.AllowUserToAddRows = False
        Me.dgv_bukpot.AllowUserToDeleteRows = False
        Me.dgv_bukpot.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_bukpot.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_bukpot.DefaultCellStyle = DataGridViewCellStyle10
        Me.dgv_bukpot.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_bukpot.Location = New System.Drawing.Point(9, 24)
        Me.dgv_bukpot.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_bukpot.MultiSelect = False
        Me.dgv_bukpot.Name = "dgv_bukpot"
        Me.dgv_bukpot.ReadOnly = True
        Me.dgv_bukpot.Size = New System.Drawing.Size(1105, 485)
        Me.dgv_bukpot.TabIndex = 48
        '
        'TabPage9
        '
        Me.TabPage9.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage9.Location = New System.Drawing.Point(4, 22)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage9.Size = New System.Drawing.Size(1122, 528)
        Me.TabPage9.TabIndex = 8
        Me.TabPage9.Text = "Rincian Penyusutan"
        '
        'btn_generate
        '
        Me.btn_generate.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_generate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_generate.Location = New System.Drawing.Point(656, 4)
        Me.btn_generate.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.btn_generate.Name = "btn_generate"
        Me.btn_generate.Size = New System.Drawing.Size(93, 24)
        Me.btn_generate.TabIndex = 54
        Me.btn_generate.TabStop = False
        Me.btn_generate.Text = "GENERATE"
        Me.btn_generate.UseVisualStyleBackColor = True
        '
        'dtp_tahun
        '
        Me.dtp_tahun.CalendarFont = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtp_tahun.CustomFormat = "yyyy"
        Me.dtp_tahun.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtp_tahun.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtp_tahun.Location = New System.Drawing.Point(568, 5)
        Me.dtp_tahun.Name = "dtp_tahun"
        Me.dtp_tahun.ShowUpDown = True
        Me.dtp_tahun.Size = New System.Drawing.Size(71, 22)
        Me.dtp_tahun.TabIndex = 53
        '
        'lbl_dgv1
        '
        Me.lbl_dgv1.AutoSize = True
        Me.lbl_dgv1.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_dgv1.Location = New System.Drawing.Point(382, 9)
        Me.lbl_dgv1.Name = "lbl_dgv1"
        Me.lbl_dgv1.Size = New System.Drawing.Size(182, 14)
        Me.lbl_dgv1.TabIndex = 52
        Me.lbl_dgv1.Text = "LAPORAN KEUANGAN TAHUN"
        '
        'btn_reset
        '
        Me.btn_reset.Enabled = False
        Me.btn_reset.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_reset.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_reset.Location = New System.Drawing.Point(768, 4)
        Me.btn_reset.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.btn_reset.Name = "btn_reset"
        Me.btn_reset.Size = New System.Drawing.Size(93, 24)
        Me.btn_reset.TabIndex = 55
        Me.btn_reset.TabStop = False
        Me.btn_reset.Text = "RESET"
        Me.btn_reset.UseVisualStyleBackColor = True
        '
        'form_laporan_keuangan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1131, 587)
        Me.Controls.Add(Me.btn_reset)
        Me.Controls.Add(Me.btn_generate)
        Me.Controls.Add(Me.dtp_tahun)
        Me.Controls.Add(Me.lbl_dgv1)
        Me.Controls.Add(Me.TabControl1)
        Me.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "form_laporan_keuangan"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage6.ResumeLayout(False)
        CType(Me.dgv_spt_clone, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_spt_aml, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_spt_efaktur, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage7.ResumeLayout(False)
        CType(Me.dgv_pln, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage8.ResumeLayout(False)
        CType(Me.dgv_bukpot, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage8 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage9 As System.Windows.Forms.TabPage
    Friend WithEvents btn_generate As System.Windows.Forms.Button
    Friend WithEvents dtp_tahun As System.Windows.Forms.DateTimePicker
    Friend WithEvents lbl_dgv1 As System.Windows.Forms.Label
    Friend WithEvents dgv_bukpot As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_pln As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_spt_aml As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_spt_efaktur As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_spt_clone As System.Windows.Forms.DataGridView
    Friend WithEvents btn_reset As System.Windows.Forms.Button
End Class
