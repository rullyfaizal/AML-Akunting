﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class form_menu_utama
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.SISTEMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LOGINToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LOGOUTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PenggunaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
        Me.KELUARToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DatabaseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CLIENTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SupplierToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.JenisBiayaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PPNPPh23ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NamaSpecsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PembelianToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DataPembelianToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UploadPembelianToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExportUploadPembelianToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CariNamaBarangSpecsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PenjualanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BuktiPotongToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DataPenjualanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OmsetPenjualanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UploadPenjualanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GenerateSuratJalanDanFakturToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InputPenjualanKainToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InputPenjualanCelupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExportUploadPenjualanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GreyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DataGreyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NeracaGreyBaruToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InputNamaHargaJualGreyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.LaporanKeuanganToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SPTMasaPPNEfakturToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PenyusutanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpahHarianUpahHarianToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchPPNPPHV121ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchPenyusutanV121ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchSPTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchBukpotToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchPenjualanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchSupplierToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchPembelianToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchGreyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatchOmsetToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.Status1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Status2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.dgv1 = New System.Windows.Forms.DataGridView()
        Me.panel_bukpot = New System.Windows.Forms.Panel()
        Me.btn_refresh_bukpot = New System.Windows.Forms.Button()
        Me.txt_jumlah_bukpot = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dtp_bukpot = New System.Windows.Forms.DateTimePicker()
        Me.dgv_bukpot = New System.Windows.Forms.DataGridView()
        Me.btn_hitung_bukpot = New System.Windows.Forms.Button()
        Me.MenuStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panel_bukpot.SuspendLayout()
        CType(Me.dgv_bukpot, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SISTEMToolStripMenuItem, Me.DatabaseToolStripMenuItem, Me.PembelianToolStripMenuItem, Me.PenjualanToolStripMenuItem, Me.GreyToolStripMenuItem, Me.ToolStripMenuItem2, Me.PatchToolStripMenuItem})
        Me.MenuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1244, 26)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'SISTEMToolStripMenuItem
        '
        Me.SISTEMToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LOGINToolStripMenuItem, Me.LOGOUTToolStripMenuItem, Me.PenggunaToolStripMenuItem, Me.ToolStripMenuItem1, Me.KELUARToolStripMenuItem})
        Me.SISTEMToolStripMenuItem.Name = "SISTEMToolStripMenuItem"
        Me.SISTEMToolStripMenuItem.Size = New System.Drawing.Size(80, 22)
        Me.SISTEMToolStripMenuItem.Text = "System"
        '
        'LOGINToolStripMenuItem
        '
        Me.LOGINToolStripMenuItem.Name = "LOGINToolStripMenuItem"
        Me.LOGINToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.LOGINToolStripMenuItem.Text = "Login"
        '
        'LOGOUTToolStripMenuItem
        '
        Me.LOGOUTToolStripMenuItem.Name = "LOGOUTToolStripMenuItem"
        Me.LOGOUTToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.LOGOUTToolStripMenuItem.Text = "Logout"
        '
        'PenggunaToolStripMenuItem
        '
        Me.PenggunaToolStripMenuItem.Name = "PenggunaToolStripMenuItem"
        Me.PenggunaToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.PenggunaToolStripMenuItem.Text = "Pengguna"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(153, 6)
        '
        'KELUARToolStripMenuItem
        '
        Me.KELUARToolStripMenuItem.Name = "KELUARToolStripMenuItem"
        Me.KELUARToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.KELUARToolStripMenuItem.Text = "Keluar"
        '
        'DatabaseToolStripMenuItem
        '
        Me.DatabaseToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CLIENTToolStripMenuItem, Me.SupplierToolStripMenuItem1, Me.JenisBiayaToolStripMenuItem, Me.PPNPPh23ToolStripMenuItem, Me.NamaSpecsToolStripMenuItem})
        Me.DatabaseToolStripMenuItem.Name = "DatabaseToolStripMenuItem"
        Me.DatabaseToolStripMenuItem.Size = New System.Drawing.Size(98, 22)
        Me.DatabaseToolStripMenuItem.Text = "Database"
        '
        'CLIENTToolStripMenuItem
        '
        Me.CLIENTToolStripMenuItem.Name = "CLIENTToolStripMenuItem"
        Me.CLIENTToolStripMenuItem.Size = New System.Drawing.Size(189, 22)
        Me.CLIENTToolStripMenuItem.Text = "Client"
        '
        'SupplierToolStripMenuItem1
        '
        Me.SupplierToolStripMenuItem1.Name = "SupplierToolStripMenuItem1"
        Me.SupplierToolStripMenuItem1.Size = New System.Drawing.Size(189, 22)
        Me.SupplierToolStripMenuItem1.Text = "Supplier"
        '
        'JenisBiayaToolStripMenuItem
        '
        Me.JenisBiayaToolStripMenuItem.Name = "JenisBiayaToolStripMenuItem"
        Me.JenisBiayaToolStripMenuItem.Size = New System.Drawing.Size(189, 22)
        Me.JenisBiayaToolStripMenuItem.Text = "Jenis Biaya"
        '
        'PPNPPh23ToolStripMenuItem
        '
        Me.PPNPPh23ToolStripMenuItem.Name = "PPNPPh23ToolStripMenuItem"
        Me.PPNPPh23ToolStripMenuItem.Size = New System.Drawing.Size(286, 22)
        Me.PPNPPh23ToolStripMenuItem.Text = "Parameter (PPN, PPh, dll)"
        '
        'NamaSpecsToolStripMenuItem
        '
        Me.NamaSpecsToolStripMenuItem.Name = "NamaSpecsToolStripMenuItem"
        Me.NamaSpecsToolStripMenuItem.Size = New System.Drawing.Size(189, 22)
        Me.NamaSpecsToolStripMenuItem.Text = "Nama / Specs"
        '
        'PembelianToolStripMenuItem
        '
        Me.PembelianToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DataPembelianToolStripMenuItem, Me.UploadPembelianToolStripMenuItem, Me.ToolStripMenuItem3, Me.ExportUploadPembelianToolStripMenuItem, Me.CariNamaBarangSpecsToolStripMenuItem})
        Me.PembelianToolStripMenuItem.Name = "PembelianToolStripMenuItem"
        Me.PembelianToolStripMenuItem.Size = New System.Drawing.Size(105, 22)
        Me.PembelianToolStripMenuItem.Text = "Pembelian"
        '
        'DataPembelianToolStripMenuItem
        '
        Me.DataPembelianToolStripMenuItem.Name = "DataPembelianToolStripMenuItem"
        Me.DataPembelianToolStripMenuItem.Size = New System.Drawing.Size(290, 22)
        Me.DataPembelianToolStripMenuItem.Text = "Data Pembelian"
        '
        'UploadPembelianToolStripMenuItem
        '
        Me.UploadPembelianToolStripMenuItem.Name = "UploadPembelianToolStripMenuItem"
        Me.UploadPembelianToolStripMenuItem.Size = New System.Drawing.Size(290, 22)
        Me.UploadPembelianToolStripMenuItem.Text = "Upload Pembelian"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(290, 22)
        Me.ToolStripMenuItem3.Text = "Input Pembelian Baru"
        '
        'ExportUploadPembelianToolStripMenuItem
        '
        Me.ExportUploadPembelianToolStripMenuItem.Name = "ExportUploadPembelianToolStripMenuItem"
        Me.ExportUploadPembelianToolStripMenuItem.Size = New System.Drawing.Size(290, 22)
        Me.ExportUploadPembelianToolStripMenuItem.Text = "Export Upload Pembelian"
        '
        'CariNamaBarangSpecsToolStripMenuItem
        '
        Me.CariNamaBarangSpecsToolStripMenuItem.Name = "CariNamaBarangSpecsToolStripMenuItem"
        Me.CariNamaBarangSpecsToolStripMenuItem.Size = New System.Drawing.Size(290, 22)
        Me.CariNamaBarangSpecsToolStripMenuItem.Text = "Cari Nama Barang / Specs"
        '
        'PenjualanToolStripMenuItem
        '
        Me.PenjualanToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BuktiPotongToolStripMenuItem, Me.DataPenjualanToolStripMenuItem, Me.OmsetPenjualanToolStripMenuItem, Me.UploadPenjualanToolStripMenuItem, Me.GenerateSuratJalanDanFakturToolStripMenuItem, Me.InputPenjualanKainToolStripMenuItem, Me.InputPenjualanCelupToolStripMenuItem, Me.ExportUploadPenjualanToolStripMenuItem})
        Me.PenjualanToolStripMenuItem.Name = "PenjualanToolStripMenuItem"
        Me.PenjualanToolStripMenuItem.Size = New System.Drawing.Size(101, 22)
        Me.PenjualanToolStripMenuItem.Text = "Penjualan"
        '
        'BuktiPotongToolStripMenuItem
        '
        Me.BuktiPotongToolStripMenuItem.Name = "BuktiPotongToolStripMenuItem"
        Me.BuktiPotongToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.BuktiPotongToolStripMenuItem.Text = "Bukti Potong"
        '
        'DataPenjualanToolStripMenuItem
        '
        Me.DataPenjualanToolStripMenuItem.Name = "DataPenjualanToolStripMenuItem"
        Me.DataPenjualanToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.DataPenjualanToolStripMenuItem.Text = "Data Penjualan"
        '
        'OmsetPenjualanToolStripMenuItem
        '
        Me.OmsetPenjualanToolStripMenuItem.Name = "OmsetPenjualanToolStripMenuItem"
        Me.OmsetPenjualanToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.OmsetPenjualanToolStripMenuItem.Text = "Omset Penjualan"
        '
        'UploadPenjualanToolStripMenuItem
        '
        Me.UploadPenjualanToolStripMenuItem.Name = "UploadPenjualanToolStripMenuItem"
        Me.UploadPenjualanToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.UploadPenjualanToolStripMenuItem.Text = "Upload Penjualan"
        '
        'GenerateSuratJalanDanFakturToolStripMenuItem
        '
        Me.GenerateSuratJalanDanFakturToolStripMenuItem.Name = "GenerateSuratJalanDanFakturToolStripMenuItem"
        Me.GenerateSuratJalanDanFakturToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.GenerateSuratJalanDanFakturToolStripMenuItem.Text = "Generate Surat Jalan"
        '
        'InputPenjualanKainToolStripMenuItem
        '
        Me.InputPenjualanKainToolStripMenuItem.Name = "InputPenjualanKainToolStripMenuItem"
        Me.InputPenjualanKainToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.InputPenjualanKainToolStripMenuItem.Text = "Input Penjualan Kain"
        '
        'InputPenjualanCelupToolStripMenuItem
        '
        Me.InputPenjualanCelupToolStripMenuItem.Name = "InputPenjualanCelupToolStripMenuItem"
        Me.InputPenjualanCelupToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.InputPenjualanCelupToolStripMenuItem.Text = "Input Penjualan Celup"
        '
        'ExportUploadPenjualanToolStripMenuItem
        '
        Me.ExportUploadPenjualanToolStripMenuItem.Name = "ExportUploadPenjualanToolStripMenuItem"
        Me.ExportUploadPenjualanToolStripMenuItem.Size = New System.Drawing.Size(278, 22)
        Me.ExportUploadPenjualanToolStripMenuItem.Text = "Export Upload Penjualan"
        '
        'GreyToolStripMenuItem
        '
        Me.GreyToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DataGreyToolStripMenuItem, Me.NeracaGreyBaruToolStripMenuItem, Me.InputNamaHargaJualGreyToolStripMenuItem})
        Me.GreyToolStripMenuItem.Name = "GreyToolStripMenuItem"
        Me.GreyToolStripMenuItem.Size = New System.Drawing.Size(57, 22)
        Me.GreyToolStripMenuItem.Text = "Grey"
        '
        'DataGreyToolStripMenuItem
        '
        Me.DataGreyToolStripMenuItem.Name = "DataGreyToolStripMenuItem"
        Me.DataGreyToolStripMenuItem.Size = New System.Drawing.Size(255, 22)
        Me.DataGreyToolStripMenuItem.Text = "Data Grey"
        '
        'NeracaGreyBaruToolStripMenuItem
        '
        Me.NeracaGreyBaruToolStripMenuItem.Name = "NeracaGreyBaruToolStripMenuItem"
        Me.NeracaGreyBaruToolStripMenuItem.Size = New System.Drawing.Size(255, 22)
        Me.NeracaGreyBaruToolStripMenuItem.Text = "Neraca Grey"
        '
        'InputNamaHargaJualGreyToolStripMenuItem
        '
        Me.InputNamaHargaJualGreyToolStripMenuItem.Name = "InputNamaHargaJualGreyToolStripMenuItem"
        Me.InputNamaHargaJualGreyToolStripMenuItem.Size = New System.Drawing.Size(255, 22)
        Me.InputNamaHargaJualGreyToolStripMenuItem.Text = "Input Harga Jual Grey"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LaporanKeuanganToolStripMenuItem, Me.SPTMasaPPNEfakturToolStripMenuItem, Me.PenyusutanToolStripMenuItem, Me.UpahHarianUpahHarianToolStripMenuItem})
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(85, 22)
        Me.ToolStripMenuItem2.Text = "Laporan"
        '
        'LaporanKeuanganToolStripMenuItem
        '
        Me.LaporanKeuanganToolStripMenuItem.Name = "LaporanKeuanganToolStripMenuItem"
        Me.LaporanKeuanganToolStripMenuItem.Size = New System.Drawing.Size(297, 22)
        Me.LaporanKeuanganToolStripMenuItem.Text = "Laporan Keuangan"
        '
        'SPTMasaPPNEfakturToolStripMenuItem
        '
        Me.SPTMasaPPNEfakturToolStripMenuItem.Name = "SPTMasaPPNEfakturToolStripMenuItem"
        Me.SPTMasaPPNEfakturToolStripMenuItem.Size = New System.Drawing.Size(297, 22)
        Me.SPTMasaPPNEfakturToolStripMenuItem.Text = "SPT Masa PPN Efaktur"
        '
        'PenyusutanToolStripMenuItem
        '
        Me.PenyusutanToolStripMenuItem.Name = "PenyusutanToolStripMenuItem"
        Me.PenyusutanToolStripMenuItem.Size = New System.Drawing.Size(297, 22)
        Me.PenyusutanToolStripMenuItem.Text = "Penyusutan"
        Me.PenyusutanToolStripMenuItem.Visible = False
        '
        'UpahHarianUpahHarianToolStripMenuItem
        '
        Me.UpahHarianUpahHarianToolStripMenuItem.Name = "UpahHarianUpahHarianToolStripMenuItem"
        Me.UpahHarianUpahHarianToolStripMenuItem.Size = New System.Drawing.Size(297, 22)
        Me.UpahHarianUpahHarianToolStripMenuItem.Text = "Upah Harian / Upah Harian"
        Me.UpahHarianUpahHarianToolStripMenuItem.Visible = False
        '
        'PatchToolStripMenuItem
        '
        Me.PatchToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PatchPPNPPHV121ToolStripMenuItem, Me.PatchPenyusutanV121ToolStripMenuItem, Me.PatchSPTToolStripMenuItem, Me.PatchBukpotToolStripMenuItem, Me.PatchToolStripMenuItem1, Me.PatchPenjualanToolStripMenuItem, Me.PatchSupplierToolStripMenuItem, Me.PatchPembelianToolStripMenuItem, Me.PatchGreyToolStripMenuItem, Me.PatchOmsetToolStripMenuItem})
        Me.PatchToolStripMenuItem.Name = "PatchToolStripMenuItem"
        Me.PatchToolStripMenuItem.Size = New System.Drawing.Size(65, 22)
        Me.PatchToolStripMenuItem.Text = "Patch"
        '
        'PatchPPNPPHV121ToolStripMenuItem
        '
        Me.PatchPPNPPHV121ToolStripMenuItem.Name = "PatchPPNPPHV121ToolStripMenuItem"
        Me.PatchPPNPPHV121ToolStripMenuItem.Size = New System.Drawing.Size(284, 22)
        Me.PatchPPNPPHV121ToolStripMenuItem.Text = "Patch PPN / PPH v.1.2.1"
        '
        'PatchPenyusutanV121ToolStripMenuItem
        '
        Me.PatchPenyusutanV121ToolStripMenuItem.Name = "PatchPenyusutanV121ToolStripMenuItem"
        Me.PatchPenyusutanV121ToolStripMenuItem.Size = New System.Drawing.Size(284, 22)
        Me.PatchPenyusutanV121ToolStripMenuItem.Text = "Patch Penyusutan v.1.2.1"
        Me.PatchPenyusutanV121ToolStripMenuItem.Visible = False
        '
        'PatchSPTToolStripMenuItem
        '
        Me.PatchSPTToolStripMenuItem.Name = "PatchSPTToolStripMenuItem"
        Me.PatchSPTToolStripMenuItem.Size = New System.Drawing.Size(284, 22)
        Me.PatchSPTToolStripMenuItem.Text = "Patch SPT v.1.2.1"
        '
        'PatchBukpotToolStripMenuItem
        '
        Me.PatchBukpotToolStripMenuItem.Name = "PatchBukpotToolStripMenuItem"
        Me.PatchBukpotToolStripMenuItem.Size = New System.Drawing.Size(284, 22)
        Me.PatchBukpotToolStripMenuItem.Text = "Patch Bukpot v.1.2.0a"
        Me.PatchBukpotToolStripMenuItem.Visible = False
        '
        'PatchToolStripMenuItem1
        '
        Me.PatchToolStripMenuItem1.Name = "PatchToolStripMenuItem1"
        Me.PatchToolStripMenuItem1.Size = New System.Drawing.Size(284, 22)
        Me.PatchToolStripMenuItem1.Text = "Patch Revisi 10 Jan 2024"
        Me.PatchToolStripMenuItem1.Visible = False
        '
        'PatchPenjualanToolStripMenuItem
        '
        Me.PatchPenjualanToolStripMenuItem.Name = "PatchPenjualanToolStripMenuItem"
        Me.PatchPenjualanToolStripMenuItem.Size = New System.Drawing.Size(284, 22)
        Me.PatchPenjualanToolStripMenuItem.Text = "Patch Penjualan"
        Me.PatchPenjualanToolStripMenuItem.Visible = False
        '
        'PatchSupplierToolStripMenuItem
        '
        Me.PatchSupplierToolStripMenuItem.Enabled = False
        Me.PatchSupplierToolStripMenuItem.Name = "PatchSupplierToolStripMenuItem"
        Me.PatchSupplierToolStripMenuItem.Size = New System.Drawing.Size(284, 22)
        Me.PatchSupplierToolStripMenuItem.Text = "Patch Supplier"
        Me.PatchSupplierToolStripMenuItem.Visible = False
        '
        'PatchPembelianToolStripMenuItem
        '
        Me.PatchPembelianToolStripMenuItem.Enabled = False
        Me.PatchPembelianToolStripMenuItem.Name = "PatchPembelianToolStripMenuItem"
        Me.PatchPembelianToolStripMenuItem.Size = New System.Drawing.Size(284, 22)
        Me.PatchPembelianToolStripMenuItem.Text = "Patch Pembelian"
        Me.PatchPembelianToolStripMenuItem.Visible = False
        '
        'PatchGreyToolStripMenuItem
        '
        Me.PatchGreyToolStripMenuItem.Enabled = False
        Me.PatchGreyToolStripMenuItem.Name = "PatchGreyToolStripMenuItem"
        Me.PatchGreyToolStripMenuItem.Size = New System.Drawing.Size(284, 22)
        Me.PatchGreyToolStripMenuItem.Text = "Patch Grey"
        Me.PatchGreyToolStripMenuItem.Visible = False
        '
        'PatchOmsetToolStripMenuItem
        '
        Me.PatchOmsetToolStripMenuItem.Name = "PatchOmsetToolStripMenuItem"
        Me.PatchOmsetToolStripMenuItem.Size = New System.Drawing.Size(284, 22)
        Me.PatchOmsetToolStripMenuItem.Text = "Patch Omset"
        Me.PatchOmsetToolStripMenuItem.Visible = False
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Status1, Me.Status2})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 727)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Padding = New System.Windows.Forms.Padding(1, 0, 12, 0)
        Me.StatusStrip1.Size = New System.Drawing.Size(1244, 22)
        Me.StatusStrip1.TabIndex = 3
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'Status1
        '
        Me.Status1.Name = "Status1"
        Me.Status1.Size = New System.Drawing.Size(45, 17)
        Me.Status1.Text = "Status1"
        '
        'Status2
        '
        Me.Status2.Name = "Status2"
        Me.Status2.Size = New System.Drawing.Size(45, 17)
        Me.Status2.Text = "Status2"
        '
        'dgv1
        '
        Me.dgv1.AllowUserToAddRows = False
        Me.dgv1.AllowUserToDeleteRows = False
        Me.dgv1.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv1.DefaultCellStyle = DataGridViewCellStyle5
        Me.dgv1.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv1.Location = New System.Drawing.Point(13, 437)
        Me.dgv1.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv1.MultiSelect = False
        Me.dgv1.Name = "dgv1"
        Me.dgv1.ReadOnly = True
        Me.dgv1.Size = New System.Drawing.Size(601, 271)
        Me.dgv1.TabIndex = 24
        Me.dgv1.Visible = False
        '
        'panel_bukpot
        '
        Me.panel_bukpot.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.panel_bukpot.Controls.Add(Me.btn_refresh_bukpot)
        Me.panel_bukpot.Controls.Add(Me.txt_jumlah_bukpot)
        Me.panel_bukpot.Controls.Add(Me.Label1)
        Me.panel_bukpot.Controls.Add(Me.dtp_bukpot)
        Me.panel_bukpot.Controls.Add(Me.dgv_bukpot)
        Me.panel_bukpot.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.panel_bukpot.Location = New System.Drawing.Point(13, 40)
        Me.panel_bukpot.Name = "panel_bukpot"
        Me.panel_bukpot.Size = New System.Drawing.Size(730, 329)
        Me.panel_bukpot.TabIndex = 26
        Me.panel_bukpot.Visible = False
        '
        'btn_refresh_bukpot
        '
        Me.btn_refresh_bukpot.Location = New System.Drawing.Point(618, 18)
        Me.btn_refresh_bukpot.Name = "btn_refresh_bukpot"
        Me.btn_refresh_bukpot.Size = New System.Drawing.Size(95, 23)
        Me.btn_refresh_bukpot.TabIndex = 29
        Me.btn_refresh_bukpot.Text = "REFRESH"
        Me.btn_refresh_bukpot.UseVisualStyleBackColor = True
        '
        'txt_jumlah_bukpot
        '
        Me.txt_jumlah_bukpot.Location = New System.Drawing.Point(241, 18)
        Me.txt_jumlah_bukpot.Name = "txt_jumlah_bukpot"
        Me.txt_jumlah_bukpot.ReadOnly = True
        Me.txt_jumlah_bukpot.Size = New System.Drawing.Size(62, 22)
        Me.txt_jumlah_bukpot.TabIndex = 27
        Me.txt_jumlah_bukpot.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(18, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(219, 14)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "Jumlah Faktur Belum Bukti Potong"
        '
        'dtp_bukpot
        '
        Me.dtp_bukpot.Location = New System.Drawing.Point(332, 18)
        Me.dtp_bukpot.Name = "dtp_bukpot"
        Me.dtp_bukpot.Size = New System.Drawing.Size(150, 22)
        Me.dtp_bukpot.TabIndex = 0
        Me.dtp_bukpot.Visible = False
        '
        'dgv_bukpot
        '
        Me.dgv_bukpot.AllowUserToAddRows = False
        Me.dgv_bukpot.AllowUserToDeleteRows = False
        Me.dgv_bukpot.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_bukpot.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_bukpot.DefaultCellStyle = DataGridViewCellStyle6
        Me.dgv_bukpot.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgv_bukpot.Location = New System.Drawing.Point(18, 47)
        Me.dgv_bukpot.Margin = New System.Windows.Forms.Padding(4)
        Me.dgv_bukpot.MultiSelect = False
        Me.dgv_bukpot.Name = "dgv_bukpot"
        Me.dgv_bukpot.ReadOnly = True
        Me.dgv_bukpot.Size = New System.Drawing.Size(695, 264)
        Me.dgv_bukpot.TabIndex = 25
        '
        'btn_hitung_bukpot
        '
        Me.btn_hitung_bukpot.Location = New System.Drawing.Point(12, 375)
        Me.btn_hitung_bukpot.Name = "btn_hitung_bukpot"
        Me.btn_hitung_bukpot.Size = New System.Drawing.Size(125, 23)
        Me.btn_hitung_bukpot.TabIndex = 28
        Me.btn_hitung_bukpot.Text = "Hitung Bukpot"
        Me.btn_hitung_bukpot.UseVisualStyleBackColor = True
        Me.btn_hitung_bukpot.Visible = False
        '
        'form_menu_utama
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1244, 749)
        Me.Controls.Add(Me.btn_hitung_bukpot)
        Me.Controls.Add(Me.panel_bukpot)
        Me.Controls.Add(Me.dgv1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.IsMdiContainer = True
        Me.Name = "form_menu_utama"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "AML Akunting v.1.2.1"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panel_bukpot.ResumeLayout(False)
        Me.panel_bukpot.PerformLayout()
        CType(Me.dgv_bukpot, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents SISTEMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LOGINToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LOGOUTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PenggunaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents KELUARToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents Status1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Status2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents DatabaseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents JenisBiayaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NamaSpecsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SupplierToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PPNPPh23ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PembelianToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DataPembelianToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UploadPembelianToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExportUploadPembelianToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CariNamaBarangSpecsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CLIENTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PenjualanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DataPenjualanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InputPenjualanCelupToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GreyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DataGreyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InputNamaHargaJualGreyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatchToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatchPembelianToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatchGreyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InputPenjualanKainToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatchPenjualanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatchSupplierToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OmsetPenjualanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GenerateSuratJalanDanFakturToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NeracaGreyBaruToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatchOmsetToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExportUploadPenjualanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UploadPenjualanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents dgv1 As System.Windows.Forms.DataGridView
    Friend WithEvents PatchToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatchBukpotToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents panel_bukpot As System.Windows.Forms.Panel
    Friend WithEvents txt_jumlah_bukpot As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents dgv_bukpot As System.Windows.Forms.DataGridView
    Friend WithEvents dtp_bukpot As System.Windows.Forms.DateTimePicker
    Friend WithEvents btn_hitung_bukpot As System.Windows.Forms.Button
    Friend WithEvents btn_refresh_bukpot As System.Windows.Forms.Button
    Friend WithEvents BuktiPotongToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatchPPNPPHV121ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatchPenyusutanV121ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LaporanKeuanganToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SPTMasaPPNEfakturToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PenyusutanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpahHarianUpahHarianToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatchSPTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
