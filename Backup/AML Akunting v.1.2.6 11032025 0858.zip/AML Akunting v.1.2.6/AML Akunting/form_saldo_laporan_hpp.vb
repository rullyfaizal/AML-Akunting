﻿Imports MySql.Data.MySqlClient

Public Class form_saldo_laporan_hpp

    Private Sub form_saldo_laporan_hpp_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call tampil_data()
        btn_simpan.Focus()
    End Sub

    Private Sub tampil_data()
        Try
            Using conx As New MySqlConnection(sLocalConn)
                conx.Open()
                Dim selectedYear As Integer = dtp_tahun.Value.Year
                Dim sqlx As String = "SELECT tahun, awal_tahun_obat, akhir_tahun_obat, awal_kain_proses, akhir_kain_proses, awal_kain_warna, akhir_kain_warna " &
                                     "FROM tblaphpp " &
                                     "WHERE tahun = @selectedYear"

                Using cmdx As New MySqlCommand(sqlx, conx)
                    cmdx.Parameters.AddWithValue("@selectedYear", selectedYear)
                    Using reader As MySqlDataReader = cmdx.ExecuteReader()
                        ' Membuat DataTable
                        Dim dt As New DataTable()
                        dt.Columns.Add("TAHUN", GetType(String))
                        dt.Columns.Add(selectedYear.ToString(), GetType(Decimal)) ' Ubah ke Decimal agar bisa diformat

                        ' Menambahkan data default jika tidak ada hasil
                        Dim dataExist As Boolean = False

                        If reader.Read() Then
                            dataExist = True
                            dt.Rows.Add("SALDO AWAL TAHUN OBAT", If(IsDBNull(reader("awal_tahun_obat")), 0D, Convert.ToDecimal(reader("awal_tahun_obat"))))
                            dt.Rows.Add("SALDO AKHIR TAHUN OBAT", If(IsDBNull(reader("akhir_tahun_obat")), 0D, Convert.ToDecimal(reader("akhir_tahun_obat"))))
                            dt.Rows.Add("SALDO AWAL KAIN PROSES", If(IsDBNull(reader("awal_kain_proses")), 0D, Convert.ToDecimal(reader("awal_kain_proses"))))
                            dt.Rows.Add("SALDO AKHIR KAIN PROSES", If(IsDBNull(reader("akhir_kain_proses")), 0D, Convert.ToDecimal(reader("akhir_kain_proses"))))
                            dt.Rows.Add("SALDO AWAL KAIN WARNA", If(IsDBNull(reader("awal_kain_warna")), 0D, Convert.ToDecimal(reader("awal_kain_warna"))))
                            dt.Rows.Add("SALDO AKHIR KAIN WARNA", If(IsDBNull(reader("akhir_kain_warna")), 0D, Convert.ToDecimal(reader("akhir_kain_warna"))))
                        End If

                        ' Jika data tidak ditemukan, tambahkan baris dengan nilai default 0D
                        If Not dataExist Then
                            dt.Rows.Add("SALDO AWAL TAHUN OBAT", 0D)
                            dt.Rows.Add("SALDO AKHIR TAHUN OBAT", 0D)
                            dt.Rows.Add("SALDO AWAL KAIN PROSES", 0D)
                            dt.Rows.Add("SALDO AKHIR KAIN PROSES", 0D)
                            dt.Rows.Add("SALDO AWAL KAIN WARNA", 0D)
                            dt.Rows.Add("SALDO AKHIR KAIN WARNA", 0D)
                        End If

                        ' Menampilkan data di DataGridView
                        dgv1.DataSource = dt

                        ' Atur tampilan DataGridView
                        dgv1.Columns(0).Width = 200
                        dgv1.Columns(1).Width = 175
                        dgv1.Columns(0).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                        dgv1.Columns(1).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                        dgv1.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                        dgv1.Columns(1).DefaultCellStyle.Format = "#,##0.00" ' Pastikan format tetap

                        'txt_upah_harian.Text = FormatNumber(Convert.ToDecimal(dgv1.Rows(0).Cells(1).Value), 2)
                        'txt_gaji_pegawai.Text = FormatNumber(Convert.ToDecimal(dgv1.Rows(1).Cells(1).Value), 2)
                        'txt_sewa_pabrik.Text = FormatNumber(Convert.ToDecimal(dgv1.Rows(2).Cells(1).Value), 2)
                        'txt_sewa_kantor.Text = FormatNumber(Convert.ToDecimal(dgv1.Rows(3).Cells(1).Value), 2)
                        'txt_pbb.Text = FormatNumber(Convert.ToDecimal(dgv1.Rows(4).Cells(1).Value), 2)

                    End Using
                End Using
            End Using
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class